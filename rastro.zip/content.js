(() => {
  // src/shared/util.ts
  function looksGenerated(s) {
    return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/content/overlay.ts
  var CSS2 = `
:host { all: initial; }
.box {
  position: fixed; pointer-events: none; z-index: 2147483646; display: none;
  border: 2px solid var(--c, #7c5cff); background: color-mix(in srgb, var(--c, #7c5cff) 12%, transparent);
  border-radius: 4px; transition: all 60ms ease-out; box-sizing: border-box;
}
.tag {
  position: fixed; pointer-events: none; z-index: 2147483647; display: none;
  font: 600 11px/1.2 ui-sans-serif, system-ui, sans-serif; color: #fff; background: var(--c, #7c5cff);
  padding: 4px 7px; border-radius: 5px; white-space: nowrap; max-width: 360px; overflow: hidden; text-overflow: ellipsis;
  box-shadow: 0 2px 8px rgb(0 0 0 / .25);
}
.pill {
  position: fixed; z-index: 2147483647; left: 50%; bottom: 18px; transform: translateX(-50%);
  display: none; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px;
  font: 600 12px/1 ui-sans-serif, system-ui, sans-serif; color: #f4f2ff; background: #1b1830ee;
  box-shadow: 0 6px 24px rgb(0 0 0 / .35); backdrop-filter: blur(6px); user-select: none;
}
.dot { width: 9px; height: 9px; border-radius: 50%; background: #ff4d6d; animation: pulse 1.2s infinite; }
.pill.point .dot { background: #7c5cff; }
@keyframes pulse { 50% { opacity: .35; } }
.pill button {
  all: unset; cursor: pointer; padding: 5px 10px; border-radius: 999px; background: #ffffff1f; color: #fff;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
}
.pill button:hover { background: #ffffff38; }
.toasts { position: fixed; z-index: 2147483647; right: 16px; bottom: 64px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; pointer-events: none; }
.toast {
  font: 500 12px/1.3 ui-sans-serif, system-ui, sans-serif; color: #fff; background: #1b1830ee; padding: 7px 11px;
  border-radius: 8px; border-left: 3px solid var(--c, #7c5cff); box-shadow: 0 4px 14px rgb(0 0 0 / .3);
  animation: in .18s ease-out; max-width: 340px;
}
.toast.warn { --c: #ffb020; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } }
`;
  var COLORS = { click: "#7c5cff", fill: "#14b8a6", select: "#0ea5e9", check: "#22c55e", file: "#ffb020", run: "#f97316" };

  class Overlay {
    host;
    box;
    tag;
    pill;
    pillText;
    toasts;
    onStop = () => {};
    ensure() {
      if (this.host?.isConnected)
        return;
      this.host = document.createElement("div");
      this.host.id = "__rastro_host";
      const root = this.host.attachShadow({ mode: "open" });
      root.innerHTML = `<style>${CSS2}</style><div class="box"></div><div class="tag"></div>
      <div class="pill"><span class="dot"></span><span class="txt"></span><button type="button">Terminar</button></div>
      <div class="toasts"></div>`;
      this.box = root.querySelector(".box");
      this.tag = root.querySelector(".tag");
      this.pill = root.querySelector(".pill");
      this.pillText = root.querySelector(".txt");
      this.toasts = root.querySelector(".toasts");
      root.querySelector("button").addEventListener("click", (e) => {
        e.stopPropagation();
        this.onStop();
      });
      document.documentElement.appendChild(this.host);
    }
    owns(el) {
      return !!this.host && el instanceof Node && (el === this.host || this.host.contains(el));
    }
    show(el, text, color = COLORS.click) {
      this.ensure();
      const r = el.getBoundingClientRect();
      Object.assign(this.box.style, {
        display: "block",
        left: `${r.left - 3}px`,
        top: `${r.top - 3}px`,
        width: `${r.width + 6}px`,
        height: `${r.height + 6}px`
      });
      this.box.style.setProperty("--c", color);
      this.tag.style.setProperty("--c", color);
      this.tag.textContent = text;
      this.tag.style.display = "block";
      const above = r.top > 30;
      this.tag.style.left = `${Math.max(4, Math.min(r.left - 3, innerWidth - 370))}px`;
      this.tag.style.top = above ? `${r.top - 27}px` : `${r.bottom + 6}px`;
    }
    hide() {
      if (!this.box)
        return;
      this.box.style.display = "none";
      this.tag.style.display = "none";
    }
    flash(el, text, ms = 700, color = COLORS.run) {
      this.show(el, text, color);
      setTimeout(() => this.hide(), ms);
    }
    setPill(mode) {
      this.ensure();
      if (!mode) {
        this.pill.style.display = "none";
        return;
      }
      this.pill.className = "pill " + mode;
      this.pillText.textContent = mode === "record" ? "Rastro grabando" : "Rastro · modo señalar (Esc para salir)";
      this.pill.style.display = "flex";
    }
    toast(text, color, warn = false) {
      this.ensure();
      const t = document.createElement("div");
      t.className = "toast" + (warn ? " warn" : "");
      if (color)
        t.style.setProperty("--c", color);
      t.textContent = text;
      this.toasts.appendChild(t);
      setTimeout(() => t.remove(), 2200);
      while (this.toasts.children.length > 4)
        this.toasts.firstElementChild.remove();
    }
  }
  var overlay = new Overlay;

  // src/content/selector.ts
  var TEST_ATTRS = ["data-testid", "data-test-id", "data-test", "data-cy", "data-qa", "data-e2e", "data-automation-id"];
  var CLICKABLE = 'button, a[href], [role="button"], [role="link"], [role="menuitem"], [role="tab"], [role="option"], ' + '[role="checkbox"], [role="radio"], [role="switch"], input[type="submit"], input[type="button"], ' + 'input[type="reset"], input[type="image"], summary, label, [onclick]';
  var CONTROL = 'input, textarea, select, [contenteditable]:not([contenteditable="false"])';
  var norm = (s) => (s ?? "").replace(/\s+/g, " ").trim();
  var STATE_CLASSES = /^(is-|has-)?(active|focus(ed)?|hover(ed)?|selected|open(ed)?|disabled|checked|visible|hidden|show|in|ng-.*)$/i;
  var STATE_WORDS = new Set([
    "active",
    "focus",
    "focused",
    "focusvisible",
    "focuswithin",
    "hover",
    "hovered",
    "hovering",
    "highlight",
    "highlighted",
    "selected",
    "current",
    "open",
    "opened",
    "expanded",
    "collapsed",
    "pressed",
    "disabled",
    "checked",
    "visible",
    "hidden",
    "shown",
    "enter",
    "entering",
    "leave",
    "leaving",
    "touched",
    "dirty",
    "pristine",
    "valid",
    "invalid",
    "error"
  ]);
  function isStateClass(c) {
    if (STATE_CLASSES.test(c))
      return true;
    const words = c.split(/[-_]+|(?<=[a-z])(?=[A-Z])/).filter(Boolean);
    return words.length > 1 && STATE_WORDS.has(words.at(-1).toLowerCase());
  }
  var volatile = new Set;
  var classObserver = null;
  function noteClassChanges(records) {
    for (const r of records) {
      const before = new Set((r.oldValue ?? "").split(/\s+/).filter(Boolean));
      const after = r.target.classList;
      for (const c of after)
        if (!before.has(c))
          volatile.add(c);
      for (const c of before)
        if (!after.contains(c))
          volatile.add(c);
    }
  }
  function trackVolatileClasses(on) {
    if (on && !classObserver) {
      classObserver = new MutationObserver(noteClassChanges);
      classObserver.observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ["class"], attributeOldValue: true });
    } else if (!on && classObserver) {
      noteClassChanges(classObserver.takeRecords());
      classObserver.disconnect();
      classObserver = null;
    }
  }
  function stableClasses(el) {
    if (classObserver)
      noteClassChanges(classObserver.takeRecords());
    return [...el.classList].filter((c) => !looksGenerated(c) && !isStateClass(c) && !volatile.has(c) && !c.includes(":") && c.length < 32);
  }
  var q = (v) => JSON.stringify(v);
  function isVisible(el) {
    if (!el.isConnected)
      return false;
    if (el.getClientRects().length === 0)
      return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.opacity !== "0";
  }
  function textOf(el) {
    if (el instanceof HTMLInputElement && ["submit", "button", "reset"].includes(el.type))
      return norm(el.value);
    return norm(el.innerText ?? el.textContent);
  }
  function* allElements(root = document) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let n = walker.nextNode();
    while (n) {
      yield n;
      const sr = n.shadowRoot;
      if (sr)
        yield* allElements(sr);
      n = walker.nextNode();
    }
  }
  function byText(text) {
    const target = norm(text);
    const exact = [];
    const partial = [];
    const lower = target.toLowerCase();
    for (const el of allElements()) {
      if (el.closest("script, style, noscript, template, #__rastro_host"))
        continue;
      const limit = target.length * 3 + 20;
      if (!(el instanceof HTMLInputElement) && norm(el.textContent).length > limit)
        continue;
      const t = textOf(el);
      if (!t || t.length > limit)
        continue;
      if (t === target)
        exact.push(el);
      else if (t.toLowerCase().includes(lower))
        partial.push(el);
    }
    const pick = exact.length ? exact : partial;
    const deepest = pick.filter((el) => !pick.some((o) => o !== el && el.contains(o)));
    return dedupe(deepest.map((el) => el.closest(CLICKABLE) ?? el));
  }
  function byLabel(text) {
    const target = norm(text).toLowerCase();
    const out = [];
    for (const label of document.querySelectorAll("label")) {
      if (norm(label.innerText).toLowerCase().replace(/\s*\*$/, "") === target && label.control)
        out.push(label.control);
    }
    for (const el of document.querySelectorAll(CONTROL + ", [aria-label], [aria-labelledby]")) {
      if (norm(el.getAttribute("aria-label")).toLowerCase() === target)
        out.push(el);
      const lb = el.getAttribute("aria-labelledby");
      if (lb) {
        const t = lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" ");
        if (norm(t).toLowerCase() === target)
          out.push(el);
      }
    }
    if (!out.length) {
      for (const el of document.querySelectorAll("[placeholder]")) {
        if (norm(el.getAttribute("placeholder")).toLowerCase() === target)
          out.push(el);
      }
    }
    return dedupe(out);
  }
  function byXPath(xp) {
    const res = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const out = [];
    for (let i = 0;i < res.snapshotLength; i++) {
      const n = res.snapshotItem(i);
      if (n instanceof Element)
        out.push(n);
    }
    return out;
  }
  function dedupe(arr) {
    return [...new Set(arr)];
  }
  function resolveAll(selector) {
    try {
      if (selector.startsWith("text="))
        return byText(unquote(selector.slice(5)));
      if (selector.startsWith("label="))
        return byLabel(unquote(selector.slice(6)));
      if (selector.startsWith("xpath="))
        return byXPath(selector.slice(6));
      if (selector.startsWith("frame=")) {
        const f = document.querySelectorAll("iframe, frame")[Number(selector.slice(6))];
        return f ? [f] : [];
      }
      return [...document.querySelectorAll(selector)];
    } catch {
      return [];
    }
  }
  function unquote(s) {
    const t = s.trim();
    if (t.startsWith('"') && t.endsWith('"') || t.startsWith("'") && t.endsWith("'"))
      return t.slice(1, -1);
    return t;
  }
  function resolve(selectors) {
    for (const sel of selectors) {
      const found = resolveAll(sel);
      if (found.length === 1)
        return { el: found[0], selector: sel };
      const vis = found.filter(isVisible);
      if (vis.length >= 1)
        return { el: vis[0], selector: sel };
      if (found.length)
        return { el: found[0], selector: sel };
    }
    return null;
  }
  function isUnique(sel, el) {
    const r = resolveAll(sel);
    return r.length === 1 && r[0] === el;
  }
  function cssPath(el) {
    const parts = [];
    let cur = el;
    while (cur && cur !== document.documentElement) {
      const tag = cur.tagName.toLowerCase();
      if (cur !== el && cur.id && !looksGenerated(cur.id)) {
        parts.unshift("#" + CSS.escape(cur.id));
        const s = parts.join(" > ");
        if (isUnique(s, el))
          return s;
        parts.shift();
      }
      let seg = tag;
      const cls = stableClasses(cur).slice(0, 2);
      if (cls.length)
        seg += "." + cls.map((c) => CSS.escape(c)).join(".");
      const withoutNth = [seg, ...parts].join(" > ");
      if (isUnique(withoutNth, el))
        return withoutNth;
      const parent = cur.parentElement;
      if (parent) {
        const same = [...parent.children].filter((c) => c.tagName === cur.tagName);
        if (same.length > 1)
          seg += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(seg);
      const s = parts.join(" > ");
      if (isUnique(s, el))
        return s;
      cur = parent;
    }
    return parts.join(" > ");
  }
  function buildSelectors(el) {
    const tag = el.tagName.toLowerCase();
    const c = [];
    for (const a of TEST_ATTRS) {
      const v = el.getAttribute(a);
      if (v)
        c.push(`[${a}=${q(v)}]`);
    }
    if (el.id && !looksGenerated(el.id))
      c.push("#" + CSS.escape(el.id));
    const name = el.getAttribute("name");
    if (name) {
      if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.value && el.value !== "on") {
        c.push(`${tag}[name=${q(name)}][value=${q(el.value)}]`);
      } else
        c.push(`${tag}[name=${q(name)}]`);
    }
    const isControl = el.matches(CONTROL);
    if (isControl) {
      const lbl = labelText(el);
      if (lbl && lbl.length <= 60)
        c.push(`label=${lbl}`);
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      c.push(`${tag}[aria-label=${q(aria)}]`);
    const ph = el.getAttribute("placeholder");
    if (ph)
      c.push(`${tag}[placeholder=${q(ph)}]`);
    if (!isControl) {
      const t = textOf(el);
      if (t && t.length <= 50 && !el.querySelector(CONTROL))
        c.push(`text=${t}`);
    }
    if (el instanceof HTMLAnchorElement) {
      const href = el.getAttribute("href");
      if (href && href.length < 80 && !href.startsWith("javascript:") && href !== "#")
        c.push(`a[href=${q(href)}]`);
    }
    if (el instanceof HTMLIFrameElement || el instanceof HTMLFrameElement) {
      const src = el.getAttribute("src");
      if (src && !src.startsWith("data:") && !src.startsWith("javascript:")) {
        const base = src.split(/[?#]/)[0];
        c.push(base === src ? `${tag}[src=${q(src)}]` : `${tag}[src^=${q(base)}]`);
      }
    }
    const title = el.getAttribute("title");
    if (title)
      c.push(`${tag}[title=${q(title)}]`);
    const sameTarget = (s) => {
      const isText = s.startsWith("text=");
      const hit = (x) => x === el || isText && el.contains(x) && textOf(x) === textOf(el);
      const r = resolveAll(s);
      if (r.length === 1)
        return hit(r[0]);
      if (!isText)
        return false;
      const vis = r.filter(isVisible);
      return vis.length === 1 && hit(vis[0]);
    };
    const unique = dedupe(c).filter(sameTarget);
    unique.push(cssPath(el));
    return dedupe(unique).slice(0, 5);
  }
  function labelText(el) {
    if (el.labels?.length) {
      const t = norm(el.labels[0].innerText).replace(/\s*\*$/, "");
      if (t)
        return t;
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      return norm(aria);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = norm(lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" "));
      if (t)
        return t;
    }
    return "";
  }
  function describe(el) {
    if (el.matches(CONTROL)) {
      return (labelText(el) || el.getAttribute("placeholder") || el.getAttribute("name") || el.id || el.getAttribute("title") || el.tagName.toLowerCase()).slice(0, 60);
    }
    const t = textOf(el);
    if (t)
      return t.length > 50 ? t.slice(0, 47) + "…" : t;
    return (el.getAttribute("aria-label") || el.getAttribute("title") || el.querySelector("img")?.getAttribute("alt") || el.getAttribute("name") || el.tagName.toLowerCase()).slice(0, 60);
  }
  function actionable(target) {
    const ctrl = target.closest(CONTROL);
    if (ctrl)
      return ctrl;
    const clickable = target.closest(CLICKABLE);
    if (clickable instanceof HTMLLabelElement && clickable.control)
      return clickable.control;
    return clickable ?? target;
  }
  var TEXTLIKE = new Set([
    "",
    "text",
    "email",
    "password",
    "search",
    "tel",
    "url",
    "number",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "color",
    "range"
  ]);
  function kindOf(el) {
    if (el instanceof HTMLSelectElement)
      return "select";
    if (el instanceof HTMLTextAreaElement)
      return el.readOnly ? "click" : "fill";
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio")
        return "check";
      if (el.type === "file")
        return "file";
      if (TEXTLIKE.has(el.type))
        return el.readOnly ? "click" : "fill";
      return "click";
    }
    if (el.isContentEditable)
      return "fill";
    const role = el.getAttribute("role");
    if (role === "checkbox" || role === "switch")
      return "check";
    return "click";
  }
  function valueOf(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)
      return el.value;
    return norm(el.innerText);
  }
  function checkedOf(el) {
    if (el instanceof HTMLInputElement)
      return el.checked;
    return el.getAttribute("aria-checked") === "true";
  }

  // src/content/player.ts
  class StepError extends Error {
  }
  async function find(step, timeout, requireVisible) {
    const selectors = [step.selector, ...step.fallbacks ?? []].filter(Boolean);
    if (!selectors.length)
      throw new StepError("El paso no tiene selector");
    const start = performance.now();
    let hiddenSince = 0;
    while (true) {
      const r = resolve(selectors);
      if (r) {
        if (isVisible(r.el))
          return r;
        if (!requireVisible) {
          hiddenSince ||= performance.now();
          if (performance.now() - hiddenSince > 1000)
            return r;
        }
      }
      if (performance.now() - start > timeout) {
        if (r)
          throw new StepError(`El elemento «${step.label ?? selectors[0]}» existe pero no es visible`);
        throw new StepError(`No se encontró «${step.label ?? selectors[0]}» (${selectors[0]})`);
      }
      await sleep(100);
    }
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }
  async function scrollTo(el) {
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      await sleep(50);
    }
  }
  function mouse(target, type, x, y) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + screenX,
      screenY: y + screenY,
      button: 0,
      buttons: type.endsWith("down") ? 1 : 0,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };
    const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
    return target.dispatchEvent(new Ctor(type, init));
  }
  async function realClick(el) {
    await scrollTo(el);
    const { x, y } = center(el);
    const top = document.elementFromPoint(x, y);
    const target = top && el.contains(top) ? top : el;
    mouse(target, "pointerover", x, y);
    mouse(target, "mouseover", x, y);
    mouse(target, "pointermove", x, y);
    mouse(target, "mousemove", x, y);
    const down = mouse(target, "pointerdown", x, y) && mouse(target, "mousedown", x, y);
    if (down && el instanceof HTMLElement && el.tabIndex >= -1)
      el.focus({ preventScroll: true });
    mouse(target, "pointerup", x, y);
    mouse(target, "mouseup", x, y);
    mouse(target, "click", x, y);
  }
  var NO_TYPING = new Set(["date", "datetime-local", "month", "week", "time", "color", "range"]);
  function setNative(el, v) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  }
  function fireInput(el, data, inputType = "insertText") {
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, data, inputType }));
  }
  function key(el, type, k) {
    return el.dispatchEvent(new KeyboardEvent(type, { key: k, code: codeFor(k), bubbles: true, cancelable: true, composed: true }));
  }
  function codeFor(k) {
    if (k.length === 1) {
      if (/[a-z]/i.test(k))
        return "Key" + k.toUpperCase();
      if (/\d/.test(k))
        return "Digit" + k;
      if (k === " ")
        return "Space";
      return "";
    }
    return k;
  }
  function selectAll(el) {
    try {
      el.select();
    } catch {}
  }
  async function typeInto(el, value, s) {
    await scrollTo(el);
    el.focus({ preventScroll: true });
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      if (value)
        document.execCommand("insertText", false, value);
      else
        document.execCommand("delete");
      if (textOf(el) !== value.replace(/\s+/g, " ").trim()) {
        el.textContent = value;
        fireInput(el, value);
      }
      return;
    }
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement))
      throw new StepError("El elemento no es editable");
    if (el.disabled)
      throw new StepError(`«${el.name || el.id}» está deshabilitado`);
    const typeable = !(el instanceof HTMLInputElement && NO_TYPING.has(el.type));
    if (!typeable || s.typeMode === "instant") {
      selectAll(el);
      const ok = typeable && (value ? document.execCommand("insertText", false, value) : document.execCommand("delete"));
      if (!ok || el.value !== value) {
        setNative(el, value);
        fireInput(el, value);
      }
    } else {
      selectAll(el);
      if (!document.execCommand("delete") || el.value !== "") {
        setNative(el, "");
        fireInput(el, null, "deleteContentBackward");
      }
      for (const ch of value) {
        const allowed = key(el, "keydown", ch);
        key(el, "keypress", ch);
        if (allowed) {
          const before = el.value;
          if (!document.execCommand("insertText", false, ch) || el.value === before) {
            setNative(el, before + ch);
            fireInput(el, ch);
          }
        }
        key(el, "keyup", ch);
        if (s.keyDelay)
          await sleep(s.keyDelay);
      }
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectOption(el, value, optionText) {
    if (!(el instanceof HTMLSelectElement))
      throw new StepError("El elemento no es un <select>");
    const opts = [...el.options];
    const opt = opts.find((o) => o.value === value) ?? (optionText ? opts.find((o) => o.text.trim() === optionText) : undefined) ?? opts.find((o) => o.text.trim() === value) ?? opts.find((o) => o.text.trim().toLowerCase().includes(value.toLowerCase()));
    if (!opt)
      throw new StepError(`El select no tiene la opción «${optionText ?? value}»`);
    el.focus();
    el.value = opt.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function setChecked(el, want) {
    if (checkedOf(el) === want)
      return;
    if (el instanceof HTMLInputElement && el.type === "radio" && !want) {
      throw new StepError("Un radio no se puede desmarcar; marca otra opción del grupo");
    }
    if (isVisible(el))
      await realClick(el);
    else if (el instanceof HTMLInputElement && el.labels?.[0] && isVisible(el.labels[0]))
      await realClick(el.labels[0]);
    else
      el.click();
    if (checkedOf(el) !== want && el instanceof HTMLInputElement) {
      el.checked = want;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  var FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"]), [contenteditable]:not([contenteditable="false"])';
  async function press(el, k) {
    const down = key(el, "keydown", k);
    if (k === "Enter")
      key(el, "keypress", k);
    if (down) {
      if (k === "Enter") {
        if (el instanceof HTMLInputElement && el.form) {
          const btn = el.form.querySelector('button[type="submit"], button:not([type]), input[type="submit"], input[type="image"]');
          if (btn)
            await realClick(btn);
          else
            el.form.requestSubmit();
        } else if (el instanceof HTMLButtonElement || el instanceof HTMLAnchorElement) {
          el.click();
        }
      } else if (k === "Tab") {
        const all = [...document.querySelectorAll(FOCUSABLE)].filter((e) => isVisible(e) && !e.disabled);
        const i = all.indexOf(el);
        all[(i + 1) % all.length]?.focus();
      }
    }
    key(el, "keyup", k);
  }
  function mayNavigate(el) {
    if (el.closest("a[href]"))
      return true;
    const btn = el.closest("button, input");
    if (btn instanceof HTMLButtonElement)
      return !!btn.form && btn.type === "submit";
    if (btn instanceof HTMLInputElement)
      return !!btn.form && (["submit", "image"].includes(btn.type) || kindOf(btn) === "fill");
    return false;
  }
  async function runStep(step, s) {
    const timeout = step.timeout ?? s.timeout;
    let nav = false;
    try {
      let used;
      const target = async (visible = true) => {
        const r = await find(step, timeout, visible);
        used = r.selector;
        if (s.highlight)
          overlay.flash(r.el, step.label ?? step.type, Math.max(400, s.stepDelay + 200), COLORS.run);
        return r.el;
      };
      switch (step.type) {
        case "click": {
          const el = await target();
          nav = mayNavigate(el);
          await realClick(el);
          break;
        }
        case "fill": {
          const el = await target(false);
          if (el instanceof HTMLSelectElement)
            selectOption(el, step.value ?? "");
          else if (kindOf(el) === "check")
            await setChecked(el, !["", "false", "off", "0"].includes(step.value ?? ""));
          else
            await typeInto(el, step.value ?? "", s);
          break;
        }
        case "select":
          selectOption(await target(false), step.value ?? "", step.optionText);
          break;
        case "check":
          await setChecked(await target(false), step.value !== "false");
          break;
        case "press": {
          const el = step.selector ? await target(false) : document.activeElement ?? document.body;
          nav = (step.value || "Enter") === "Enter" && mayNavigate(el);
          await press(el, step.value || "Enter");
          break;
        }
        case "waitFor":
          await target();
          break;
        case "assertText": {
          const el = await target(false);
          const want = (step.value ?? "").trim();
          const start = performance.now();
          let have = "";
          while (true) {
            have = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement ? valueOf(el) : textOf(el);
            if (have.includes(want))
              break;
            if (performance.now() - start > timeout)
              throw new StepError(`Se esperaba «${want}» y hay «${have.slice(0, 80)}»`);
            await sleep(150);
          }
          break;
        }
        default:
          throw new StepError(`Tipo de paso «${step.type}» no se ejecuta en la página`);
      }
      return { ok: true, usedSelector: used, mayNavigate: nav };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }
  async function highlight(selectors) {
    const r = resolve(selectors);
    if (!r)
      return false;
    await scrollTo(r.el);
    overlay.flash(r.el, r.selector, 1500, COLORS.click);
    return true;
  }

  // src/content/recorder.ts
  var mode = null;
  var send = () => {};
  var pendingFill = new Map;
  var VERB = { click: "Click", fill: "Escribir", select: "Seleccionar", check: "Marcar", file: "Fichero" };
  function capture(el) {
    const kind = kindOf(el);
    if (kind === "file")
      return null;
    const [selector, ...fallbacks] = buildSelectors(el);
    const base = { selector, fallbacks, label: describe(el) };
    switch (kind) {
      case "fill":
        return { ...base, type: "fill", value: valueOf(el), secret: el.type === "password" || undefined };
      case "select": {
        const s = el;
        return { ...base, type: "select", value: s.value, optionText: s.selectedOptions[0]?.text.trim() };
      }
      case "check":
        return { ...base, type: "check", value: String(checkedOf(el)) };
      default:
        return { ...base, type: "click" };
    }
  }
  function emit(el, step) {
    if (!step)
      return;
    send(step);
    const what = step.type === "fill" ? step.secret ? "••••" : `«${(step.value ?? "").slice(0, 30)}»` : "";
    overlay.toast(`✓ ${VERB[step.type] ?? step.type}: ${step.label} ${what}`.trim(), COLORS[kindOf(el)]);
  }
  function flushFills() {
    for (const [el, t] of pendingFill) {
      clearTimeout(t);
      send(capture(el));
    }
    pendingFill.clear();
  }
  function scheduleFill(el) {
    clearTimeout(pendingFill.get(el));
    pendingFill.set(el, setTimeout(() => {
      pendingFill.delete(el);
      const s = capture(el);
      if (s)
        send(s);
    }, 350));
  }
  var targetOf = (e) => {
    const t = e.composedPath()[0];
    return t instanceof Element ? t : null;
  };
  function onMove(e) {
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    const el = actionable(t);
    const k = kindOf(el);
    const hint = k === "file" ? "Fichero (no automatizable)" : `${VERB[k]} · ${describe(el)}`;
    overlay.show(el, hint, COLORS[k]);
  }
  function blockInPoint(e) {
    if (mode !== "point" || !e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    if (kindOf(actionable(t)) === "click") {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  function onClick(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    blockInPoint(e);
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "file")
      return overlay.toast("Los inputs de fichero no se pueden automatizar", undefined, true);
    if (k === "check" || k === "select")
      return;
    flushFills();
    if (k === "fill") {
      if (valueOf(el))
        emit(el, capture(el));
      return;
    }
    emit(el, capture(el));
  }
  function onInput(e) {
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    if (kindOf(el) === "fill")
      scheduleFill(el);
  }
  function onChange(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "fill") {
      clearTimeout(pendingFill.get(el));
      pendingFill.delete(el);
      send(capture(el));
    } else if (k === "select" || k === "check") {
      flushFills();
      emit(el, capture(el));
    }
  }
  function onKey(e) {
    if (!e.isTrusted)
      return;
    if (mode === "point" && e.key === "Escape") {
      e.preventDefault();
      stopHandler();
      return;
    }
    const t = targetOf(e);
    if (!t)
      return;
    if (e.key === "Enter" && t instanceof HTMLInputElement && kindOf(t) === "fill") {
      flushFills();
      send({ type: "press", value: "Enter", selector: buildSelectors(t)[0], label: describe(t) });
      overlay.toast(`✓ Tecla: Enter en ${describe(t)}`);
    }
  }
  function onLeave() {
    flushFills();
  }
  var onScroll = () => overlay.hide();
  var stopHandler = () => {};
  var listeners = [
    ["mousemove", onMove],
    ["pointerdown", blockInPoint],
    ["mousedown", blockInPoint],
    ["pointerup", blockInPoint],
    ["mouseup", blockInPoint],
    ["click", onClick],
    ["input", onInput],
    ["change", onChange],
    ["keydown", onKey]
  ];
  function startRecording(m, sink, onStop) {
    if (mode)
      stopRecording();
    mode = m;
    send = sink;
    stopHandler = onStop;
    overlay.onStop = onStop;
    trackVolatileClasses(true);
    for (const [ev, fn] of listeners)
      window.addEventListener(ev, fn, true);
    window.addEventListener("pagehide", onLeave);
    window.addEventListener("scroll", onScroll, true);
    if (window === window.top)
      overlay.setPill(m);
  }
  function stopRecording() {
    flushFills();
    for (const [ev, fn] of listeners)
      window.removeEventListener(ev, fn, true);
    window.removeEventListener("pagehide", onLeave);
    window.removeEventListener("scroll", onScroll, true);
    trackVolatileClasses(false);
    mode = null;
    overlay.hide();
    overlay.setPill(null);
  }
  function pickOnce() {
    return new Promise((resolve) => {
      const block = (e) => {
        if (overlay.owns(targetOf(e)))
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
      };
      const done = (r) => {
        window.removeEventListener("mousemove", onMove, true);
        for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
          window.removeEventListener(ev, block, true);
        window.removeEventListener("click", click, true);
        window.removeEventListener("keydown", key, true);
        overlay.hide();
        cancelPick = () => {};
        if (!mode)
          trackVolatileClasses(false);
        resolve(r);
      };
      const click = (e) => {
        block(e);
        const t = targetOf(e);
        if (!t || overlay.owns(t))
          return;
        done(capture(actionable(t)) ?? null);
      };
      const key = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          done(null);
        }
      };
      trackVolatileClasses(true);
      window.addEventListener("mousemove", onMove, true);
      for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
        window.addEventListener(ev, block, true);
      window.addEventListener("click", click, true);
      window.addEventListener("keydown", key, true);
      cancelPick = () => done(null);
      if (window === window.top)
        overlay.toast("Clica el elemento (Esc para cancelar)");
    });
  }
  var cancelPick = () => {};

  // src/content/index.ts
  function toBg(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => {
        return;
      });
    } catch {
      stopRecording();
      return Promise.resolve(undefined);
    }
  }
  var sink = (step) => void toBg({ kind: "record:step", step });
  var onStop = () => void toBg({ kind: "record:stop" });
  var MSG = "__rastro_frame";
  var announced = new Map;
  function frameElementFor(source) {
    if (!source)
      return;
    return [...document.querySelectorAll("iframe, frame")].find((f) => f.contentWindow === source);
  }
  function onFrameMessage(e) {
    const d = e.data;
    if (!d || typeof d !== "object" || d[MSG] == null || typeof d.token !== "string")
      return;
    if (d[MSG] === "announce") {
      const el = frameElementFor(e.source);
      if (el)
        announced.set(d.token, el);
    } else if (d[MSG] === "probe" && e.source === window.parent && window !== window.top) {
      toBg({ kind: "frame:probe", token: d.token });
    }
  }
  async function selectorsForAnnounced(token) {
    for (let i = 0;i < 20 && !announced.has(token); i++)
      await sleep(50);
    const el = announced.get(token);
    announced.delete(token);
    return el ? buildSelectors(el) : null;
  }
  async function resolveFrame(selectors, timeout) {
    const end = performance.now() + timeout;
    while (true) {
      const r = resolve(selectors);
      const win = r && r.el.contentWindow;
      if (win) {
        const token = crypto.randomUUID();
        win.postMessage({ [MSG]: "probe", token }, "*");
        return { token };
      }
      if (performance.now() > end)
        return { error: `No se encontró el iframe «${selectors[0]}»` };
      await sleep(100);
    }
  }
  if (!window.__rastro) {
    window.__rastro = true;
    window.addEventListener("message", onFrameMessage);
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
      switch (msg.kind) {
        case "ping":
          reply({ ok: true });
          return;
        case "record:on":
          startRecording(msg.mode, sink, onStop);
          reply({ ok: true });
          return;
        case "record:off":
          stopRecording();
          reply({ ok: true });
          return;
        case "run-step":
          runStep(msg.step, msg.settings).then(reply);
          return true;
        case "highlight":
          highlight([msg.selector, ...msg.fallbacks ?? []]).then((found) => reply({ ok: found }));
          return true;
        case "pick":
          pickOnce().then(async (step) => reply(step ? await toBg({ kind: "frame:locate", step }) ?? step : null));
          return true;
        case "pick:cancel":
          cancelPick();
          reply({ ok: true });
          return;
        case "frame:announce":
          window.parent.postMessage({ [MSG]: "announce", token: msg.token }, "*");
          reply({ ok: true });
          return;
        case "frame:selectors":
          selectorsForAnnounced(msg.token).then(reply);
          return true;
        case "frame:resolve":
          resolveFrame(msg.selectors, msg.timeout).then(reply);
          return true;
      }
    });
    toBg({ kind: "record:status" }).then((r) => {
      if (r?.mode)
        startRecording(r.mode, sink, onStop);
    });
  }
})();

//# debugId=921A7C8156842B4164756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC91dGlsLnRzIiwgInNyYy9jb250ZW50L292ZXJsYXkudHMiLCAic3JjL2NvbnRlbnQvc2VsZWN0b3IudHMiLCAic3JjL2NvbnRlbnQvcGxheWVyLnRzIiwgInNyYy9jb250ZW50L3JlY29yZGVyLnRzIiwgInNyYy9jb250ZW50L2luZGV4LnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWwogICAgImV4cG9ydCBjb25zdCB1aWQgPSAoKTogc3RyaW5nID0+IGNyeXB0by5yYW5kb21VVUlEKCkuc2xpY2UoMCwgOCkgKyBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KS5zbGljZSgtNCk7XG5cbi8qKiDCv1BhcmVjZSB1biBpZC9jbGFzZSBhdXRvZ2VuZXJhZG8gKGhhc2hlcywgY29udGFkb3JlcywgaWRzIGRlIFJlYWN0L0VsZW1lbnQgUGx1c+KApik/ICovXG5leHBvcnQgZnVuY3Rpb24gbG9va3NHZW5lcmF0ZWQoczogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgcy5sZW5ndGggPiA0MCB8fFxuICAgIC9cXGR7NCx9Ly50ZXN0KHMpIHx8XG4gICAgL1stXzpdXFxkK1stXzpdXFxkKyQvLnRlc3QocykgfHwgLy8gcHJlZmlqby1hbGVhdG9yaW8tY29udGFkb3I6IGVsLWlkLTc0NC0xNjUsIGlucHV0LTEyLTNcbiAgICAvXlthLWYwLTktXXsxMCx9JC9pLnRlc3QocykgfHxcbiAgICAvXjpyWzAtOWEtel0rOj8kLy50ZXN0KHMpIHx8IC8vIFJlYWN0IHVzZUlkXG4gICAgL14oZW1iZXJ8ZXh0LWdlbnxyZWFjdC18bXVpLXxyYWRpeC18aGVhZGxlc3N1aS18ZG93bnNoaWZ0LXxyYy18ZWwtaWQtfHYtXFxkfGlucHV0LVxcZCkvaS50ZXN0KHMpIHx8XG4gICAgKC9bXy1dW2EtekEtWjAtOV17NSx9JC8udGVzdChzKSAmJiAvXFxkLipcXGQvLnRlc3Qocy5zbGljZSgtNikpKSB8fCAvLyBjc3MtbW9kdWxlczogYnRuX3gzRjlhXG4gICAgL14oY3NzfHNjfGpzeHxlbW90aW9ufHN2ZWx0ZSktW2EtejAtOV0rJC9pLnRlc3QocylcbiAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG5cbi8qKiBWYXJpYWJsZXMgaW50ZWdyYWRhczoge3skdGltZXN0YW1wfX0sIHt7JHV1aWR9fSwge3skcmFuZG9tRW1haWx9fSwge3skcmFuZG9tSW50fX0sIHt7JHRvZGF5fX0gKi9cbmZ1bmN0aW9uIGJ1aWx0aW4obmFtZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgc3dpdGNoIChuYW1lKSB7XG4gICAgY2FzZSBcIiR0aW1lc3RhbXBcIjpcbiAgICAgIHJldHVybiBTdHJpbmcoRGF0ZS5ub3coKSk7XG4gICAgY2FzZSBcIiR1dWlkXCI6XG4gICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjYXNlIFwiJHJhbmRvbUludFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxXzAwMF8wMDApKTtcbiAgICBjYXNlIFwiJHJhbmRvbUVtYWlsXCI6XG4gICAgICByZXR1cm4gYHRlc3QrJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX0ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApfUBleGFtcGxlLmNvbWA7XG4gICAgY2FzZSBcIiR0b2RheVwiOlxuICAgICAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuLyoqIFN1c3RpdHV5ZSB7e3ZhcmlhYmxlfX0gcG9yIHN1IHZhbG9yLiBMYXMgZGVzY29ub2NpZGFzIHNlIGRlamFuIHRhbCBjdWFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlKHRleHQ6IHN0cmluZywgdmFyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0LnJlcGxhY2UoL1xce1xce1xccyooWyRcXHcuLV0rKVxccypcXH1cXH0vZywgKG0sIG5hbWU6IHN0cmluZykgPT4gdmFyc1tuYW1lXSA/PyBidWlsdGluKG5hbWUpID8/IG0pO1xufVxuXG5leHBvcnQgY29uc3QgQlVJTFRJTl9WQVJTID0gW1wiJHRpbWVzdGFtcFwiLCBcIiR1dWlkXCIsIFwiJHJhbmRvbUVtYWlsXCIsIFwiJHJhbmRvbUludFwiLCBcIiR0b2RheVwiXTtcbiIsCiAgICAiLy8gQ2FwYSB2aXN1YWwgZGVudHJvIGRlIGxhIHDDoWdpbmEsIGFpc2xhZGEgZW4gdW4gc2hhZG93IHJvb3QgcGFyYSBubyBoZXJlZGFyIG5pIHJvbXBlciBlc3RpbG9zLlxuXG5jb25zdCBDU1MgPSBgXG46aG9zdCB7IGFsbDogaW5pdGlhbDsgfVxuLmJveCB7XG4gIHBvc2l0aW9uOiBmaXhlZDsgcG9pbnRlci1ldmVudHM6IG5vbmU7IHotaW5kZXg6IDIxNDc0ODM2NDY7IGRpc3BsYXk6IG5vbmU7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWMsICM3YzVjZmYpOyBiYWNrZ3JvdW5kOiBjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tYywgIzdjNWNmZikgMTIlLCB0cmFuc3BhcmVudCk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDsgdHJhbnNpdGlvbjogYWxsIDYwbXMgZWFzZS1vdXQ7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG4udGFnIHtcbiAgcG9zaXRpb246IGZpeGVkOyBwb2ludGVyLWV2ZW50czogbm9uZTsgei1pbmRleDogMjE0NzQ4MzY0NzsgZGlzcGxheTogbm9uZTtcbiAgZm9udDogNjAwIDExcHgvMS4yIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjsgY29sb3I6ICNmZmY7IGJhY2tncm91bmQ6IHZhcigtLWMsICM3YzVjZmYpO1xuICBwYWRkaW5nOiA0cHggN3B4OyBib3JkZXItcmFkaXVzOiA1cHg7IHdoaXRlLXNwYWNlOiBub3dyYXA7IG1heC13aWR0aDogMzYwcHg7IG92ZXJmbG93OiBoaWRkZW47IHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiKDAgMCAwIC8gLjI1KTtcbn1cbi5waWxsIHtcbiAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiAyMTQ3NDgzNjQ3OyBsZWZ0OiA1MCU7IGJvdHRvbTogMThweDsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuICBkaXNwbGF5OiBub25lOyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDEwcHg7IHBhZGRpbmc6IDdweCA4cHggN3B4IDE0cHg7IGJvcmRlci1yYWRpdXM6IDk5OXB4O1xuICBmb250OiA2MDAgMTJweC8xIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjsgY29sb3I6ICNmNGYyZmY7IGJhY2tncm91bmQ6ICMxYjE4MzBlZTtcbiAgYm94LXNoYWRvdzogMCA2cHggMjRweCByZ2IoMCAwIDAgLyAuMzUpOyBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNnB4KTsgdXNlci1zZWxlY3Q6IG5vbmU7XG59XG4uZG90IHsgd2lkdGg6IDlweDsgaGVpZ2h0OiA5cHg7IGJvcmRlci1yYWRpdXM6IDUwJTsgYmFja2dyb3VuZDogI2ZmNGQ2ZDsgYW5pbWF0aW9uOiBwdWxzZSAxLjJzIGluZmluaXRlOyB9XG4ucGlsbC5wb2ludCAuZG90IHsgYmFja2dyb3VuZDogIzdjNWNmZjsgfVxuQGtleWZyYW1lcyBwdWxzZSB7IDUwJSB7IG9wYWNpdHk6IC4zNTsgfSB9XG4ucGlsbCBidXR0b24ge1xuICBhbGw6IHVuc2V0OyBjdXJzb3I6IHBvaW50ZXI7IHBhZGRpbmc6IDVweCAxMHB4OyBib3JkZXItcmFkaXVzOiA5OTlweDsgYmFja2dyb3VuZDogI2ZmZmZmZjFmOyBjb2xvcjogI2ZmZjtcbiAgZm9udDogNjAwIDExcHgvMSB1aS1zYW5zLXNlcmlmLCBzeXN0ZW0tdWksIHNhbnMtc2VyaWY7XG59XG4ucGlsbCBidXR0b246aG92ZXIgeyBiYWNrZ3JvdW5kOiAjZmZmZmZmMzg7IH1cbi50b2FzdHMgeyBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDIxNDc0ODM2NDc7IHJpZ2h0OiAxNnB4OyBib3R0b206IDY0cHg7IGRpc3BsYXk6IGZsZXg7IGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IGdhcDogNnB4OyBhbGlnbi1pdGVtczogZmxleC1lbmQ7IHBvaW50ZXItZXZlbnRzOiBub25lOyB9XG4udG9hc3Qge1xuICBmb250OiA1MDAgMTJweC8xLjMgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2ZmZjsgYmFja2dyb3VuZDogIzFiMTgzMGVlOyBwYWRkaW5nOiA3cHggMTFweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXItbGVmdDogM3B4IHNvbGlkIHZhcigtLWMsICM3YzVjZmYpOyBib3gtc2hhZG93OiAwIDRweCAxNHB4IHJnYigwIDAgMCAvIC4zKTtcbiAgYW5pbWF0aW9uOiBpbiAuMThzIGVhc2Utb3V0OyBtYXgtd2lkdGg6IDM0MHB4O1xufVxuLnRvYXN0Lndhcm4geyAtLWM6ICNmZmIwMjA7IH1cbkBrZXlmcmFtZXMgaW4geyBmcm9tIHsgb3BhY2l0eTogMDsgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDZweCk7IH0gfVxuYDtcblxuZXhwb3J0IGNvbnN0IENPTE9SUyA9IHsgY2xpY2s6IFwiIzdjNWNmZlwiLCBmaWxsOiBcIiMxNGI4YTZcIiwgc2VsZWN0OiBcIiMwZWE1ZTlcIiwgY2hlY2s6IFwiIzIyYzU1ZVwiLCBmaWxlOiBcIiNmZmIwMjBcIiwgcnVuOiBcIiNmOTczMTZcIiB9IGFzIGNvbnN0O1xuXG5jbGFzcyBPdmVybGF5IHtcbiAgaG9zdCE6IEhUTUxFbGVtZW50O1xuICBwcml2YXRlIGJveCE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHRhZyE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHBpbGwhOiBIVE1MRGl2RWxlbWVudDtcbiAgcHJpdmF0ZSBwaWxsVGV4dCE6IEhUTUxTcGFuRWxlbWVudDtcbiAgcHJpdmF0ZSB0b2FzdHMhOiBIVE1MRGl2RWxlbWVudDtcbiAgb25TdG9wOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbiAgcHJpdmF0ZSBlbnN1cmUoKSB7XG4gICAgaWYgKHRoaXMuaG9zdD8uaXNDb25uZWN0ZWQpIHJldHVybjtcbiAgICB0aGlzLmhvc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHRoaXMuaG9zdC5pZCA9IFwiX19yYXN0cm9faG9zdFwiO1xuICAgIGNvbnN0IHJvb3QgPSB0aGlzLmhvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogXCJvcGVuXCIgfSk7XG4gICAgcm9vdC5pbm5lckhUTUwgPSBgPHN0eWxlPiR7Q1NTfTwvc3R5bGU+PGRpdiBjbGFzcz1cImJveFwiPjwvZGl2PjxkaXYgY2xhc3M9XCJ0YWdcIj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJwaWxsXCI+PHNwYW4gY2xhc3M9XCJkb3RcIj48L3NwYW4+PHNwYW4gY2xhc3M9XCJ0eHRcIj48L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCI+VGVybWluYXI8L2J1dHRvbj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0b2FzdHNcIj48L2Rpdj5gO1xuICAgIHRoaXMuYm94ID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLmJveFwiKSE7XG4gICAgdGhpcy50YWcgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIudGFnXCIpITtcbiAgICB0aGlzLnBpbGwgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIucGlsbFwiKSE7XG4gICAgdGhpcy5waWxsVGV4dCA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi50eHRcIikhO1xuICAgIHRoaXMudG9hc3RzID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLnRvYXN0c1wiKSE7XG4gICAgcm9vdC5xdWVyeVNlbGVjdG9yKFwiYnV0dG9uXCIpIS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB0aGlzLm9uU3RvcCgpO1xuICAgIH0pO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZCh0aGlzLmhvc3QpO1xuICB9XG5cbiAgb3ducyhlbDogRXZlbnRUYXJnZXQgfCBudWxsKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5ob3N0ICYmIGVsIGluc3RhbmNlb2YgTm9kZSAmJiAoZWwgPT09IHRoaXMuaG9zdCB8fCB0aGlzLmhvc3QuY29udGFpbnMoZWwpKTtcbiAgfVxuXG4gIHNob3coZWw6IEVsZW1lbnQsIHRleHQ6IHN0cmluZywgY29sb3I6IHN0cmluZyA9IENPTE9SUy5jbGljaykge1xuICAgIHRoaXMuZW5zdXJlKCk7XG4gICAgY29uc3QgciA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIE9iamVjdC5hc3NpZ24odGhpcy5ib3guc3R5bGUsIHtcbiAgICAgIGRpc3BsYXk6IFwiYmxvY2tcIiwgbGVmdDogYCR7ci5sZWZ0IC0gM31weGAsIHRvcDogYCR7ci50b3AgLSAzfXB4YCwgd2lkdGg6IGAke3Iud2lkdGggKyA2fXB4YCwgaGVpZ2h0OiBgJHtyLmhlaWdodCArIDZ9cHhgLFxuICAgIH0pO1xuICAgIHRoaXMuYm94LnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0aGlzLnRhZy5zdHlsZS5zZXRQcm9wZXJ0eShcIi0tY1wiLCBjb2xvcik7XG4gICAgdGhpcy50YWcudGV4dENvbnRlbnQgPSB0ZXh0O1xuICAgIHRoaXMudGFnLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgY29uc3QgYWJvdmUgPSByLnRvcCA+IDMwO1xuICAgIHRoaXMudGFnLnN0eWxlLmxlZnQgPSBgJHtNYXRoLm1heCg0LCBNYXRoLm1pbihyLmxlZnQgLSAzLCBpbm5lcldpZHRoIC0gMzcwKSl9cHhgO1xuICAgIHRoaXMudGFnLnN0eWxlLnRvcCA9IGFib3ZlID8gYCR7ci50b3AgLSAyN31weGAgOiBgJHtyLmJvdHRvbSArIDZ9cHhgO1xuICB9XG5cbiAgaGlkZSgpIHtcbiAgICBpZiAoIXRoaXMuYm94KSByZXR1cm47XG4gICAgdGhpcy5ib3guc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIHRoaXMudGFnLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgfVxuXG4gIC8qKiBSZXNhbHRhIGJyZXZlbWVudGUgKHJlcHJvZHVjY2nDs24gLyBcInZlciBlbGVtZW50b1wiKS4gKi9cbiAgZmxhc2goZWw6IEVsZW1lbnQsIHRleHQ6IHN0cmluZywgbXMgPSA3MDAsIGNvbG9yOiBzdHJpbmcgPSBDT0xPUlMucnVuKSB7XG4gICAgdGhpcy5zaG93KGVsLCB0ZXh0LCBjb2xvcik7XG4gICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLmhpZGUoKSwgbXMpO1xuICB9XG5cbiAgc2V0UGlsbChtb2RlOiBcInJlY29yZFwiIHwgXCJwb2ludFwiIHwgbnVsbCkge1xuICAgIHRoaXMuZW5zdXJlKCk7XG4gICAgaWYgKCFtb2RlKSB7XG4gICAgICB0aGlzLnBpbGwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnBpbGwuY2xhc3NOYW1lID0gXCJwaWxsIFwiICsgbW9kZTtcbiAgICB0aGlzLnBpbGxUZXh0LnRleHRDb250ZW50ID0gbW9kZSA9PT0gXCJyZWNvcmRcIiA/IFwiUmFzdHJvIGdyYWJhbmRvXCIgOiBcIlJhc3RybyDCtyBtb2RvIHNlw7FhbGFyIChFc2MgcGFyYSBzYWxpcilcIjtcbiAgICB0aGlzLnBpbGwuc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICB9XG5cbiAgdG9hc3QodGV4dDogc3RyaW5nLCBjb2xvcj86IHN0cmluZywgd2FybiA9IGZhbHNlKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBjb25zdCB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICB0LmNsYXNzTmFtZSA9IFwidG9hc3RcIiArICh3YXJuID8gXCIgd2FyblwiIDogXCJcIik7XG4gICAgaWYgKGNvbG9yKSB0LnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0LnRleHRDb250ZW50ID0gdGV4dDtcbiAgICB0aGlzLnRvYXN0cy5hcHBlbmRDaGlsZCh0KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHQucmVtb3ZlKCksIDIyMDApO1xuICAgIHdoaWxlICh0aGlzLnRvYXN0cy5jaGlsZHJlbi5sZW5ndGggPiA0KSB0aGlzLnRvYXN0cy5maXJzdEVsZW1lbnRDaGlsZCEucmVtb3ZlKCk7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IG92ZXJsYXkgPSBuZXcgT3ZlcmxheSgpO1xuIiwKICAgICIvLyBNb3RvciBkZSBzZWxlY3RvcmVzIHByb3Bpby5cbi8vXG4vLyBTaW50YXhpcyBzb3BvcnRhZGE6XG4vLyAgIGNzcyAgICAgICAgICAgIOKGkiBjdWFscXVpZXIgc2VsZWN0b3IgQ1NTIChwb3IgZGVmZWN0bylcbi8vICAgZnJhbWU9MiAgICAgICAg4oaSIGVsIHRlcmNlciA8aWZyYW1lPiBkZWwgZG9jdW1lbnRvIChwYXJhIHJ1dGFzIGRlIGZyYW1lcyBpbXBvcnRhZGFzKVxuLy8gICB0ZXh0PUVudmlhciAgICDihpIgZWxlbWVudG8gY3V5byB0ZXh0byB2aXNpYmxlIGVzIGV4YWN0YW1lbnRlIMKrRW52aWFywrsgKG8sIHNpIG5vIGhheSwgcXVlIGxvIGNvbnRpZW5lKVxuLy8gICBsYWJlbD1FbWFpbCAgICDihpIgY29udHJvbCBkZSBmb3JtdWxhcmlvIGFzb2NpYWRvIGEgbGEgZXRpcXVldGEvYXJpYS1sYWJlbCDCq0VtYWlswrtcbi8vICAgeHBhdGg9Ly9kaXZbMV0g4oaSIFhQYXRoXG4vL1xuLy8gQWwgZ2VuZXJhciwgc2UgcHJvZHVjZW4gdmFyaW9zIGNhbmRpZGF0b3Mgb3JkZW5hZG9zIHBvciByb2J1c3Rlei4gRWwgcmVwcm9kdWN0b3Jcbi8vIHBydWViYSBlbCBwcmluY2lwYWwgeSwgc2kgZmFsbGEsIGxvcyBhbHRlcm5hdGl2b3MuXG5cbmltcG9ydCB7IGxvb2tzR2VuZXJhdGVkIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5cbmNvbnN0IFRFU1RfQVRUUlMgPSBbXCJkYXRhLXRlc3RpZFwiLCBcImRhdGEtdGVzdC1pZFwiLCBcImRhdGEtdGVzdFwiLCBcImRhdGEtY3lcIiwgXCJkYXRhLXFhXCIsIFwiZGF0YS1lMmVcIiwgXCJkYXRhLWF1dG9tYXRpb24taWRcIl07XG5cbmNvbnN0IENMSUNLQUJMRSA9XG4gICdidXR0b24sIGFbaHJlZl0sIFtyb2xlPVwiYnV0dG9uXCJdLCBbcm9sZT1cImxpbmtcIl0sIFtyb2xlPVwibWVudWl0ZW1cIl0sIFtyb2xlPVwidGFiXCJdLCBbcm9sZT1cIm9wdGlvblwiXSwgJyArXG4gICdbcm9sZT1cImNoZWNrYm94XCJdLCBbcm9sZT1cInJhZGlvXCJdLCBbcm9sZT1cInN3aXRjaFwiXSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgaW5wdXRbdHlwZT1cImJ1dHRvblwiXSwgJyArXG4gICdpbnB1dFt0eXBlPVwicmVzZXRcIl0sIGlucHV0W3R5cGU9XCJpbWFnZVwiXSwgc3VtbWFyeSwgbGFiZWwsIFtvbmNsaWNrXSc7XG5cbmV4cG9ydCBjb25zdCBDT05UUk9MID0gJ2lucHV0LCB0ZXh0YXJlYSwgc2VsZWN0LCBbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT1cImZhbHNlXCJdKSc7XG5cbmNvbnN0IG5vcm0gPSAoczogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCkgPT4gKHMgPz8gXCJcIikucmVwbGFjZSgvXFxzKy9nLCBcIiBcIikudHJpbSgpO1xuXG5jb25zdCBTVEFURV9DTEFTU0VTID0gL14oaXMtfGhhcy0pPyhhY3RpdmV8Zm9jdXMoZWQpP3xob3ZlcihlZCk/fHNlbGVjdGVkfG9wZW4oZWQpP3xkaXNhYmxlZHxjaGVja2VkfHZpc2libGV8aGlkZGVufHNob3d8aW58bmctLiopJC9pO1xuXG4vLyDDmmx0aW1hIHBhbGFicmEgZGUgdW5hIGNsYXNlIEJFTS91dGlsaXRhcmlhIHF1ZSBpbmRpY2EgZXN0YWRvOiBpcy1ob3ZlcmluZywgYW50LXNlbGVjdC1pdGVtLW9wdGlvbi1hY3RpdmUsXG4vLyB2LWxpc3QtaXRlbS0taGlnaGxpZ2h0ZWQsIE11aS1mb2N1c1Zpc2libGUsIHJvdXRlci1saW5rLWV4YWN0LWFjdGl2ZeKAplxuY29uc3QgU1RBVEVfV09SRFMgPSBuZXcgU2V0KFtcbiAgXCJhY3RpdmVcIiwgXCJmb2N1c1wiLCBcImZvY3VzZWRcIiwgXCJmb2N1c3Zpc2libGVcIiwgXCJmb2N1c3dpdGhpblwiLCBcImhvdmVyXCIsIFwiaG92ZXJlZFwiLCBcImhvdmVyaW5nXCIsIFwiaGlnaGxpZ2h0XCIsIFwiaGlnaGxpZ2h0ZWRcIixcbiAgXCJzZWxlY3RlZFwiLCBcImN1cnJlbnRcIiwgXCJvcGVuXCIsIFwib3BlbmVkXCIsIFwiZXhwYW5kZWRcIiwgXCJjb2xsYXBzZWRcIiwgXCJwcmVzc2VkXCIsIFwiZGlzYWJsZWRcIiwgXCJjaGVja2VkXCIsIFwidmlzaWJsZVwiLCBcImhpZGRlblwiLFxuICBcInNob3duXCIsIFwiZW50ZXJcIiwgXCJlbnRlcmluZ1wiLCBcImxlYXZlXCIsIFwibGVhdmluZ1wiLCBcInRvdWNoZWRcIiwgXCJkaXJ0eVwiLCBcInByaXN0aW5lXCIsIFwidmFsaWRcIiwgXCJpbnZhbGlkXCIsIFwiZXJyb3JcIixcbl0pO1xuXG5mdW5jdGlvbiBpc1N0YXRlQ2xhc3MoYzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIGlmIChTVEFURV9DTEFTU0VTLnRlc3QoYykpIHJldHVybiB0cnVlO1xuICBjb25zdCB3b3JkcyA9IGMuc3BsaXQoL1stX10rfCg/PD1bYS16XSkoPz1bQS1aXSkvKS5maWx0ZXIoQm9vbGVhbik7XG4gIHJldHVybiB3b3Jkcy5sZW5ndGggPiAxICYmIFNUQVRFX1dPUkRTLmhhcyh3b3Jkcy5hdCgtMSkhLnRvTG93ZXJDYXNlKCkpO1xufVxuXG4vLyBDbGFzZXMgcXVlIHNlIGhhbiB2aXN0byBhcGFyZWNlci9kZXNhcGFyZWNlciBkdXJhbnRlIGxhIGdyYWJhY2nDs24gKGhvdmVyLCBmb2N1cywgYWJpZXJ0b+KApik6XG4vLyBkZXBlbmRlbiBkZWwgZXN0YWRvIGRlbCByYXTDs24gbyBkZSBsYSBVSSwgYXPDrSBxdWUgbm8gc2lydmVuIHBhcmEgcmVlbmNvbnRyYXIgZWwgZWxlbWVudG8uXG5jb25zdCB2b2xhdGlsZSA9IG5ldyBTZXQ8c3RyaW5nPigpO1xubGV0IGNsYXNzT2JzZXJ2ZXI6IE11dGF0aW9uT2JzZXJ2ZXIgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gbm90ZUNsYXNzQ2hhbmdlcyhyZWNvcmRzOiBNdXRhdGlvblJlY29yZFtdKSB7XG4gIGZvciAoY29uc3QgciBvZiByZWNvcmRzKSB7XG4gICAgY29uc3QgYmVmb3JlID0gbmV3IFNldCgoci5vbGRWYWx1ZSA/PyBcIlwiKS5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKSk7XG4gICAgY29uc3QgYWZ0ZXIgPSAoci50YXJnZXQgYXMgRWxlbWVudCkuY2xhc3NMaXN0O1xuICAgIGZvciAoY29uc3QgYyBvZiBhZnRlcikgaWYgKCFiZWZvcmUuaGFzKGMpKSB2b2xhdGlsZS5hZGQoYyk7XG4gICAgZm9yIChjb25zdCBjIG9mIGJlZm9yZSkgaWYgKCFhZnRlci5jb250YWlucyhjKSkgdm9sYXRpbGUuYWRkKGMpO1xuICB9XG59XG5cbi8qKiBFbXBpZXphL3BhcmEgZGUgYW5vdGFyIGNsYXNlcyBxdWUgY2FtYmlhbi4gU2UgYWN0aXZhIG1pZW50cmFzIHNlIGdyYWJhIG8gc2Ugc2XDsWFsYS4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0cmFja1ZvbGF0aWxlQ2xhc3NlcyhvbjogYm9vbGVhbikge1xuICBpZiAob24gJiYgIWNsYXNzT2JzZXJ2ZXIpIHtcbiAgICBjbGFzc09ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIobm90ZUNsYXNzQ2hhbmdlcyk7XG4gICAgY2xhc3NPYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCwgeyBzdWJ0cmVlOiB0cnVlLCBhdHRyaWJ1dGVzOiB0cnVlLCBhdHRyaWJ1dGVGaWx0ZXI6IFtcImNsYXNzXCJdLCBhdHRyaWJ1dGVPbGRWYWx1ZTogdHJ1ZSB9KTtcbiAgfSBlbHNlIGlmICghb24gJiYgY2xhc3NPYnNlcnZlcikge1xuICAgIG5vdGVDbGFzc0NoYW5nZXMoY2xhc3NPYnNlcnZlci50YWtlUmVjb3JkcygpKTtcbiAgICBjbGFzc09ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICBjbGFzc09ic2VydmVyID0gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdGFibGVDbGFzc2VzKGVsOiBFbGVtZW50KTogc3RyaW5nW10ge1xuICAvLyBQcm9jZXNhciBtdXRhY2lvbmVzIHBlbmRpZW50ZXM6IGxhIGNsYXNlIGRlIGhvdmVyIHB1ZWRlIGhhYmVyc2UgYcOxYWRpZG8ganVzdG8gYW50ZXMgZGVsIGNsaWNrLlxuICBpZiAoY2xhc3NPYnNlcnZlcikgbm90ZUNsYXNzQ2hhbmdlcyhjbGFzc09ic2VydmVyLnRha2VSZWNvcmRzKCkpO1xuICByZXR1cm4gWy4uLmVsLmNsYXNzTGlzdF0uZmlsdGVyKFxuICAgIChjKSA9PiAhbG9va3NHZW5lcmF0ZWQoYykgJiYgIWlzU3RhdGVDbGFzcyhjKSAmJiAhdm9sYXRpbGUuaGFzKGMpICYmICFjLmluY2x1ZGVzKFwiOlwiKSAmJiBjLmxlbmd0aCA8IDMyLFxuICApO1xufVxuXG5jb25zdCBxID0gKHY6IHN0cmluZykgPT4gSlNPTi5zdHJpbmdpZnkodik7IC8vIGNvbWlsbGFzICsgZXNjYXBlcyB2w6FsaWRvcyBlbiBDU1NcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIFJlc29sdWNpw7NuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgZnVuY3Rpb24gaXNWaXNpYmxlKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGlmICghZWwuaXNDb25uZWN0ZWQpIHJldHVybiBmYWxzZTtcbiAgaWYgKGVsLmdldENsaWVudFJlY3RzKCkubGVuZ3RoID09PSAwKSByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHN0ID0gZ2V0Q29tcHV0ZWRTdHlsZShlbCk7XG4gIHJldHVybiBzdC52aXNpYmlsaXR5ICE9PSBcImhpZGRlblwiICYmIHN0Lm9wYWNpdHkgIT09IFwiMFwiO1xufVxuXG4vKiogVGV4dG8gwqt2aXNpYmxlwrsgZGUgdW4gZWxlbWVudG8sIGNvbW8gbG8gdmVyw61hIGVsIHVzdWFyaW8uICovXG5leHBvcnQgZnVuY3Rpb24gdGV4dE9mKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBbXCJzdWJtaXRcIiwgXCJidXR0b25cIiwgXCJyZXNldFwiXS5pbmNsdWRlcyhlbC50eXBlKSkgcmV0dXJuIG5vcm0oZWwudmFsdWUpO1xuICByZXR1cm4gbm9ybSgoZWwgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dCA/PyBlbC50ZXh0Q29udGVudCk7XG59XG5cbmZ1bmN0aW9uKiBhbGxFbGVtZW50cyhyb290OiBEb2N1bWVudCB8IFNoYWRvd1Jvb3QgPSBkb2N1bWVudCk6IEdlbmVyYXRvcjxFbGVtZW50PiB7XG4gIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIocm9vdCwgTm9kZUZpbHRlci5TSE9XX0VMRU1FTlQpO1xuICBsZXQgbiA9IHdhbGtlci5uZXh0Tm9kZSgpO1xuICB3aGlsZSAobikge1xuICAgIHlpZWxkIG4gYXMgRWxlbWVudDtcbiAgICBjb25zdCBzciA9IChuIGFzIEVsZW1lbnQpLnNoYWRvd1Jvb3Q7XG4gICAgaWYgKHNyKSB5aWVsZCogYWxsRWxlbWVudHMoc3IpO1xuICAgIG4gPSB3YWxrZXIubmV4dE5vZGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBieVRleHQodGV4dDogc3RyaW5nKTogRWxlbWVudFtdIHtcbiAgY29uc3QgdGFyZ2V0ID0gbm9ybSh0ZXh0KTtcbiAgY29uc3QgZXhhY3Q6IEVsZW1lbnRbXSA9IFtdO1xuICBjb25zdCBwYXJ0aWFsOiBFbGVtZW50W10gPSBbXTtcbiAgY29uc3QgbG93ZXIgPSB0YXJnZXQudG9Mb3dlckNhc2UoKTtcbiAgZm9yIChjb25zdCBlbCBvZiBhbGxFbGVtZW50cygpKSB7XG4gICAgaWYgKGVsLmNsb3Nlc3QoXCJzY3JpcHQsIHN0eWxlLCBub3NjcmlwdCwgdGVtcGxhdGUsICNfX3Jhc3Ryb19ob3N0XCIpKSBjb250aW51ZTtcbiAgICBjb25zdCBsaW1pdCA9IHRhcmdldC5sZW5ndGggKiAzICsgMjA7XG4gICAgLy8gdGV4dENvbnRlbnQgZXMgYmFyYXRvOyBpbm5lclRleHQgZnVlcnphIGxheW91dCwgYXPDrSBxdWUgc29sbyBwYXJhIGNhbmRpZGF0b3MgY29ydG9zLlxuICAgIGlmICghKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCkgJiYgbm9ybShlbC50ZXh0Q29udGVudCkubGVuZ3RoID4gbGltaXQpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHQgPSB0ZXh0T2YoZWwpO1xuICAgIGlmICghdCB8fCB0Lmxlbmd0aCA+IGxpbWl0KSBjb250aW51ZTtcbiAgICBpZiAodCA9PT0gdGFyZ2V0KSBleGFjdC5wdXNoKGVsKTtcbiAgICBlbHNlIGlmICh0LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMobG93ZXIpKSBwYXJ0aWFsLnB1c2goZWwpO1xuICB9XG4gIGNvbnN0IHBpY2sgPSBleGFjdC5sZW5ndGggPyBleGFjdCA6IHBhcnRpYWw7XG4gIC8vIFF1ZWRhcnNlIGNvbiBlbCBtw6FzIHByb2Z1bmRvIHkgc3ViaXIgYSBzdSBhbmNlc3RybyBjbGljYWJsZSBzaSBsbyBoYXkuXG4gIGNvbnN0IGRlZXBlc3QgPSBwaWNrLmZpbHRlcigoZWwpID0+ICFwaWNrLnNvbWUoKG8pID0+IG8gIT09IGVsICYmIGVsLmNvbnRhaW5zKG8pKSk7XG4gIHJldHVybiBkZWR1cGUoZGVlcGVzdC5tYXAoKGVsKSA9PiBlbC5jbG9zZXN0KENMSUNLQUJMRSkgPz8gZWwpKTtcbn1cblxuZnVuY3Rpb24gYnlMYWJlbCh0ZXh0OiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCB0YXJnZXQgPSBub3JtKHRleHQpLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IG91dDogRWxlbWVudFtdID0gW107XG4gIGZvciAoY29uc3QgbGFiZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcImxhYmVsXCIpKSB7XG4gICAgaWYgKG5vcm0obGFiZWwuaW5uZXJUZXh0KS50b0xvd2VyQ2FzZSgpLnJlcGxhY2UoL1xccypcXCokLywgXCJcIikgPT09IHRhcmdldCAmJiBsYWJlbC5jb250cm9sKSBvdXQucHVzaChsYWJlbC5jb250cm9sKTtcbiAgfVxuICBmb3IgKGNvbnN0IGVsIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoQ09OVFJPTCArIFwiLCBbYXJpYS1sYWJlbF0sIFthcmlhLWxhYmVsbGVkYnldXCIpKSB7XG4gICAgaWYgKG5vcm0oZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKSkudG9Mb3dlckNhc2UoKSA9PT0gdGFyZ2V0KSBvdXQucHVzaChlbCk7XG4gICAgY29uc3QgbGIgPSBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsbGVkYnlcIik7XG4gICAgaWYgKGxiKSB7XG4gICAgICBjb25zdCB0ID0gbGJcbiAgICAgICAgLnNwbGl0KC9cXHMrLylcbiAgICAgICAgLm1hcCgoaWQpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKT8uaW5uZXJUZXh0ID8/IFwiXCIpXG4gICAgICAgIC5qb2luKFwiIFwiKTtcbiAgICAgIGlmIChub3JtKHQpLnRvTG93ZXJDYXNlKCkgPT09IHRhcmdldCkgb3V0LnB1c2goZWwpO1xuICAgIH1cbiAgfVxuICBpZiAoIW91dC5sZW5ndGgpIHtcbiAgICBmb3IgKGNvbnN0IGVsIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJbcGxhY2Vob2xkZXJdXCIpKSB7XG4gICAgICBpZiAobm9ybShlbC5nZXRBdHRyaWJ1dGUoXCJwbGFjZWhvbGRlclwiKSkudG9Mb3dlckNhc2UoKSA9PT0gdGFyZ2V0KSBvdXQucHVzaChlbCk7XG4gICAgfVxuICB9XG4gIHJldHVybiBkZWR1cGUob3V0KTtcbn1cblxuZnVuY3Rpb24gYnlYUGF0aCh4cDogc3RyaW5nKTogRWxlbWVudFtdIHtcbiAgY29uc3QgcmVzID0gZG9jdW1lbnQuZXZhbHVhdGUoeHAsIGRvY3VtZW50LCBudWxsLCBYUGF0aFJlc3VsdC5PUkRFUkVEX05PREVfU05BUFNIT1RfVFlQRSwgbnVsbCk7XG4gIGNvbnN0IG91dDogRWxlbWVudFtdID0gW107XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzLnNuYXBzaG90TGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBuID0gcmVzLnNuYXBzaG90SXRlbShpKTtcbiAgICBpZiAobiBpbnN0YW5jZW9mIEVsZW1lbnQpIG91dC5wdXNoKG4pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59XG5cbmZ1bmN0aW9uIGRlZHVwZTxUPihhcnI6IFRbXSk6IFRbXSB7XG4gIHJldHVybiBbLi4ubmV3IFNldChhcnIpXTtcbn1cblxuLyoqIERldnVlbHZlIHRvZG9zIGxvcyBlbGVtZW50b3MgcXVlIGNhc2FuIGNvbiB1biBzZWxlY3RvciBkZSBSYXN0cm8uICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZUFsbChzZWxlY3Rvcjogc3RyaW5nKTogRWxlbWVudFtdIHtcbiAgdHJ5IHtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcInRleHQ9XCIpKSByZXR1cm4gYnlUZXh0KHVucXVvdGUoc2VsZWN0b3Iuc2xpY2UoNSkpKTtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcImxhYmVsPVwiKSkgcmV0dXJuIGJ5TGFiZWwodW5xdW90ZShzZWxlY3Rvci5zbGljZSg2KSkpO1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwieHBhdGg9XCIpKSByZXR1cm4gYnlYUGF0aChzZWxlY3Rvci5zbGljZSg2KSk7XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJmcmFtZT1cIikpIHtcbiAgICAgIC8vIE4tw6lzaW1vIGlmcmFtZSBkZWwgZG9jdW1lbnRvIChmb3JtYXRvIGRlIERldlRvb2xzIFJlY29yZGVyKS5cbiAgICAgIGNvbnN0IGYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lLCBmcmFtZVwiKVtOdW1iZXIoc2VsZWN0b3Iuc2xpY2UoNikpXTtcbiAgICAgIHJldHVybiBmID8gW2ZdIDogW107XG4gICAgfVxuICAgIHJldHVybiBbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvcildO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gW107XG4gIH1cbn1cblxuZnVuY3Rpb24gdW5xdW90ZShzOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB0ID0gcy50cmltKCk7XG4gIGlmICgodC5zdGFydHNXaXRoKCdcIicpICYmIHQuZW5kc1dpdGgoJ1wiJykpIHx8ICh0LnN0YXJ0c1dpdGgoXCInXCIpICYmIHQuZW5kc1dpdGgoXCInXCIpKSkgcmV0dXJuIHQuc2xpY2UoMSwgLTEpO1xuICByZXR1cm4gdDtcbn1cblxuLyoqIEVuY3VlbnRyYSBlbCBwcmltZXIgc2VsZWN0b3IgcXVlIHJlc3VlbHZlIGEgZXhhY3RhbWVudGUgdW4gZWxlbWVudG8gKG8gYWwgcHJpbWVybyB2aXNpYmxlKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlKHNlbGVjdG9yczogc3RyaW5nW10pOiB7IGVsOiBFbGVtZW50OyBzZWxlY3Rvcjogc3RyaW5nIH0gfCBudWxsIHtcbiAgZm9yIChjb25zdCBzZWwgb2Ygc2VsZWN0b3JzKSB7XG4gICAgY29uc3QgZm91bmQgPSByZXNvbHZlQWxsKHNlbCk7XG4gICAgaWYgKGZvdW5kLmxlbmd0aCA9PT0gMSkgcmV0dXJuIHsgZWw6IGZvdW5kWzBdISwgc2VsZWN0b3I6IHNlbCB9O1xuICAgIGNvbnN0IHZpcyA9IGZvdW5kLmZpbHRlcihpc1Zpc2libGUpO1xuICAgIGlmICh2aXMubGVuZ3RoID49IDEpIHJldHVybiB7IGVsOiB2aXNbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gICAgaWYgKGZvdW5kLmxlbmd0aCkgcmV0dXJuIHsgZWw6IGZvdW5kWzBdISwgc2VsZWN0b3I6IHNlbCB9O1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgR2VuZXJhY2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIGlzVW5pcXVlKHNlbDogc3RyaW5nLCBlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICBjb25zdCByID0gcmVzb2x2ZUFsbChzZWwpO1xuICByZXR1cm4gci5sZW5ndGggPT09IDEgJiYgclswXSA9PT0gZWw7XG59XG5cbmZ1bmN0aW9uIGNzc1BhdGgoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBjb25zdCBwYXJ0czogc3RyaW5nW10gPSBbXTtcbiAgbGV0IGN1cjogRWxlbWVudCB8IG51bGwgPSBlbDtcbiAgd2hpbGUgKGN1ciAmJiBjdXIgIT09IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCkge1xuICAgIGNvbnN0IHRhZyA9IGN1ci50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGN1ciAhPT0gZWwgJiYgY3VyLmlkICYmICFsb29rc0dlbmVyYXRlZChjdXIuaWQpKSB7XG4gICAgICBwYXJ0cy51bnNoaWZ0KFwiI1wiICsgQ1NTLmVzY2FwZShjdXIuaWQpKTtcbiAgICAgIGNvbnN0IHMgPSBwYXJ0cy5qb2luKFwiID4gXCIpO1xuICAgICAgaWYgKGlzVW5pcXVlKHMsIGVsKSkgcmV0dXJuIHM7XG4gICAgICBwYXJ0cy5zaGlmdCgpO1xuICAgIH1cbiAgICBsZXQgc2VnID0gdGFnO1xuICAgIGNvbnN0IGNscyA9IHN0YWJsZUNsYXNzZXMoY3VyKS5zbGljZSgwLCAyKTtcbiAgICBpZiAoY2xzLmxlbmd0aCkgc2VnICs9IFwiLlwiICsgY2xzLm1hcCgoYykgPT4gQ1NTLmVzY2FwZShjKSkuam9pbihcIi5cIik7XG5cbiAgICBjb25zdCB3aXRob3V0TnRoID0gW3NlZywgLi4ucGFydHNdLmpvaW4oXCIgPiBcIik7XG4gICAgaWYgKGlzVW5pcXVlKHdpdGhvdXROdGgsIGVsKSkgcmV0dXJuIHdpdGhvdXROdGg7XG5cbiAgICBjb25zdCBwYXJlbnQ6IEVsZW1lbnQgfCBudWxsID0gY3VyLnBhcmVudEVsZW1lbnQ7XG4gICAgaWYgKHBhcmVudCkge1xuICAgICAgY29uc3Qgc2FtZSA9IFsuLi5wYXJlbnQuY2hpbGRyZW5dLmZpbHRlcigoYykgPT4gYy50YWdOYW1lID09PSBjdXIhLnRhZ05hbWUpO1xuICAgICAgaWYgKHNhbWUubGVuZ3RoID4gMSkgc2VnICs9IGA6bnRoLW9mLXR5cGUoJHtzYW1lLmluZGV4T2YoY3VyKSArIDF9KWA7XG4gICAgfVxuICAgIHBhcnRzLnVuc2hpZnQoc2VnKTtcbiAgICBjb25zdCBzID0gcGFydHMuam9pbihcIiA+IFwiKTtcbiAgICBpZiAoaXNVbmlxdWUocywgZWwpKSByZXR1cm4gcztcbiAgICBjdXIgPSBwYXJlbnQ7XG4gIH1cbiAgcmV0dXJuIHBhcnRzLmpvaW4oXCIgPiBcIik7XG59XG5cbi8qKiBHZW5lcmEgc2VsZWN0b3JlcyBjYW5kaWRhdG9zIG9yZGVuYWRvcyBkZSBtw6FzIGEgbWVub3Mgcm9idXN0by4gVG9kb3Mgw7puaWNvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBidWlsZFNlbGVjdG9ycyhlbDogRWxlbWVudCk6IHN0cmluZ1tdIHtcbiAgY29uc3QgdGFnID0gZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICBjb25zdCBjOiBzdHJpbmdbXSA9IFtdO1xuXG4gIGZvciAoY29uc3QgYSBvZiBURVNUX0FUVFJTKSB7XG4gICAgY29uc3QgdiA9IGVsLmdldEF0dHJpYnV0ZShhKTtcbiAgICBpZiAodikgYy5wdXNoKGBbJHthfT0ke3Eodil9XWApO1xuICB9XG4gIGlmIChlbC5pZCAmJiAhbG9va3NHZW5lcmF0ZWQoZWwuaWQpKSBjLnB1c2goXCIjXCIgKyBDU1MuZXNjYXBlKGVsLmlkKSk7XG5cbiAgY29uc3QgbmFtZSA9IGVsLmdldEF0dHJpYnV0ZShcIm5hbWVcIik7XG4gIGlmIChuYW1lKSB7XG4gICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiAoZWwudHlwZSA9PT0gXCJyYWRpb1wiIHx8IGVsLnR5cGUgPT09IFwiY2hlY2tib3hcIikgJiYgZWwudmFsdWUgJiYgZWwudmFsdWUgIT09IFwib25cIikge1xuICAgICAgYy5wdXNoKGAke3RhZ31bbmFtZT0ke3EobmFtZSl9XVt2YWx1ZT0ke3EoZWwudmFsdWUpfV1gKTtcbiAgICB9IGVsc2UgYy5wdXNoKGAke3RhZ31bbmFtZT0ke3EobmFtZSl9XWApO1xuICB9XG5cbiAgY29uc3QgaXNDb250cm9sID0gZWwubWF0Y2hlcyhDT05UUk9MKTtcbiAgaWYgKGlzQ29udHJvbCkge1xuICAgIGNvbnN0IGxibCA9IGxhYmVsVGV4dChlbCk7XG4gICAgaWYgKGxibCAmJiBsYmwubGVuZ3RoIDw9IDYwKSBjLnB1c2goYGxhYmVsPSR7bGJsfWApO1xuICB9XG5cbiAgY29uc3QgYXJpYSA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIik7XG4gIGlmIChhcmlhKSBjLnB1c2goYCR7dGFnfVthcmlhLWxhYmVsPSR7cShhcmlhKX1dYCk7XG4gIGNvbnN0IHBoID0gZWwuZ2V0QXR0cmlidXRlKFwicGxhY2Vob2xkZXJcIik7XG4gIGlmIChwaCkgYy5wdXNoKGAke3RhZ31bcGxhY2Vob2xkZXI9JHtxKHBoKX1dYCk7XG5cbiAgaWYgKCFpc0NvbnRyb2wpIHtcbiAgICBjb25zdCB0ID0gdGV4dE9mKGVsKTtcbiAgICBpZiAodCAmJiB0Lmxlbmd0aCA8PSA1MCAmJiAhZWwucXVlcnlTZWxlY3RvcihDT05UUk9MKSkgYy5wdXNoKGB0ZXh0PSR7dH1gKTtcbiAgfVxuXG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxBbmNob3JFbGVtZW50KSB7XG4gICAgY29uc3QgaHJlZiA9IGVsLmdldEF0dHJpYnV0ZShcImhyZWZcIik7XG4gICAgaWYgKGhyZWYgJiYgaHJlZi5sZW5ndGggPCA4MCAmJiAhaHJlZi5zdGFydHNXaXRoKFwiamF2YXNjcmlwdDpcIikgJiYgaHJlZiAhPT0gXCIjXCIpIGMucHVzaChgYVtocmVmPSR7cShocmVmKX1dYCk7XG4gIH1cbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElGcmFtZUVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MRnJhbWVFbGVtZW50KSB7XG4gICAgY29uc3Qgc3JjID0gZWwuZ2V0QXR0cmlidXRlKFwic3JjXCIpO1xuICAgIGlmIChzcmMgJiYgIXNyYy5zdGFydHNXaXRoKFwiZGF0YTpcIikgJiYgIXNyYy5zdGFydHNXaXRoKFwiamF2YXNjcmlwdDpcIikpIHtcbiAgICAgIC8vIFNpbiBxdWVyeSBzdHJpbmc6IHN1ZWxlIGxsZXZhciB0b2tlbnMgcXVlIGNhbWJpYW4gZW4gY2FkYSBjYXJnYS5cbiAgICAgIGNvbnN0IGJhc2UgPSBzcmMuc3BsaXQoL1s/I10vKVswXSE7XG4gICAgICBjLnB1c2goYmFzZSA9PT0gc3JjID8gYCR7dGFnfVtzcmM9JHtxKHNyYyl9XWAgOiBgJHt0YWd9W3NyY149JHtxKGJhc2UpfV1gKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgdGl0bGUgPSBlbC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKTtcbiAgaWYgKHRpdGxlKSBjLnB1c2goYCR7dGFnfVt0aXRsZT0ke3EodGl0bGUpfV1gKTtcblxuICAvLyB0ZXh0PSBhcHVudGEgYWwgbm9kbyBtw6FzIHByb2Z1bmRvIGNvbiBlc2UgdGV4dG8gKHAuIGVqLiBlbCA8c3Bhbj4gZGUgdW4gPGxpPiBkZSBkZXNwbGVnYWJsZSk6IGNsaWNhcmxvIGVxdWl2YWxlLlxuICBjb25zdCBzYW1lVGFyZ2V0ID0gKHM6IHN0cmluZykgPT4ge1xuICAgIGNvbnN0IGlzVGV4dCA9IHMuc3RhcnRzV2l0aChcInRleHQ9XCIpO1xuICAgIGNvbnN0IGhpdCA9ICh4OiBFbGVtZW50KSA9PiB4ID09PSBlbCB8fCAoaXNUZXh0ICYmIGVsLmNvbnRhaW5zKHgpICYmIHRleHRPZih4KSA9PT0gdGV4dE9mKGVsKSk7XG4gICAgY29uc3QgciA9IHJlc29sdmVBbGwocyk7XG4gICAgaWYgKHIubGVuZ3RoID09PSAxKSByZXR1cm4gaGl0KHJbMF0hKTtcbiAgICAvLyBEZXNwbGVnYWJsZXMgdGVsZXRyYW5zcG9ydGFkb3MgKEVsZW1lbnQgUGx1cywgQW504oCmKTogbGFzIG9wY2lvbmVzIGRlIG90cm9zIHNlbGVjdHMgc2lndWVuIGVuIGVsIERPTVxuICAgIC8vIHBlcm8gb2N1bHRhcy4gU2kgZWwgw7puaWNvIHZpc2libGUgZXMgZWwgbnVlc3RybywgcmVzb2x2ZSgpIGxvIGVsZWdpcsOhIHRhbWJpw6luIGFsIHJlcHJvZHVjaXIuXG4gICAgaWYgKCFpc1RleHQpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCB2aXMgPSByLmZpbHRlcihpc1Zpc2libGUpO1xuICAgIHJldHVybiB2aXMubGVuZ3RoID09PSAxICYmIGhpdCh2aXNbMF0hKTtcbiAgfTtcbiAgY29uc3QgdW5pcXVlID0gZGVkdXBlKGMpLmZpbHRlcihzYW1lVGFyZ2V0KTtcbiAgdW5pcXVlLnB1c2goY3NzUGF0aChlbCkpO1xuICByZXR1cm4gZGVkdXBlKHVuaXF1ZSkuc2xpY2UoMCwgNSk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBEZXNjcmlwY2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBsYWJlbFRleHQoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscz8ubGVuZ3RoKSB7XG4gICAgY29uc3QgdCA9IG5vcm0oKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscyFbMF0hLmlubmVyVGV4dCkucmVwbGFjZSgvXFxzKlxcKiQvLCBcIlwiKTtcbiAgICBpZiAodCkgcmV0dXJuIHQ7XG4gIH1cbiAgY29uc3QgYXJpYSA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIik7XG4gIGlmIChhcmlhKSByZXR1cm4gbm9ybShhcmlhKTtcbiAgY29uc3QgbGIgPSBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsbGVkYnlcIik7XG4gIGlmIChsYikge1xuICAgIGNvbnN0IHQgPSBub3JtKGxiLnNwbGl0KC9cXHMrLykubWFwKChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpPy5pbm5lclRleHQgPz8gXCJcIikuam9pbihcIiBcIikpO1xuICAgIGlmICh0KSByZXR1cm4gdDtcbiAgfVxuICByZXR1cm4gXCJcIjtcbn1cblxuLyoqIE5vbWJyZSBsZWdpYmxlIHBhcmEgbW9zdHJhciBlbiBsYSBsaXN0YSBkZSBwYXNvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZShlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGlmIChlbC5tYXRjaGVzKENPTlRST0wpKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIGxhYmVsVGV4dChlbCkgfHxcbiAgICAgIGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpIHx8XG4gICAgICBlbC5nZXRBdHRyaWJ1dGUoXCJuYW1lXCIpIHx8XG4gICAgICBlbC5pZCB8fFxuICAgICAgZWwuZ2V0QXR0cmlidXRlKFwidGl0bGVcIikgfHxcbiAgICAgIGVsLnRhZ05hbWUudG9Mb3dlckNhc2UoKVxuICAgICkuc2xpY2UoMCwgNjApO1xuICB9XG4gIGNvbnN0IHQgPSB0ZXh0T2YoZWwpO1xuICBpZiAodCkgcmV0dXJuIHQubGVuZ3RoID4gNTAgPyB0LnNsaWNlKDAsIDQ3KSArIFwi4oCmXCIgOiB0O1xuICByZXR1cm4gKFxuICAgIGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIikgfHxcbiAgICBlbC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKSB8fFxuICAgIGVsLnF1ZXJ5U2VsZWN0b3IoXCJpbWdcIik/LmdldEF0dHJpYnV0ZShcImFsdFwiKSB8fFxuICAgIGVsLmdldEF0dHJpYnV0ZShcIm5hbWVcIikgfHxcbiAgICBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKClcbiAgKS5zbGljZSgwLCA2MCk7XG59XG5cbi8qKiBFbGVtZW50byBzb2JyZSBlbCBxdWUgYWN0w7phIGVsIHVzdWFyaW86IGVsIGNvbnRyb2wgbyBlbCBhbmNlc3RybyBjbGljYWJsZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhY3Rpb25hYmxlKHRhcmdldDogRWxlbWVudCk6IEVsZW1lbnQge1xuICBjb25zdCBjdHJsID0gdGFyZ2V0LmNsb3Nlc3QoQ09OVFJPTCk7XG4gIGlmIChjdHJsKSByZXR1cm4gY3RybDtcbiAgY29uc3QgY2xpY2thYmxlID0gdGFyZ2V0LmNsb3Nlc3QoQ0xJQ0tBQkxFKTtcbiAgaWYgKGNsaWNrYWJsZSBpbnN0YW5jZW9mIEhUTUxMYWJlbEVsZW1lbnQgJiYgY2xpY2thYmxlLmNvbnRyb2wpIHJldHVybiBjbGlja2FibGUuY29udHJvbDtcbiAgcmV0dXJuIGNsaWNrYWJsZSA/PyB0YXJnZXQ7XG59XG5cbmNvbnN0IFRFWFRMSUtFID0gbmV3IFNldChbXG4gIFwiXCIsIFwidGV4dFwiLCBcImVtYWlsXCIsIFwicGFzc3dvcmRcIiwgXCJzZWFyY2hcIiwgXCJ0ZWxcIiwgXCJ1cmxcIiwgXCJudW1iZXJcIixcbiAgXCJkYXRlXCIsIFwiZGF0ZXRpbWUtbG9jYWxcIiwgXCJtb250aFwiLCBcIndlZWtcIiwgXCJ0aW1lXCIsIFwiY29sb3JcIiwgXCJyYW5nZVwiLFxuXSk7XG5cbmV4cG9ydCB0eXBlIEFjdGlvbktpbmQgPSBcImNsaWNrXCIgfCBcImZpbGxcIiB8IFwic2VsZWN0XCIgfCBcImNoZWNrXCIgfCBcImZpbGVcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGtpbmRPZihlbDogRWxlbWVudCk6IEFjdGlvbktpbmQge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCkgcmV0dXJuIFwic2VsZWN0XCI7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQpIHJldHVybiBlbC5yZWFkT25seSA/IFwiY2xpY2tcIiA6IFwiZmlsbFwiO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSB7XG4gICAgaWYgKGVsLnR5cGUgPT09IFwiY2hlY2tib3hcIiB8fCBlbC50eXBlID09PSBcInJhZGlvXCIpIHJldHVybiBcImNoZWNrXCI7XG4gICAgaWYgKGVsLnR5cGUgPT09IFwiZmlsZVwiKSByZXR1cm4gXCJmaWxlXCI7XG4gICAgLy8gUmVhZG9ubHkgPSBzZWxlY3RzL2RhdGVwaWNrZXJzIGRlIGxpYnJlcsOtYXMgKEVsZW1lbnQgUGx1cywgVnVldGlmeeKApik6IGFicmVuIHVuIGRlc3BsZWdhYmxlLCBubyBzZSBlc2NyaWJlLlxuICAgIGlmIChURVhUTElLRS5oYXMoZWwudHlwZSkpIHJldHVybiBlbC5yZWFkT25seSA/IFwiY2xpY2tcIiA6IFwiZmlsbFwiO1xuICAgIHJldHVybiBcImNsaWNrXCI7XG4gIH1cbiAgaWYgKChlbCBhcyBIVE1MRWxlbWVudCkuaXNDb250ZW50RWRpdGFibGUpIHJldHVybiBcImZpbGxcIjtcbiAgY29uc3Qgcm9sZSA9IGVsLmdldEF0dHJpYnV0ZShcInJvbGVcIik7XG4gIGlmIChyb2xlID09PSBcImNoZWNrYm94XCIgfHwgcm9sZSA9PT0gXCJzd2l0Y2hcIikgcmV0dXJuIFwiY2hlY2tcIjtcbiAgcmV0dXJuIFwiY2xpY2tcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbHVlT2YoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSByZXR1cm4gZWwudmFsdWU7XG4gIHJldHVybiBub3JtKChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrZWRPZihlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSByZXR1cm4gZWwuY2hlY2tlZDtcbiAgcmV0dXJuIGVsLmdldEF0dHJpYnV0ZShcImFyaWEtY2hlY2tlZFwiKSA9PT0gXCJ0cnVlXCI7XG59XG4iLAogICAgIi8vIFJlcHJvZHVjdG9yOiBlamVjdXRhIHVuIHBhc28gc29icmUgbGEgcMOhZ2luYSBzaW11bGFuZG8gYSB1biB1c3VhcmlvIHJlYWxcbi8vIChzZWN1ZW5jaWEgY29tcGxldGEgZGUgZXZlbnRvcyBkZSBwdW50ZXJvL3RlY2xhZG8sIGNvbXBhdGlibGUgY29uIFJlYWN0L1Z1ZS9Bbmd1bGFyKS5cblxuaW1wb3J0IHR5cGUgeyBTdGVwUmVzdWx0IH0gZnJvbSBcIi4uL3NoYXJlZC9tZXNzYWdlc1wiO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncywgU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5pbXBvcnQgeyBDT0xPUlMsIG92ZXJsYXkgfSBmcm9tIFwiLi9vdmVybGF5XCI7XG5pbXBvcnQgeyBjaGVja2VkT2YsIGlzVmlzaWJsZSwga2luZE9mLCByZXNvbHZlLCB0ZXh0T2YsIHZhbHVlT2YgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG5jbGFzcyBTdGVwRXJyb3IgZXh0ZW5kcyBFcnJvciB7fVxuXG4vKiogRXNwZXJhIGEgcXVlIGVsIGVsZW1lbnRvIGV4aXN0YSAoeSBwcmVmZXJpYmxlbWVudGUgc2VhIHZpc2libGUpLiAqL1xuYXN5bmMgZnVuY3Rpb24gZmluZChzdGVwOiBTdGVwLCB0aW1lb3V0OiBudW1iZXIsIHJlcXVpcmVWaXNpYmxlOiBib29sZWFuKTogUHJvbWlzZTx7IGVsOiBFbGVtZW50OyBzZWxlY3Rvcjogc3RyaW5nIH0+IHtcbiAgY29uc3Qgc2VsZWN0b3JzID0gW3N0ZXAuc2VsZWN0b3IsIC4uLihzdGVwLmZhbGxiYWNrcyA/PyBbXSldLmZpbHRlcihCb29sZWFuKSBhcyBzdHJpbmdbXTtcbiAgaWYgKCFzZWxlY3RvcnMubGVuZ3RoKSB0aHJvdyBuZXcgU3RlcEVycm9yKFwiRWwgcGFzbyBubyB0aWVuZSBzZWxlY3RvclwiKTtcbiAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgbGV0IGhpZGRlblNpbmNlID0gMDtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCByID0gcmVzb2x2ZShzZWxlY3RvcnMpO1xuICAgIGlmIChyKSB7XG4gICAgICBpZiAoaXNWaXNpYmxlKHIuZWwpKSByZXR1cm4gcjtcbiAgICAgIC8vIENvbnRyb2xlcyBvY3VsdG9zIChjaGVja2JveCBjdXN0b20sIGlucHV0cyBjb24gbGFiZWwgZXN0aWxpemFkb+KApik6IHNlIGFjZXB0YW4gdHJhcyAxcy5cbiAgICAgIGlmICghcmVxdWlyZVZpc2libGUpIHtcbiAgICAgICAgaGlkZGVuU2luY2UgfHw9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBoaWRkZW5TaW5jZSA+IDEwMDApIHJldHVybiByO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHtcbiAgICAgIGlmIChyKSB0aHJvdyBuZXcgU3RlcEVycm9yKGBFbCBlbGVtZW50byDCqyR7c3RlcC5sYWJlbCA/PyBzZWxlY3RvcnNbMF19wrsgZXhpc3RlIHBlcm8gbm8gZXMgdmlzaWJsZWApO1xuICAgICAgdGhyb3cgbmV3IFN0ZXBFcnJvcihgTm8gc2UgZW5jb250csOzIMKrJHtzdGVwLmxhYmVsID8/IHNlbGVjdG9yc1swXX3CuyAoJHtzZWxlY3RvcnNbMF19KWApO1xuICAgIH1cbiAgICBhd2FpdCBzbGVlcCgxMDApO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNlbnRlcihlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHJldHVybiB7IHg6IHIubGVmdCArIHIud2lkdGggLyAyLCB5OiByLnRvcCArIHIuaGVpZ2h0IC8gMiB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBzY3JvbGxUbyhlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGlmIChyLnRvcCA8IDAgfHwgci5ib3R0b20gPiBpbm5lckhlaWdodCB8fCByLmxlZnQgPCAwIHx8IHIucmlnaHQgPiBpbm5lcldpZHRoKSB7XG4gICAgZWwuc2Nyb2xsSW50b1ZpZXcoeyBibG9jazogXCJjZW50ZXJcIiwgaW5saW5lOiBcImNlbnRlclwiLCBiZWhhdmlvcjogXCJpbnN0YW50XCIgYXMgU2Nyb2xsQmVoYXZpb3IgfSk7XG4gICAgYXdhaXQgc2xlZXAoNTApO1xuICB9XG59XG5cbmZ1bmN0aW9uIG1vdXNlKHRhcmdldDogRWxlbWVudCwgdHlwZTogc3RyaW5nLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICBjb25zdCBpbml0OiBQb2ludGVyRXZlbnRJbml0ID0ge1xuICAgIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUsIGNvbXBvc2VkOiB0cnVlLCB2aWV3OiB3aW5kb3csXG4gICAgY2xpZW50WDogeCwgY2xpZW50WTogeSwgc2NyZWVuWDogeCArIHNjcmVlblgsIHNjcmVlblk6IHkgKyBzY3JlZW5ZLFxuICAgIGJ1dHRvbjogMCwgYnV0dG9uczogdHlwZS5lbmRzV2l0aChcImRvd25cIikgPyAxIDogMCwgcG9pbnRlcklkOiAxLCBwb2ludGVyVHlwZTogXCJtb3VzZVwiLCBpc1ByaW1hcnk6IHRydWUsXG4gIH07XG4gIGNvbnN0IEN0b3IgPSB0eXBlLnN0YXJ0c1dpdGgoXCJwb2ludGVyXCIpID8gUG9pbnRlckV2ZW50IDogTW91c2VFdmVudDtcbiAgcmV0dXJuIHRhcmdldC5kaXNwYXRjaEV2ZW50KG5ldyBDdG9yKHR5cGUsIGluaXQpKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVhbENsaWNrKGVsOiBFbGVtZW50KSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgY29uc3QgeyB4LCB5IH0gPSBjZW50ZXIoZWwpO1xuICAvLyBTaSBoYXkgYWxnbyBlbmNpbWEgcGVybyBlcyB1biBoaWpvIChpY29ubyBkZW50cm8gZGVsIGJvdMOzbiksIGRpc3BhcmFtb3Mgc29icmUgw6lsIGNvbW8gaGFyw61hIGVsIG5hdmVnYWRvci5cbiAgY29uc3QgdG9wID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludCh4LCB5KTtcbiAgY29uc3QgdGFyZ2V0ID0gdG9wICYmIGVsLmNvbnRhaW5zKHRvcCkgPyB0b3AgOiBlbDtcbiAgbW91c2UodGFyZ2V0LCBcInBvaW50ZXJvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2VvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcm1vdmVcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJtb3VzZW1vdmVcIiwgeCwgeSk7XG4gIGNvbnN0IGRvd24gPSBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcmRvd25cIiwgeCwgeSkgJiYgbW91c2UodGFyZ2V0LCBcIm1vdXNlZG93blwiLCB4LCB5KTtcbiAgaWYgKGRvd24gJiYgZWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCAmJiBlbC50YWJJbmRleCA+PSAtMSkgZWwuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcnVwXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2V1cFwiLCB4LCB5KTtcbiAgLy8gY2xpY2sgc2ludMOpdGljbzogZWwgbmF2ZWdhZG9yIGVqZWN1dGEgbGEgYWNjacOzbiBwb3IgZGVmZWN0byAoc2VndWlyIGVubGFjZSwgZW52aWFyIGZvcm3igKYpLlxuICBtb3VzZSh0YXJnZXQsIFwiY2xpY2tcIiwgeCwgeSk7XG59XG5cbmNvbnN0IE5PX1RZUElORyA9IG5ldyBTZXQoW1wiZGF0ZVwiLCBcImRhdGV0aW1lLWxvY2FsXCIsIFwibW9udGhcIiwgXCJ3ZWVrXCIsIFwidGltZVwiLCBcImNvbG9yXCIsIFwicmFuZ2VcIl0pO1xuXG5mdW5jdGlvbiBzZXROYXRpdmUoZWw6IEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50LCB2OiBzdHJpbmcpIHtcbiAgLy8gRXN0YW1vcyBlbiBlbCDCq2lzb2xhdGVkIHdvcmxkwrsgZGVsIGNvbnRlbnQgc2NyaXB0OiBlc3RlIHNldHRlciBlcyBlbCBuYXRpdm8sXG4gIC8vIGFzw60gcXVlIGVsIHZhbHVlIHRyYWNrZXIgZGUgUmVhY3QgZGV0ZWN0YSBlbCBjYW1iaW8gYWwgcmVjaWJpciBlbCBldmVudG8gaW5wdXQuXG4gIGNvbnN0IHByb3RvID0gZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50ID8gSFRNTFRleHRBcmVhRWxlbWVudC5wcm90b3R5cGUgOiBIVE1MSW5wdXRFbGVtZW50LnByb3RvdHlwZTtcbiAgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90bywgXCJ2YWx1ZVwiKSEuc2V0IS5jYWxsKGVsLCB2KTtcbn1cblxuZnVuY3Rpb24gZmlyZUlucHV0KGVsOiBFbGVtZW50LCBkYXRhOiBzdHJpbmcgfCBudWxsLCBpbnB1dFR5cGUgPSBcImluc2VydFRleHRcIikge1xuICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBJbnB1dEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSwgZGF0YSwgaW5wdXRUeXBlIH0pKTtcbn1cblxuZnVuY3Rpb24ga2V5KGVsOiBFbGVtZW50LCB0eXBlOiBcImtleWRvd25cIiB8IFwia2V5cHJlc3NcIiB8IFwia2V5dXBcIiwgazogc3RyaW5nKSB7XG4gIHJldHVybiBlbC5kaXNwYXRjaEV2ZW50KFxuICAgIG5ldyBLZXlib2FyZEV2ZW50KHR5cGUsIHsga2V5OiBrLCBjb2RlOiBjb2RlRm9yKGspLCBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSB9KSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gY29kZUZvcihrOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoay5sZW5ndGggPT09IDEpIHtcbiAgICBpZiAoL1thLXpdL2kudGVzdChrKSkgcmV0dXJuIFwiS2V5XCIgKyBrLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKC9cXGQvLnRlc3QoaykpIHJldHVybiBcIkRpZ2l0XCIgKyBrO1xuICAgIGlmIChrID09PSBcIiBcIikgcmV0dXJuIFwiU3BhY2VcIjtcbiAgICByZXR1cm4gXCJcIjtcbiAgfVxuICByZXR1cm4gaztcbn1cblxuZnVuY3Rpb24gc2VsZWN0QWxsKGVsOiBIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudCkge1xuICB0cnkge1xuICAgIGVsLnNlbGVjdCgpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBudW1iZXIvZW1haWwgbm8gc29wb3J0YW4gc2VsZWNjacOzbiBlbiBhbGd1bm9zIG5hdmVnYWRvcmVzICovXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gdHlwZUludG8oZWw6IEVsZW1lbnQsIHZhbHVlOiBzdHJpbmcsIHM6IFNldHRpbmdzKSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgKGVsIGFzIEhUTUxFbGVtZW50KS5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG5cbiAgaWYgKChlbCBhcyBIVE1MRWxlbWVudCkuaXNDb250ZW50RWRpdGFibGUpIHtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZChcInNlbGVjdEFsbFwiKTtcbiAgICBpZiAodmFsdWUpIGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiaW5zZXJ0VGV4dFwiLCBmYWxzZSwgdmFsdWUpO1xuICAgIGVsc2UgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJkZWxldGVcIik7XG4gICAgaWYgKHRleHRPZihlbCkgIT09IHZhbHVlLnJlcGxhY2UoL1xccysvZywgXCIgXCIpLnRyaW0oKSkge1xuICAgICAgZWwudGV4dENvbnRlbnQgPSB2YWx1ZTtcbiAgICAgIGZpcmVJbnB1dChlbCwgdmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIGVkaXRhYmxlXCIpO1xuICBpZiAoZWwuZGlzYWJsZWQpIHRocm93IG5ldyBTdGVwRXJyb3IoYMKrJHtlbC5uYW1lIHx8IGVsLmlkfcK7IGVzdMOhIGRlc2hhYmlsaXRhZG9gKTtcblxuICBjb25zdCB0eXBlYWJsZSA9ICEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIE5PX1RZUElORy5oYXMoZWwudHlwZSkpO1xuXG4gIGlmICghdHlwZWFibGUgfHwgcy50eXBlTW9kZSA9PT0gXCJpbnN0YW50XCIpIHtcbiAgICBzZWxlY3RBbGwoZWwpO1xuICAgIGNvbnN0IG9rID0gdHlwZWFibGUgJiYgKHZhbHVlID8gZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJpbnNlcnRUZXh0XCIsIGZhbHNlLCB2YWx1ZSkgOiBkb2N1bWVudC5leGVjQ29tbWFuZChcImRlbGV0ZVwiKSk7XG4gICAgaWYgKCFvayB8fCBlbC52YWx1ZSAhPT0gdmFsdWUpIHtcbiAgICAgIHNldE5hdGl2ZShlbCwgdmFsdWUpO1xuICAgICAgZmlyZUlucHV0KGVsLCB2YWx1ZSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIENhcsOhY3RlciBhIGNhcsOhY3RlcjogbcOhcyBsZW50bywgcGVybyBkaXNwYXJhIGtleWRvd24va2V5dXAgcGFyYSB2YWxpZGFjaW9uZXMgeSBhdXRvY29tcGxldGFkb3MuXG4gICAgc2VsZWN0QWxsKGVsKTtcbiAgICBpZiAoIWRvY3VtZW50LmV4ZWNDb21tYW5kKFwiZGVsZXRlXCIpIHx8IGVsLnZhbHVlICE9PSBcIlwiKSB7XG4gICAgICBzZXROYXRpdmUoZWwsIFwiXCIpO1xuICAgICAgZmlyZUlucHV0KGVsLCBudWxsLCBcImRlbGV0ZUNvbnRlbnRCYWNrd2FyZFwiKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjaCBvZiB2YWx1ZSkge1xuICAgICAgY29uc3QgYWxsb3dlZCA9IGtleShlbCwgXCJrZXlkb3duXCIsIGNoKTtcbiAgICAgIGtleShlbCwgXCJrZXlwcmVzc1wiLCBjaCk7XG4gICAgICBpZiAoYWxsb3dlZCkge1xuICAgICAgICBjb25zdCBiZWZvcmUgPSBlbC52YWx1ZTtcbiAgICAgICAgaWYgKCFkb2N1bWVudC5leGVjQ29tbWFuZChcImluc2VydFRleHRcIiwgZmFsc2UsIGNoKSB8fCBlbC52YWx1ZSA9PT0gYmVmb3JlKSB7XG4gICAgICAgICAgc2V0TmF0aXZlKGVsLCBiZWZvcmUgKyBjaCk7XG4gICAgICAgICAgZmlyZUlucHV0KGVsLCBjaCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGtleShlbCwgXCJrZXl1cFwiLCBjaCk7XG4gICAgICBpZiAocy5rZXlEZWxheSkgYXdhaXQgc2xlZXAocy5rZXlEZWxheSk7XG4gICAgfVxuICB9XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG59XG5cbmZ1bmN0aW9uIHNlbGVjdE9wdGlvbihlbDogRWxlbWVudCwgdmFsdWU6IHN0cmluZywgb3B0aW9uVGV4dD86IHN0cmluZykge1xuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIHVuIDxzZWxlY3Q+XCIpO1xuICBjb25zdCBvcHRzID0gWy4uLmVsLm9wdGlvbnNdO1xuICBjb25zdCBvcHQgPVxuICAgIG9wdHMuZmluZCgobykgPT4gby52YWx1ZSA9PT0gdmFsdWUpID8/XG4gICAgKG9wdGlvblRleHQgPyBvcHRzLmZpbmQoKG8pID0+IG8udGV4dC50cmltKCkgPT09IG9wdGlvblRleHQpIDogdW5kZWZpbmVkKSA/P1xuICAgIG9wdHMuZmluZCgobykgPT4gby50ZXh0LnRyaW0oKSA9PT0gdmFsdWUpID8/XG4gICAgb3B0cy5maW5kKChvKSA9PiBvLnRleHQudHJpbSgpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModmFsdWUudG9Mb3dlckNhc2UoKSkpO1xuICBpZiAoIW9wdCkgdGhyb3cgbmV3IFN0ZXBFcnJvcihgRWwgc2VsZWN0IG5vIHRpZW5lIGxhIG9wY2nDs24gwqske29wdGlvblRleHQgPz8gdmFsdWV9wrtgKTtcbiAgZWwuZm9jdXMoKTtcbiAgZWwudmFsdWUgPSBvcHQudmFsdWU7XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0Q2hlY2tlZChlbDogRWxlbWVudCwgd2FudDogYm9vbGVhbikge1xuICBpZiAoY2hlY2tlZE9mKGVsKSA9PT0gd2FudCkgcmV0dXJuO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGVsLnR5cGUgPT09IFwicmFkaW9cIiAmJiAhd2FudCkge1xuICAgIHRocm93IG5ldyBTdGVwRXJyb3IoXCJVbiByYWRpbyBubyBzZSBwdWVkZSBkZXNtYXJjYXI7IG1hcmNhIG90cmEgb3BjacOzbiBkZWwgZ3J1cG9cIik7XG4gIH1cbiAgaWYgKGlzVmlzaWJsZShlbCkpIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gIGVsc2UgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5sYWJlbHM/LlswXSAmJiBpc1Zpc2libGUoZWwubGFiZWxzWzBdKSkgYXdhaXQgcmVhbENsaWNrKGVsLmxhYmVsc1swXSk7XG4gIGVsc2UgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICBpZiAoY2hlY2tlZE9mKGVsKSAhPT0gd2FudCAmJiBlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHtcbiAgICBlbC5jaGVja2VkID0gd2FudDtcbiAgICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG4gICAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgfVxufVxuXG5jb25zdCBGT0NVU0FCTEUgPSAnYVtocmVmXSwgYnV0dG9uLCBpbnB1dCwgc2VsZWN0LCB0ZXh0YXJlYSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCBbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT1cImZhbHNlXCJdKSc7XG5cbmFzeW5jIGZ1bmN0aW9uIHByZXNzKGVsOiBFbGVtZW50LCBrOiBzdHJpbmcpIHtcbiAgY29uc3QgZG93biA9IGtleShlbCwgXCJrZXlkb3duXCIsIGspO1xuICBpZiAoayA9PT0gXCJFbnRlclwiKSBrZXkoZWwsIFwia2V5cHJlc3NcIiwgayk7XG4gIGlmIChkb3duKSB7XG4gICAgaWYgKGsgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5mb3JtKSB7XG4gICAgICAgIC8vIEVudsOtbyBpbXBsw61jaXRvOiBlbCBuYXZlZ2Fkb3IgY2xpY2EgZWwgYm90w7NuIGRlIHN1Ym1pdCBwb3IgZGVmZWN0by5cbiAgICAgICAgY29uc3QgYnRuID0gZWwuZm9ybS5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PignYnV0dG9uW3R5cGU9XCJzdWJtaXRcIl0sIGJ1dHRvbjpub3QoW3R5cGVdKSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgaW5wdXRbdHlwZT1cImltYWdlXCJdJyk7XG4gICAgICAgIGlmIChidG4pIGF3YWl0IHJlYWxDbGljayhidG4pO1xuICAgICAgICBlbHNlIGVsLmZvcm0ucmVxdWVzdFN1Ym1pdCgpO1xuICAgICAgfSBlbHNlIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoayA9PT0gXCJUYWJcIikge1xuICAgICAgY29uc3QgYWxsID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KEZPQ1VTQUJMRSldLmZpbHRlcigoZSkgPT4gaXNWaXNpYmxlKGUpICYmICEoZSBhcyBIVE1MSW5wdXRFbGVtZW50KS5kaXNhYmxlZCk7XG4gICAgICBjb25zdCBpID0gYWxsLmluZGV4T2YoZWwgYXMgSFRNTEVsZW1lbnQpO1xuICAgICAgYWxsWyhpICsgMSkgJSBhbGwubGVuZ3RoXT8uZm9jdXMoKTtcbiAgICB9XG4gIH1cbiAga2V5KGVsLCBcImtleXVwXCIsIGspO1xufVxuXG4vKiogwr9BY3RpdmFyIGVzdGUgZWxlbWVudG8gcHVlZGUgY2FtYmlhciBkZSBww6FnaW5hPyAqL1xuZnVuY3Rpb24gbWF5TmF2aWdhdGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKGVsLmNsb3Nlc3QoXCJhW2hyZWZdXCIpKSByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgYnRuID0gZWwuY2xvc2VzdChcImJ1dHRvbiwgaW5wdXRcIik7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MQnV0dG9uRWxlbWVudCkgcmV0dXJuICEhYnRuLmZvcm0gJiYgYnRuLnR5cGUgPT09IFwic3VibWl0XCI7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSByZXR1cm4gISFidG4uZm9ybSAmJiAoW1wic3VibWl0XCIsIFwiaW1hZ2VcIl0uaW5jbHVkZXMoYnRuLnR5cGUpIHx8IGtpbmRPZihidG4pID09PSBcImZpbGxcIik7XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJ1blN0ZXAoc3RlcDogU3RlcCwgczogU2V0dGluZ3MpOiBQcm9taXNlPFN0ZXBSZXN1bHQ+IHtcbiAgY29uc3QgdGltZW91dCA9IHN0ZXAudGltZW91dCA/PyBzLnRpbWVvdXQ7XG4gIGxldCBuYXYgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBsZXQgdXNlZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGNvbnN0IHRhcmdldCA9IGFzeW5jICh2aXNpYmxlID0gdHJ1ZSkgPT4ge1xuICAgICAgY29uc3QgciA9IGF3YWl0IGZpbmQoc3RlcCwgdGltZW91dCwgdmlzaWJsZSk7XG4gICAgICB1c2VkID0gci5zZWxlY3RvcjtcbiAgICAgIGlmIChzLmhpZ2hsaWdodCkgb3ZlcmxheS5mbGFzaChyLmVsLCBzdGVwLmxhYmVsID8/IHN0ZXAudHlwZSwgTWF0aC5tYXgoNDAwLCBzLnN0ZXBEZWxheSArIDIwMCksIENPTE9SUy5ydW4pO1xuICAgICAgcmV0dXJuIHIuZWw7XG4gICAgfTtcblxuICAgIHN3aXRjaCAoc3RlcC50eXBlKSB7XG4gICAgICBjYXNlIFwiY2xpY2tcIjoge1xuICAgICAgICBjb25zdCBlbCA9IGF3YWl0IHRhcmdldCgpO1xuICAgICAgICBuYXYgPSBtYXlOYXZpZ2F0ZShlbCk7XG4gICAgICAgIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBcImZpbGxcIjoge1xuICAgICAgICAvLyBUb2xlcmFudGU6IHVuIMKrZmlsbMK7IHNvYnJlIHVuIHNlbGVjdCBvIGNoZWNrYm94IChwLiBlai4gaW1wb3J0YWRvIGRlIERldlRvb2xzKSBoYWNlIGxvIGzDs2dpY28uXG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHNlbGVjdE9wdGlvbihlbCwgc3RlcC52YWx1ZSA/PyBcIlwiKTtcbiAgICAgICAgZWxzZSBpZiAoa2luZE9mKGVsKSA9PT0gXCJjaGVja1wiKSBhd2FpdCBzZXRDaGVja2VkKGVsLCAhW1wiXCIsIFwiZmFsc2VcIiwgXCJvZmZcIiwgXCIwXCJdLmluY2x1ZGVzKHN0ZXAudmFsdWUgPz8gXCJcIikpO1xuICAgICAgICBlbHNlIGF3YWl0IHR5cGVJbnRvKGVsLCBzdGVwLnZhbHVlID8/IFwiXCIsIHMpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJzZWxlY3RcIjpcbiAgICAgICAgc2VsZWN0T3B0aW9uKGF3YWl0IHRhcmdldChmYWxzZSksIHN0ZXAudmFsdWUgPz8gXCJcIiwgc3RlcC5vcHRpb25UZXh0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiY2hlY2tcIjpcbiAgICAgICAgYXdhaXQgc2V0Q2hlY2tlZChhd2FpdCB0YXJnZXQoZmFsc2UpLCBzdGVwLnZhbHVlICE9PSBcImZhbHNlXCIpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJwcmVzc1wiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gc3RlcC5zZWxlY3RvciA/IGF3YWl0IHRhcmdldChmYWxzZSkgOiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA/PyBkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgbmF2ID0gKHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKSA9PT0gXCJFbnRlclwiICYmIG1heU5hdmlnYXRlKGVsKTtcbiAgICAgICAgYXdhaXQgcHJlc3MoZWwsIHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwid2FpdEZvclwiOlxuICAgICAgICBhd2FpdCB0YXJnZXQoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYXNzZXJ0VGV4dFwiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgY29uc3Qgd2FudCA9IChzdGVwLnZhbHVlID8/IFwiXCIpLnRyaW0oKTtcbiAgICAgICAgLy8gUmVpbnRlbnRhIGhhc3RhIGVsIHRpbWVvdXQ6IGVsIHRleHRvIHB1ZWRlIHRhcmRhciBlbiBhcGFyZWNlciAocmVzcHVlc3RhIGRlbCBzZXJ2aWRvcikuXG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIGxldCBoYXZlID0gXCJcIjtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICBoYXZlID0gZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50ID8gdmFsdWVPZihlbCkgOiB0ZXh0T2YoZWwpO1xuICAgICAgICAgIGlmIChoYXZlLmluY2x1ZGVzKHdhbnQpKSBicmVhaztcbiAgICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHRocm93IG5ldyBTdGVwRXJyb3IoYFNlIGVzcGVyYWJhIMKrJHt3YW50fcK7IHkgaGF5IMKrJHtoYXZlLnNsaWNlKDAsIDgwKX3Cu2ApO1xuICAgICAgICAgIGF3YWl0IHNsZWVwKDE1MCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgU3RlcEVycm9yKGBUaXBvIGRlIHBhc28gwqske3N0ZXAudHlwZX3CuyBubyBzZSBlamVjdXRhIGVuIGxhIHDDoWdpbmFgKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHVzZWRTZWxlY3RvcjogdXNlZCwgbWF5TmF2aWdhdGU6IG5hdiB9O1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpIH07XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhpZ2hsaWdodChzZWxlY3RvcnM6IHN0cmluZ1tdKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlKHNlbGVjdG9ycyk7XG4gIGlmICghcikgcmV0dXJuIGZhbHNlO1xuICBhd2FpdCBzY3JvbGxUbyhyLmVsKTtcbiAgb3ZlcmxheS5mbGFzaChyLmVsLCByLnNlbGVjdG9yLCAxNTAwLCBDT0xPUlMuY2xpY2spO1xuICByZXR1cm4gdHJ1ZTtcbn1cbiIsCiAgICAiLy8gR3JhYmFkb3IuIERvcyBtb2Rvczpcbi8vICAgcmVjb3JkIOKGkiBsYXMgaW50ZXJhY2Npb25lcyBvY3VycmVuIGRlIHZlcmRhZCB5IHNlIHZhbiBhbm90YW5kby5cbi8vICAgcG9pbnQgIOKGkiDCq3Nlw7FhbGFywrs6IGxvcyBjbGlja3MgZW4gYm90b25lcy9lbmxhY2VzIE5PIHNlIGVqZWN1dGFuLCBzb2xvIHNlIGFub3Rhbi5cbi8vICAgICAgICAgICAgSW5wdXRzLCBzZWxlY3RzIHkgY2hlY2tib3hlcyBmdW5jaW9uYW4gbm9ybWFsLCBhc8OtIHF1ZSBzZSBncmFiYSBzdSBlc3RhZG8uXG4vL1xuLy8gUmVnbGEgY2xhdmU6IGNsaWNhciB1biBpbnB1dCBubyBnZW5lcmEgdW4gwqtjbGlja8K7OyBnZW5lcmEgdW4gwqtmaWxswrsgY29uIHN1IGNvbnRlbmlkbyxcbi8vIHF1ZSBzZSB2YSBhY3R1YWxpemFuZG8gbWllbnRyYXMgZXNjcmliZXMgKGVsIGJhY2tncm91bmQgZnVzaW9uYSBwYXNvcyBkZWwgbWlzbW8gY2FtcG8pLlxuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvbWVzc2FnZXNcIjtcbmltcG9ydCB7IENPTE9SUywgb3ZlcmxheSB9IGZyb20gXCIuL292ZXJsYXlcIjtcbmltcG9ydCB7IGFjdGlvbmFibGUsIGJ1aWxkU2VsZWN0b3JzLCBjaGVja2VkT2YsIGRlc2NyaWJlLCBraW5kT2YsIHRyYWNrVm9sYXRpbGVDbGFzc2VzLCB2YWx1ZU9mLCB0eXBlIEFjdGlvbktpbmQgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG50eXBlIE1vZGUgPSBcInJlY29yZFwiIHwgXCJwb2ludFwiO1xuXG5sZXQgbW9kZTogTW9kZSB8IG51bGwgPSBudWxsO1xubGV0IHNlbmQ6IChzOiBSZWNvcmRlZFN0ZXApID0+IHZvaWQgPSAoKSA9PiB7fTtcbmNvbnN0IHBlbmRpbmdGaWxsID0gbmV3IE1hcDxFbGVtZW50LCBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pj4oKTtcblxuY29uc3QgVkVSQjogUmVjb3JkPEFjdGlvbktpbmQsIHN0cmluZz4gPSB7IGNsaWNrOiBcIkNsaWNrXCIsIGZpbGw6IFwiRXNjcmliaXJcIiwgc2VsZWN0OiBcIlNlbGVjY2lvbmFyXCIsIGNoZWNrOiBcIk1hcmNhclwiLCBmaWxlOiBcIkZpY2hlcm9cIiB9O1xuXG4vKiogQ29udmllcnRlIHVuIGVsZW1lbnRvIGVuIGVsIHBhc28gcXVlIGxlIGNvcnJlc3BvbmRlLCBjb24gc3UgZXN0YWRvIGFjdHVhbC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXB0dXJlKGVsOiBFbGVtZW50KTogUmVjb3JkZWRTdGVwIHwgbnVsbCB7XG4gIGNvbnN0IGtpbmQgPSBraW5kT2YoZWwpO1xuICBpZiAoa2luZCA9PT0gXCJmaWxlXCIpIHJldHVybiBudWxsO1xuICBjb25zdCBbc2VsZWN0b3IsIC4uLmZhbGxiYWNrc10gPSBidWlsZFNlbGVjdG9ycyhlbCk7XG4gIGNvbnN0IGJhc2UgPSB7IHNlbGVjdG9yLCBmYWxsYmFja3MsIGxhYmVsOiBkZXNjcmliZShlbCkgfTtcbiAgc3dpdGNoIChraW5kKSB7XG4gICAgY2FzZSBcImZpbGxcIjpcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwiZmlsbFwiLCB2YWx1ZTogdmFsdWVPZihlbCksIHNlY3JldDogKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnR5cGUgPT09IFwicGFzc3dvcmRcIiB8fCB1bmRlZmluZWQgfTtcbiAgICBjYXNlIFwic2VsZWN0XCI6IHtcbiAgICAgIGNvbnN0IHMgPSBlbCBhcyBIVE1MU2VsZWN0RWxlbWVudDtcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwic2VsZWN0XCIsIHZhbHVlOiBzLnZhbHVlLCBvcHRpb25UZXh0OiBzLnNlbGVjdGVkT3B0aW9uc1swXT8udGV4dC50cmltKCkgfTtcbiAgICB9XG4gICAgY2FzZSBcImNoZWNrXCI6XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCB0eXBlOiBcImNoZWNrXCIsIHZhbHVlOiBTdHJpbmcoY2hlY2tlZE9mKGVsKSkgfTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgdHlwZTogXCJjbGlja1wiIH07XG4gIH1cbn1cblxuZnVuY3Rpb24gZW1pdChlbDogRWxlbWVudCwgc3RlcDogUmVjb3JkZWRTdGVwIHwgbnVsbCkge1xuICBpZiAoIXN0ZXApIHJldHVybjtcbiAgc2VuZChzdGVwKTtcbiAgY29uc3Qgd2hhdCA9IHN0ZXAudHlwZSA9PT0gXCJmaWxsXCIgPyAoc3RlcC5zZWNyZXQgPyBcIuKAouKAouKAouKAolwiIDogYMKrJHsoc3RlcC52YWx1ZSA/PyBcIlwiKS5zbGljZSgwLCAzMCl9wrtgKSA6IFwiXCI7XG4gIG92ZXJsYXkudG9hc3QoYOKckyAke1ZFUkJbc3RlcC50eXBlIGFzIEFjdGlvbktpbmRdID8/IHN0ZXAudHlwZX06ICR7c3RlcC5sYWJlbH0gJHt3aGF0fWAudHJpbSgpLCBDT0xPUlNba2luZE9mKGVsKV0pO1xufVxuXG5mdW5jdGlvbiBmbHVzaEZpbGxzKCkge1xuICBmb3IgKGNvbnN0IFtlbCwgdF0gb2YgcGVuZGluZ0ZpbGwpIHtcbiAgICBjbGVhclRpbWVvdXQodCk7XG4gICAgc2VuZChjYXB0dXJlKGVsKSEpO1xuICB9XG4gIHBlbmRpbmdGaWxsLmNsZWFyKCk7XG59XG5cbmZ1bmN0aW9uIHNjaGVkdWxlRmlsbChlbDogRWxlbWVudCkge1xuICBjbGVhclRpbWVvdXQocGVuZGluZ0ZpbGwuZ2V0KGVsKSk7XG4gIHBlbmRpbmdGaWxsLnNldChcbiAgICBlbCxcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHBlbmRpbmdGaWxsLmRlbGV0ZShlbCk7XG4gICAgICBjb25zdCBzID0gY2FwdHVyZShlbCk7XG4gICAgICBpZiAocykgc2VuZChzKTtcbiAgICB9LCAzNTApLFxuICApO1xufVxuXG5jb25zdCB0YXJnZXRPZiA9IChlOiBFdmVudCk6IEVsZW1lbnQgfCBudWxsID0+IHtcbiAgY29uc3QgdCA9IGUuY29tcG9zZWRQYXRoKClbMF07XG4gIHJldHVybiB0IGluc3RhbmNlb2YgRWxlbWVudCA/IHQgOiBudWxsO1xufTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIExpc3RlbmVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gb25Nb3ZlKGU6IE1vdXNlRXZlbnQpIHtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGNvbnN0IGhpbnQgPSBrID09PSBcImZpbGVcIiA/IFwiRmljaGVybyAobm8gYXV0b21hdGl6YWJsZSlcIiA6IGAke1ZFUkJba119IMK3ICR7ZGVzY3JpYmUoZWwpfWA7XG4gIG92ZXJsYXkuc2hvdyhlbCwgaGludCwgQ09MT1JTW2tdKTtcbn1cblxuLyoqIEVuIG1vZG8gc2XDsWFsYXIsIGJsb3F1ZWEgYm90b25lcy9lbmxhY2VzIHBhcmEgcXVlIG5vIGhhZ2FuIG5hZGEgKGVsIHJlc3RvIGZ1bmNpb25hIG5vcm1hbCkuICovXG5mdW5jdGlvbiBibG9ja0luUG9pbnQoZTogRXZlbnQpIHtcbiAgaWYgKG1vZGUgIT09IFwicG9pbnRcIiB8fCAhZS5pc1RydXN0ZWQpIHJldHVybjtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gIGlmIChraW5kT2YoYWN0aW9uYWJsZSh0KSkgPT09IFwiY2xpY2tcIikge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uQ2xpY2soZTogTW91c2VFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0IHx8IG92ZXJsYXkub3ducyh0KSkgcmV0dXJuO1xuICBibG9ja0luUG9pbnQoZSk7XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGlmIChrID09PSBcImZpbGVcIikgcmV0dXJuIG92ZXJsYXkudG9hc3QoXCJMb3MgaW5wdXRzIGRlIGZpY2hlcm8gbm8gc2UgcHVlZGVuIGF1dG9tYXRpemFyXCIsIHVuZGVmaW5lZCwgdHJ1ZSk7XG4gIGlmIChrID09PSBcImNoZWNrXCIgfHwgayA9PT0gXCJzZWxlY3RcIikgcmV0dXJuOyAvLyBzZSBncmFiYW4gZW4gXCJjaGFuZ2VcIiBjb24gZWwgZXN0YWRvIGZpbmFsXG4gIGZsdXNoRmlsbHMoKTtcbiAgaWYgKGsgPT09IFwiZmlsbFwiKSB7XG4gICAgLy8gQ2xpY2FyIHVuIGlucHV0IGNvbiBjb250ZW5pZG8gPSByZWxsZW5hcmxvIGNvbiBlc2UgY29udGVuaWRvLlxuICAgIC8vIFNpIGVzdMOhIHZhY8OtbywgZWwgcGFzbyBzZSBjcmVhIGVuIGN1YW50byBlc2NyaWJhcy5cbiAgICBpZiAodmFsdWVPZihlbCkpIGVtaXQoZWwsIGNhcHR1cmUoZWwpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdChlbCwgY2FwdHVyZShlbCkpO1xufVxuXG5mdW5jdGlvbiBvbklucHV0KGU6IEV2ZW50KSB7XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgaWYgKGtpbmRPZihlbCkgPT09IFwiZmlsbFwiKSBzY2hlZHVsZUZpbGwoZWwpO1xufVxuXG5mdW5jdGlvbiBvbkNoYW5nZShlOiBFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGlmIChrID09PSBcImZpbGxcIikge1xuICAgIGNsZWFyVGltZW91dChwZW5kaW5nRmlsbC5nZXQoZWwpKTtcbiAgICBwZW5kaW5nRmlsbC5kZWxldGUoZWwpO1xuICAgIHNlbmQoY2FwdHVyZShlbCkhKTtcbiAgfSBlbHNlIGlmIChrID09PSBcInNlbGVjdFwiIHx8IGsgPT09IFwiY2hlY2tcIikge1xuICAgIGZsdXNoRmlsbHMoKTtcbiAgICBlbWl0KGVsLCBjYXB0dXJlKGVsKSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25LZXkoZTogS2V5Ym9hcmRFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGlmIChtb2RlID09PSBcInBvaW50XCIgJiYgZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc3RvcEhhbmRsZXIoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQpIHJldHVybjtcbiAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgJiYgdCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYga2luZE9mKHQpID09PSBcImZpbGxcIikge1xuICAgIGZsdXNoRmlsbHMoKTtcbiAgICBzZW5kKHsgdHlwZTogXCJwcmVzc1wiLCB2YWx1ZTogXCJFbnRlclwiLCBzZWxlY3RvcjogYnVpbGRTZWxlY3RvcnModClbMF0sIGxhYmVsOiBkZXNjcmliZSh0KSB9KTtcbiAgICBvdmVybGF5LnRvYXN0KGDinJMgVGVjbGE6IEVudGVyIGVuICR7ZGVzY3JpYmUodCl9YCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25MZWF2ZSgpIHtcbiAgZmx1c2hGaWxscygpO1xufVxuXG5jb25zdCBvblNjcm9sbCA9ICgpID0+IG92ZXJsYXkuaGlkZSgpO1xuXG5sZXQgc3RvcEhhbmRsZXI6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuY29uc3QgbGlzdGVuZXJzOiBbc3RyaW5nLCBFdmVudExpc3RlbmVyXVtdID0gW1xuICBbXCJtb3VzZW1vdmVcIiwgb25Nb3ZlIGFzIEV2ZW50TGlzdGVuZXJdLFxuICBbXCJwb2ludGVyZG93blwiLCBibG9ja0luUG9pbnRdLFxuICBbXCJtb3VzZWRvd25cIiwgYmxvY2tJblBvaW50XSxcbiAgW1wicG9pbnRlcnVwXCIsIGJsb2NrSW5Qb2ludF0sXG4gIFtcIm1vdXNldXBcIiwgYmxvY2tJblBvaW50XSxcbiAgW1wiY2xpY2tcIiwgb25DbGljayBhcyBFdmVudExpc3RlbmVyXSxcbiAgW1wiaW5wdXRcIiwgb25JbnB1dF0sXG4gIFtcImNoYW5nZVwiLCBvbkNoYW5nZV0sXG4gIFtcImtleWRvd25cIiwgb25LZXkgYXMgRXZlbnRMaXN0ZW5lcl0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcobTogTW9kZSwgc2luazogKHM6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCwgb25TdG9wOiAoKSA9PiB2b2lkKSB7XG4gIGlmIChtb2RlKSBzdG9wUmVjb3JkaW5nKCk7XG4gIG1vZGUgPSBtO1xuICBzZW5kID0gc2luaztcbiAgc3RvcEhhbmRsZXIgPSBvblN0b3A7XG4gIG92ZXJsYXkub25TdG9wID0gb25TdG9wO1xuICB0cmFja1ZvbGF0aWxlQ2xhc3Nlcyh0cnVlKTtcbiAgZm9yIChjb25zdCBbZXYsIGZuXSBvZiBsaXN0ZW5lcnMpIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2LCBmbiwgdHJ1ZSk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgb25MZWF2ZSk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIG9uU2Nyb2xsLCB0cnVlKTtcbiAgLy8gTGEgcMOtbGRvcmEgc29sbyBlbiBsYSBww6FnaW5hIHByaW5jaXBhbCwgbm8gZW4gY2FkYSBpZnJhbWUuXG4gIGlmICh3aW5kb3cgPT09IHdpbmRvdy50b3ApIG92ZXJsYXkuc2V0UGlsbChtKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0b3BSZWNvcmRpbmcoKSB7XG4gIGZsdXNoRmlsbHMoKTtcbiAgZm9yIChjb25zdCBbZXYsIGZuXSBvZiBsaXN0ZW5lcnMpIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKGV2LCBmbiwgdHJ1ZSk7XG4gIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgb25MZWF2ZSk7XG4gIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIG9uU2Nyb2xsLCB0cnVlKTtcbiAgdHJhY2tWb2xhdGlsZUNsYXNzZXMoZmFsc2UpO1xuICBtb2RlID0gbnVsbDtcbiAgb3ZlcmxheS5oaWRlKCk7XG4gIG92ZXJsYXkuc2V0UGlsbChudWxsKTtcbn1cblxuLyoqIFNlbGVjY2nDs24gZGUgdW4gw7puaWNvIGVsZW1lbnRvIChwYXJhIHJlLWFwdW50YXIgdW4gcGFzbykuIENsaWNrcyBibG9xdWVhZG9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBpY2tPbmNlKCk6IFByb21pc2U8UmVjb3JkZWRTdGVwIHwgbnVsbD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBjb25zdCBibG9jayA9IChlOiBFdmVudCkgPT4ge1xuICAgICAgaWYgKG92ZXJsYXkub3ducyh0YXJnZXRPZihlKSkpIHJldHVybjtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgfTtcbiAgICBjb25zdCBkb25lID0gKHI6IFJlY29yZGVkU3RlcCB8IG51bGwpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyLCB0cnVlKTtcbiAgICAgIGZvciAoY29uc3QgZXYgb2YgW1wicG9pbnRlcmRvd25cIiwgXCJtb3VzZWRvd25cIiwgXCJwb2ludGVydXBcIiwgXCJtb3VzZXVwXCJdKSB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihldiwgYmxvY2ssIHRydWUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBjbGljaywgdHJ1ZSk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwga2V5LCB0cnVlKTtcbiAgICAgIG92ZXJsYXkuaGlkZSgpO1xuICAgICAgY2FuY2VsUGljayA9ICgpID0+IHt9O1xuICAgICAgaWYgKCFtb2RlKSB0cmFja1ZvbGF0aWxlQ2xhc3NlcyhmYWxzZSk7XG4gICAgICByZXNvbHZlKHIpO1xuICAgIH07XG4gICAgY29uc3QgY2xpY2sgPSAoZTogTW91c2VFdmVudCkgPT4ge1xuICAgICAgYmxvY2soZSk7XG4gICAgICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gICAgICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gICAgICBkb25lKGNhcHR1cmUoYWN0aW9uYWJsZSh0KSkgPz8gbnVsbCk7XG4gICAgfTtcbiAgICBjb25zdCBrZXkgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZG9uZShudWxsKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRyYWNrVm9sYXRpbGVDbGFzc2VzKHRydWUpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyLCB0cnVlKTtcbiAgICBmb3IgKGNvbnN0IGV2IG9mIFtcInBvaW50ZXJkb3duXCIsIFwibW91c2Vkb3duXCIsIFwicG9pbnRlcnVwXCIsIFwibW91c2V1cFwiXSkgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXYsIGJsb2NrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNsaWNrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwga2V5LCB0cnVlKTtcbiAgICBjYW5jZWxQaWNrID0gKCkgPT4gZG9uZShudWxsKTtcbiAgICBpZiAod2luZG93ID09PSB3aW5kb3cudG9wKSBvdmVybGF5LnRvYXN0KFwiQ2xpY2EgZWwgZWxlbWVudG8gKEVzYyBwYXJhIGNhbmNlbGFyKVwiKTtcbiAgfSk7XG59XG5cbmV4cG9ydCBsZXQgY2FuY2VsUGljazogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuIiwKICAgICIvLyBDb250ZW50IHNjcmlwdDogcHVlbnRlIGVudHJlIGxhIHDDoWdpbmEgeSBsYSBleHRlbnNpw7NuLiBTZSBpbnllY3RhIGVuIHRvZG9zIGxvcyBmcmFtZXMuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCwgVG9CYWNrZ3JvdW5kLCBUb0NvbnRlbnQgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgaGlnaGxpZ2h0LCBydW5TdGVwIH0gZnJvbSBcIi4vcGxheWVyXCI7XG5pbXBvcnQgeyBjYW5jZWxQaWNrLCBwaWNrT25jZSwgc3RhcnRSZWNvcmRpbmcsIHN0b3BSZWNvcmRpbmcgfSBmcm9tIFwiLi9yZWNvcmRlclwiO1xuaW1wb3J0IHsgYnVpbGRTZWxlY3RvcnMsIHJlc29sdmUgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIF9fcmFzdHJvPzogYm9vbGVhbjtcbiAgfVxufVxuXG5mdW5jdGlvbiB0b0JnPFQgPSBhbnk+KG1zZzogVG9CYWNrZ3JvdW5kKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTGEgZXh0ZW5zacOzbiBzZSByZWNhcmfDsyB5IGVzdGUgc2NyaXB0IHF1ZWTDsyBodcOpcmZhbm8uXG4gICAgc3RvcFJlY29yZGluZygpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodW5kZWZpbmVkKTtcbiAgfVxufVxuXG5jb25zdCBzaW5rID0gKHN0ZXA6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RlcFwiLCBzdGVwIH0pO1xuY29uc3Qgb25TdG9wID0gKCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RvcFwiIH0pO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRnJhbWVzOiBoYW5kc2hha2UgcG9yIHBvc3RNZXNzYWdlIChmdW5jaW9uYSB0YW1iacOpbiBjcm9zcy1vcmlnaW4pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBNU0cgPSBcIl9fcmFzdHJvX2ZyYW1lXCI7XG4vKiogdG9rZW4g4oaSIDxpZnJhbWU+IGhpam8gcXVlIHNlIGFudW5jacOzIGNvbiDDqWwuICovXG5jb25zdCBhbm5vdW5jZWQgPSBuZXcgTWFwPHN0cmluZywgRWxlbWVudD4oKTtcblxuZnVuY3Rpb24gZnJhbWVFbGVtZW50Rm9yKHNvdXJjZTogTWVzc2FnZUV2ZW50U291cmNlIHwgbnVsbCk6IEVsZW1lbnQgfCB1bmRlZmluZWQge1xuICBpZiAoIXNvdXJjZSkgcmV0dXJuO1xuICByZXR1cm4gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWUsIGZyYW1lXCIpXS5maW5kKChmKSA9PiAoZiBhcyBIVE1MSUZyYW1lRWxlbWVudCkuY29udGVudFdpbmRvdyA9PT0gc291cmNlKTtcbn1cblxuZnVuY3Rpb24gb25GcmFtZU1lc3NhZ2UoZTogTWVzc2FnZUV2ZW50KSB7XG4gIGNvbnN0IGQgPSBlLmRhdGE7XG4gIGlmICghZCB8fCB0eXBlb2YgZCAhPT0gXCJvYmplY3RcIiB8fCBkW01TR10gPT0gbnVsbCB8fCB0eXBlb2YgZC50b2tlbiAhPT0gXCJzdHJpbmdcIikgcmV0dXJuO1xuICBpZiAoZFtNU0ddID09PSBcImFubm91bmNlXCIpIHtcbiAgICBjb25zdCBlbCA9IGZyYW1lRWxlbWVudEZvcihlLnNvdXJjZSk7XG4gICAgaWYgKGVsKSBhbm5vdW5jZWQuc2V0KGQudG9rZW4sIGVsKTtcbiAgfSBlbHNlIGlmIChkW01TR10gPT09IFwicHJvYmVcIiAmJiBlLnNvdXJjZSA9PT0gd2luZG93LnBhcmVudCAmJiB3aW5kb3cgIT09IHdpbmRvdy50b3ApIHtcbiAgICB2b2lkIHRvQmcoeyBraW5kOiBcImZyYW1lOnByb2JlXCIsIHRva2VuOiBkLnRva2VuIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbGVjdG9yc0ZvckFubm91bmNlZCh0b2tlbjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXSB8IG51bGw+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMCAmJiAhYW5ub3VuY2VkLmhhcyh0b2tlbik7IGkrKykgYXdhaXQgc2xlZXAoNTApO1xuICBjb25zdCBlbCA9IGFubm91bmNlZC5nZXQodG9rZW4pO1xuICBhbm5vdW5jZWQuZGVsZXRlKHRva2VuKTtcbiAgcmV0dXJuIGVsID8gYnVpbGRTZWxlY3RvcnMoZWwpIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVzb2x2ZUZyYW1lKHNlbGVjdG9yczogc3RyaW5nW10sIHRpbWVvdXQ6IG51bWJlcik6IFByb21pc2U8eyB0b2tlbj86IHN0cmluZzsgZXJyb3I/OiBzdHJpbmcgfT4ge1xuICBjb25zdCBlbmQgPSBwZXJmb3JtYW5jZS5ub3coKSArIHRpbWVvdXQ7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgY29uc3QgciA9IHJlc29sdmUoc2VsZWN0b3JzKTtcbiAgICBjb25zdCB3aW4gPSByICYmIChyLmVsIGFzIEhUTUxJRnJhbWVFbGVtZW50KS5jb250ZW50V2luZG93O1xuICAgIGlmICh3aW4pIHtcbiAgICAgIGNvbnN0IHRva2VuID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICAgIHdpbi5wb3N0TWVzc2FnZSh7IFtNU0ddOiBcInByb2JlXCIsIHRva2VuIH0sIFwiKlwiKTtcbiAgICAgIHJldHVybiB7IHRva2VuIH07XG4gICAgfVxuICAgIGlmIChwZXJmb3JtYW5jZS5ub3coKSA+IGVuZCkgcmV0dXJuIHsgZXJyb3I6IGBObyBzZSBlbmNvbnRyw7MgZWwgaWZyYW1lIMKrJHtzZWxlY3RvcnNbMF19wrtgIH07XG4gICAgYXdhaXQgc2xlZXAoMTAwKTtcbiAgfVxufVxuXG5pZiAoIXdpbmRvdy5fX3Jhc3Rybykge1xuICB3aW5kb3cuX19yYXN0cm8gPSB0cnVlO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgb25GcmFtZU1lc3NhZ2UpO1xuXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiBUb0NvbnRlbnQsIF9zZW5kZXIsIHJlcGx5KSA9PiB7XG4gICAgc3dpdGNoIChtc2cua2luZCkge1xuICAgICAgY2FzZSBcInBpbmdcIjpcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvblwiOlxuICAgICAgICBzdGFydFJlY29yZGluZyhtc2cubW9kZSwgc2luaywgb25TdG9wKTtcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvZmZcIjpcbiAgICAgICAgc3RvcFJlY29yZGluZygpO1xuICAgICAgICByZXBseSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICBjYXNlIFwicnVuLXN0ZXBcIjpcbiAgICAgICAgcnVuU3RlcChtc2cuc3RlcCwgbXNnLnNldHRpbmdzKS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIHJlc3B1ZXN0YSBhc8OtbmNyb25hXG4gICAgICBjYXNlIFwiaGlnaGxpZ2h0XCI6XG4gICAgICAgIGhpZ2hsaWdodChbbXNnLnNlbGVjdG9yLCAuLi4obXNnLmZhbGxiYWNrcyA/PyBbXSldKS50aGVuKChmb3VuZCkgPT4gcmVwbHkoeyBvazogZm91bmQgfSkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrXCI6XG4gICAgICAgIC8vIFNlIGRpZnVuZGUgYSB0b2RvcyBsb3MgZnJhbWVzOyByZXNwb25kZSBlbCBmcmFtZSBkb25kZSBjbGlxdWUgZWwgdXN1YXJpbyxcbiAgICAgICAgLy8gdHJhcyBwZWRpciBhbCBiYWNrZ3JvdW5kIHF1ZSBhw7FhZGEgbGEgcnV0YSBkZSBpZnJhbWVzLlxuICAgICAgICBwaWNrT25jZSgpLnRoZW4oYXN5bmMgKHN0ZXApID0+IHJlcGx5KHN0ZXAgPyAoKGF3YWl0IHRvQmc8UmVjb3JkZWRTdGVwPih7IGtpbmQ6IFwiZnJhbWU6bG9jYXRlXCIsIHN0ZXAgfSkpID8/IHN0ZXApIDogbnVsbCkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrOmNhbmNlbFwiOlxuICAgICAgICBjYW5jZWxQaWNrKCk7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTphbm5vdW5jZVwiOlxuICAgICAgICB3aW5kb3cucGFyZW50LnBvc3RNZXNzYWdlKHsgW01TR106IFwiYW5ub3VuY2VcIiwgdG9rZW46IG1zZy50b2tlbiB9LCBcIipcIik7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTpzZWxlY3RvcnNcIjpcbiAgICAgICAgc2VsZWN0b3JzRm9yQW5ub3VuY2VkKG1zZy50b2tlbikudGhlbihyZXBseSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgY2FzZSBcImZyYW1lOnJlc29sdmVcIjpcbiAgICAgICAgcmVzb2x2ZUZyYW1lKG1zZy5zZWxlY3RvcnMsIG1zZy50aW1lb3V0KS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcblxuICAvLyBBbCBjYXJnYXIgdW5hIHDDoWdpbmEgbnVldmEsIMK/c2VndWltb3MgZ3JhYmFuZG8gZW4gZXN0YSBwZXN0YcOxYT9cbiAgdG9CZzx7IG1vZGU/OiBcInJlY29yZFwiIHwgXCJwb2ludFwiIH0+KHsga2luZDogXCJyZWNvcmQ6c3RhdHVzXCIgfSkudGhlbigocikgPT4ge1xuICAgIGlmIChyPy5tb2RlKSBzdGFydFJlY29yZGluZyhyLm1vZGUsIHNpbmssIG9uU3RvcCk7XG4gIH0pO1xufVxuIgogIF0sCiAgIm1hcHBpbmdzIjogIjs7RUFHTyxTQUFTLGNBQWMsQ0FBQyxHQUFvQjtBQUFBLElBQ2pELE9BQ0UsRUFBRSxTQUFTLE1BQ1gsU0FBUyxLQUFLLENBQUMsS0FDZixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLG9CQUFvQixLQUFLLENBQUMsS0FDMUIsa0JBQWtCLEtBQUssQ0FBQyxLQUN4Qix1RkFBdUYsS0FBSyxDQUFDLEtBQzVGLHVCQUF1QixLQUFLLENBQUMsS0FBSyxTQUFTLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQyxLQUM1RCwyQ0FBMkMsS0FBSyxDQUFDO0FBQUE7QUFBQSxFQUk5QyxJQUFNLFFBQVEsQ0FBQyxPQUFlLElBQUksUUFBYyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQzs7O0VDZC9FLElBQU0sT0FBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFDTCxJQUFNLFNBQVMsRUFBRSxPQUFPLFdBQVcsTUFBTSxXQUFXLFFBQVEsV0FBVyxPQUFPLFdBQVcsTUFBTSxXQUFXLEtBQUssVUFBVTtBQUFBO0FBQUEsRUFFaEksTUFBTSxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ1E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDUixTQUFxQixNQUFNO0FBQUEsSUFFbkIsTUFBTSxHQUFHO0FBQUEsTUFDZixJQUFJLEtBQUssTUFBTTtBQUFBLFFBQWE7QUFBQSxNQUM1QixLQUFLLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFBQSxNQUN4QyxLQUFLLEtBQUssS0FBSztBQUFBLE1BQ2YsTUFBTSxPQUFPLEtBQUssS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFBQSxNQUNwRCxLQUFLLFlBQVksVUFBVTtBQUFBO0FBQUE7QUFBQSxNQUczQixLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE9BQU8sS0FBSyxjQUFjLE9BQU87QUFBQSxNQUN0QyxLQUFLLFdBQVcsS0FBSyxjQUFjLE1BQU07QUFBQSxNQUN6QyxLQUFLLFNBQVMsS0FBSyxjQUFjLFNBQVM7QUFBQSxNQUMxQyxLQUFLLGNBQWMsUUFBUSxFQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUFBLFFBQzdELEVBQUUsZ0JBQWdCO0FBQUEsUUFDbEIsS0FBSyxPQUFPO0FBQUEsT0FDYjtBQUFBLE1BQ0QsU0FBUyxnQkFBZ0IsWUFBWSxLQUFLLElBQUk7QUFBQTtBQUFBLElBR2hELElBQUksQ0FBQyxJQUFpQztBQUFBLE1BQ3BDLE9BQU8sQ0FBQyxDQUFDLEtBQUssUUFBUSxjQUFjLFNBQVMsT0FBTyxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQVMsRUFBRTtBQUFBO0FBQUEsSUFHeEYsSUFBSSxDQUFDLElBQWEsTUFBYyxRQUFnQixPQUFPLE9BQU87QUFBQSxNQUM1RCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLE1BQ25DLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTztBQUFBLFFBQzVCLFNBQVM7QUFBQSxRQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU87QUFBQSxRQUFPLEtBQUssR0FBRyxFQUFFLE1BQU07QUFBQSxRQUFPLE9BQU8sR0FBRyxFQUFFLFFBQVE7QUFBQSxRQUFPLFFBQVEsR0FBRyxFQUFFLFNBQVM7QUFBQSxNQUNySCxDQUFDO0FBQUEsTUFDRCxLQUFLLElBQUksTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQ3ZDLEtBQUssSUFBSSxNQUFNLFlBQVksT0FBTyxLQUFLO0FBQUEsTUFDdkMsS0FBSyxJQUFJLGNBQWM7QUFBQSxNQUN2QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUEsTUFDekIsTUFBTSxRQUFRLEVBQUUsTUFBTTtBQUFBLE1BQ3RCLEtBQUssSUFBSSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxPQUFPLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFBQSxNQUMzRSxLQUFLLElBQUksTUFBTSxNQUFNLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxHQUFHLEVBQUUsU0FBUztBQUFBO0FBQUEsSUFHakUsSUFBSSxHQUFHO0FBQUEsTUFDTCxJQUFJLENBQUMsS0FBSztBQUFBLFFBQUs7QUFBQSxNQUNmLEtBQUssSUFBSSxNQUFNLFVBQVU7QUFBQSxNQUN6QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUkzQixLQUFLLENBQUMsSUFBYSxNQUFjLEtBQUssS0FBSyxRQUFnQixPQUFPLEtBQUs7QUFBQSxNQUNyRSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUs7QUFBQSxNQUN6QixXQUFXLE1BQU0sS0FBSyxLQUFLLEdBQUcsRUFBRTtBQUFBO0FBQUEsSUFHbEMsT0FBTyxDQUFDLE1BQWlDO0FBQUEsTUFDdkMsS0FBSyxPQUFPO0FBQUEsTUFDWixJQUFJLENBQUMsTUFBTTtBQUFBLFFBQ1QsS0FBSyxLQUFLLE1BQU0sVUFBVTtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxLQUFLLFlBQVksVUFBVTtBQUFBLE1BQ2hDLEtBQUssU0FBUyxjQUFjLFNBQVMsV0FBVyxvQkFBb0I7QUFBQSxNQUNwRSxLQUFLLEtBQUssTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUc1QixLQUFLLENBQUMsTUFBYyxPQUFnQixPQUFPLE9BQU87QUFBQSxNQUNoRCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxTQUFTLGNBQWMsS0FBSztBQUFBLE1BQ3RDLEVBQUUsWUFBWSxXQUFXLE9BQU8sVUFBVTtBQUFBLE1BQzFDLElBQUk7QUFBQSxRQUFPLEVBQUUsTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQzNDLEVBQUUsY0FBYztBQUFBLE1BQ2hCLEtBQUssT0FBTyxZQUFZLENBQUM7QUFBQSxNQUN6QixXQUFXLE1BQU0sRUFBRSxPQUFPLEdBQUcsSUFBSTtBQUFBLE1BQ2pDLE9BQU8sS0FBSyxPQUFPLFNBQVMsU0FBUztBQUFBLFFBQUcsS0FBSyxPQUFPLGtCQUFtQixPQUFPO0FBQUE7QUFBQSxFQUVsRjtBQUFBLEVBRU8sSUFBTSxVQUFVLElBQUk7OztFQzlHM0IsSUFBTSxhQUFhLENBQUMsZUFBZSxnQkFBZ0IsYUFBYSxXQUFXLFdBQVcsWUFBWSxvQkFBb0I7QUFBQSxFQUV0SCxJQUFNLFlBQ0osd0dBQ0EscUdBQ0E7QUFBQSxFQUVLLElBQU0sVUFBVTtBQUFBLEVBRXZCLElBQU0sT0FBTyxDQUFDLE9BQWtDLEtBQUssSUFBSSxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFBQSxFQUVuRixJQUFNLGdCQUFnQjtBQUFBLEVBSXRCLElBQU0sY0FBYyxJQUFJLElBQUk7QUFBQSxJQUMxQjtBQUFBLElBQVU7QUFBQSxJQUFTO0FBQUEsSUFBVztBQUFBLElBQWdCO0FBQUEsSUFBZTtBQUFBLElBQVM7QUFBQSxJQUFXO0FBQUEsSUFBWTtBQUFBLElBQWE7QUFBQSxJQUMxRztBQUFBLElBQVk7QUFBQSxJQUFXO0FBQUEsSUFBUTtBQUFBLElBQVU7QUFBQSxJQUFZO0FBQUEsSUFBYTtBQUFBLElBQVc7QUFBQSxJQUFZO0FBQUEsSUFBVztBQUFBLElBQVc7QUFBQSxJQUMvRztBQUFBLElBQVM7QUFBQSxJQUFTO0FBQUEsSUFBWTtBQUFBLElBQVM7QUFBQSxJQUFXO0FBQUEsSUFBVztBQUFBLElBQVM7QUFBQSxJQUFZO0FBQUEsSUFBUztBQUFBLElBQVc7QUFBQSxFQUN4RyxDQUFDO0FBQUEsRUFFRCxTQUFTLFlBQVksQ0FBQyxHQUFvQjtBQUFBLElBQ3hDLElBQUksY0FBYyxLQUFLLENBQUM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNsQyxNQUFNLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixFQUFFLE9BQU8sT0FBTztBQUFBLElBQ2pFLE9BQU8sTUFBTSxTQUFTLEtBQUssWUFBWSxJQUFJLE1BQU0sR0FBRyxFQUFFLEVBQUcsWUFBWSxDQUFDO0FBQUE7QUFBQSxFQUt4RSxJQUFNLFdBQVcsSUFBSTtBQUFBLEVBQ3JCLElBQUksZ0JBQXlDO0FBQUEsRUFFN0MsU0FBUyxnQkFBZ0IsQ0FBQyxTQUEyQjtBQUFBLElBQ25ELFdBQVcsS0FBSyxTQUFTO0FBQUEsTUFDdkIsTUFBTSxTQUFTLElBQUksS0FBSyxFQUFFLFlBQVksSUFBSSxNQUFNLEtBQUssRUFBRSxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQ3RFLE1BQU0sUUFBUyxFQUFFLE9BQW1CO0FBQUEsTUFDcEMsV0FBVyxLQUFLO0FBQUEsUUFBTyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUM7QUFBQSxVQUFHLFNBQVMsSUFBSSxDQUFDO0FBQUEsTUFDekQsV0FBVyxLQUFLO0FBQUEsUUFBUSxJQUFJLENBQUMsTUFBTSxTQUFTLENBQUM7QUFBQSxVQUFHLFNBQVMsSUFBSSxDQUFDO0FBQUEsSUFDaEU7QUFBQTtBQUFBLEVBSUssU0FBUyxvQkFBb0IsQ0FBQyxJQUFhO0FBQUEsSUFDaEQsSUFBSSxNQUFNLENBQUMsZUFBZTtBQUFBLE1BQ3hCLGdCQUFnQixJQUFJLGlCQUFpQixnQkFBZ0I7QUFBQSxNQUNyRCxjQUFjLFFBQVEsU0FBUyxpQkFBaUIsRUFBRSxTQUFTLE1BQU0sWUFBWSxNQUFNLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxtQkFBbUIsS0FBSyxDQUFDO0FBQUEsSUFDMUksRUFBTyxTQUFJLENBQUMsTUFBTSxlQUFlO0FBQUEsTUFDL0IsaUJBQWlCLGNBQWMsWUFBWSxDQUFDO0FBQUEsTUFDNUMsY0FBYyxXQUFXO0FBQUEsTUFDekIsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxhQUFhLENBQUMsSUFBdUI7QUFBQSxJQUU1QyxJQUFJO0FBQUEsTUFBZSxpQkFBaUIsY0FBYyxZQUFZLENBQUM7QUFBQSxJQUMvRCxPQUFPLENBQUMsR0FBRyxHQUFHLFNBQVMsRUFBRSxPQUN2QixDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsU0FBUyxHQUFHLEtBQUssRUFBRSxTQUFTLEVBQ3RHO0FBQUE7QUFBQSxFQUdGLElBQU0sSUFBSSxDQUFDLE1BQWMsS0FBSyxVQUFVLENBQUM7QUFBQSxFQUlsQyxTQUFTLFNBQVMsQ0FBQyxJQUFzQjtBQUFBLElBQzlDLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFBYSxPQUFPO0FBQUEsSUFDNUIsSUFBSSxHQUFHLGVBQWUsRUFBRSxXQUFXO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDN0MsTUFBTSxLQUFLLGlCQUFpQixFQUFFO0FBQUEsSUFDOUIsT0FBTyxHQUFHLGVBQWUsWUFBWSxHQUFHLFlBQVk7QUFBQTtBQUFBLEVBSS9DLFNBQVMsTUFBTSxDQUFDLElBQXFCO0FBQUEsSUFDMUMsSUFBSSxjQUFjLG9CQUFvQixDQUFDLFVBQVUsVUFBVSxPQUFPLEVBQUUsU0FBUyxHQUFHLElBQUk7QUFBQSxNQUFHLE9BQU8sS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUMzRyxPQUFPLEtBQU0sR0FBbUIsYUFBYSxHQUFHLFdBQVc7QUFBQTtBQUFBLEVBRzdELFVBQVUsV0FBVyxDQUFDLE9BQThCLFVBQThCO0FBQUEsSUFDaEYsTUFBTSxTQUFTLFNBQVMsaUJBQWlCLE1BQU0sV0FBVyxZQUFZO0FBQUEsSUFDdEUsSUFBSSxJQUFJLE9BQU8sU0FBUztBQUFBLElBQ3hCLE9BQU8sR0FBRztBQUFBLE1BQ1IsTUFBTTtBQUFBLE1BQ04sTUFBTSxLQUFNLEVBQWM7QUFBQSxNQUMxQixJQUFJO0FBQUEsUUFBSSxPQUFPLFlBQVksRUFBRTtBQUFBLE1BQzdCLElBQUksT0FBTyxTQUFTO0FBQUEsSUFDdEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxNQUFNLENBQUMsTUFBeUI7QUFBQSxJQUN2QyxNQUFNLFNBQVMsS0FBSyxJQUFJO0FBQUEsSUFDeEIsTUFBTSxRQUFtQixDQUFDO0FBQUEsSUFDMUIsTUFBTSxVQUFxQixDQUFDO0FBQUEsSUFDNUIsTUFBTSxRQUFRLE9BQU8sWUFBWTtBQUFBLElBQ2pDLFdBQVcsTUFBTSxZQUFZLEdBQUc7QUFBQSxNQUM5QixJQUFJLEdBQUcsUUFBUSxtREFBbUQ7QUFBQSxRQUFHO0FBQUEsTUFDckUsTUFBTSxRQUFRLE9BQU8sU0FBUyxJQUFJO0FBQUEsTUFFbEMsSUFBSSxFQUFFLGNBQWMscUJBQXFCLEtBQUssR0FBRyxXQUFXLEVBQUUsU0FBUztBQUFBLFFBQU87QUFBQSxNQUM5RSxNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsTUFDbkIsSUFBSSxDQUFDLEtBQUssRUFBRSxTQUFTO0FBQUEsUUFBTztBQUFBLE1BQzVCLElBQUksTUFBTTtBQUFBLFFBQVEsTUFBTSxLQUFLLEVBQUU7QUFBQSxNQUMxQixTQUFJLEVBQUUsWUFBWSxFQUFFLFNBQVMsS0FBSztBQUFBLFFBQUcsUUFBUSxLQUFLLEVBQUU7QUFBQSxJQUMzRDtBQUFBLElBQ0EsTUFBTSxPQUFPLE1BQU0sU0FBUyxRQUFRO0FBQUEsSUFFcEMsTUFBTSxVQUFVLEtBQUssT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEtBQUssQ0FBQyxNQUFNLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFBQSxJQUNqRixPQUFPLE9BQU8sUUFBUSxJQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsU0FBUyxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBQUEsRUFHaEUsU0FBUyxPQUFPLENBQUMsTUFBeUI7QUFBQSxJQUN4QyxNQUFNLFNBQVMsS0FBSyxJQUFJLEVBQUUsWUFBWTtBQUFBLElBQ3RDLE1BQU0sTUFBaUIsQ0FBQztBQUFBLElBQ3hCLFdBQVcsU0FBUyxTQUFTLGlCQUFpQixPQUFPLEdBQUc7QUFBQSxNQUN0RCxJQUFJLEtBQUssTUFBTSxTQUFTLEVBQUUsWUFBWSxFQUFFLFFBQVEsVUFBVSxFQUFFLE1BQU0sVUFBVSxNQUFNO0FBQUEsUUFBUyxJQUFJLEtBQUssTUFBTSxPQUFPO0FBQUEsSUFDbkg7QUFBQSxJQUNBLFdBQVcsTUFBTSxTQUFTLGlCQUFpQixVQUFVLG1DQUFtQyxHQUFHO0FBQUEsTUFDekYsSUFBSSxLQUFLLEdBQUcsYUFBYSxZQUFZLENBQUMsRUFBRSxZQUFZLE1BQU07QUFBQSxRQUFRLElBQUksS0FBSyxFQUFFO0FBQUEsTUFDN0UsTUFBTSxLQUFLLEdBQUcsYUFBYSxpQkFBaUI7QUFBQSxNQUM1QyxJQUFJLElBQUk7QUFBQSxRQUNOLE1BQU0sSUFBSSxHQUNQLE1BQU0sS0FBSyxFQUNYLElBQUksQ0FBQyxPQUFPLFNBQVMsZUFBZSxFQUFFLEdBQUcsYUFBYSxFQUFFLEVBQ3hELEtBQUssR0FBRztBQUFBLFFBQ1gsSUFBSSxLQUFLLENBQUMsRUFBRSxZQUFZLE1BQU07QUFBQSxVQUFRLElBQUksS0FBSyxFQUFFO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQUEsSUFDQSxJQUFJLENBQUMsSUFBSSxRQUFRO0FBQUEsTUFDZixXQUFXLE1BQU0sU0FBUyxpQkFBaUIsZUFBZSxHQUFHO0FBQUEsUUFDM0QsSUFBSSxLQUFLLEdBQUcsYUFBYSxhQUFhLENBQUMsRUFBRSxZQUFZLE1BQU07QUFBQSxVQUFRLElBQUksS0FBSyxFQUFFO0FBQUEsTUFDaEY7QUFBQSxJQUNGO0FBQUEsSUFDQSxPQUFPLE9BQU8sR0FBRztBQUFBO0FBQUEsRUFHbkIsU0FBUyxPQUFPLENBQUMsSUFBdUI7QUFBQSxJQUN0QyxNQUFNLE1BQU0sU0FBUyxTQUFTLElBQUksVUFBVSxNQUFNLFlBQVksNEJBQTRCLElBQUk7QUFBQSxJQUM5RixNQUFNLE1BQWlCLENBQUM7QUFBQSxJQUN4QixTQUFTLElBQUksRUFBRyxJQUFJLElBQUksZ0JBQWdCLEtBQUs7QUFBQSxNQUMzQyxNQUFNLElBQUksSUFBSSxhQUFhLENBQUM7QUFBQSxNQUM1QixJQUFJLGFBQWE7QUFBQSxRQUFTLElBQUksS0FBSyxDQUFDO0FBQUEsSUFDdEM7QUFBQSxJQUNBLE9BQU87QUFBQTtBQUFBLEVBR1QsU0FBUyxNQUFTLENBQUMsS0FBZTtBQUFBLElBQ2hDLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxHQUFHLENBQUM7QUFBQTtBQUFBLEVBSWxCLFNBQVMsVUFBVSxDQUFDLFVBQTZCO0FBQUEsSUFDdEQsSUFBSTtBQUFBLE1BQ0YsSUFBSSxTQUFTLFdBQVcsT0FBTztBQUFBLFFBQUcsT0FBTyxPQUFPLFFBQVEsU0FBUyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDMUUsSUFBSSxTQUFTLFdBQVcsUUFBUTtBQUFBLFFBQUcsT0FBTyxRQUFRLFFBQVEsU0FBUyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQUEsTUFDNUUsSUFBSSxTQUFTLFdBQVcsUUFBUTtBQUFBLFFBQUcsT0FBTyxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUM7QUFBQSxNQUNuRSxJQUFJLFNBQVMsV0FBVyxRQUFRLEdBQUc7QUFBQSxRQUVqQyxNQUFNLElBQUksU0FBUyxpQkFBaUIsZUFBZSxFQUFFLE9BQU8sU0FBUyxNQUFNLENBQUMsQ0FBQztBQUFBLFFBQzdFLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQUEsTUFDcEI7QUFBQSxNQUNBLE9BQU8sQ0FBQyxHQUFHLFNBQVMsaUJBQWlCLFFBQVEsQ0FBQztBQUFBLE1BQzlDLE1BQU07QUFBQSxNQUNOLE9BQU8sQ0FBQztBQUFBO0FBQUE7QUFBQSxFQUlaLFNBQVMsT0FBTyxDQUFDLEdBQW1CO0FBQUEsSUFDbEMsTUFBTSxJQUFJLEVBQUUsS0FBSztBQUFBLElBQ2pCLElBQUssRUFBRSxXQUFXLEdBQUcsS0FBSyxFQUFFLFNBQVMsR0FBRyxLQUFPLEVBQUUsV0FBVyxHQUFHLEtBQUssRUFBRSxTQUFTLEdBQUc7QUFBQSxNQUFJLE9BQU8sRUFBRSxNQUFNLEdBQUcsRUFBRTtBQUFBLElBQzFHLE9BQU87QUFBQTtBQUFBLEVBSUYsU0FBUyxPQUFPLENBQUMsV0FBK0Q7QUFBQSxJQUNyRixXQUFXLE9BQU8sV0FBVztBQUFBLE1BQzNCLE1BQU0sUUFBUSxXQUFXLEdBQUc7QUFBQSxNQUM1QixJQUFJLE1BQU0sV0FBVztBQUFBLFFBQUcsT0FBTyxFQUFFLElBQUksTUFBTSxJQUFLLFVBQVUsSUFBSTtBQUFBLE1BQzlELE1BQU0sTUFBTSxNQUFNLE9BQU8sU0FBUztBQUFBLE1BQ2xDLElBQUksSUFBSSxVQUFVO0FBQUEsUUFBRyxPQUFPLEVBQUUsSUFBSSxJQUFJLElBQUssVUFBVSxJQUFJO0FBQUEsTUFDekQsSUFBSSxNQUFNO0FBQUEsUUFBUSxPQUFPLEVBQUUsSUFBSSxNQUFNLElBQUssVUFBVSxJQUFJO0FBQUEsSUFDMUQ7QUFBQSxJQUNBLE9BQU87QUFBQTtBQUFBLEVBS1QsU0FBUyxRQUFRLENBQUMsS0FBYSxJQUFzQjtBQUFBLElBQ25ELE1BQU0sSUFBSSxXQUFXLEdBQUc7QUFBQSxJQUN4QixPQUFPLEVBQUUsV0FBVyxLQUFLLEVBQUUsT0FBTztBQUFBO0FBQUEsRUFHcEMsU0FBUyxPQUFPLENBQUMsSUFBcUI7QUFBQSxJQUNwQyxNQUFNLFFBQWtCLENBQUM7QUFBQSxJQUN6QixJQUFJLE1BQXNCO0FBQUEsSUFDMUIsT0FBTyxPQUFPLFFBQVEsU0FBUyxpQkFBaUI7QUFBQSxNQUM5QyxNQUFNLE1BQU0sSUFBSSxRQUFRLFlBQVk7QUFBQSxNQUNwQyxJQUFJLFFBQVEsTUFBTSxJQUFJLE1BQU0sQ0FBQyxlQUFlLElBQUksRUFBRSxHQUFHO0FBQUEsUUFDbkQsTUFBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLElBQUksRUFBRSxDQUFDO0FBQUEsUUFDdEMsTUFBTSxJQUFJLE1BQU0sS0FBSyxLQUFLO0FBQUEsUUFDMUIsSUFBSSxTQUFTLEdBQUcsRUFBRTtBQUFBLFVBQUcsT0FBTztBQUFBLFFBQzVCLE1BQU0sTUFBTTtBQUFBLE1BQ2Q7QUFBQSxNQUNBLElBQUksTUFBTTtBQUFBLE1BQ1YsTUFBTSxNQUFNLGNBQWMsR0FBRyxFQUFFLE1BQU0sR0FBRyxDQUFDO0FBQUEsTUFDekMsSUFBSSxJQUFJO0FBQUEsUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBQUEsTUFFbkUsTUFBTSxhQUFhLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxLQUFLLEtBQUs7QUFBQSxNQUM3QyxJQUFJLFNBQVMsWUFBWSxFQUFFO0FBQUEsUUFBRyxPQUFPO0FBQUEsTUFFckMsTUFBTSxTQUF5QixJQUFJO0FBQUEsTUFDbkMsSUFBSSxRQUFRO0FBQUEsUUFDVixNQUFNLE9BQU8sQ0FBQyxHQUFHLE9BQU8sUUFBUSxFQUFFLE9BQU8sQ0FBQyxNQUFNLEVBQUUsWUFBWSxJQUFLLE9BQU87QUFBQSxRQUMxRSxJQUFJLEtBQUssU0FBUztBQUFBLFVBQUcsT0FBTyxnQkFBZ0IsS0FBSyxRQUFRLEdBQUcsSUFBSTtBQUFBLE1BQ2xFO0FBQUEsTUFDQSxNQUFNLFFBQVEsR0FBRztBQUFBLE1BQ2pCLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSztBQUFBLE1BQzFCLElBQUksU0FBUyxHQUFHLEVBQUU7QUFBQSxRQUFHLE9BQU87QUFBQSxNQUM1QixNQUFNO0FBQUEsSUFDUjtBQUFBLElBQ0EsT0FBTyxNQUFNLEtBQUssS0FBSztBQUFBO0FBQUEsRUFJbEIsU0FBUyxjQUFjLENBQUMsSUFBdUI7QUFBQSxJQUNwRCxNQUFNLE1BQU0sR0FBRyxRQUFRLFlBQVk7QUFBQSxJQUNuQyxNQUFNLElBQWMsQ0FBQztBQUFBLElBRXJCLFdBQVcsS0FBSyxZQUFZO0FBQUEsTUFDMUIsTUFBTSxJQUFJLEdBQUcsYUFBYSxDQUFDO0FBQUEsTUFDM0IsSUFBSTtBQUFBLFFBQUcsRUFBRSxLQUFLLElBQUksS0FBSyxFQUFFLENBQUMsSUFBSTtBQUFBLElBQ2hDO0FBQUEsSUFDQSxJQUFJLEdBQUcsTUFBTSxDQUFDLGVBQWUsR0FBRyxFQUFFO0FBQUEsTUFBRyxFQUFFLEtBQUssTUFBTSxJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUM7QUFBQSxJQUVuRSxNQUFNLE9BQU8sR0FBRyxhQUFhLE1BQU07QUFBQSxJQUNuQyxJQUFJLE1BQU07QUFBQSxNQUNSLElBQUksY0FBYyxxQkFBcUIsR0FBRyxTQUFTLFdBQVcsR0FBRyxTQUFTLGVBQWUsR0FBRyxTQUFTLEdBQUcsVUFBVSxNQUFNO0FBQUEsUUFDdEgsRUFBRSxLQUFLLEdBQUcsWUFBWSxFQUFFLElBQUksWUFBWSxFQUFFLEdBQUcsS0FBSyxJQUFJO0FBQUEsTUFDeEQsRUFBTztBQUFBLFVBQUUsS0FBSyxHQUFHLFlBQVksRUFBRSxJQUFJLElBQUk7QUFBQSxJQUN6QztBQUFBLElBRUEsTUFBTSxZQUFZLEdBQUcsUUFBUSxPQUFPO0FBQUEsSUFDcEMsSUFBSSxXQUFXO0FBQUEsTUFDYixNQUFNLE1BQU0sVUFBVSxFQUFFO0FBQUEsTUFDeEIsSUFBSSxPQUFPLElBQUksVUFBVTtBQUFBLFFBQUksRUFBRSxLQUFLLFNBQVMsS0FBSztBQUFBLElBQ3BEO0FBQUEsSUFFQSxNQUFNLE9BQU8sR0FBRyxhQUFhLFlBQVk7QUFBQSxJQUN6QyxJQUFJO0FBQUEsTUFBTSxFQUFFLEtBQUssR0FBRyxrQkFBa0IsRUFBRSxJQUFJLElBQUk7QUFBQSxJQUNoRCxNQUFNLEtBQUssR0FBRyxhQUFhLGFBQWE7QUFBQSxJQUN4QyxJQUFJO0FBQUEsTUFBSSxFQUFFLEtBQUssR0FBRyxtQkFBbUIsRUFBRSxFQUFFLElBQUk7QUFBQSxJQUU3QyxJQUFJLENBQUMsV0FBVztBQUFBLE1BQ2QsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQ25CLElBQUksS0FBSyxFQUFFLFVBQVUsTUFBTSxDQUFDLEdBQUcsY0FBYyxPQUFPO0FBQUEsUUFBRyxFQUFFLEtBQUssUUFBUSxHQUFHO0FBQUEsSUFDM0U7QUFBQSxJQUVBLElBQUksY0FBYyxtQkFBbUI7QUFBQSxNQUNuQyxNQUFNLE9BQU8sR0FBRyxhQUFhLE1BQU07QUFBQSxNQUNuQyxJQUFJLFFBQVEsS0FBSyxTQUFTLE1BQU0sQ0FBQyxLQUFLLFdBQVcsYUFBYSxLQUFLLFNBQVM7QUFBQSxRQUFLLEVBQUUsS0FBSyxVQUFVLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDOUc7QUFBQSxJQUNBLElBQUksY0FBYyxxQkFBcUIsY0FBYyxrQkFBa0I7QUFBQSxNQUNyRSxNQUFNLE1BQU0sR0FBRyxhQUFhLEtBQUs7QUFBQSxNQUNqQyxJQUFJLE9BQU8sQ0FBQyxJQUFJLFdBQVcsT0FBTyxLQUFLLENBQUMsSUFBSSxXQUFXLGFBQWEsR0FBRztBQUFBLFFBRXJFLE1BQU0sT0FBTyxJQUFJLE1BQU0sTUFBTSxFQUFFO0FBQUEsUUFDL0IsRUFBRSxLQUFLLFNBQVMsTUFBTSxHQUFHLFdBQVcsRUFBRSxHQUFHLE9BQU8sR0FBRyxZQUFZLEVBQUUsSUFBSSxJQUFJO0FBQUEsTUFDM0U7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLFFBQVEsR0FBRyxhQUFhLE9BQU87QUFBQSxJQUNyQyxJQUFJO0FBQUEsTUFBTyxFQUFFLEtBQUssR0FBRyxhQUFhLEVBQUUsS0FBSyxJQUFJO0FBQUEsSUFHN0MsTUFBTSxhQUFhLENBQUMsTUFBYztBQUFBLE1BQ2hDLE1BQU0sU0FBUyxFQUFFLFdBQVcsT0FBTztBQUFBLE1BQ25DLE1BQU0sTUFBTSxDQUFDLE1BQWUsTUFBTSxNQUFPLFVBQVUsR0FBRyxTQUFTLENBQUMsS0FBSyxPQUFPLENBQUMsTUFBTSxPQUFPLEVBQUU7QUFBQSxNQUM1RixNQUFNLElBQUksV0FBVyxDQUFDO0FBQUEsTUFDdEIsSUFBSSxFQUFFLFdBQVc7QUFBQSxRQUFHLE9BQU8sSUFBSSxFQUFFLEVBQUc7QUFBQSxNQUdwQyxJQUFJLENBQUM7QUFBQSxRQUFRLE9BQU87QUFBQSxNQUNwQixNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVM7QUFBQSxNQUM5QixPQUFPLElBQUksV0FBVyxLQUFLLElBQUksSUFBSSxFQUFHO0FBQUE7QUFBQSxJQUV4QyxNQUFNLFNBQVMsT0FBTyxDQUFDLEVBQUUsT0FBTyxVQUFVO0FBQUEsSUFDMUMsT0FBTyxLQUFLLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDdkIsT0FBTyxPQUFPLE1BQU0sRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBO0FBQUEsRUFLM0IsU0FBUyxTQUFTLENBQUMsSUFBcUI7QUFBQSxJQUM3QyxJQUFLLEdBQXdCLFFBQVEsUUFBUTtBQUFBLE1BQzNDLE1BQU0sSUFBSSxLQUFNLEdBQXdCLE9BQVEsR0FBSSxTQUFTLEVBQUUsUUFBUSxVQUFVLEVBQUU7QUFBQSxNQUNuRixJQUFJO0FBQUEsUUFBRyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxJQUNBLE1BQU0sT0FBTyxHQUFHLGFBQWEsWUFBWTtBQUFBLElBQ3pDLElBQUk7QUFBQSxNQUFNLE9BQU8sS0FBSyxJQUFJO0FBQUEsSUFDMUIsTUFBTSxLQUFLLEdBQUcsYUFBYSxpQkFBaUI7QUFBQSxJQUM1QyxJQUFJLElBQUk7QUFBQSxNQUNOLE1BQU0sSUFBSSxLQUFLLEdBQUcsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sU0FBUyxlQUFlLEVBQUUsR0FBRyxhQUFhLEVBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQztBQUFBLE1BQ2xHLElBQUk7QUFBQSxRQUFHLE9BQU87QUFBQSxJQUNoQjtBQUFBLElBQ0EsT0FBTztBQUFBO0FBQUEsRUFJRixTQUFTLFFBQVEsQ0FBQyxJQUFxQjtBQUFBLElBQzVDLElBQUksR0FBRyxRQUFRLE9BQU8sR0FBRztBQUFBLE1BQ3ZCLFFBQ0UsVUFBVSxFQUFFLEtBQ1osR0FBRyxhQUFhLGFBQWEsS0FDN0IsR0FBRyxhQUFhLE1BQU0sS0FDdEIsR0FBRyxNQUNILEdBQUcsYUFBYSxPQUFPLEtBQ3ZCLEdBQUcsUUFBUSxZQUFZLEdBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDZjtBQUFBLElBQ0EsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ25CLElBQUk7QUFBQSxNQUFHLE9BQU8sRUFBRSxTQUFTLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFBQSxJQUNyRCxRQUNFLEdBQUcsYUFBYSxZQUFZLEtBQzVCLEdBQUcsYUFBYSxPQUFPLEtBQ3ZCLEdBQUcsY0FBYyxLQUFLLEdBQUcsYUFBYSxLQUFLLEtBQzNDLEdBQUcsYUFBYSxNQUFNLEtBQ3RCLEdBQUcsUUFBUSxZQUFZLEdBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQUE7QUFBQSxFQUlSLFNBQVMsVUFBVSxDQUFDLFFBQTBCO0FBQUEsSUFDbkQsTUFBTSxPQUFPLE9BQU8sUUFBUSxPQUFPO0FBQUEsSUFDbkMsSUFBSTtBQUFBLE1BQU0sT0FBTztBQUFBLElBQ2pCLE1BQU0sWUFBWSxPQUFPLFFBQVEsU0FBUztBQUFBLElBQzFDLElBQUkscUJBQXFCLG9CQUFvQixVQUFVO0FBQUEsTUFBUyxPQUFPLFVBQVU7QUFBQSxJQUNqRixPQUFPLGFBQWE7QUFBQTtBQUFBLEVBR3RCLElBQU0sV0FBVyxJQUFJLElBQUk7QUFBQSxJQUN2QjtBQUFBLElBQUk7QUFBQSxJQUFRO0FBQUEsSUFBUztBQUFBLElBQVk7QUFBQSxJQUFVO0FBQUEsSUFBTztBQUFBLElBQU87QUFBQSxJQUN6RDtBQUFBLElBQVE7QUFBQSxJQUFrQjtBQUFBLElBQVM7QUFBQSxJQUFRO0FBQUEsSUFBUTtBQUFBLElBQVM7QUFBQSxFQUM5RCxDQUFDO0FBQUEsRUFJTSxTQUFTLE1BQU0sQ0FBQyxJQUF5QjtBQUFBLElBQzlDLElBQUksY0FBYztBQUFBLE1BQW1CLE9BQU87QUFBQSxJQUM1QyxJQUFJLGNBQWM7QUFBQSxNQUFxQixPQUFPLEdBQUcsV0FBVyxVQUFVO0FBQUEsSUFDdEUsSUFBSSxjQUFjLGtCQUFrQjtBQUFBLE1BQ2xDLElBQUksR0FBRyxTQUFTLGNBQWMsR0FBRyxTQUFTO0FBQUEsUUFBUyxPQUFPO0FBQUEsTUFDMUQsSUFBSSxHQUFHLFNBQVM7QUFBQSxRQUFRLE9BQU87QUFBQSxNQUUvQixJQUFJLFNBQVMsSUFBSSxHQUFHLElBQUk7QUFBQSxRQUFHLE9BQU8sR0FBRyxXQUFXLFVBQVU7QUFBQSxNQUMxRCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSyxHQUFtQjtBQUFBLE1BQW1CLE9BQU87QUFBQSxJQUNsRCxNQUFNLE9BQU8sR0FBRyxhQUFhLE1BQU07QUFBQSxJQUNuQyxJQUFJLFNBQVMsY0FBYyxTQUFTO0FBQUEsTUFBVSxPQUFPO0FBQUEsSUFDckQsT0FBTztBQUFBO0FBQUEsRUFHRixTQUFTLE9BQU8sQ0FBQyxJQUFxQjtBQUFBLElBQzNDLElBQUksY0FBYyxvQkFBb0IsY0FBYyx1QkFBdUIsY0FBYztBQUFBLE1BQW1CLE9BQU8sR0FBRztBQUFBLElBQ3RILE9BQU8sS0FBTSxHQUFtQixTQUFTO0FBQUE7QUFBQSxFQUdwQyxTQUFTLFNBQVMsQ0FBQyxJQUFzQjtBQUFBLElBQzlDLElBQUksY0FBYztBQUFBLE1BQWtCLE9BQU8sR0FBRztBQUFBLElBQzlDLE9BQU8sR0FBRyxhQUFhLGNBQWMsTUFBTTtBQUFBOzs7RUNwWDdDLE1BQU0sa0JBQWtCLE1BQU07QUFBQSxFQUFDO0FBQUEsRUFHL0IsZUFBZSxJQUFJLENBQUMsTUFBWSxTQUFpQixnQkFBcUU7QUFBQSxJQUNwSCxNQUFNLFlBQVksQ0FBQyxLQUFLLFVBQVUsR0FBSSxLQUFLLGFBQWEsQ0FBQyxDQUFFLEVBQUUsT0FBTyxPQUFPO0FBQUEsSUFDM0UsSUFBSSxDQUFDLFVBQVU7QUFBQSxNQUFRLE1BQU0sSUFBSSxVQUFVLDJCQUEyQjtBQUFBLElBQ3RFLE1BQU0sUUFBUSxZQUFZLElBQUk7QUFBQSxJQUM5QixJQUFJLGNBQWM7QUFBQSxJQUNsQixPQUFPLE1BQU07QUFBQSxNQUNYLE1BQU0sSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUMzQixJQUFJLEdBQUc7QUFBQSxRQUNMLElBQUksVUFBVSxFQUFFLEVBQUU7QUFBQSxVQUFHLE9BQU87QUFBQSxRQUU1QixJQUFJLENBQUMsZ0JBQWdCO0FBQUEsVUFDbkIsZ0JBQWdCLFlBQVksSUFBSTtBQUFBLFVBQ2hDLElBQUksWUFBWSxJQUFJLElBQUksY0FBYztBQUFBLFlBQU0sT0FBTztBQUFBLFFBQ3JEO0FBQUEsTUFDRjtBQUFBLE1BQ0EsSUFBSSxZQUFZLElBQUksSUFBSSxRQUFRLFNBQVM7QUFBQSxRQUN2QyxJQUFJO0FBQUEsVUFBRyxNQUFNLElBQUksVUFBVSxnQkFBZ0IsS0FBSyxTQUFTLFVBQVUsK0JBQStCO0FBQUEsUUFDbEcsTUFBTSxJQUFJLFVBQVUsbUJBQW1CLEtBQUssU0FBUyxVQUFVLFFBQVEsVUFBVSxLQUFLO0FBQUEsTUFDeEY7QUFBQSxNQUNBLE1BQU0sTUFBTSxHQUFHO0FBQUEsSUFDakI7QUFBQTtBQUFBLEVBR0YsU0FBUyxNQUFNLENBQUMsSUFBYTtBQUFBLElBQzNCLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLElBQ25DLE9BQU8sRUFBRSxHQUFHLEVBQUUsT0FBTyxFQUFFLFFBQVEsR0FBRyxHQUFHLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBRTtBQUFBO0FBQUEsRUFHNUQsZUFBZSxRQUFRLENBQUMsSUFBYTtBQUFBLElBQ25DLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLElBQ25DLElBQUksRUFBRSxNQUFNLEtBQUssRUFBRSxTQUFTLGVBQWUsRUFBRSxPQUFPLEtBQUssRUFBRSxRQUFRLFlBQVk7QUFBQSxNQUM3RSxHQUFHLGVBQWUsRUFBRSxPQUFPLFVBQVUsUUFBUSxVQUFVLFVBQVUsVUFBNEIsQ0FBQztBQUFBLE1BQzlGLE1BQU0sTUFBTSxFQUFFO0FBQUEsSUFDaEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxLQUFLLENBQUMsUUFBaUIsTUFBYyxHQUFXLEdBQVc7QUFBQSxJQUNsRSxNQUFNLE9BQXlCO0FBQUEsTUFDN0IsU0FBUztBQUFBLE1BQU0sWUFBWTtBQUFBLE1BQU0sVUFBVTtBQUFBLE1BQU0sTUFBTTtBQUFBLE1BQ3ZELFNBQVM7QUFBQSxNQUFHLFNBQVM7QUFBQSxNQUFHLFNBQVMsSUFBSTtBQUFBLE1BQVMsU0FBUyxJQUFJO0FBQUEsTUFDM0QsUUFBUTtBQUFBLE1BQUcsU0FBUyxLQUFLLFNBQVMsTUFBTSxJQUFJLElBQUk7QUFBQSxNQUFHLFdBQVc7QUFBQSxNQUFHLGFBQWE7QUFBQSxNQUFTLFdBQVc7QUFBQSxJQUNwRztBQUFBLElBQ0EsTUFBTSxPQUFPLEtBQUssV0FBVyxTQUFTLElBQUksZUFBZTtBQUFBLElBQ3pELE9BQU8sT0FBTyxjQUFjLElBQUksS0FBSyxNQUFNLElBQUksQ0FBQztBQUFBO0FBQUEsRUFHbEQsZUFBZSxTQUFTLENBQUMsSUFBYTtBQUFBLElBQ3BDLE1BQU0sU0FBUyxFQUFFO0FBQUEsSUFDakIsUUFBUSxHQUFHLE1BQU0sT0FBTyxFQUFFO0FBQUEsSUFFMUIsTUFBTSxNQUFNLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQztBQUFBLElBQzFDLE1BQU0sU0FBUyxPQUFPLEdBQUcsU0FBUyxHQUFHLElBQUksTUFBTTtBQUFBLElBQy9DLE1BQU0sUUFBUSxlQUFlLEdBQUcsQ0FBQztBQUFBLElBQ2pDLE1BQU0sUUFBUSxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQy9CLE1BQU0sUUFBUSxlQUFlLEdBQUcsQ0FBQztBQUFBLElBQ2pDLE1BQU0sUUFBUSxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQy9CLE1BQU0sT0FBTyxNQUFNLFFBQVEsZUFBZSxHQUFHLENBQUMsS0FBSyxNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUNsRixJQUFJLFFBQVEsY0FBYyxlQUFlLEdBQUcsWUFBWTtBQUFBLE1BQUksR0FBRyxNQUFNLEVBQUUsZUFBZSxLQUFLLENBQUM7QUFBQSxJQUM1RixNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUMvQixNQUFNLFFBQVEsV0FBVyxHQUFHLENBQUM7QUFBQSxJQUU3QixNQUFNLFFBQVEsU0FBUyxHQUFHLENBQUM7QUFBQTtBQUFBLEVBRzdCLElBQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxRQUFRLGtCQUFrQixTQUFTLFFBQVEsUUFBUSxTQUFTLE9BQU8sQ0FBQztBQUFBLEVBRS9GLFNBQVMsU0FBUyxDQUFDLElBQTRDLEdBQVc7QUFBQSxJQUd4RSxNQUFNLFFBQVEsY0FBYyxzQkFBc0Isb0JBQW9CLFlBQVksaUJBQWlCO0FBQUEsSUFDbkcsT0FBTyx5QkFBeUIsT0FBTyxPQUFPLEVBQUcsSUFBSyxLQUFLLElBQUksQ0FBQztBQUFBO0FBQUEsRUFHbEUsU0FBUyxTQUFTLENBQUMsSUFBYSxNQUFxQixZQUFZLGNBQWM7QUFBQSxJQUM3RSxHQUFHLGNBQWMsSUFBSSxXQUFXLFNBQVMsRUFBRSxTQUFTLE1BQU0sVUFBVSxNQUFNLE1BQU0sVUFBVSxDQUFDLENBQUM7QUFBQTtBQUFBLEVBRzlGLFNBQVMsR0FBRyxDQUFDLElBQWEsTUFBd0MsR0FBVztBQUFBLElBQzNFLE9BQU8sR0FBRyxjQUNSLElBQUksY0FBYyxNQUFNLEVBQUUsS0FBSyxHQUFHLE1BQU0sUUFBUSxDQUFDLEdBQUcsU0FBUyxNQUFNLFlBQVksTUFBTSxVQUFVLEtBQUssQ0FBQyxDQUN2RztBQUFBO0FBQUEsRUFHRixTQUFTLE9BQU8sQ0FBQyxHQUFtQjtBQUFBLElBQ2xDLElBQUksRUFBRSxXQUFXLEdBQUc7QUFBQSxNQUNsQixJQUFJLFNBQVMsS0FBSyxDQUFDO0FBQUEsUUFBRyxPQUFPLFFBQVEsRUFBRSxZQUFZO0FBQUEsTUFDbkQsSUFBSSxLQUFLLEtBQUssQ0FBQztBQUFBLFFBQUcsT0FBTyxVQUFVO0FBQUEsTUFDbkMsSUFBSSxNQUFNO0FBQUEsUUFBSyxPQUFPO0FBQUEsTUFDdEIsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLE9BQU87QUFBQTtBQUFBLEVBR1QsU0FBUyxTQUFTLENBQUMsSUFBNEM7QUFBQSxJQUM3RCxJQUFJO0FBQUEsTUFDRixHQUFHLE9BQU87QUFBQSxNQUNWLE1BQU07QUFBQTtBQUFBLEVBS1YsZUFBZSxRQUFRLENBQUMsSUFBYSxPQUFlLEdBQWE7QUFBQSxJQUMvRCxNQUFNLFNBQVMsRUFBRTtBQUFBLElBQ2hCLEdBQW1CLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztBQUFBLElBRWpELElBQUssR0FBbUIsbUJBQW1CO0FBQUEsTUFDekMsU0FBUyxZQUFZLFdBQVc7QUFBQSxNQUNoQyxJQUFJO0FBQUEsUUFBTyxTQUFTLFlBQVksY0FBYyxPQUFPLEtBQUs7QUFBQSxNQUNyRDtBQUFBLGlCQUFTLFlBQVksUUFBUTtBQUFBLE1BQ2xDLElBQUksT0FBTyxFQUFFLE1BQU0sTUFBTSxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUssR0FBRztBQUFBLFFBQ3BELEdBQUcsY0FBYztBQUFBLFFBQ2pCLFVBQVUsSUFBSSxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBLElBRUEsSUFBSSxFQUFFLGNBQWMsb0JBQW9CLGNBQWM7QUFBQSxNQUFzQixNQUFNLElBQUksVUFBVSw0QkFBNEI7QUFBQSxJQUM1SCxJQUFJLEdBQUc7QUFBQSxNQUFVLE1BQU0sSUFBSSxVQUFVLElBQUksR0FBRyxRQUFRLEdBQUcsd0JBQXdCO0FBQUEsSUFFL0UsTUFBTSxXQUFXLEVBQUUsY0FBYyxvQkFBb0IsVUFBVSxJQUFJLEdBQUcsSUFBSTtBQUFBLElBRTFFLElBQUksQ0FBQyxZQUFZLEVBQUUsYUFBYSxXQUFXO0FBQUEsTUFDekMsVUFBVSxFQUFFO0FBQUEsTUFDWixNQUFNLEtBQUssYUFBYSxRQUFRLFNBQVMsWUFBWSxjQUFjLE9BQU8sS0FBSyxJQUFJLFNBQVMsWUFBWSxRQUFRO0FBQUEsTUFDaEgsSUFBSSxDQUFDLE1BQU0sR0FBRyxVQUFVLE9BQU87QUFBQSxRQUM3QixVQUFVLElBQUksS0FBSztBQUFBLFFBQ25CLFVBQVUsSUFBSSxLQUFLO0FBQUEsTUFDckI7QUFBQSxJQUNGLEVBQU87QUFBQSxNQUVMLFVBQVUsRUFBRTtBQUFBLE1BQ1osSUFBSSxDQUFDLFNBQVMsWUFBWSxRQUFRLEtBQUssR0FBRyxVQUFVLElBQUk7QUFBQSxRQUN0RCxVQUFVLElBQUksRUFBRTtBQUFBLFFBQ2hCLFVBQVUsSUFBSSxNQUFNLHVCQUF1QjtBQUFBLE1BQzdDO0FBQUEsTUFDQSxXQUFXLE1BQU0sT0FBTztBQUFBLFFBQ3RCLE1BQU0sVUFBVSxJQUFJLElBQUksV0FBVyxFQUFFO0FBQUEsUUFDckMsSUFBSSxJQUFJLFlBQVksRUFBRTtBQUFBLFFBQ3RCLElBQUksU0FBUztBQUFBLFVBQ1gsTUFBTSxTQUFTLEdBQUc7QUFBQSxVQUNsQixJQUFJLENBQUMsU0FBUyxZQUFZLGNBQWMsT0FBTyxFQUFFLEtBQUssR0FBRyxVQUFVLFFBQVE7QUFBQSxZQUN6RSxVQUFVLElBQUksU0FBUyxFQUFFO0FBQUEsWUFDekIsVUFBVSxJQUFJLEVBQUU7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFBQSxRQUNBLElBQUksSUFBSSxTQUFTLEVBQUU7QUFBQSxRQUNuQixJQUFJLEVBQUU7QUFBQSxVQUFVLE1BQU0sTUFBTSxFQUFFLFFBQVE7QUFBQSxNQUN4QztBQUFBO0FBQUEsSUFFRixHQUFHLGNBQWMsSUFBSSxNQUFNLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUd6RCxTQUFTLFlBQVksQ0FBQyxJQUFhLE9BQWUsWUFBcUI7QUFBQSxJQUNyRSxJQUFJLEVBQUUsY0FBYztBQUFBLE1BQW9CLE1BQU0sSUFBSSxVQUFVLCtCQUErQjtBQUFBLElBQzNGLE1BQU0sT0FBTyxDQUFDLEdBQUcsR0FBRyxPQUFPO0FBQUEsSUFDM0IsTUFBTSxNQUNKLEtBQUssS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFVLEtBQUssTUFDakMsYUFBYSxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sVUFBVSxJQUFJLGNBQy9ELEtBQUssS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEtBQUssTUFBTSxLQUFLLEtBQ3hDLEtBQUssS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEtBQUssRUFBRSxZQUFZLEVBQUUsU0FBUyxNQUFNLFlBQVksQ0FBQyxDQUFDO0FBQUEsSUFDNUUsSUFBSSxDQUFDO0FBQUEsTUFBSyxNQUFNLElBQUksVUFBVSxpQ0FBaUMsY0FBYyxRQUFRO0FBQUEsSUFDckYsR0FBRyxNQUFNO0FBQUEsSUFDVCxHQUFHLFFBQVEsSUFBSTtBQUFBLElBQ2YsR0FBRyxjQUFjLElBQUksTUFBTSxTQUFTLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQ3RELEdBQUcsY0FBYyxJQUFJLE1BQU0sVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQTtBQUFBLEVBR3pELGVBQWUsVUFBVSxDQUFDLElBQWEsTUFBZTtBQUFBLElBQ3BELElBQUksVUFBVSxFQUFFLE1BQU07QUFBQSxNQUFNO0FBQUEsSUFDNUIsSUFBSSxjQUFjLG9CQUFvQixHQUFHLFNBQVMsV0FBVyxDQUFDLE1BQU07QUFBQSxNQUNsRSxNQUFNLElBQUksVUFBVSw2REFBNkQ7QUFBQSxJQUNuRjtBQUFBLElBQ0EsSUFBSSxVQUFVLEVBQUU7QUFBQSxNQUFHLE1BQU0sVUFBVSxFQUFFO0FBQUEsSUFDaEMsU0FBSSxjQUFjLG9CQUFvQixHQUFHLFNBQVMsTUFBTSxVQUFVLEdBQUcsT0FBTyxFQUFFO0FBQUEsTUFBRyxNQUFNLFVBQVUsR0FBRyxPQUFPLEVBQUU7QUFBQSxJQUM3RztBQUFBLE1BQUMsR0FBbUIsTUFBTTtBQUFBLElBQy9CLElBQUksVUFBVSxFQUFFLE1BQU0sUUFBUSxjQUFjLGtCQUFrQjtBQUFBLE1BQzVELEdBQUcsVUFBVTtBQUFBLE1BQ2IsR0FBRyxjQUFjLElBQUksTUFBTSxTQUFTLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLE1BQ3RELEdBQUcsY0FBYyxJQUFJLE1BQU0sVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxJQUN6RDtBQUFBO0FBQUEsRUFHRixJQUFNLFlBQVk7QUFBQSxFQUVsQixlQUFlLEtBQUssQ0FBQyxJQUFhLEdBQVc7QUFBQSxJQUMzQyxNQUFNLE9BQU8sSUFBSSxJQUFJLFdBQVcsQ0FBQztBQUFBLElBQ2pDLElBQUksTUFBTTtBQUFBLE1BQVMsSUFBSSxJQUFJLFlBQVksQ0FBQztBQUFBLElBQ3hDLElBQUksTUFBTTtBQUFBLE1BQ1IsSUFBSSxNQUFNLFNBQVM7QUFBQSxRQUNqQixJQUFJLGNBQWMsb0JBQW9CLEdBQUcsTUFBTTtBQUFBLFVBRTdDLE1BQU0sTUFBTSxHQUFHLEtBQUssY0FBMkIsc0ZBQXNGO0FBQUEsVUFDckksSUFBSTtBQUFBLFlBQUssTUFBTSxVQUFVLEdBQUc7QUFBQSxVQUN2QjtBQUFBLGVBQUcsS0FBSyxjQUFjO0FBQUEsUUFDN0IsRUFBTyxTQUFJLGNBQWMscUJBQXFCLGNBQWMsbUJBQW1CO0FBQUEsVUFDNUUsR0FBbUIsTUFBTTtBQUFBLFFBQzVCO0FBQUEsTUFDRixFQUFPLFNBQUksTUFBTSxPQUFPO0FBQUEsUUFDdEIsTUFBTSxNQUFNLENBQUMsR0FBRyxTQUFTLGlCQUE4QixTQUFTLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxVQUFVLENBQUMsS0FBSyxDQUFFLEVBQXVCLFFBQVE7QUFBQSxRQUNsSSxNQUFNLElBQUksSUFBSSxRQUFRLEVBQWlCO0FBQUEsUUFDdkMsSUFBSyxLQUFJLEtBQUssSUFBSSxTQUFTLE1BQU07QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxJQUNBLElBQUksSUFBSSxTQUFTLENBQUM7QUFBQTtBQUFBLEVBSXBCLFNBQVMsV0FBVyxDQUFDLElBQXNCO0FBQUEsSUFDekMsSUFBSSxHQUFHLFFBQVEsU0FBUztBQUFBLE1BQUcsT0FBTztBQUFBLElBQ2xDLE1BQU0sTUFBTSxHQUFHLFFBQVEsZUFBZTtBQUFBLElBQ3RDLElBQUksZUFBZTtBQUFBLE1BQW1CLE9BQU8sQ0FBQyxDQUFDLElBQUksUUFBUSxJQUFJLFNBQVM7QUFBQSxJQUN4RSxJQUFJLGVBQWU7QUFBQSxNQUFrQixPQUFPLENBQUMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxVQUFVLE9BQU8sRUFBRSxTQUFTLElBQUksSUFBSSxLQUFLLE9BQU8sR0FBRyxNQUFNO0FBQUEsSUFDckgsT0FBTztBQUFBO0FBQUEsRUFHVCxlQUFzQixPQUFPLENBQUMsTUFBWSxHQUFrQztBQUFBLElBQzFFLE1BQU0sVUFBVSxLQUFLLFdBQVcsRUFBRTtBQUFBLElBQ2xDLElBQUksTUFBTTtBQUFBLElBQ1YsSUFBSTtBQUFBLE1BQ0YsSUFBSTtBQUFBLE1BQ0osTUFBTSxTQUFTLE9BQU8sVUFBVSxTQUFTO0FBQUEsUUFDdkMsTUFBTSxJQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVMsT0FBTztBQUFBLFFBQzNDLE9BQU8sRUFBRTtBQUFBLFFBQ1QsSUFBSSxFQUFFO0FBQUEsVUFBVyxRQUFRLE1BQU0sRUFBRSxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxZQUFZLEdBQUcsR0FBRyxPQUFPLEdBQUc7QUFBQSxRQUMxRyxPQUFPLEVBQUU7QUFBQTtBQUFBLE1BR1gsUUFBUSxLQUFLO0FBQUEsYUFDTixTQUFTO0FBQUEsVUFDWixNQUFNLEtBQUssTUFBTSxPQUFPO0FBQUEsVUFDeEIsTUFBTSxZQUFZLEVBQUU7QUFBQSxVQUNwQixNQUFNLFVBQVUsRUFBRTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUFBLGFBQ0ssUUFBUTtBQUFBLFVBRVgsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQUEsVUFDN0IsSUFBSSxjQUFjO0FBQUEsWUFBbUIsYUFBYSxJQUFJLEtBQUssU0FBUyxFQUFFO0FBQUEsVUFDakUsU0FBSSxPQUFPLEVBQUUsTUFBTTtBQUFBLFlBQVMsTUFBTSxXQUFXLElBQUksQ0FBQyxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUcsRUFBRSxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7QUFBQSxVQUN0RztBQUFBLGtCQUFNLFNBQVMsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDO0FBQUEsVUFDM0M7QUFBQSxRQUNGO0FBQUEsYUFDSztBQUFBLFVBQ0gsYUFBYSxNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssU0FBUyxJQUFJLEtBQUssVUFBVTtBQUFBLFVBQ25FO0FBQUEsYUFDRztBQUFBLFVBQ0gsTUFBTSxXQUFXLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxVQUFVLE9BQU87QUFBQSxVQUM1RDtBQUFBLGFBQ0csU0FBUztBQUFBLFVBQ1osTUFBTSxLQUFLLEtBQUssV0FBVyxNQUFNLE9BQU8sS0FBSyxJQUFLLFNBQVMsaUJBQWlCLFNBQVM7QUFBQSxVQUNyRixPQUFPLEtBQUssU0FBUyxhQUFhLFdBQVcsWUFBWSxFQUFFO0FBQUEsVUFDM0QsTUFBTSxNQUFNLElBQUksS0FBSyxTQUFTLE9BQU87QUFBQSxVQUNyQztBQUFBLFFBQ0Y7QUFBQSxhQUNLO0FBQUEsVUFDSCxNQUFNLE9BQU87QUFBQSxVQUNiO0FBQUEsYUFDRyxjQUFjO0FBQUEsVUFDakIsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQUEsVUFDN0IsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUs7QUFBQSxVQUVyQyxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsVUFDOUIsSUFBSSxPQUFPO0FBQUEsVUFDWCxPQUFPLE1BQU07QUFBQSxZQUNYLE9BQU8sY0FBYyxvQkFBb0IsY0FBYyx1QkFBdUIsY0FBYyxvQkFBb0IsUUFBUSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQUEsWUFDdkksSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQUc7QUFBQSxZQUN6QixJQUFJLFlBQVksSUFBSSxJQUFJLFFBQVE7QUFBQSxjQUFTLE1BQU0sSUFBSSxVQUFVLGdCQUFnQixnQkFBZ0IsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQUEsWUFDakgsTUFBTSxNQUFNLEdBQUc7QUFBQSxVQUNqQjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUE7QUFBQSxVQUVFLE1BQU0sSUFBSSxVQUFVLGlCQUFpQixLQUFLLGtDQUFrQztBQUFBO0FBQUEsTUFFaEYsT0FBTyxFQUFFLElBQUksTUFBTSxjQUFjLE1BQU0sYUFBYSxJQUFJO0FBQUEsTUFDeEQsT0FBTyxHQUFHO0FBQUEsTUFDVixPQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sYUFBYSxRQUFRLEVBQUUsVUFBVSxPQUFPLENBQUMsRUFBRTtBQUFBO0FBQUE7QUFBQSxFQUkxRSxlQUFzQixTQUFTLENBQUMsV0FBdUM7QUFBQSxJQUNyRSxNQUFNLElBQUksUUFBUSxTQUFTO0FBQUEsSUFDM0IsSUFBSSxDQUFDO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDZixNQUFNLFNBQVMsRUFBRSxFQUFFO0FBQUEsSUFDbkIsUUFBUSxNQUFNLEVBQUUsSUFBSSxFQUFFLFVBQVUsTUFBTSxPQUFPLEtBQUs7QUFBQSxJQUNsRCxPQUFPO0FBQUE7OztFQzNSVCxJQUFJLE9BQW9CO0FBQUEsRUFDeEIsSUFBSSxPQUFrQyxNQUFNO0FBQUEsRUFDNUMsSUFBTSxjQUFjLElBQUk7QUFBQSxFQUV4QixJQUFNLE9BQW1DLEVBQUUsT0FBTyxTQUFTLE1BQU0sWUFBWSxRQUFRLGVBQWUsT0FBTyxVQUFVLE1BQU0sVUFBVTtBQUFBLEVBRzlILFNBQVMsT0FBTyxDQUFDLElBQWtDO0FBQUEsSUFDeEQsTUFBTSxPQUFPLE9BQU8sRUFBRTtBQUFBLElBQ3RCLElBQUksU0FBUztBQUFBLE1BQVEsT0FBTztBQUFBLElBQzVCLE9BQU8sYUFBYSxhQUFhLGVBQWUsRUFBRTtBQUFBLElBQ2xELE1BQU0sT0FBTyxFQUFFLFVBQVUsV0FBVyxPQUFPLFNBQVMsRUFBRSxFQUFFO0FBQUEsSUFDeEQsUUFBUTtBQUFBLFdBQ0Q7QUFBQSxRQUNILE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLFFBQVEsRUFBRSxHQUFHLFFBQVMsR0FBd0IsU0FBUyxjQUFjLFVBQVU7QUFBQSxXQUNuSCxVQUFVO0FBQUEsUUFDYixNQUFNLElBQUk7QUFBQSxRQUNWLE9BQU8sS0FBSyxNQUFNLE1BQU0sVUFBVSxPQUFPLEVBQUUsT0FBTyxZQUFZLEVBQUUsZ0JBQWdCLElBQUksS0FBSyxLQUFLLEVBQUU7QUFBQSxNQUNsRztBQUFBLFdBQ0s7QUFBQSxRQUNILE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUyxPQUFPLE9BQU8sVUFBVSxFQUFFLENBQUMsRUFBRTtBQUFBO0FBQUEsUUFFOUQsT0FBTyxLQUFLLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBLEVBSXRDLFNBQVMsSUFBSSxDQUFDLElBQWEsTUFBMkI7QUFBQSxJQUNwRCxJQUFJLENBQUM7QUFBQSxNQUFNO0FBQUEsSUFDWCxLQUFLLElBQUk7QUFBQSxJQUNULE1BQU0sT0FBTyxLQUFLLFNBQVMsU0FBVSxLQUFLLFNBQVMsU0FBUyxLQUFLLEtBQUssU0FBUyxJQUFJLE1BQU0sR0FBRyxFQUFFLE9BQVE7QUFBQSxJQUN0RyxRQUFRLE1BQU0sS0FBSyxLQUFLLEtBQUssU0FBdUIsS0FBSyxTQUFTLEtBQUssU0FBUyxPQUFPLEtBQUssR0FBRyxPQUFPLE9BQU8sRUFBRSxFQUFFO0FBQUE7QUFBQSxFQUduSCxTQUFTLFVBQVUsR0FBRztBQUFBLElBQ3BCLFlBQVksSUFBSSxNQUFNLGFBQWE7QUFBQSxNQUNqQyxhQUFhLENBQUM7QUFBQSxNQUNkLEtBQUssUUFBUSxFQUFFLENBQUU7QUFBQSxJQUNuQjtBQUFBLElBQ0EsWUFBWSxNQUFNO0FBQUE7QUFBQSxFQUdwQixTQUFTLFlBQVksQ0FBQyxJQUFhO0FBQUEsSUFDakMsYUFBYSxZQUFZLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDaEMsWUFBWSxJQUNWLElBQ0EsV0FBVyxNQUFNO0FBQUEsTUFDZixZQUFZLE9BQU8sRUFBRTtBQUFBLE1BQ3JCLE1BQU0sSUFBSSxRQUFRLEVBQUU7QUFBQSxNQUNwQixJQUFJO0FBQUEsUUFBRyxLQUFLLENBQUM7QUFBQSxPQUNaLEdBQUcsQ0FDUjtBQUFBO0FBQUEsRUFHRixJQUFNLFdBQVcsQ0FBQyxNQUE2QjtBQUFBLElBQzdDLE1BQU0sSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUFBLElBQzNCLE9BQU8sYUFBYSxVQUFVLElBQUk7QUFBQTtBQUFBLEVBS3BDLFNBQVMsTUFBTSxDQUFDLEdBQWU7QUFBQSxJQUM3QixNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDM0IsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQ3ZCLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixNQUFNLE9BQU8sTUFBTSxTQUFTLCtCQUErQixHQUFHLEtBQUssUUFBUSxTQUFTLEVBQUU7QUFBQSxJQUN0RixRQUFRLEtBQUssSUFBSSxNQUFNLE9BQU8sRUFBRTtBQUFBO0FBQUEsRUFJbEMsU0FBUyxZQUFZLENBQUMsR0FBVTtBQUFBLElBQzlCLElBQUksU0FBUyxXQUFXLENBQUMsRUFBRTtBQUFBLE1BQVc7QUFBQSxJQUN0QyxNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDM0IsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLE1BQU0sU0FBUztBQUFBLE1BQ3JDLEVBQUUsZUFBZTtBQUFBLE1BQ2pCLEVBQUUseUJBQXlCO0FBQUEsSUFDN0I7QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsR0FBZTtBQUFBLElBQzlCLElBQUksQ0FBQyxFQUFFO0FBQUEsTUFBVztBQUFBLElBQ2xCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUMzQixhQUFhLENBQUM7QUFBQSxJQUNkLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDbkIsSUFBSSxNQUFNO0FBQUEsTUFBUSxPQUFPLFFBQVEsTUFBTSxrREFBa0QsV0FBVyxJQUFJO0FBQUEsSUFDeEcsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLE1BQVU7QUFBQSxJQUNyQyxXQUFXO0FBQUEsSUFDWCxJQUFJLE1BQU0sUUFBUTtBQUFBLE1BR2hCLElBQUksUUFBUSxFQUFFO0FBQUEsUUFBRyxLQUFLLElBQUksUUFBUSxFQUFFLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztBQUFBO0FBQUEsRUFHdEIsU0FBUyxPQUFPLENBQUMsR0FBVTtBQUFBLElBQ3pCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDUixNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsSUFDdkIsSUFBSSxPQUFPLEVBQUUsTUFBTTtBQUFBLE1BQVEsYUFBYSxFQUFFO0FBQUE7QUFBQSxFQUc1QyxTQUFTLFFBQVEsQ0FBQyxHQUFVO0FBQUEsSUFDMUIsSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDbEIsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUNSLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDbkIsSUFBSSxNQUFNLFFBQVE7QUFBQSxNQUNoQixhQUFhLFlBQVksSUFBSSxFQUFFLENBQUM7QUFBQSxNQUNoQyxZQUFZLE9BQU8sRUFBRTtBQUFBLE1BQ3JCLEtBQUssUUFBUSxFQUFFLENBQUU7QUFBQSxJQUNuQixFQUFPLFNBQUksTUFBTSxZQUFZLE1BQU0sU0FBUztBQUFBLE1BQzFDLFdBQVc7QUFBQSxNQUNYLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ3RCO0FBQUE7QUFBQSxFQUdGLFNBQVMsS0FBSyxDQUFDLEdBQWtCO0FBQUEsSUFDL0IsSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDbEIsSUFBSSxTQUFTLFdBQVcsRUFBRSxRQUFRLFVBQVU7QUFBQSxNQUMxQyxFQUFFLGVBQWU7QUFBQSxNQUNqQixZQUFZO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDUixJQUFJLEVBQUUsUUFBUSxXQUFXLGFBQWEsb0JBQW9CLE9BQU8sQ0FBQyxNQUFNLFFBQVE7QUFBQSxNQUM5RSxXQUFXO0FBQUEsTUFDWCxLQUFLLEVBQUUsTUFBTSxTQUFTLE9BQU8sU0FBUyxVQUFVLGVBQWUsQ0FBQyxFQUFFLElBQUksT0FBTyxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQUEsTUFDMUYsUUFBUSxNQUFNLHFCQUFxQixTQUFTLENBQUMsR0FBRztBQUFBLElBQ2xEO0FBQUE7QUFBQSxFQUdGLFNBQVMsT0FBTyxHQUFHO0FBQUEsSUFDakIsV0FBVztBQUFBO0FBQUEsRUFHYixJQUFNLFdBQVcsTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUVwQyxJQUFJLGNBQTBCLE1BQU07QUFBQSxFQUVwQyxJQUFNLFlBQXVDO0FBQUEsSUFDM0MsQ0FBQyxhQUFhLE1BQXVCO0FBQUEsSUFDckMsQ0FBQyxlQUFlLFlBQVk7QUFBQSxJQUM1QixDQUFDLGFBQWEsWUFBWTtBQUFBLElBQzFCLENBQUMsYUFBYSxZQUFZO0FBQUEsSUFDMUIsQ0FBQyxXQUFXLFlBQVk7QUFBQSxJQUN4QixDQUFDLFNBQVMsT0FBd0I7QUFBQSxJQUNsQyxDQUFDLFNBQVMsT0FBTztBQUFBLElBQ2pCLENBQUMsVUFBVSxRQUFRO0FBQUEsSUFDbkIsQ0FBQyxXQUFXLEtBQXNCO0FBQUEsRUFDcEM7QUFBQSxFQUVPLFNBQVMsY0FBYyxDQUFDLEdBQVMsTUFBaUMsUUFBb0I7QUFBQSxJQUMzRixJQUFJO0FBQUEsTUFBTSxjQUFjO0FBQUEsSUFDeEIsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsY0FBYztBQUFBLElBQ2QsUUFBUSxTQUFTO0FBQUEsSUFDakIscUJBQXFCLElBQUk7QUFBQSxJQUN6QixZQUFZLElBQUksT0FBTztBQUFBLE1BQVcsT0FBTyxpQkFBaUIsSUFBSSxJQUFJLElBQUk7QUFBQSxJQUN0RSxPQUFPLGlCQUFpQixZQUFZLE9BQU87QUFBQSxJQUMzQyxPQUFPLGlCQUFpQixVQUFVLFVBQVUsSUFBSTtBQUFBLElBRWhELElBQUksV0FBVyxPQUFPO0FBQUEsTUFBSyxRQUFRLFFBQVEsQ0FBQztBQUFBO0FBQUEsRUFHdkMsU0FBUyxhQUFhLEdBQUc7QUFBQSxJQUM5QixXQUFXO0FBQUEsSUFDWCxZQUFZLElBQUksT0FBTztBQUFBLE1BQVcsT0FBTyxvQkFBb0IsSUFBSSxJQUFJLElBQUk7QUFBQSxJQUN6RSxPQUFPLG9CQUFvQixZQUFZLE9BQU87QUFBQSxJQUM5QyxPQUFPLG9CQUFvQixVQUFVLFVBQVUsSUFBSTtBQUFBLElBQ25ELHFCQUFxQixLQUFLO0FBQUEsSUFDMUIsT0FBTztBQUFBLElBQ1AsUUFBUSxLQUFLO0FBQUEsSUFDYixRQUFRLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFJZixTQUFTLFFBQVEsR0FBaUM7QUFBQSxJQUN2RCxPQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFBQSxNQUM5QixNQUFNLFFBQVEsQ0FBQyxNQUFhO0FBQUEsUUFDMUIsSUFBSSxRQUFRLEtBQUssU0FBUyxDQUFDLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDL0IsRUFBRSxlQUFlO0FBQUEsUUFDakIsRUFBRSx5QkFBeUI7QUFBQTtBQUFBLE1BRTdCLE1BQU0sT0FBTyxDQUFDLE1BQTJCO0FBQUEsUUFDdkMsT0FBTyxvQkFBb0IsYUFBYSxRQUF5QixJQUFJO0FBQUEsUUFDckUsV0FBVyxNQUFNLENBQUMsZUFBZSxhQUFhLGFBQWEsU0FBUztBQUFBLFVBQUcsT0FBTyxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxRQUNqSCxPQUFPLG9CQUFvQixTQUFTLE9BQU8sSUFBSTtBQUFBLFFBQy9DLE9BQU8sb0JBQW9CLFdBQVcsS0FBSyxJQUFJO0FBQUEsUUFDL0MsUUFBUSxLQUFLO0FBQUEsUUFDYixhQUFhLE1BQU07QUFBQSxRQUNuQixJQUFJLENBQUM7QUFBQSxVQUFNLHFCQUFxQixLQUFLO0FBQUEsUUFDckMsUUFBUSxDQUFDO0FBQUE7QUFBQSxNQUVYLE1BQU0sUUFBUSxDQUFDLE1BQWtCO0FBQUEsUUFDL0IsTUFBTSxDQUFDO0FBQUEsUUFDUCxNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsUUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDM0IsS0FBSyxRQUFRLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSTtBQUFBO0FBQUEsTUFFckMsTUFBTSxNQUFNLENBQUMsTUFBcUI7QUFBQSxRQUNoQyxJQUFJLEVBQUUsUUFBUSxVQUFVO0FBQUEsVUFDdEIsRUFBRSxlQUFlO0FBQUEsVUFDakIsS0FBSyxJQUFJO0FBQUEsUUFDWDtBQUFBO0FBQUEsTUFFRixxQkFBcUIsSUFBSTtBQUFBLE1BQ3pCLE9BQU8saUJBQWlCLGFBQWEsUUFBeUIsSUFBSTtBQUFBLE1BQ2xFLFdBQVcsTUFBTSxDQUFDLGVBQWUsYUFBYSxhQUFhLFNBQVM7QUFBQSxRQUFHLE9BQU8saUJBQWlCLElBQUksT0FBTyxJQUFJO0FBQUEsTUFDOUcsT0FBTyxpQkFBaUIsU0FBUyxPQUFPLElBQUk7QUFBQSxNQUM1QyxPQUFPLGlCQUFpQixXQUFXLEtBQUssSUFBSTtBQUFBLE1BQzVDLGFBQWEsTUFBTSxLQUFLLElBQUk7QUFBQSxNQUM1QixJQUFJLFdBQVcsT0FBTztBQUFBLFFBQUssUUFBUSxNQUFNLHVDQUF1QztBQUFBLEtBQ2pGO0FBQUE7QUFBQSxFQUdJLElBQUksYUFBeUIsTUFBTTs7O0VDaE8xQyxTQUFTLElBQWEsQ0FBQyxLQUEyQztBQUFBLElBQ2hFLElBQUk7QUFBQSxNQUNGLE9BQU8sT0FBTyxRQUFRLFlBQVksR0FBRyxFQUFFLE1BQU0sTUFBRztBQUFBLFFBQUc7QUFBQSxPQUFTO0FBQUEsTUFDNUQsTUFBTTtBQUFBLE1BRU4sY0FBYztBQUFBLE1BQ2QsT0FBTyxRQUFRLFFBQVEsU0FBUztBQUFBO0FBQUE7QUFBQSxFQUlwQyxJQUFNLE9BQU8sQ0FBQyxTQUF1QixLQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDNUUsSUFBTSxTQUFTLE1BQU0sS0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUl0RCxJQUFNLE1BQU07QUFBQSxFQUVaLElBQU0sWUFBWSxJQUFJO0FBQUEsRUFFdEIsU0FBUyxlQUFlLENBQUMsUUFBd0Q7QUFBQSxJQUMvRSxJQUFJLENBQUM7QUFBQSxNQUFRO0FBQUEsSUFDYixPQUFPLENBQUMsR0FBRyxTQUFTLGlCQUFpQixlQUFlLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTyxFQUF3QixrQkFBa0IsTUFBTTtBQUFBO0FBQUEsRUFHdEgsU0FBUyxjQUFjLENBQUMsR0FBaUI7QUFBQSxJQUN2QyxNQUFNLElBQUksRUFBRTtBQUFBLElBQ1osSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksRUFBRSxRQUFRLFFBQVEsT0FBTyxFQUFFLFVBQVU7QUFBQSxNQUFVO0FBQUEsSUFDbEYsSUFBSSxFQUFFLFNBQVMsWUFBWTtBQUFBLE1BQ3pCLE1BQU0sS0FBSyxnQkFBZ0IsRUFBRSxNQUFNO0FBQUEsTUFDbkMsSUFBSTtBQUFBLFFBQUksVUFBVSxJQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUEsSUFDbkMsRUFBTyxTQUFJLEVBQUUsU0FBUyxXQUFXLEVBQUUsV0FBVyxPQUFPLFVBQVUsV0FBVyxPQUFPLEtBQUs7QUFBQSxNQUMvRSxLQUFLLEVBQUUsTUFBTSxlQUFlLE9BQU8sRUFBRSxNQUFNLENBQUM7QUFBQSxJQUNuRDtBQUFBO0FBQUEsRUFHRixlQUFlLHFCQUFxQixDQUFDLE9BQXlDO0FBQUEsSUFDNUUsU0FBUyxJQUFJLEVBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxJQUFJLEtBQUssR0FBRztBQUFBLE1BQUssTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNwRSxNQUFNLEtBQUssVUFBVSxJQUFJLEtBQUs7QUFBQSxJQUM5QixVQUFVLE9BQU8sS0FBSztBQUFBLElBQ3RCLE9BQU8sS0FBSyxlQUFlLEVBQUUsSUFBSTtBQUFBO0FBQUEsRUFHbkMsZUFBZSxZQUFZLENBQUMsV0FBcUIsU0FBOEQ7QUFBQSxJQUM3RyxNQUFNLE1BQU0sWUFBWSxJQUFJLElBQUk7QUFBQSxJQUNoQyxPQUFPLE1BQU07QUFBQSxNQUNYLE1BQU0sSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUMzQixNQUFNLE1BQU0sS0FBTSxFQUFFLEdBQXlCO0FBQUEsTUFDN0MsSUFBSSxLQUFLO0FBQUEsUUFDUCxNQUFNLFFBQVEsT0FBTyxXQUFXO0FBQUEsUUFDaEMsSUFBSSxZQUFZLEdBQUcsTUFBTSxTQUFTLE1BQU0sR0FBRyxHQUFHO0FBQUEsUUFDOUMsT0FBTyxFQUFFLE1BQU07QUFBQSxNQUNqQjtBQUFBLE1BQ0EsSUFBSSxZQUFZLElBQUksSUFBSTtBQUFBLFFBQUssT0FBTyxFQUFFLE9BQU8sNkJBQTZCLFVBQVUsTUFBTTtBQUFBLE1BQzFGLE1BQU0sTUFBTSxHQUFHO0FBQUEsSUFDakI7QUFBQTtBQUFBLEVBR0YsSUFBSSxDQUFDLE9BQU8sVUFBVTtBQUFBLElBQ3BCLE9BQU8sV0FBVztBQUFBLElBQ2xCLE9BQU8saUJBQWlCLFdBQVcsY0FBYztBQUFBLElBRWpELE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFnQixTQUFTLFVBQVU7QUFBQSxNQUN2RSxRQUFRLElBQUk7QUFBQSxhQUNMO0FBQUEsVUFDSCxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFBQSxVQUNsQjtBQUFBLGFBQ0c7QUFBQSxVQUNILGVBQWUsSUFBSSxNQUFNLE1BQU0sTUFBTTtBQUFBLFVBQ3JDLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsY0FBYztBQUFBLFVBQ2QsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxRQUFRLElBQUksTUFBTSxJQUFJLFFBQVEsRUFBRSxLQUFLLEtBQUs7QUFBQSxVQUMxQyxPQUFPO0FBQUEsYUFDSjtBQUFBLFVBQ0gsVUFBVSxDQUFDLElBQUksVUFBVSxHQUFJLElBQUksYUFBYSxDQUFDLENBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxVQUFVLE1BQU0sRUFBRSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsVUFDeEYsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUdILFNBQVMsRUFBRSxLQUFLLE9BQU8sU0FBUyxNQUFNLE9BQVMsTUFBTSxLQUFtQixFQUFFLE1BQU0sZ0JBQWdCLEtBQUssQ0FBQyxLQUFNLE9BQVEsSUFBSSxDQUFDO0FBQUEsVUFDekgsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILFdBQVc7QUFBQSxVQUNYLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsT0FBTyxPQUFPLFlBQVksR0FBRyxNQUFNLFlBQVksT0FBTyxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBQUEsVUFDdEUsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxzQkFBc0IsSUFBSSxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsVUFDM0MsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILGFBQWEsSUFBSSxXQUFXLElBQUksT0FBTyxFQUFFLEtBQUssS0FBSztBQUFBLFVBQ25ELE9BQU87QUFBQTtBQUFBLEtBRVo7QUFBQSxJQUdELEtBQW9DLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNO0FBQUEsTUFDekUsSUFBSSxHQUFHO0FBQUEsUUFBTSxlQUFlLEVBQUUsTUFBTSxNQUFNLE1BQU07QUFBQSxLQUNqRDtBQUFBLEVBQ0g7IiwKICAiZGVidWdJZCI6ICI5MjFBN0M4MTU2ODQyQjQxNjQ3NTZFMjE2NDc1NkUyMSIsCiAgIm5hbWVzIjogW10KfQ==
