(() => {
  // src/shared/util.ts
  function looksGenerated(s) {
    return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/content/overlay.ts
  var CSS2 = `
:host { all: initial; }
.box {
  position: fixed; pointer-events: none; z-index: 2147483646; display: none;
  border: 2px solid var(--c, #7c5cff); background: color-mix(in srgb, var(--c, #7c5cff) 12%, transparent);
  border-radius: 4px; transition: all 60ms ease-out; box-sizing: border-box;
}
.tag {
  position: fixed; pointer-events: none; z-index: 2147483647; display: none;
  font: 600 11px/1.2 ui-sans-serif, system-ui, sans-serif; color: #fff; background: var(--c, #7c5cff);
  padding: 4px 7px; border-radius: 5px; white-space: nowrap; max-width: 360px; overflow: hidden; text-overflow: ellipsis;
  box-shadow: 0 2px 8px rgb(0 0 0 / .25);
}
.pill {
  position: fixed; z-index: 2147483647; left: 50%; bottom: 18px; transform: translateX(-50%);
  display: none; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px;
  font: 600 12px/1 ui-sans-serif, system-ui, sans-serif; color: #f4f2ff; background: #1b1830ee;
  box-shadow: 0 6px 24px rgb(0 0 0 / .35); backdrop-filter: blur(6px); user-select: none;
}
.dot { width: 9px; height: 9px; border-radius: 50%; background: #ff4d6d; animation: pulse 1.2s infinite; }
.pill.point .dot { background: #7c5cff; }
@keyframes pulse { 50% { opacity: .35; } }
.pill button {
  all: unset; cursor: pointer; padding: 5px 10px; border-radius: 999px; background: #ffffff1f; color: #fff;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
}
.pill button:hover { background: #ffffff38; }
.toasts { position: fixed; z-index: 2147483647; right: 16px; bottom: 64px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; pointer-events: none; }
.toast {
  font: 500 12px/1.3 ui-sans-serif, system-ui, sans-serif; color: #fff; background: #1b1830ee; padding: 7px 11px;
  border-radius: 8px; border-left: 3px solid var(--c, #7c5cff); box-shadow: 0 4px 14px rgb(0 0 0 / .3);
  animation: in .18s ease-out; max-width: 340px;
}
.toast.warn { --c: #ffb020; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } }
`;
  var COLORS = { click: "#7c5cff", fill: "#14b8a6", select: "#0ea5e9", check: "#22c55e", file: "#ffb020", run: "#f97316" };

  class Overlay {
    host;
    box;
    tag;
    pill;
    pillText;
    toasts;
    onStop = () => {};
    ensure() {
      if (this.host?.isConnected)
        return;
      this.host = document.createElement("div");
      this.host.id = "__rastro_host";
      const root = this.host.attachShadow({ mode: "open" });
      root.innerHTML = `<style>${CSS2}</style><div class="box"></div><div class="tag"></div>
      <div class="pill"><span class="dot"></span><span class="txt"></span><button type="button">Terminar</button></div>
      <div class="toasts"></div>`;
      this.box = root.querySelector(".box");
      this.tag = root.querySelector(".tag");
      this.pill = root.querySelector(".pill");
      this.pillText = root.querySelector(".txt");
      this.toasts = root.querySelector(".toasts");
      root.querySelector("button").addEventListener("click", (e) => {
        e.stopPropagation();
        this.onStop();
      });
      document.documentElement.appendChild(this.host);
    }
    owns(el) {
      return !!this.host && el instanceof Node && (el === this.host || this.host.contains(el));
    }
    show(el, text, color = COLORS.click) {
      this.ensure();
      const r = el.getBoundingClientRect();
      Object.assign(this.box.style, {
        display: "block",
        left: `${r.left - 3}px`,
        top: `${r.top - 3}px`,
        width: `${r.width + 6}px`,
        height: `${r.height + 6}px`
      });
      this.box.style.setProperty("--c", color);
      this.tag.style.setProperty("--c", color);
      this.tag.textContent = text;
      this.tag.style.display = "block";
      const above = r.top > 30;
      this.tag.style.left = `${Math.max(4, Math.min(r.left - 3, innerWidth - 370))}px`;
      this.tag.style.top = above ? `${r.top - 27}px` : `${r.bottom + 6}px`;
    }
    hide() {
      if (!this.box)
        return;
      this.box.style.display = "none";
      this.tag.style.display = "none";
    }
    flash(el, text, ms = 700, color = COLORS.run) {
      this.show(el, text, color);
      setTimeout(() => this.hide(), ms);
    }
    setPill(mode) {
      this.ensure();
      if (!mode) {
        this.pill.style.display = "none";
        return;
      }
      this.pill.className = "pill " + mode;
      this.pillText.textContent = mode === "record" ? "Rastro grabando" : "Rastro · modo señalar (Esc para salir)";
      this.pill.style.display = "flex";
    }
    toast(text, color, warn = false) {
      this.ensure();
      const t = document.createElement("div");
      t.className = "toast" + (warn ? " warn" : "");
      if (color)
        t.style.setProperty("--c", color);
      t.textContent = text;
      this.toasts.appendChild(t);
      setTimeout(() => t.remove(), 2200);
      while (this.toasts.children.length > 4)
        this.toasts.firstElementChild.remove();
    }
  }
  var overlay = new Overlay;

  // src/content/selector.ts
  var TEST_ATTRS = ["data-testid", "data-test-id", "data-test", "data-cy", "data-qa", "data-e2e", "data-automation-id"];
  var CLICKABLE = 'button, a[href], [role="button"], [role="link"], [role="menuitem"], [role="tab"], [role="option"], ' + '[role="checkbox"], [role="radio"], [role="switch"], input[type="submit"], input[type="button"], ' + 'input[type="reset"], input[type="image"], summary, label, [onclick]';
  var CONTROL = 'input, textarea, select, [contenteditable]:not([contenteditable="false"])';
  var norm = (s) => (s ?? "").replace(/\s+/g, " ").trim();
  var STATE_CLASSES = /^(is-|has-)?(active|focus(ed)?|hover(ed)?|selected|open(ed)?|disabled|checked|visible|hidden|show|in|ng-.*)$/i;
  var STATE_WORDS = new Set([
    "active",
    "focus",
    "focused",
    "focusvisible",
    "focuswithin",
    "hover",
    "hovered",
    "hovering",
    "highlight",
    "highlighted",
    "selected",
    "current",
    "open",
    "opened",
    "expanded",
    "collapsed",
    "pressed",
    "disabled",
    "checked",
    "visible",
    "hidden",
    "shown",
    "enter",
    "entering",
    "leave",
    "leaving",
    "touched",
    "dirty",
    "pristine",
    "valid",
    "invalid",
    "error"
  ]);
  function isStateClass(c) {
    if (STATE_CLASSES.test(c))
      return true;
    const words = c.split(/[-_]+|(?<=[a-z])(?=[A-Z])/).filter(Boolean);
    return words.length > 1 && STATE_WORDS.has(words.at(-1).toLowerCase());
  }
  var volatile = new Set;
  var classObserver = null;
  function noteClassChanges(records) {
    for (const r of records) {
      const before = new Set((r.oldValue ?? "").split(/\s+/).filter(Boolean));
      const after = r.target.classList;
      for (const c of after)
        if (!before.has(c))
          volatile.add(c);
      for (const c of before)
        if (!after.contains(c))
          volatile.add(c);
    }
  }
  function trackVolatileClasses(on) {
    if (on && !classObserver) {
      classObserver = new MutationObserver(noteClassChanges);
      classObserver.observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ["class"], attributeOldValue: true });
    } else if (!on && classObserver) {
      noteClassChanges(classObserver.takeRecords());
      classObserver.disconnect();
      classObserver = null;
    }
  }
  function stableClasses(el) {
    if (classObserver)
      noteClassChanges(classObserver.takeRecords());
    return [...el.classList].filter((c) => !looksGenerated(c) && !isStateClass(c) && !volatile.has(c) && !c.includes(":") && c.length < 32);
  }
  var q = (v) => JSON.stringify(v);
  function isVisible(el) {
    if (!el.isConnected)
      return false;
    if (el.getClientRects().length === 0)
      return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.opacity !== "0";
  }
  function textOf(el) {
    if (el instanceof HTMLInputElement && ["submit", "button", "reset"].includes(el.type))
      return norm(el.value);
    return norm(el.innerText ?? el.textContent);
  }
  function* allElements(root = document) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let n = walker.nextNode();
    while (n) {
      yield n;
      const sr = n.shadowRoot;
      if (sr)
        yield* allElements(sr);
      n = walker.nextNode();
    }
  }
  function byText(text) {
    const target = norm(text);
    const exact = [];
    const partial = [];
    const lower = target.toLowerCase();
    for (const el of allElements()) {
      if (el.closest("script, style, noscript, template, #__rastro_host"))
        continue;
      const limit = target.length * 3 + 20;
      if (!(el instanceof HTMLInputElement) && norm(el.textContent).length > limit)
        continue;
      const t = textOf(el);
      if (!t || t.length > limit)
        continue;
      if (t === target)
        exact.push(el);
      else if (t.toLowerCase().includes(lower))
        partial.push(el);
    }
    const pick = exact.length ? exact : partial;
    const deepest = pick.filter((el) => !pick.some((o) => o !== el && el.contains(o)));
    return dedupe(deepest.map((el) => el.closest(CLICKABLE) ?? el));
  }
  function byLabel(text) {
    const target = norm(text).toLowerCase();
    const out = [];
    for (const label of document.querySelectorAll("label")) {
      if (norm(label.innerText).toLowerCase().replace(/\s*\*$/, "") === target && label.control)
        out.push(label.control);
    }
    for (const el of document.querySelectorAll(CONTROL + ", [aria-label], [aria-labelledby]")) {
      if (norm(el.getAttribute("aria-label")).toLowerCase() === target)
        out.push(el);
      const lb = el.getAttribute("aria-labelledby");
      if (lb) {
        const t = lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" ");
        if (norm(t).toLowerCase() === target)
          out.push(el);
      }
    }
    if (!out.length) {
      for (const el of document.querySelectorAll("[placeholder]")) {
        if (norm(el.getAttribute("placeholder")).toLowerCase() === target)
          out.push(el);
      }
    }
    return dedupe(out);
  }
  function byXPath(xp) {
    const res = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const out = [];
    for (let i = 0;i < res.snapshotLength; i++) {
      const n = res.snapshotItem(i);
      if (n instanceof Element)
        out.push(n);
    }
    return out;
  }
  function dedupe(arr) {
    return [...new Set(arr)];
  }
  function resolveAll(selector) {
    try {
      if (selector.startsWith("text="))
        return byText(unquote(selector.slice(5)));
      if (selector.startsWith("label="))
        return byLabel(unquote(selector.slice(6)));
      if (selector.startsWith("xpath="))
        return byXPath(selector.slice(6));
      if (selector.startsWith("frame=")) {
        const f = document.querySelectorAll("iframe, frame")[Number(selector.slice(6))];
        return f ? [f] : [];
      }
      return [...document.querySelectorAll(selector)];
    } catch {
      return [];
    }
  }
  function unquote(s) {
    const t = s.trim();
    if (t.startsWith('"') && t.endsWith('"') || t.startsWith("'") && t.endsWith("'"))
      return t.slice(1, -1);
    return t;
  }
  function resolve(selectors) {
    for (const sel of selectors) {
      const found = resolveAll(sel);
      if (found.length === 1)
        return { el: found[0], selector: sel };
      const vis = found.filter(isVisible);
      if (vis.length >= 1)
        return { el: vis[0], selector: sel };
      if (found.length)
        return { el: found[0], selector: sel };
    }
    return null;
  }
  function isUnique(sel, el) {
    const r = resolveAll(sel);
    return r.length === 1 && r[0] === el;
  }
  function cssPath(el) {
    const parts = [];
    let cur = el;
    while (cur && cur !== document.documentElement) {
      const tag = cur.tagName.toLowerCase();
      if (cur !== el && cur.id && !looksGenerated(cur.id)) {
        parts.unshift("#" + CSS.escape(cur.id));
        const s = parts.join(" > ");
        if (isUnique(s, el))
          return s;
        parts.shift();
      }
      let seg = tag;
      const cls = stableClasses(cur).slice(0, 2);
      if (cls.length)
        seg += "." + cls.map((c) => CSS.escape(c)).join(".");
      const withoutNth = [seg, ...parts].join(" > ");
      if (isUnique(withoutNth, el))
        return withoutNth;
      const parent = cur.parentElement;
      if (parent) {
        const same = [...parent.children].filter((c) => c.tagName === cur.tagName);
        if (same.length > 1)
          seg += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(seg);
      const s = parts.join(" > ");
      if (isUnique(s, el))
        return s;
      cur = parent;
    }
    return parts.join(" > ");
  }
  function buildSelectors(el) {
    const tag = el.tagName.toLowerCase();
    const c = [];
    for (const a of TEST_ATTRS) {
      const v = el.getAttribute(a);
      if (v)
        c.push(`[${a}=${q(v)}]`);
    }
    if (el.id && !looksGenerated(el.id))
      c.push("#" + CSS.escape(el.id));
    const name = el.getAttribute("name");
    if (name) {
      if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.value && el.value !== "on") {
        c.push(`${tag}[name=${q(name)}][value=${q(el.value)}]`);
      } else
        c.push(`${tag}[name=${q(name)}]`);
    }
    const isControl = el.matches(CONTROL);
    if (isControl) {
      const lbl = labelText(el);
      if (lbl && lbl.length <= 60)
        c.push(`label=${lbl}`);
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      c.push(`${tag}[aria-label=${q(aria)}]`);
    const ph = el.getAttribute("placeholder");
    if (ph)
      c.push(`${tag}[placeholder=${q(ph)}]`);
    if (!isControl) {
      const t = textOf(el);
      if (t && t.length <= 50 && !el.querySelector(CONTROL))
        c.push(`text=${t}`);
    }
    if (el instanceof HTMLAnchorElement) {
      const href = el.getAttribute("href");
      if (href && href.length < 80 && !href.startsWith("javascript:") && href !== "#")
        c.push(`a[href=${q(href)}]`);
    }
    if (el instanceof HTMLIFrameElement || el instanceof HTMLFrameElement) {
      const src = el.getAttribute("src");
      if (src && !src.startsWith("data:") && !src.startsWith("javascript:")) {
        const base = src.split(/[?#]/)[0];
        c.push(base === src ? `${tag}[src=${q(src)}]` : `${tag}[src^=${q(base)}]`);
      }
    }
    const title = el.getAttribute("title");
    if (title)
      c.push(`${tag}[title=${q(title)}]`);
    const sameTarget = (s) => {
      const isText = s.startsWith("text=");
      const hit = (x) => x === el || isText && el.contains(x) && textOf(x) === textOf(el);
      const r = resolveAll(s);
      if (r.length === 1)
        return hit(r[0]);
      if (!isText)
        return false;
      const vis = r.filter(isVisible);
      return vis.length === 1 && hit(vis[0]);
    };
    const unique = dedupe(c).filter(sameTarget);
    unique.push(cssPath(el));
    return dedupe(unique).slice(0, 5);
  }
  function labelText(el) {
    if (el.labels?.length) {
      const t = norm(el.labels[0].innerText).replace(/\s*\*$/, "");
      if (t)
        return t;
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      return norm(aria);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = norm(lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" "));
      if (t)
        return t;
    }
    return "";
  }
  function describe(el) {
    if (el.matches(CONTROL)) {
      return (labelText(el) || el.getAttribute("placeholder") || el.getAttribute("name") || el.id || el.getAttribute("title") || el.tagName.toLowerCase()).slice(0, 60);
    }
    const t = textOf(el);
    if (t)
      return t.length > 50 ? t.slice(0, 47) + "…" : t;
    return (el.getAttribute("aria-label") || el.getAttribute("title") || el.querySelector("img")?.getAttribute("alt") || el.getAttribute("name") || el.tagName.toLowerCase()).slice(0, 60);
  }
  function actionable(target) {
    const ctrl = target.closest(CONTROL);
    if (ctrl)
      return ctrl;
    const clickable = target.closest(CLICKABLE);
    if (clickable instanceof HTMLLabelElement && clickable.control)
      return clickable.control;
    return clickable ?? target;
  }
  var TEXTLIKE = new Set([
    "",
    "text",
    "email",
    "password",
    "search",
    "tel",
    "url",
    "number",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "color",
    "range"
  ]);
  function kindOf(el) {
    if (el instanceof HTMLSelectElement)
      return "select";
    if (el instanceof HTMLTextAreaElement)
      return el.readOnly ? "click" : "fill";
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio")
        return "check";
      if (el.type === "file")
        return "file";
      if (TEXTLIKE.has(el.type))
        return el.readOnly ? "click" : "fill";
      return "click";
    }
    if (el.isContentEditable)
      return "fill";
    const role = el.getAttribute("role");
    if (role === "checkbox" || role === "switch")
      return "check";
    return "click";
  }
  function valueOf(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)
      return el.value;
    return norm(el.innerText);
  }
  function checkedOf(el) {
    if (el instanceof HTMLInputElement)
      return el.checked;
    return el.getAttribute("aria-checked") === "true";
  }

  // src/content/wait.ts
  var NET_QUIET = 300;
  var DOM_QUIET = 150;
  var DOM_CAP = 1500;
  var LOADERS = [
    '[aria-busy="true"]',
    ".el-loading-mask",
    ".ant-spin-spinning",
    ".v-progress-circular--indeterminate",
    ".v-progress-linear--active",
    ".MuiCircularProgress-root",
    ".MuiLinearProgress-root",
    ".p-progress-spinner",
    ".p-blockui",
    ".q-loading",
    ".q-spinner",
    ".spinner-border",
    ".spinner-grow",
    ".blockUI",
    ".loading-overlay",
    ".loading-mask",
    ".loader",
    ".spinner"
  ].join(", ");
  var pending = 0;
  var netChanged = performance.now();
  document.addEventListener("__rastro_net", (e) => {
    const n = e.detail;
    if (typeof n !== "number")
      return;
    pending = n;
    netChanged = performance.now();
  });
  document.dispatchEvent(new Event("__rastro_net?"));
  var domChanged = performance.now();
  var domObserver = null;
  function watchDom() {
    if (domObserver)
      return;
    domObserver = new MutationObserver((records) => {
      if (records.some((r) => !r.target.closest?.("#__rastro_host")))
        domChanged = performance.now();
    });
    domObserver.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
  }
  function loaderSelector(extra) {
    const x = extra?.trim();
    if (!x)
      return LOADERS;
    try {
      document.querySelector(x);
      return `${LOADERS}, ${x}`;
    } catch {
      return LOADERS;
    }
  }
  function visibleLoader(extra) {
    for (const el of document.querySelectorAll(loaderSelector(extra))) {
      if (el.closest("#__rastro_host") || !isVisible(el))
        continue;
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0)
        return el;
    }
  }
  async function settle(maxMs, extraLoader) {
    watchDom();
    const start = performance.now();
    while (true) {
      const now = performance.now();
      const netQuiet = pending === 0 && now - netChanged >= NET_QUIET;
      const domQuiet = now - domChanged >= DOM_QUIET || now - start > DOM_CAP;
      if (netQuiet && domQuiet && !visibleLoader(extraLoader))
        return;
      if (now - start > maxMs)
        return;
      await sleep(50);
    }
  }
  function isDisabled(el, visible) {
    if (el.matches(":disabled"))
      return true;
    if (el.closest('[aria-disabled="true"]'))
      return true;
    return visible && getComputedStyle(el).pointerEvents === "none";
  }
  function ancestor(el, levels) {
    let cur = el;
    for (let i = 0;i < levels && cur.parentElement; i++)
      cur = cur.parentElement;
    return cur;
  }
  function coveredBy(el, extraLoader) {
    if (el.getRootNode() !== document)
      return null;
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x > innerWidth || y > innerHeight)
      return null;
    const top = document.elementFromPoint(x, y);
    if (!top || el.contains(top) || top.closest("#__rastro_host"))
      return null;
    if (el.labels && [...el.labels].some((l) => l.contains(top)))
      return null;
    if (!top.closest(loaderSelector(extraLoader)) && ancestor(el, 3).contains(top))
      return null;
    return top;
  }
  function describeEl(el) {
    const cls = [...el.classList].slice(0, 2).join(".");
    return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (cls ? "." + cls : "");
  }
  async function untilActionable(el, timeout, checkHit, extraLoader) {
    const start = performance.now();
    let lastRect = "";
    let why = null;
    while (true) {
      const r = el.getBoundingClientRect();
      const rect = `${r.x},${r.y},${r.width},${r.height}`;
      const stable = rect === lastRect;
      lastRect = rect;
      const cover = checkHit ? coveredBy(el, extraLoader) : null;
      if (isDisabled(el, checkHit))
        why = "está deshabilitado";
      else if (cover)
        why = `está tapado por ${describeEl(cover)}`;
      else if (!stable)
        why = "se está moviendo";
      else
        return null;
      if (performance.now() - start > timeout)
        return why;
      await sleep(50);
    }
  }

  // src/content/player.ts
  class StepError extends Error {
  }
  async function find(step, timeout, requireVisible) {
    const selectors = [step.selector, ...step.fallbacks ?? []].filter(Boolean);
    if (!selectors.length)
      throw new StepError("El paso no tiene selector");
    const start = performance.now();
    let hiddenSince = 0;
    while (true) {
      const r = resolve(selectors);
      if (r) {
        if (isVisible(r.el))
          return r;
        if (!requireVisible) {
          hiddenSince ||= performance.now();
          if (performance.now() - hiddenSince > 1000)
            return r;
        }
      }
      if (performance.now() - start > timeout) {
        if (r)
          throw new StepError(`El elemento «${step.label ?? selectors[0]}» existe pero no es visible`);
        throw new StepError(`No se encontró «${step.label ?? selectors[0]}» (${selectors[0]})`);
      }
      await sleep(100);
    }
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }
  async function scrollTo(el) {
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      await sleep(50);
    }
  }
  function mouse(target, type, x, y) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + screenX,
      screenY: y + screenY,
      button: 0,
      buttons: type.endsWith("down") ? 1 : 0,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };
    const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
    return target.dispatchEvent(new Ctor(type, init));
  }
  async function realClick(el) {
    await scrollTo(el);
    const { x, y } = center(el);
    const top = document.elementFromPoint(x, y);
    const target = top && el.contains(top) ? top : el;
    mouse(target, "pointerover", x, y);
    mouse(target, "mouseover", x, y);
    mouse(target, "pointermove", x, y);
    mouse(target, "mousemove", x, y);
    const down = mouse(target, "pointerdown", x, y) && mouse(target, "mousedown", x, y);
    if (down && el instanceof HTMLElement && el.tabIndex >= -1)
      el.focus({ preventScroll: true });
    mouse(target, "pointerup", x, y);
    mouse(target, "mouseup", x, y);
    mouse(target, "click", x, y);
  }
  var NO_TYPING = new Set(["date", "datetime-local", "month", "week", "time", "color", "range"]);
  function setNative(el, v) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  }
  function fireInput(el, data, inputType = "insertText") {
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, data, inputType }));
  }
  function key(el, type, k) {
    return el.dispatchEvent(new KeyboardEvent(type, { key: k, code: codeFor(k), bubbles: true, cancelable: true, composed: true }));
  }
  function codeFor(k) {
    if (k.length === 1) {
      if (/[a-z]/i.test(k))
        return "Key" + k.toUpperCase();
      if (/\d/.test(k))
        return "Digit" + k;
      if (k === " ")
        return "Space";
      return "";
    }
    return k;
  }
  function selectAll(el) {
    try {
      el.select();
    } catch {}
  }
  async function typeInto(el, value, s) {
    await scrollTo(el);
    el.focus({ preventScroll: true });
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      if (value)
        document.execCommand("insertText", false, value);
      else
        document.execCommand("delete");
      if (textOf(el) !== value.replace(/\s+/g, " ").trim()) {
        el.textContent = value;
        fireInput(el, value);
      }
      return;
    }
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement))
      throw new StepError("El elemento no es editable");
    if (el.disabled)
      throw new StepError(`«${el.name || el.id}» está deshabilitado`);
    const typeable = !(el instanceof HTMLInputElement && NO_TYPING.has(el.type));
    if (!typeable || s.typeMode === "instant") {
      selectAll(el);
      const ok = typeable && (value ? document.execCommand("insertText", false, value) : document.execCommand("delete"));
      if (!ok || el.value !== value) {
        setNative(el, value);
        fireInput(el, value);
      }
    } else {
      selectAll(el);
      if (!document.execCommand("delete") || el.value !== "") {
        setNative(el, "");
        fireInput(el, null, "deleteContentBackward");
      }
      for (const ch of value) {
        const allowed = key(el, "keydown", ch);
        key(el, "keypress", ch);
        if (allowed) {
          const before = el.value;
          if (!document.execCommand("insertText", false, ch) || el.value === before) {
            setNative(el, before + ch);
            fireInput(el, ch);
          }
        }
        key(el, "keyup", ch);
        if (s.keyDelay)
          await sleep(s.keyDelay);
      }
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectOption(el, value, optionText) {
    if (!(el instanceof HTMLSelectElement))
      throw new StepError("El elemento no es un <select>");
    const opts = [...el.options];
    const opt = opts.find((o) => o.value === value) ?? (optionText ? opts.find((o) => o.text.trim() === optionText) : undefined) ?? opts.find((o) => o.text.trim() === value) ?? opts.find((o) => o.text.trim().toLowerCase().includes(value.toLowerCase()));
    if (!opt)
      throw new StepError(`El select no tiene la opción «${optionText ?? value}»`);
    el.focus();
    el.value = opt.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function setChecked(el, want) {
    if (checkedOf(el) === want)
      return;
    if (el instanceof HTMLInputElement && el.type === "radio" && !want) {
      throw new StepError("Un radio no se puede desmarcar; marca otra opción del grupo");
    }
    if (isVisible(el))
      await realClick(el);
    else if (el instanceof HTMLInputElement && el.labels?.[0] && isVisible(el.labels[0]))
      await realClick(el.labels[0]);
    else
      el.click();
    if (checkedOf(el) !== want && el instanceof HTMLInputElement) {
      el.checked = want;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  var FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"]), [contenteditable]:not([contenteditable="false"])';
  async function press(el, k) {
    const down = key(el, "keydown", k);
    if (k === "Enter")
      key(el, "keypress", k);
    if (down) {
      if (k === "Enter") {
        if (el instanceof HTMLInputElement && el.form) {
          const btn = el.form.querySelector('button[type="submit"], button:not([type]), input[type="submit"], input[type="image"]');
          if (btn)
            await realClick(btn);
          else
            el.form.requestSubmit();
        } else if (el instanceof HTMLButtonElement || el instanceof HTMLAnchorElement) {
          el.click();
        }
      } else if (k === "Tab") {
        const all = [...document.querySelectorAll(FOCUSABLE)].filter((e) => isVisible(e) && !e.disabled);
        const i = all.indexOf(el);
        all[(i + 1) % all.length]?.focus();
      }
    }
    key(el, "keyup", k);
  }
  function mayNavigate(el) {
    if (el.closest("a[href]"))
      return true;
    const btn = el.closest("button, input");
    if (btn instanceof HTMLButtonElement)
      return !!btn.form && btn.type === "submit";
    if (btn instanceof HTMLInputElement)
      return !!btn.form && (["submit", "image"].includes(btn.type) || kindOf(btn) === "fill");
    return false;
  }
  async function runStep(step, s) {
    const timeout = step.timeout ?? s.timeout;
    let nav = false;
    try {
      let used;
      const acts = !["waitFor", "assertText"].includes(step.type);
      if (s.autoWait && acts)
        await settle(timeout, s.loaderSelector);
      const target = async (visible = true) => {
        const r = await find(step, timeout, visible);
        used = r.selector;
        if (s.autoWait && acts) {
          if (isVisible(r.el))
            await scrollTo(r.el);
          const why = await untilActionable(r.el, timeout, isVisible(r.el), s.loaderSelector);
          if (why)
            throw new StepError(`«${step.label ?? r.selector}» ${why}`);
        }
        if (s.highlight)
          overlay.flash(r.el, step.label ?? step.type, Math.max(400, s.stepDelay + 200), COLORS.run);
        return r.el;
      };
      switch (step.type) {
        case "click": {
          const el = await target();
          nav = mayNavigate(el);
          await realClick(el);
          break;
        }
        case "fill": {
          const el = await target(false);
          if (el instanceof HTMLSelectElement)
            selectOption(el, step.value ?? "");
          else if (kindOf(el) === "check")
            await setChecked(el, !["", "false", "off", "0"].includes(step.value ?? ""));
          else
            await typeInto(el, step.value ?? "", s);
          break;
        }
        case "select":
          selectOption(await target(false), step.value ?? "", step.optionText);
          break;
        case "check":
          await setChecked(await target(false), step.value !== "false");
          break;
        case "press": {
          const el = step.selector ? await target(false) : document.activeElement ?? document.body;
          nav = (step.value || "Enter") === "Enter" && mayNavigate(el);
          await press(el, step.value || "Enter");
          break;
        }
        case "waitFor":
          await target();
          break;
        case "assertText": {
          const el = await target(false);
          const want = (step.value ?? "").trim();
          const start = performance.now();
          let have = "";
          while (true) {
            have = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement ? valueOf(el) : textOf(el);
            if (have.includes(want))
              break;
            if (performance.now() - start > timeout)
              throw new StepError(`Se esperaba «${want}» y hay «${have.slice(0, 80)}»`);
            await sleep(150);
          }
          break;
        }
        default:
          throw new StepError(`Tipo de paso «${step.type}» no se ejecuta en la página`);
      }
      return { ok: true, usedSelector: used, mayNavigate: nav };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }
  async function highlight(selectors) {
    const r = resolve(selectors);
    if (!r)
      return false;
    await scrollTo(r.el);
    overlay.flash(r.el, r.selector, 1500, COLORS.click);
    return true;
  }

  // src/content/recorder.ts
  var mode = null;
  var send = () => {};
  var pendingFill = new Map;
  var VERB = { click: "Click", fill: "Escribir", select: "Seleccionar", check: "Marcar", file: "Fichero" };
  function capture(el) {
    const kind = kindOf(el);
    if (kind === "file")
      return null;
    const [selector, ...fallbacks] = buildSelectors(el);
    const base = { selector, fallbacks, label: describe(el) };
    switch (kind) {
      case "fill":
        return { ...base, type: "fill", value: valueOf(el), secret: el.type === "password" || undefined };
      case "select": {
        const s = el;
        return { ...base, type: "select", value: s.value, optionText: s.selectedOptions[0]?.text.trim() };
      }
      case "check":
        return { ...base, type: "check", value: String(checkedOf(el)) };
      default:
        return { ...base, type: "click" };
    }
  }
  function emit(el, step) {
    if (!step)
      return;
    send(step);
    const what = step.type === "fill" ? step.secret ? "••••" : `«${(step.value ?? "").slice(0, 30)}»` : "";
    overlay.toast(`✓ ${VERB[step.type] ?? step.type}: ${step.label} ${what}`.trim(), COLORS[kindOf(el)]);
  }
  function flushFills() {
    for (const [el, t] of pendingFill) {
      clearTimeout(t);
      send(capture(el));
    }
    pendingFill.clear();
  }
  function scheduleFill(el) {
    clearTimeout(pendingFill.get(el));
    pendingFill.set(el, setTimeout(() => {
      pendingFill.delete(el);
      const s = capture(el);
      if (s)
        send(s);
    }, 350));
  }
  var targetOf = (e) => {
    const t = e.composedPath()[0];
    return t instanceof Element ? t : null;
  };
  function onMove(e) {
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    const el = actionable(t);
    const k = kindOf(el);
    const hint = k === "file" ? "Fichero (no automatizable)" : `${VERB[k]} · ${describe(el)}`;
    overlay.show(el, hint, COLORS[k]);
  }
  function blockInPoint(e) {
    if (mode !== "point" || !e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    if (kindOf(actionable(t)) === "click") {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  function onClick(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    blockInPoint(e);
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "file")
      return overlay.toast("Los inputs de fichero no se pueden automatizar", undefined, true);
    if (k === "check" || k === "select")
      return;
    flushFills();
    if (k === "fill") {
      if (valueOf(el))
        emit(el, capture(el));
      return;
    }
    emit(el, capture(el));
  }
  function onInput(e) {
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    if (kindOf(el) === "fill")
      scheduleFill(el);
  }
  function onChange(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "fill") {
      clearTimeout(pendingFill.get(el));
      pendingFill.delete(el);
      send(capture(el));
    } else if (k === "select" || k === "check") {
      flushFills();
      emit(el, capture(el));
    }
  }
  function onKey(e) {
    if (!e.isTrusted)
      return;
    if (mode === "point" && e.key === "Escape") {
      e.preventDefault();
      stopHandler();
      return;
    }
    const t = targetOf(e);
    if (!t)
      return;
    if (e.key === "Enter" && t instanceof HTMLInputElement && kindOf(t) === "fill") {
      flushFills();
      send({ type: "press", value: "Enter", selector: buildSelectors(t)[0], label: describe(t) });
      overlay.toast(`✓ Tecla: Enter en ${describe(t)}`);
    }
  }
  function onLeave() {
    flushFills();
  }
  var onScroll = () => overlay.hide();
  var stopHandler = () => {};
  var listeners = [
    ["mousemove", onMove],
    ["pointerdown", blockInPoint],
    ["mousedown", blockInPoint],
    ["pointerup", blockInPoint],
    ["mouseup", blockInPoint],
    ["click", onClick],
    ["input", onInput],
    ["change", onChange],
    ["keydown", onKey]
  ];
  function startRecording(m, sink, onStop) {
    if (mode)
      stopRecording();
    mode = m;
    send = sink;
    stopHandler = onStop;
    overlay.onStop = onStop;
    trackVolatileClasses(true);
    for (const [ev, fn] of listeners)
      window.addEventListener(ev, fn, true);
    window.addEventListener("pagehide", onLeave);
    window.addEventListener("scroll", onScroll, true);
    if (window === window.top)
      overlay.setPill(m);
  }
  function stopRecording() {
    flushFills();
    for (const [ev, fn] of listeners)
      window.removeEventListener(ev, fn, true);
    window.removeEventListener("pagehide", onLeave);
    window.removeEventListener("scroll", onScroll, true);
    trackVolatileClasses(false);
    mode = null;
    overlay.hide();
    overlay.setPill(null);
  }
  function pickOnce() {
    return new Promise((resolve) => {
      const block = (e) => {
        if (overlay.owns(targetOf(e)))
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
      };
      const done = (r) => {
        window.removeEventListener("mousemove", onMove, true);
        for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
          window.removeEventListener(ev, block, true);
        window.removeEventListener("click", click, true);
        window.removeEventListener("keydown", key, true);
        overlay.hide();
        cancelPick = () => {};
        if (!mode)
          trackVolatileClasses(false);
        resolve(r);
      };
      const click = (e) => {
        block(e);
        const t = targetOf(e);
        if (!t || overlay.owns(t))
          return;
        done(capture(actionable(t)) ?? null);
      };
      const key = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          done(null);
        }
      };
      trackVolatileClasses(true);
      window.addEventListener("mousemove", onMove, true);
      for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
        window.addEventListener(ev, block, true);
      window.addEventListener("click", click, true);
      window.addEventListener("keydown", key, true);
      cancelPick = () => done(null);
      if (window === window.top)
        overlay.toast("Clica el elemento (Esc para cancelar)");
    });
  }
  var cancelPick = () => {};

  // src/content/index.ts
  function toBg(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => {
        return;
      });
    } catch {
      stopRecording();
      return Promise.resolve(undefined);
    }
  }
  var sink = (step) => void toBg({ kind: "record:step", step });
  var onStop = () => void toBg({ kind: "record:stop" });
  var MSG = "__rastro_frame";
  var announced = new Map;
  function frameElementFor(source) {
    if (!source)
      return;
    return [...document.querySelectorAll("iframe, frame")].find((f) => f.contentWindow === source);
  }
  function onFrameMessage(e) {
    const d = e.data;
    if (!d || typeof d !== "object" || d[MSG] == null || typeof d.token !== "string")
      return;
    if (d[MSG] === "announce") {
      const el = frameElementFor(e.source);
      if (el)
        announced.set(d.token, el);
    } else if (d[MSG] === "probe" && e.source === window.parent && window !== window.top) {
      toBg({ kind: "frame:probe", token: d.token });
    }
  }
  async function selectorsForAnnounced(token) {
    for (let i = 0;i < 20 && !announced.has(token); i++)
      await sleep(50);
    const el = announced.get(token);
    announced.delete(token);
    return el ? buildSelectors(el) : null;
  }
  async function resolveFrame(selectors, timeout) {
    const end = performance.now() + timeout;
    while (true) {
      const r = resolve(selectors);
      const win = r && r.el.contentWindow;
      if (win) {
        const token = crypto.randomUUID();
        win.postMessage({ [MSG]: "probe", token }, "*");
        return { token };
      }
      if (performance.now() > end)
        return { error: `No se encontró el iframe «${selectors[0]}»` };
      await sleep(100);
    }
  }
  if (!window.__rastro) {
    window.__rastro = true;
    window.addEventListener("message", onFrameMessage);
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
      switch (msg.kind) {
        case "ping":
          reply({ ok: true });
          return;
        case "record:on":
          startRecording(msg.mode, sink, onStop);
          reply({ ok: true });
          return;
        case "record:off":
          stopRecording();
          reply({ ok: true });
          return;
        case "run-step":
          runStep(msg.step, msg.settings).then(reply);
          return true;
        case "highlight":
          highlight([msg.selector, ...msg.fallbacks ?? []]).then((found) => reply({ ok: found }));
          return true;
        case "pick":
          pickOnce().then(async (step) => reply(step ? await toBg({ kind: "frame:locate", step }) ?? step : null));
          return true;
        case "pick:cancel":
          cancelPick();
          reply({ ok: true });
          return;
        case "frame:announce":
          window.parent.postMessage({ [MSG]: "announce", token: msg.token }, "*");
          reply({ ok: true });
          return;
        case "frame:selectors":
          selectorsForAnnounced(msg.token).then(reply);
          return true;
        case "frame:resolve":
          resolveFrame(msg.selectors, msg.timeout).then(reply);
          return true;
      }
    });
    toBg({ kind: "record:status" }).then((r) => {
      if (r?.mode)
        startRecording(r.mode, sink, onStop);
    });
  }
})();

//# debugId=55A07A7AC186062564756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC91dGlsLnRzIiwgInNyYy9jb250ZW50L292ZXJsYXkudHMiLCAic3JjL2NvbnRlbnQvc2VsZWN0b3IudHMiLCAic3JjL2NvbnRlbnQvd2FpdC50cyIsICJzcmMvY29udGVudC9wbGF5ZXIudHMiLCAic3JjL2NvbnRlbnQvcmVjb3JkZXIudHMiLCAic3JjL2NvbnRlbnQvaW5kZXgudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbCiAgICAiZXhwb3J0IGNvbnN0IHVpZCA9ICgpOiBzdHJpbmcgPT4gY3J5cHRvLnJhbmRvbVVVSUQoKS5zbGljZSgwLCA4KSArIERhdGUubm93KCkudG9TdHJpbmcoMzYpLnNsaWNlKC00KTtcblxuLyoqIMK/UGFyZWNlIHVuIGlkL2NsYXNlIGF1dG9nZW5lcmFkbyAoaGFzaGVzLCBjb250YWRvcmVzLCBpZHMgZGUgUmVhY3QvRWxlbWVudCBQbHVz4oCmKT8gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb29rc0dlbmVyYXRlZChzOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICBzLmxlbmd0aCA+IDQwIHx8XG4gICAgL1xcZHs0LH0vLnRlc3QocykgfHxcbiAgICAvWy1fOl1cXGQrWy1fOl1cXGQrJC8udGVzdChzKSB8fCAvLyBwcmVmaWpvLWFsZWF0b3Jpby1jb250YWRvcjogZWwtaWQtNzQ0LTE2NSwgaW5wdXQtMTItM1xuICAgIC9eW2EtZjAtOS1dezEwLH0kL2kudGVzdChzKSB8fFxuICAgIC9eOnJbMC05YS16XSs6PyQvLnRlc3QocykgfHwgLy8gUmVhY3QgdXNlSWRcbiAgICAvXihlbWJlcnxleHQtZ2VufHJlYWN0LXxtdWktfHJhZGl4LXxoZWFkbGVzc3VpLXxkb3duc2hpZnQtfHJjLXxlbC1pZC18di1cXGR8aW5wdXQtXFxkKS9pLnRlc3QocykgfHxcbiAgICAoL1tfLV1bYS16QS1aMC05XXs1LH0kLy50ZXN0KHMpICYmIC9cXGQuKlxcZC8udGVzdChzLnNsaWNlKC02KSkpIHx8IC8vIGNzcy1tb2R1bGVzOiBidG5feDNGOWFcbiAgICAvXihjc3N8c2N8anN4fGVtb3Rpb258c3ZlbHRlKS1bYS16MC05XSskL2kudGVzdChzKVxuICApO1xufVxuXG5leHBvcnQgY29uc3Qgc2xlZXAgPSAobXM6IG51bWJlcikgPT4gbmV3IFByb21pc2U8dm9pZD4oKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcblxuLyoqIFZhcmlhYmxlcyBpbnRlZ3JhZGFzOiB7eyR0aW1lc3RhbXB9fSwge3skdXVpZH19LCB7eyRyYW5kb21FbWFpbH19LCB7eyRyYW5kb21JbnR9fSwge3skdG9kYXl9fSAqL1xuZnVuY3Rpb24gYnVpbHRpbihuYW1lOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICBzd2l0Y2ggKG5hbWUpIHtcbiAgICBjYXNlIFwiJHRpbWVzdGFtcFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhEYXRlLm5vdygpKTtcbiAgICBjYXNlIFwiJHV1aWRcIjpcbiAgICAgIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgIGNhc2UgXCIkcmFuZG9tSW50XCI6XG4gICAgICByZXR1cm4gU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDFfMDAwXzAwMCkpO1xuICAgIGNhc2UgXCIkcmFuZG9tRW1haWxcIjpcbiAgICAgIHJldHVybiBgdGVzdCske0RhdGUubm93KCkudG9TdHJpbmcoMzYpfSR7TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwMCl9QGV4YW1wbGUuY29tYDtcbiAgICBjYXNlIFwiJHRvZGF5XCI6XG4gICAgICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vKiogU3VzdGl0dXllIHt7dmFyaWFibGV9fSBwb3Igc3UgdmFsb3IuIExhcyBkZXNjb25vY2lkYXMgc2UgZGVqYW4gdGFsIGN1YWwuICovXG5leHBvcnQgZnVuY3Rpb24gaW50ZXJwb2xhdGUodGV4dDogc3RyaW5nLCB2YXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHQucmVwbGFjZSgvXFx7XFx7XFxzKihbJFxcdy4tXSspXFxzKlxcfVxcfS9nLCAobSwgbmFtZTogc3RyaW5nKSA9PiB2YXJzW25hbWVdID8/IGJ1aWx0aW4obmFtZSkgPz8gbSk7XG59XG5cbmV4cG9ydCBjb25zdCBCVUlMVElOX1ZBUlMgPSBbXCIkdGltZXN0YW1wXCIsIFwiJHV1aWRcIiwgXCIkcmFuZG9tRW1haWxcIiwgXCIkcmFuZG9tSW50XCIsIFwiJHRvZGF5XCJdO1xuIiwKICAgICIvLyBDYXBhIHZpc3VhbCBkZW50cm8gZGUgbGEgcMOhZ2luYSwgYWlzbGFkYSBlbiB1biBzaGFkb3cgcm9vdCBwYXJhIG5vIGhlcmVkYXIgbmkgcm9tcGVyIGVzdGlsb3MuXG5cbmNvbnN0IENTUyA9IGBcbjpob3N0IHsgYWxsOiBpbml0aWFsOyB9XG4uYm94IHtcbiAgcG9zaXRpb246IGZpeGVkOyBwb2ludGVyLWV2ZW50czogbm9uZTsgei1pbmRleDogMjE0NzQ4MzY0NjsgZGlzcGxheTogbm9uZTtcbiAgYm9yZGVyOiAycHggc29saWQgdmFyKC0tYywgIzdjNWNmZik7IGJhY2tncm91bmQ6IGNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS1jLCAjN2M1Y2ZmKSAxMiUsIHRyYW5zcGFyZW50KTtcbiAgYm9yZGVyLXJhZGl1czogNHB4OyB0cmFuc2l0aW9uOiBhbGwgNjBtcyBlYXNlLW91dDsgYm94LXNpemluZzogYm9yZGVyLWJveDtcbn1cbi50YWcge1xuICBwb3NpdGlvbjogZml4ZWQ7IHBvaW50ZXItZXZlbnRzOiBub25lOyB6LWluZGV4OiAyMTQ3NDgzNjQ3OyBkaXNwbGF5OiBub25lO1xuICBmb250OiA2MDAgMTFweC8xLjIgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2ZmZjsgYmFja2dyb3VuZDogdmFyKC0tYywgIzdjNWNmZik7XG4gIHBhZGRpbmc6IDRweCA3cHg7IGJvcmRlci1yYWRpdXM6IDVweDsgd2hpdGUtc3BhY2U6IG5vd3JhcDsgbWF4LXdpZHRoOiAzNjBweDsgb3ZlcmZsb3c6IGhpZGRlbjsgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2IoMCAwIDAgLyAuMjUpO1xufVxuLnBpbGwge1xuICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDIxNDc0ODM2NDc7IGxlZnQ6IDUwJTsgYm90dG9tOiAxOHB4OyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XG4gIGRpc3BsYXk6IG5vbmU7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogMTBweDsgcGFkZGluZzogN3B4IDhweCA3cHggMTRweDsgYm9yZGVyLXJhZGl1czogOTk5cHg7XG4gIGZvbnQ6IDYwMCAxMnB4LzEgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2Y0ZjJmZjsgYmFja2dyb3VuZDogIzFiMTgzMGVlO1xuICBib3gtc2hhZG93OiAwIDZweCAyNHB4IHJnYigwIDAgMCAvIC4zNSk7IGJhY2tkcm9wLWZpbHRlcjogYmx1cig2cHgpOyB1c2VyLXNlbGVjdDogbm9uZTtcbn1cbi5kb3QgeyB3aWR0aDogOXB4OyBoZWlnaHQ6IDlweDsgYm9yZGVyLXJhZGl1czogNTAlOyBiYWNrZ3JvdW5kOiAjZmY0ZDZkOyBhbmltYXRpb246IHB1bHNlIDEuMnMgaW5maW5pdGU7IH1cbi5waWxsLnBvaW50IC5kb3QgeyBiYWNrZ3JvdW5kOiAjN2M1Y2ZmOyB9XG5Aa2V5ZnJhbWVzIHB1bHNlIHsgNTAlIHsgb3BhY2l0eTogLjM1OyB9IH1cbi5waWxsIGJ1dHRvbiB7XG4gIGFsbDogdW5zZXQ7IGN1cnNvcjogcG9pbnRlcjsgcGFkZGluZzogNXB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OXB4OyBiYWNrZ3JvdW5kOiAjZmZmZmZmMWY7IGNvbG9yOiAjZmZmO1xuICBmb250OiA2MDAgMTFweC8xIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjtcbn1cbi5waWxsIGJ1dHRvbjpob3ZlciB7IGJhY2tncm91bmQ6ICNmZmZmZmYzODsgfVxuLnRvYXN0cyB7IHBvc2l0aW9uOiBmaXhlZDsgei1pbmRleDogMjE0NzQ4MzY0NzsgcmlnaHQ6IDE2cHg7IGJvdHRvbTogNjRweDsgZGlzcGxheTogZmxleDsgZmxleC1kaXJlY3Rpb246IGNvbHVtbjsgZ2FwOiA2cHg7IGFsaWduLWl0ZW1zOiBmbGV4LWVuZDsgcG9pbnRlci1ldmVudHM6IG5vbmU7IH1cbi50b2FzdCB7XG4gIGZvbnQ6IDUwMCAxMnB4LzEuMyB1aS1zYW5zLXNlcmlmLCBzeXN0ZW0tdWksIHNhbnMtc2VyaWY7IGNvbG9yOiAjZmZmOyBiYWNrZ3JvdW5kOiAjMWIxODMwZWU7IHBhZGRpbmc6IDdweCAxMXB4O1xuICBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlci1sZWZ0OiAzcHggc29saWQgdmFyKC0tYywgIzdjNWNmZik7IGJveC1zaGFkb3c6IDAgNHB4IDE0cHggcmdiKDAgMCAwIC8gLjMpO1xuICBhbmltYXRpb246IGluIC4xOHMgZWFzZS1vdXQ7IG1heC13aWR0aDogMzQwcHg7XG59XG4udG9hc3Qud2FybiB7IC0tYzogI2ZmYjAyMDsgfVxuQGtleWZyYW1lcyBpbiB7IGZyb20geyBvcGFjaXR5OiAwOyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNnB4KTsgfSB9XG5gO1xuXG5leHBvcnQgY29uc3QgQ09MT1JTID0geyBjbGljazogXCIjN2M1Y2ZmXCIsIGZpbGw6IFwiIzE0YjhhNlwiLCBzZWxlY3Q6IFwiIzBlYTVlOVwiLCBjaGVjazogXCIjMjJjNTVlXCIsIGZpbGU6IFwiI2ZmYjAyMFwiLCBydW46IFwiI2Y5NzMxNlwiIH0gYXMgY29uc3Q7XG5cbmNsYXNzIE92ZXJsYXkge1xuICBob3N0ITogSFRNTEVsZW1lbnQ7XG4gIHByaXZhdGUgYm94ITogSFRNTERpdkVsZW1lbnQ7XG4gIHByaXZhdGUgdGFnITogSFRNTERpdkVsZW1lbnQ7XG4gIHByaXZhdGUgcGlsbCE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHBpbGxUZXh0ITogSFRNTFNwYW5FbGVtZW50O1xuICBwcml2YXRlIHRvYXN0cyE6IEhUTUxEaXZFbGVtZW50O1xuICBvblN0b3A6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuICBwcml2YXRlIGVuc3VyZSgpIHtcbiAgICBpZiAodGhpcy5ob3N0Py5pc0Nvbm5lY3RlZCkgcmV0dXJuO1xuICAgIHRoaXMuaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgdGhpcy5ob3N0LmlkID0gXCJfX3Jhc3Ryb19ob3N0XCI7XG4gICAgY29uc3Qgcm9vdCA9IHRoaXMuaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiBcIm9wZW5cIiB9KTtcbiAgICByb290LmlubmVySFRNTCA9IGA8c3R5bGU+JHtDU1N9PC9zdHlsZT48ZGl2IGNsYXNzPVwiYm94XCI+PC9kaXY+PGRpdiBjbGFzcz1cInRhZ1wiPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInBpbGxcIj48c3BhbiBjbGFzcz1cImRvdFwiPjwvc3Bhbj48c3BhbiBjbGFzcz1cInR4dFwiPjwvc3Bhbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIj5UZXJtaW5hcjwvYnV0dG9uPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInRvYXN0c1wiPjwvZGl2PmA7XG4gICAgdGhpcy5ib3ggPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIuYm94XCIpITtcbiAgICB0aGlzLnRhZyA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi50YWdcIikhO1xuICAgIHRoaXMucGlsbCA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi5waWxsXCIpITtcbiAgICB0aGlzLnBpbGxUZXh0ID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLnR4dFwiKSE7XG4gICAgdGhpcy50b2FzdHMgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIudG9hc3RzXCIpITtcbiAgICByb290LnF1ZXJ5U2VsZWN0b3IoXCJidXR0b25cIikhLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIHRoaXMub25TdG9wKCk7XG4gICAgfSk7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKHRoaXMuaG9zdCk7XG4gIH1cblxuICBvd25zKGVsOiBFdmVudFRhcmdldCB8IG51bGwpOiBib29sZWFuIHtcbiAgICByZXR1cm4gISF0aGlzLmhvc3QgJiYgZWwgaW5zdGFuY2VvZiBOb2RlICYmIChlbCA9PT0gdGhpcy5ob3N0IHx8IHRoaXMuaG9zdC5jb250YWlucyhlbCkpO1xuICB9XG5cbiAgc2hvdyhlbDogRWxlbWVudCwgdGV4dDogc3RyaW5nLCBjb2xvcjogc3RyaW5nID0gQ09MT1JTLmNsaWNrKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLmJveC5zdHlsZSwge1xuICAgICAgZGlzcGxheTogXCJibG9ja1wiLCBsZWZ0OiBgJHtyLmxlZnQgLSAzfXB4YCwgdG9wOiBgJHtyLnRvcCAtIDN9cHhgLCB3aWR0aDogYCR7ci53aWR0aCArIDZ9cHhgLCBoZWlnaHQ6IGAke3IuaGVpZ2h0ICsgNn1weGAsXG4gICAgfSk7XG4gICAgdGhpcy5ib3guc3R5bGUuc2V0UHJvcGVydHkoXCItLWNcIiwgY29sb3IpO1xuICAgIHRoaXMudGFnLnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0aGlzLnRhZy50ZXh0Q29udGVudCA9IHRleHQ7XG4gICAgdGhpcy50YWcuc3R5bGUuZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgICBjb25zdCBhYm92ZSA9IHIudG9wID4gMzA7XG4gICAgdGhpcy50YWcuc3R5bGUubGVmdCA9IGAke01hdGgubWF4KDQsIE1hdGgubWluKHIubGVmdCAtIDMsIGlubmVyV2lkdGggLSAzNzApKX1weGA7XG4gICAgdGhpcy50YWcuc3R5bGUudG9wID0gYWJvdmUgPyBgJHtyLnRvcCAtIDI3fXB4YCA6IGAke3IuYm90dG9tICsgNn1weGA7XG4gIH1cblxuICBoaWRlKCkge1xuICAgIGlmICghdGhpcy5ib3gpIHJldHVybjtcbiAgICB0aGlzLmJveC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgdGhpcy50YWcuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICB9XG5cbiAgLyoqIFJlc2FsdGEgYnJldmVtZW50ZSAocmVwcm9kdWNjacOzbiAvIFwidmVyIGVsZW1lbnRvXCIpLiAqL1xuICBmbGFzaChlbDogRWxlbWVudCwgdGV4dDogc3RyaW5nLCBtcyA9IDcwMCwgY29sb3I6IHN0cmluZyA9IENPTE9SUy5ydW4pIHtcbiAgICB0aGlzLnNob3coZWwsIHRleHQsIGNvbG9yKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMuaGlkZSgpLCBtcyk7XG4gIH1cblxuICBzZXRQaWxsKG1vZGU6IFwicmVjb3JkXCIgfCBcInBvaW50XCIgfCBudWxsKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBpZiAoIW1vZGUpIHtcbiAgICAgIHRoaXMucGlsbC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMucGlsbC5jbGFzc05hbWUgPSBcInBpbGwgXCIgKyBtb2RlO1xuICAgIHRoaXMucGlsbFRleHQudGV4dENvbnRlbnQgPSBtb2RlID09PSBcInJlY29yZFwiID8gXCJSYXN0cm8gZ3JhYmFuZG9cIiA6IFwiUmFzdHJvIMK3IG1vZG8gc2XDsWFsYXIgKEVzYyBwYXJhIHNhbGlyKVwiO1xuICAgIHRoaXMucGlsbC5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gIH1cblxuICB0b2FzdCh0ZXh0OiBzdHJpbmcsIGNvbG9yPzogc3RyaW5nLCB3YXJuID0gZmFsc2UpIHtcbiAgICB0aGlzLmVuc3VyZSgpO1xuICAgIGNvbnN0IHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHQuY2xhc3NOYW1lID0gXCJ0b2FzdFwiICsgKHdhcm4gPyBcIiB3YXJuXCIgOiBcIlwiKTtcbiAgICBpZiAoY29sb3IpIHQuc3R5bGUuc2V0UHJvcGVydHkoXCItLWNcIiwgY29sb3IpO1xuICAgIHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICAgIHRoaXMudG9hc3RzLmFwcGVuZENoaWxkKHQpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gdC5yZW1vdmUoKSwgMjIwMCk7XG4gICAgd2hpbGUgKHRoaXMudG9hc3RzLmNoaWxkcmVuLmxlbmd0aCA+IDQpIHRoaXMudG9hc3RzLmZpcnN0RWxlbWVudENoaWxkIS5yZW1vdmUoKTtcbiAgfVxufVxuXG5leHBvcnQgY29uc3Qgb3ZlcmxheSA9IG5ldyBPdmVybGF5KCk7XG4iLAogICAgIi8vIE1vdG9yIGRlIHNlbGVjdG9yZXMgcHJvcGlvLlxuLy9cbi8vIFNpbnRheGlzIHNvcG9ydGFkYTpcbi8vICAgY3NzICAgICAgICAgICAg4oaSIGN1YWxxdWllciBzZWxlY3RvciBDU1MgKHBvciBkZWZlY3RvKVxuLy8gICBmcmFtZT0yICAgICAgICDihpIgZWwgdGVyY2VyIDxpZnJhbWU+IGRlbCBkb2N1bWVudG8gKHBhcmEgcnV0YXMgZGUgZnJhbWVzIGltcG9ydGFkYXMpXG4vLyAgIHRleHQ9RW52aWFyICAgIOKGkiBlbGVtZW50byBjdXlvIHRleHRvIHZpc2libGUgZXMgZXhhY3RhbWVudGUgwqtFbnZpYXLCuyAobywgc2kgbm8gaGF5LCBxdWUgbG8gY29udGllbmUpXG4vLyAgIGxhYmVsPUVtYWlsICAgIOKGkiBjb250cm9sIGRlIGZvcm11bGFyaW8gYXNvY2lhZG8gYSBsYSBldGlxdWV0YS9hcmlhLWxhYmVsIMKrRW1haWzCu1xuLy8gICB4cGF0aD0vL2RpdlsxXSDihpIgWFBhdGhcbi8vXG4vLyBBbCBnZW5lcmFyLCBzZSBwcm9kdWNlbiB2YXJpb3MgY2FuZGlkYXRvcyBvcmRlbmFkb3MgcG9yIHJvYnVzdGV6LiBFbCByZXByb2R1Y3RvclxuLy8gcHJ1ZWJhIGVsIHByaW5jaXBhbCB5LCBzaSBmYWxsYSwgbG9zIGFsdGVybmF0aXZvcy5cblxuaW1wb3J0IHsgbG9va3NHZW5lcmF0ZWQgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcblxuY29uc3QgVEVTVF9BVFRSUyA9IFtcImRhdGEtdGVzdGlkXCIsIFwiZGF0YS10ZXN0LWlkXCIsIFwiZGF0YS10ZXN0XCIsIFwiZGF0YS1jeVwiLCBcImRhdGEtcWFcIiwgXCJkYXRhLWUyZVwiLCBcImRhdGEtYXV0b21hdGlvbi1pZFwiXTtcblxuY29uc3QgQ0xJQ0tBQkxFID1cbiAgJ2J1dHRvbiwgYVtocmVmXSwgW3JvbGU9XCJidXR0b25cIl0sIFtyb2xlPVwibGlua1wiXSwgW3JvbGU9XCJtZW51aXRlbVwiXSwgW3JvbGU9XCJ0YWJcIl0sIFtyb2xlPVwib3B0aW9uXCJdLCAnICtcbiAgJ1tyb2xlPVwiY2hlY2tib3hcIl0sIFtyb2xlPVwicmFkaW9cIl0sIFtyb2xlPVwic3dpdGNoXCJdLCBpbnB1dFt0eXBlPVwic3VibWl0XCJdLCBpbnB1dFt0eXBlPVwiYnV0dG9uXCJdLCAnICtcbiAgJ2lucHV0W3R5cGU9XCJyZXNldFwiXSwgaW5wdXRbdHlwZT1cImltYWdlXCJdLCBzdW1tYXJ5LCBsYWJlbCwgW29uY2xpY2tdJztcblxuZXhwb3J0IGNvbnN0IENPTlRST0wgPSAnaW5wdXQsIHRleHRhcmVhLCBzZWxlY3QsIFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pJztcblxuY29uc3Qgbm9ybSA9IChzOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSA9PiAocyA/PyBcIlwiKS5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKS50cmltKCk7XG5cbmNvbnN0IFNUQVRFX0NMQVNTRVMgPSAvXihpcy18aGFzLSk/KGFjdGl2ZXxmb2N1cyhlZCk/fGhvdmVyKGVkKT98c2VsZWN0ZWR8b3BlbihlZCk/fGRpc2FibGVkfGNoZWNrZWR8dmlzaWJsZXxoaWRkZW58c2hvd3xpbnxuZy0uKikkL2k7XG5cbi8vIMOabHRpbWEgcGFsYWJyYSBkZSB1bmEgY2xhc2UgQkVNL3V0aWxpdGFyaWEgcXVlIGluZGljYSBlc3RhZG86IGlzLWhvdmVyaW5nLCBhbnQtc2VsZWN0LWl0ZW0tb3B0aW9uLWFjdGl2ZSxcbi8vIHYtbGlzdC1pdGVtLS1oaWdobGlnaHRlZCwgTXVpLWZvY3VzVmlzaWJsZSwgcm91dGVyLWxpbmstZXhhY3QtYWN0aXZl4oCmXG5jb25zdCBTVEFURV9XT1JEUyA9IG5ldyBTZXQoW1xuICBcImFjdGl2ZVwiLCBcImZvY3VzXCIsIFwiZm9jdXNlZFwiLCBcImZvY3VzdmlzaWJsZVwiLCBcImZvY3Vzd2l0aGluXCIsIFwiaG92ZXJcIiwgXCJob3ZlcmVkXCIsIFwiaG92ZXJpbmdcIiwgXCJoaWdobGlnaHRcIiwgXCJoaWdobGlnaHRlZFwiLFxuICBcInNlbGVjdGVkXCIsIFwiY3VycmVudFwiLCBcIm9wZW5cIiwgXCJvcGVuZWRcIiwgXCJleHBhbmRlZFwiLCBcImNvbGxhcHNlZFwiLCBcInByZXNzZWRcIiwgXCJkaXNhYmxlZFwiLCBcImNoZWNrZWRcIiwgXCJ2aXNpYmxlXCIsIFwiaGlkZGVuXCIsXG4gIFwic2hvd25cIiwgXCJlbnRlclwiLCBcImVudGVyaW5nXCIsIFwibGVhdmVcIiwgXCJsZWF2aW5nXCIsIFwidG91Y2hlZFwiLCBcImRpcnR5XCIsIFwicHJpc3RpbmVcIiwgXCJ2YWxpZFwiLCBcImludmFsaWRcIiwgXCJlcnJvclwiLFxuXSk7XG5cbmZ1bmN0aW9uIGlzU3RhdGVDbGFzcyhjOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgaWYgKFNUQVRFX0NMQVNTRVMudGVzdChjKSkgcmV0dXJuIHRydWU7XG4gIGNvbnN0IHdvcmRzID0gYy5zcGxpdCgvWy1fXSt8KD88PVthLXpdKSg/PVtBLVpdKS8pLmZpbHRlcihCb29sZWFuKTtcbiAgcmV0dXJuIHdvcmRzLmxlbmd0aCA+IDEgJiYgU1RBVEVfV09SRFMuaGFzKHdvcmRzLmF0KC0xKSEudG9Mb3dlckNhc2UoKSk7XG59XG5cbi8vIENsYXNlcyBxdWUgc2UgaGFuIHZpc3RvIGFwYXJlY2VyL2Rlc2FwYXJlY2VyIGR1cmFudGUgbGEgZ3JhYmFjacOzbiAoaG92ZXIsIGZvY3VzLCBhYmllcnRv4oCmKTpcbi8vIGRlcGVuZGVuIGRlbCBlc3RhZG8gZGVsIHJhdMOzbiBvIGRlIGxhIFVJLCBhc8OtIHF1ZSBubyBzaXJ2ZW4gcGFyYSByZWVuY29udHJhciBlbCBlbGVtZW50by5cbmNvbnN0IHZvbGF0aWxlID0gbmV3IFNldDxzdHJpbmc+KCk7XG5sZXQgY2xhc3NPYnNlcnZlcjogTXV0YXRpb25PYnNlcnZlciB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBub3RlQ2xhc3NDaGFuZ2VzKHJlY29yZHM6IE11dGF0aW9uUmVjb3JkW10pIHtcbiAgZm9yIChjb25zdCByIG9mIHJlY29yZHMpIHtcbiAgICBjb25zdCBiZWZvcmUgPSBuZXcgU2V0KChyLm9sZFZhbHVlID8/IFwiXCIpLnNwbGl0KC9cXHMrLykuZmlsdGVyKEJvb2xlYW4pKTtcbiAgICBjb25zdCBhZnRlciA9IChyLnRhcmdldCBhcyBFbGVtZW50KS5jbGFzc0xpc3Q7XG4gICAgZm9yIChjb25zdCBjIG9mIGFmdGVyKSBpZiAoIWJlZm9yZS5oYXMoYykpIHZvbGF0aWxlLmFkZChjKTtcbiAgICBmb3IgKGNvbnN0IGMgb2YgYmVmb3JlKSBpZiAoIWFmdGVyLmNvbnRhaW5zKGMpKSB2b2xhdGlsZS5hZGQoYyk7XG4gIH1cbn1cblxuLyoqIEVtcGllemEvcGFyYSBkZSBhbm90YXIgY2xhc2VzIHF1ZSBjYW1iaWFuLiBTZSBhY3RpdmEgbWllbnRyYXMgc2UgZ3JhYmEgbyBzZSBzZcOxYWxhLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYWNrVm9sYXRpbGVDbGFzc2VzKG9uOiBib29sZWFuKSB7XG4gIGlmIChvbiAmJiAhY2xhc3NPYnNlcnZlcikge1xuICAgIGNsYXNzT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihub3RlQ2xhc3NDaGFuZ2VzKTtcbiAgICBjbGFzc09ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LCB7IHN1YnRyZWU6IHRydWUsIGF0dHJpYnV0ZXM6IHRydWUsIGF0dHJpYnV0ZUZpbHRlcjogW1wiY2xhc3NcIl0sIGF0dHJpYnV0ZU9sZFZhbHVlOiB0cnVlIH0pO1xuICB9IGVsc2UgaWYgKCFvbiAmJiBjbGFzc09ic2VydmVyKSB7XG4gICAgbm90ZUNsYXNzQ2hhbmdlcyhjbGFzc09ic2VydmVyLnRha2VSZWNvcmRzKCkpO1xuICAgIGNsYXNzT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgIGNsYXNzT2JzZXJ2ZXIgPSBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0YWJsZUNsYXNzZXMoZWw6IEVsZW1lbnQpOiBzdHJpbmdbXSB7XG4gIC8vIFByb2Nlc2FyIG11dGFjaW9uZXMgcGVuZGllbnRlczogbGEgY2xhc2UgZGUgaG92ZXIgcHVlZGUgaGFiZXJzZSBhw7FhZGlkbyBqdXN0byBhbnRlcyBkZWwgY2xpY2suXG4gIGlmIChjbGFzc09ic2VydmVyKSBub3RlQ2xhc3NDaGFuZ2VzKGNsYXNzT2JzZXJ2ZXIudGFrZVJlY29yZHMoKSk7XG4gIHJldHVybiBbLi4uZWwuY2xhc3NMaXN0XS5maWx0ZXIoXG4gICAgKGMpID0+ICFsb29rc0dlbmVyYXRlZChjKSAmJiAhaXNTdGF0ZUNsYXNzKGMpICYmICF2b2xhdGlsZS5oYXMoYykgJiYgIWMuaW5jbHVkZXMoXCI6XCIpICYmIGMubGVuZ3RoIDwgMzIsXG4gICk7XG59XG5cbmNvbnN0IHEgPSAodjogc3RyaW5nKSA9PiBKU09OLnN0cmluZ2lmeSh2KTsgLy8gY29taWxsYXMgKyBlc2NhcGVzIHbDoWxpZG9zIGVuIENTU1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUmVzb2x1Y2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKCFlbC5pc0Nvbm5lY3RlZCkgcmV0dXJuIGZhbHNlO1xuICBpZiAoZWwuZ2V0Q2xpZW50UmVjdHMoKS5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3QgPSBnZXRDb21wdXRlZFN0eWxlKGVsKTtcbiAgcmV0dXJuIHN0LnZpc2liaWxpdHkgIT09IFwiaGlkZGVuXCIgJiYgc3Qub3BhY2l0eSAhPT0gXCIwXCI7XG59XG5cbi8qKiBUZXh0byDCq3Zpc2libGXCuyBkZSB1biBlbGVtZW50bywgY29tbyBsbyB2ZXLDrWEgZWwgdXN1YXJpby4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXh0T2YoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIFtcInN1Ym1pdFwiLCBcImJ1dHRvblwiLCBcInJlc2V0XCJdLmluY2x1ZGVzKGVsLnR5cGUpKSByZXR1cm4gbm9ybShlbC52YWx1ZSk7XG4gIHJldHVybiBub3JtKChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0ID8/IGVsLnRleHRDb250ZW50KTtcbn1cblxuZnVuY3Rpb24qIGFsbEVsZW1lbnRzKHJvb3Q6IERvY3VtZW50IHwgU2hhZG93Um9vdCA9IGRvY3VtZW50KTogR2VuZXJhdG9yPEVsZW1lbnQ+IHtcbiAgY29uc3Qgd2Fsa2VyID0gZG9jdW1lbnQuY3JlYXRlVHJlZVdhbGtlcihyb290LCBOb2RlRmlsdGVyLlNIT1dfRUxFTUVOVCk7XG4gIGxldCBuID0gd2Fsa2VyLm5leHROb2RlKCk7XG4gIHdoaWxlIChuKSB7XG4gICAgeWllbGQgbiBhcyBFbGVtZW50O1xuICAgIGNvbnN0IHNyID0gKG4gYXMgRWxlbWVudCkuc2hhZG93Um9vdDtcbiAgICBpZiAoc3IpIHlpZWxkKiBhbGxFbGVtZW50cyhzcik7XG4gICAgbiA9IHdhbGtlci5uZXh0Tm9kZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGJ5VGV4dCh0ZXh0OiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCB0YXJnZXQgPSBub3JtKHRleHQpO1xuICBjb25zdCBleGFjdDogRWxlbWVudFtdID0gW107XG4gIGNvbnN0IHBhcnRpYWw6IEVsZW1lbnRbXSA9IFtdO1xuICBjb25zdCBsb3dlciA9IHRhcmdldC50b0xvd2VyQ2FzZSgpO1xuICBmb3IgKGNvbnN0IGVsIG9mIGFsbEVsZW1lbnRzKCkpIHtcbiAgICBpZiAoZWwuY2xvc2VzdChcInNjcmlwdCwgc3R5bGUsIG5vc2NyaXB0LCB0ZW1wbGF0ZSwgI19fcmFzdHJvX2hvc3RcIikpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxpbWl0ID0gdGFyZ2V0Lmxlbmd0aCAqIDMgKyAyMDtcbiAgICAvLyB0ZXh0Q29udGVudCBlcyBiYXJhdG87IGlubmVyVGV4dCBmdWVyemEgbGF5b3V0LCBhc8OtIHF1ZSBzb2xvIHBhcmEgY2FuZGlkYXRvcyBjb3J0b3MuXG4gICAgaWYgKCEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSAmJiBub3JtKGVsLnRleHRDb250ZW50KS5sZW5ndGggPiBsaW1pdCkgY29udGludWU7XG4gICAgY29uc3QgdCA9IHRleHRPZihlbCk7XG4gICAgaWYgKCF0IHx8IHQubGVuZ3RoID4gbGltaXQpIGNvbnRpbnVlO1xuICAgIGlmICh0ID09PSB0YXJnZXQpIGV4YWN0LnB1c2goZWwpO1xuICAgIGVsc2UgaWYgKHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlcikpIHBhcnRpYWwucHVzaChlbCk7XG4gIH1cbiAgY29uc3QgcGljayA9IGV4YWN0Lmxlbmd0aCA/IGV4YWN0IDogcGFydGlhbDtcbiAgLy8gUXVlZGFyc2UgY29uIGVsIG3DoXMgcHJvZnVuZG8geSBzdWJpciBhIHN1IGFuY2VzdHJvIGNsaWNhYmxlIHNpIGxvIGhheS5cbiAgY29uc3QgZGVlcGVzdCA9IHBpY2suZmlsdGVyKChlbCkgPT4gIXBpY2suc29tZSgobykgPT4gbyAhPT0gZWwgJiYgZWwuY29udGFpbnMobykpKTtcbiAgcmV0dXJuIGRlZHVwZShkZWVwZXN0Lm1hcCgoZWwpID0+IGVsLmNsb3Nlc3QoQ0xJQ0tBQkxFKSA/PyBlbCkpO1xufVxuXG5mdW5jdGlvbiBieUxhYmVsKHRleHQ6IHN0cmluZyk6IEVsZW1lbnRbXSB7XG4gIGNvbnN0IHRhcmdldCA9IG5vcm0odGV4dCkudG9Mb3dlckNhc2UoKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChjb25zdCBsYWJlbCBvZiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxcIikpIHtcbiAgICBpZiAobm9ybShsYWJlbC5pbm5lclRleHQpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKlxcKiQvLCBcIlwiKSA9PT0gdGFyZ2V0ICYmIGxhYmVsLmNvbnRyb2wpIG91dC5wdXNoKGxhYmVsLmNvbnRyb2wpO1xuICB9XG4gIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChDT05UUk9MICsgXCIsIFthcmlhLWxhYmVsXSwgW2FyaWEtbGFiZWxsZWRieV1cIikpIHtcbiAgICBpZiAobm9ybShlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICBjb25zdCBsYiA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxsZWRieVwiKTtcbiAgICBpZiAobGIpIHtcbiAgICAgIGNvbnN0IHQgPSBsYlxuICAgICAgICAuc3BsaXQoL1xccysvKVxuICAgICAgICAubWFwKChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpPy5pbm5lclRleHQgPz8gXCJcIilcbiAgICAgICAgLmpvaW4oXCIgXCIpO1xuICAgICAgaWYgKG5vcm0odCkudG9Mb3dlckNhc2UoKSA9PT0gdGFyZ2V0KSBvdXQucHVzaChlbCk7XG4gICAgfVxuICB9XG4gIGlmICghb3V0Lmxlbmd0aCkge1xuICAgIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIltwbGFjZWhvbGRlcl1cIikpIHtcbiAgICAgIGlmIChub3JtKGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRlZHVwZShvdXQpO1xufVxuXG5mdW5jdGlvbiBieVhQYXRoKHhwOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCByZXMgPSBkb2N1bWVudC5ldmFsdWF0ZSh4cCwgZG9jdW1lbnQsIG51bGwsIFhQYXRoUmVzdWx0Lk9SREVSRURfTk9ERV9TTkFQU0hPVF9UWVBFLCBudWxsKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXMuc25hcHNob3RMZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG4gPSByZXMuc25hcHNob3RJdGVtKGkpO1xuICAgIGlmIChuIGluc3RhbmNlb2YgRWxlbWVudCkgb3V0LnB1c2gobik7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZGVkdXBlPFQ+KGFycjogVFtdKTogVFtdIHtcbiAgcmV0dXJuIFsuLi5uZXcgU2V0KGFycildO1xufVxuXG4vKiogRGV2dWVsdmUgdG9kb3MgbG9zIGVsZW1lbnRvcyBxdWUgY2FzYW4gY29uIHVuIHNlbGVjdG9yIGRlIFJhc3Ryby4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQWxsKHNlbGVjdG9yOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICB0cnkge1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwidGV4dD1cIikpIHJldHVybiBieVRleHQodW5xdW90ZShzZWxlY3Rvci5zbGljZSg1KSkpO1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwibGFiZWw9XCIpKSByZXR1cm4gYnlMYWJlbCh1bnF1b3RlKHNlbGVjdG9yLnNsaWNlKDYpKSk7XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJ4cGF0aD1cIikpIHJldHVybiBieVhQYXRoKHNlbGVjdG9yLnNsaWNlKDYpKTtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcImZyYW1lPVwiKSkge1xuICAgICAgLy8gTi3DqXNpbW8gaWZyYW1lIGRlbCBkb2N1bWVudG8gKGZvcm1hdG8gZGUgRGV2VG9vbHMgUmVjb3JkZXIpLlxuICAgICAgY29uc3QgZiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWUsIGZyYW1lXCIpW051bWJlcihzZWxlY3Rvci5zbGljZSg2KSldO1xuICAgICAgcmV0dXJuIGYgPyBbZl0gOiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKV07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBbXTtcbiAgfVxufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHQgPSBzLnRyaW0oKTtcbiAgaWYgKCh0LnN0YXJ0c1dpdGgoJ1wiJykgJiYgdC5lbmRzV2l0aCgnXCInKSkgfHwgKHQuc3RhcnRzV2l0aChcIidcIikgJiYgdC5lbmRzV2l0aChcIidcIikpKSByZXR1cm4gdC5zbGljZSgxLCAtMSk7XG4gIHJldHVybiB0O1xufVxuXG4vKiogRW5jdWVudHJhIGVsIHByaW1lciBzZWxlY3RvciBxdWUgcmVzdWVsdmUgYSBleGFjdGFtZW50ZSB1biBlbGVtZW50byAobyBhbCBwcmltZXJvIHZpc2libGUpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmUoc2VsZWN0b3JzOiBzdHJpbmdbXSk6IHsgZWw6IEVsZW1lbnQ7IHNlbGVjdG9yOiBzdHJpbmcgfSB8IG51bGwge1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBjb25zdCBmb3VuZCA9IHJlc29sdmVBbGwoc2VsKTtcbiAgICBpZiAoZm91bmQubGVuZ3RoID09PSAxKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gICAgY29uc3QgdmlzID0gZm91bmQuZmlsdGVyKGlzVmlzaWJsZSk7XG4gICAgaWYgKHZpcy5sZW5ndGggPj0gMSkgcmV0dXJuIHsgZWw6IHZpc1swXSEsIHNlbGVjdG9yOiBzZWwgfTtcbiAgICBpZiAoZm91bmQubGVuZ3RoKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBHZW5lcmFjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gaXNVbmlxdWUoc2VsOiBzdHJpbmcsIGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlQWxsKHNlbCk7XG4gIHJldHVybiByLmxlbmd0aCA9PT0gMSAmJiByWzBdID09PSBlbDtcbn1cblxuZnVuY3Rpb24gY3NzUGF0aChlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgY3VyOiBFbGVtZW50IHwgbnVsbCA9IGVsO1xuICB3aGlsZSAoY3VyICYmIGN1ciAhPT0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KSB7XG4gICAgY29uc3QgdGFnID0gY3VyLnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoY3VyICE9PSBlbCAmJiBjdXIuaWQgJiYgIWxvb2tzR2VuZXJhdGVkKGN1ci5pZCkpIHtcbiAgICAgIHBhcnRzLnVuc2hpZnQoXCIjXCIgKyBDU1MuZXNjYXBlKGN1ci5pZCkpO1xuICAgICAgY29uc3QgcyA9IHBhcnRzLmpvaW4oXCIgPiBcIik7XG4gICAgICBpZiAoaXNVbmlxdWUocywgZWwpKSByZXR1cm4gcztcbiAgICAgIHBhcnRzLnNoaWZ0KCk7XG4gICAgfVxuICAgIGxldCBzZWcgPSB0YWc7XG4gICAgY29uc3QgY2xzID0gc3RhYmxlQ2xhc3NlcyhjdXIpLnNsaWNlKDAsIDIpO1xuICAgIGlmIChjbHMubGVuZ3RoKSBzZWcgKz0gXCIuXCIgKyBjbHMubWFwKChjKSA9PiBDU1MuZXNjYXBlKGMpKS5qb2luKFwiLlwiKTtcblxuICAgIGNvbnN0IHdpdGhvdXROdGggPSBbc2VnLCAuLi5wYXJ0c10uam9pbihcIiA+IFwiKTtcbiAgICBpZiAoaXNVbmlxdWUod2l0aG91dE50aCwgZWwpKSByZXR1cm4gd2l0aG91dE50aDtcblxuICAgIGNvbnN0IHBhcmVudDogRWxlbWVudCB8IG51bGwgPSBjdXIucGFyZW50RWxlbWVudDtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICBjb25zdCBzYW1lID0gWy4uLnBhcmVudC5jaGlsZHJlbl0uZmlsdGVyKChjKSA9PiBjLnRhZ05hbWUgPT09IGN1ciEudGFnTmFtZSk7XG4gICAgICBpZiAoc2FtZS5sZW5ndGggPiAxKSBzZWcgKz0gYDpudGgtb2YtdHlwZSgke3NhbWUuaW5kZXhPZihjdXIpICsgMX0pYDtcbiAgICB9XG4gICAgcGFydHMudW5zaGlmdChzZWcpO1xuICAgIGNvbnN0IHMgPSBwYXJ0cy5qb2luKFwiID4gXCIpO1xuICAgIGlmIChpc1VuaXF1ZShzLCBlbCkpIHJldHVybiBzO1xuICAgIGN1ciA9IHBhcmVudDtcbiAgfVxuICByZXR1cm4gcGFydHMuam9pbihcIiA+IFwiKTtcbn1cblxuLyoqIEdlbmVyYSBzZWxlY3RvcmVzIGNhbmRpZGF0b3Mgb3JkZW5hZG9zIGRlIG3DoXMgYSBtZW5vcyByb2J1c3RvLiBUb2RvcyDDum5pY29zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkU2VsZWN0b3JzKGVsOiBFbGVtZW50KTogc3RyaW5nW10ge1xuICBjb25zdCB0YWcgPSBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGM6IHN0cmluZ1tdID0gW107XG5cbiAgZm9yIChjb25zdCBhIG9mIFRFU1RfQVRUUlMpIHtcbiAgICBjb25zdCB2ID0gZWwuZ2V0QXR0cmlidXRlKGEpO1xuICAgIGlmICh2KSBjLnB1c2goYFske2F9PSR7cSh2KX1dYCk7XG4gIH1cbiAgaWYgKGVsLmlkICYmICFsb29rc0dlbmVyYXRlZChlbC5pZCkpIGMucHVzaChcIiNcIiArIENTUy5lc2NhcGUoZWwuaWQpKTtcblxuICBjb25zdCBuYW1lID0gZWwuZ2V0QXR0cmlidXRlKFwibmFtZVwiKTtcbiAgaWYgKG5hbWUpIHtcbiAgICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIChlbC50eXBlID09PSBcInJhZGlvXCIgfHwgZWwudHlwZSA9PT0gXCJjaGVja2JveFwiKSAmJiBlbC52YWx1ZSAmJiBlbC52YWx1ZSAhPT0gXCJvblwiKSB7XG4gICAgICBjLnB1c2goYCR7dGFnfVtuYW1lPSR7cShuYW1lKX1dW3ZhbHVlPSR7cShlbC52YWx1ZSl9XWApO1xuICAgIH0gZWxzZSBjLnB1c2goYCR7dGFnfVtuYW1lPSR7cShuYW1lKX1dYCk7XG4gIH1cblxuICBjb25zdCBpc0NvbnRyb2wgPSBlbC5tYXRjaGVzKENPTlRST0wpO1xuICBpZiAoaXNDb250cm9sKSB7XG4gICAgY29uc3QgbGJsID0gbGFiZWxUZXh0KGVsKTtcbiAgICBpZiAobGJsICYmIGxibC5sZW5ndGggPD0gNjApIGMucHVzaChgbGFiZWw9JHtsYmx9YCk7XG4gIH1cblxuICBjb25zdCBhcmlhID0gZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKTtcbiAgaWYgKGFyaWEpIGMucHVzaChgJHt0YWd9W2FyaWEtbGFiZWw9JHtxKGFyaWEpfV1gKTtcbiAgY29uc3QgcGggPSBlbC5nZXRBdHRyaWJ1dGUoXCJwbGFjZWhvbGRlclwiKTtcbiAgaWYgKHBoKSBjLnB1c2goYCR7dGFnfVtwbGFjZWhvbGRlcj0ke3EocGgpfV1gKTtcblxuICBpZiAoIWlzQ29udHJvbCkge1xuICAgIGNvbnN0IHQgPSB0ZXh0T2YoZWwpO1xuICAgIGlmICh0ICYmIHQubGVuZ3RoIDw9IDUwICYmICFlbC5xdWVyeVNlbGVjdG9yKENPTlRST0wpKSBjLnB1c2goYHRleHQ9JHt0fWApO1xuICB9XG5cbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICBjb25zdCBocmVmID0gZWwuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKTtcbiAgICBpZiAoaHJlZiAmJiBocmVmLmxlbmd0aCA8IDgwICYmICFocmVmLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSAmJiBocmVmICE9PSBcIiNcIikgYy5wdXNoKGBhW2hyZWY9JHtxKGhyZWYpfV1gKTtcbiAgfVxuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSUZyYW1lRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxGcmFtZUVsZW1lbnQpIHtcbiAgICBjb25zdCBzcmMgPSBlbC5nZXRBdHRyaWJ1dGUoXCJzcmNcIik7XG4gICAgaWYgKHNyYyAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJkYXRhOlwiKSAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSkge1xuICAgICAgLy8gU2luIHF1ZXJ5IHN0cmluZzogc3VlbGUgbGxldmFyIHRva2VucyBxdWUgY2FtYmlhbiBlbiBjYWRhIGNhcmdhLlxuICAgICAgY29uc3QgYmFzZSA9IHNyYy5zcGxpdCgvWz8jXS8pWzBdITtcbiAgICAgIGMucHVzaChiYXNlID09PSBzcmMgPyBgJHt0YWd9W3NyYz0ke3Eoc3JjKX1dYCA6IGAke3RhZ31bc3JjXj0ke3EoYmFzZSl9XWApO1xuICAgIH1cbiAgfVxuICBjb25zdCB0aXRsZSA9IGVsLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpO1xuICBpZiAodGl0bGUpIGMucHVzaChgJHt0YWd9W3RpdGxlPSR7cSh0aXRsZSl9XWApO1xuXG4gIC8vIHRleHQ9IGFwdW50YSBhbCBub2RvIG3DoXMgcHJvZnVuZG8gY29uIGVzZSB0ZXh0byAocC4gZWouIGVsIDxzcGFuPiBkZSB1biA8bGk+IGRlIGRlc3BsZWdhYmxlKTogY2xpY2FybG8gZXF1aXZhbGUuXG4gIGNvbnN0IHNhbWVUYXJnZXQgPSAoczogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgaXNUZXh0ID0gcy5zdGFydHNXaXRoKFwidGV4dD1cIik7XG4gICAgY29uc3QgaGl0ID0gKHg6IEVsZW1lbnQpID0+IHggPT09IGVsIHx8IChpc1RleHQgJiYgZWwuY29udGFpbnMoeCkgJiYgdGV4dE9mKHgpID09PSB0ZXh0T2YoZWwpKTtcbiAgICBjb25zdCByID0gcmVzb2x2ZUFsbChzKTtcbiAgICBpZiAoci5sZW5ndGggPT09IDEpIHJldHVybiBoaXQoclswXSEpO1xuICAgIC8vIERlc3BsZWdhYmxlcyB0ZWxldHJhbnNwb3J0YWRvcyAoRWxlbWVudCBQbHVzLCBBbnTigKYpOiBsYXMgb3BjaW9uZXMgZGUgb3Ryb3Mgc2VsZWN0cyBzaWd1ZW4gZW4gZWwgRE9NXG4gICAgLy8gcGVybyBvY3VsdGFzLiBTaSBlbCDDum5pY28gdmlzaWJsZSBlcyBlbCBudWVzdHJvLCByZXNvbHZlKCkgbG8gZWxlZ2lyw6EgdGFtYmnDqW4gYWwgcmVwcm9kdWNpci5cbiAgICBpZiAoIWlzVGV4dCkgcmV0dXJuIGZhbHNlO1xuICAgIGNvbnN0IHZpcyA9IHIuZmlsdGVyKGlzVmlzaWJsZSk7XG4gICAgcmV0dXJuIHZpcy5sZW5ndGggPT09IDEgJiYgaGl0KHZpc1swXSEpO1xuICB9O1xuICBjb25zdCB1bmlxdWUgPSBkZWR1cGUoYykuZmlsdGVyKHNhbWVUYXJnZXQpO1xuICB1bmlxdWUucHVzaChjc3NQYXRoKGVsKSk7XG4gIHJldHVybiBkZWR1cGUodW5pcXVlKS5zbGljZSgwLCA1KTtcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIERlc2NyaXBjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGZ1bmN0aW9uIGxhYmVsVGV4dChlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGlmICgoZWwgYXMgSFRNTElucHV0RWxlbWVudCkubGFiZWxzPy5sZW5ndGgpIHtcbiAgICBjb25zdCB0ID0gbm9ybSgoZWwgYXMgSFRNTElucHV0RWxlbWVudCkubGFiZWxzIVswXSEuaW5uZXJUZXh0KS5yZXBsYWNlKC9cXHMqXFwqJC8sIFwiXCIpO1xuICAgIGlmICh0KSByZXR1cm4gdDtcbiAgfVxuICBjb25zdCBhcmlhID0gZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKTtcbiAgaWYgKGFyaWEpIHJldHVybiBub3JtKGFyaWEpO1xuICBjb25zdCBsYiA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxsZWRieVwiKTtcbiAgaWYgKGxiKSB7XG4gICAgY29uc3QgdCA9IG5vcm0obGIuc3BsaXQoL1xccysvKS5tYXAoKGlkKSA9PiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCk/LmlubmVyVGV4dCA/PyBcIlwiKS5qb2luKFwiIFwiKSk7XG4gICAgaWYgKHQpIHJldHVybiB0O1xuICB9XG4gIHJldHVybiBcIlwiO1xufVxuXG4vKiogTm9tYnJlIGxlZ2libGUgcGFyYSBtb3N0cmFyIGVuIGxhIGxpc3RhIGRlIHBhc29zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlc2NyaWJlKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgaWYgKGVsLm1hdGNoZXMoQ09OVFJPTCkpIHtcbiAgICByZXR1cm4gKFxuICAgICAgbGFiZWxUZXh0KGVsKSB8fFxuICAgICAgZWwuZ2V0QXR0cmlidXRlKFwicGxhY2Vob2xkZXJcIikgfHxcbiAgICAgIGVsLmdldEF0dHJpYnV0ZShcIm5hbWVcIikgfHxcbiAgICAgIGVsLmlkIHx8XG4gICAgICBlbC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKSB8fFxuICAgICAgZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpXG4gICAgKS5zbGljZSgwLCA2MCk7XG4gIH1cbiAgY29uc3QgdCA9IHRleHRPZihlbCk7XG4gIGlmICh0KSByZXR1cm4gdC5sZW5ndGggPiA1MCA/IHQuc2xpY2UoMCwgNDcpICsgXCLigKZcIiA6IHQ7XG4gIHJldHVybiAoXG4gICAgZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKSB8fFxuICAgIGVsLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpIHx8XG4gICAgZWwucXVlcnlTZWxlY3RvcihcImltZ1wiKT8uZ2V0QXR0cmlidXRlKFwiYWx0XCIpIHx8XG4gICAgZWwuZ2V0QXR0cmlidXRlKFwibmFtZVwiKSB8fFxuICAgIGVsLnRhZ05hbWUudG9Mb3dlckNhc2UoKVxuICApLnNsaWNlKDAsIDYwKTtcbn1cblxuLyoqIEVsZW1lbnRvIHNvYnJlIGVsIHF1ZSBhY3TDumEgZWwgdXN1YXJpbzogZWwgY29udHJvbCBvIGVsIGFuY2VzdHJvIGNsaWNhYmxlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFjdGlvbmFibGUodGFyZ2V0OiBFbGVtZW50KTogRWxlbWVudCB7XG4gIGNvbnN0IGN0cmwgPSB0YXJnZXQuY2xvc2VzdChDT05UUk9MKTtcbiAgaWYgKGN0cmwpIHJldHVybiBjdHJsO1xuICBjb25zdCBjbGlja2FibGUgPSB0YXJnZXQuY2xvc2VzdChDTElDS0FCTEUpO1xuICBpZiAoY2xpY2thYmxlIGluc3RhbmNlb2YgSFRNTExhYmVsRWxlbWVudCAmJiBjbGlja2FibGUuY29udHJvbCkgcmV0dXJuIGNsaWNrYWJsZS5jb250cm9sO1xuICByZXR1cm4gY2xpY2thYmxlID8/IHRhcmdldDtcbn1cblxuY29uc3QgVEVYVExJS0UgPSBuZXcgU2V0KFtcbiAgXCJcIiwgXCJ0ZXh0XCIsIFwiZW1haWxcIiwgXCJwYXNzd29yZFwiLCBcInNlYXJjaFwiLCBcInRlbFwiLCBcInVybFwiLCBcIm51bWJlclwiLFxuICBcImRhdGVcIiwgXCJkYXRldGltZS1sb2NhbFwiLCBcIm1vbnRoXCIsIFwid2Vla1wiLCBcInRpbWVcIiwgXCJjb2xvclwiLCBcInJhbmdlXCIsXG5dKTtcblxuZXhwb3J0IHR5cGUgQWN0aW9uS2luZCA9IFwiY2xpY2tcIiB8IFwiZmlsbFwiIHwgXCJzZWxlY3RcIiB8IFwiY2hlY2tcIiB8IFwiZmlsZVwiO1xuXG5leHBvcnQgZnVuY3Rpb24ga2luZE9mKGVsOiBFbGVtZW50KTogQWN0aW9uS2luZCB7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSByZXR1cm4gXCJzZWxlY3RcIjtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCkgcmV0dXJuIGVsLnJlYWRPbmx5ID8gXCJjbGlja1wiIDogXCJmaWxsXCI7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHtcbiAgICBpZiAoZWwudHlwZSA9PT0gXCJjaGVja2JveFwiIHx8IGVsLnR5cGUgPT09IFwicmFkaW9cIikgcmV0dXJuIFwiY2hlY2tcIjtcbiAgICBpZiAoZWwudHlwZSA9PT0gXCJmaWxlXCIpIHJldHVybiBcImZpbGVcIjtcbiAgICAvLyBSZWFkb25seSA9IHNlbGVjdHMvZGF0ZXBpY2tlcnMgZGUgbGlicmVyw61hcyAoRWxlbWVudCBQbHVzLCBWdWV0aWZ54oCmKTogYWJyZW4gdW4gZGVzcGxlZ2FibGUsIG5vIHNlIGVzY3JpYmUuXG4gICAgaWYgKFRFWFRMSUtFLmhhcyhlbC50eXBlKSkgcmV0dXJuIGVsLnJlYWRPbmx5ID8gXCJjbGlja1wiIDogXCJmaWxsXCI7XG4gICAgcmV0dXJuIFwiY2xpY2tcIjtcbiAgfVxuICBpZiAoKGVsIGFzIEhUTUxFbGVtZW50KS5pc0NvbnRlbnRFZGl0YWJsZSkgcmV0dXJuIFwiZmlsbFwiO1xuICBjb25zdCByb2xlID0gZWwuZ2V0QXR0cmlidXRlKFwicm9sZVwiKTtcbiAgaWYgKHJvbGUgPT09IFwiY2hlY2tib3hcIiB8fCByb2xlID09PSBcInN3aXRjaFwiKSByZXR1cm4gXCJjaGVja1wiO1xuICByZXR1cm4gXCJjbGlja1wiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsdWVPZihlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHJldHVybiBlbC52YWx1ZTtcbiAgcmV0dXJuIG5vcm0oKGVsIGFzIEhUTUxFbGVtZW50KS5pbm5lclRleHQpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tlZE9mKGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHJldHVybiBlbC5jaGVja2VkO1xuICByZXR1cm4gZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIpID09PSBcInRydWVcIjtcbn1cbiIsCiAgICAiLy8gRXNwZXJhIGF1dG9tw6F0aWNhIGFudGVzIGRlIGNhZGEgYWNjacOzbjogcXVlIGxhIHDDoWdpbmEgZXN0w6kgwqt0cmFucXVpbGHCuyAoc2luIHBldGljaW9uZXMgZW4gdnVlbG8sXG4vLyBzaW4gY2FtYmlvcyBlbiBlbCBET00sIHNpbiBsb2FkZXJzIHZpc2libGVzKSB5IHF1ZSBlbCBlbGVtZW50byBlc3TDqSBsaXN0byBwYXJhIHJlY2liaXIgbGEgYWNjacOzblxuLy8gKGhhYmlsaXRhZG8sIHF1aWV0byB5IHNpbiBuYWRhIGVuY2ltYSkuIEV2aXRhIGNsaWNrcyBxdWUgwqtubyBoYWNlbiBuYWRhwrsgcG9ycXVlIGHDum4gaGF5IHVuIGxvYWRlci5cblxuaW1wb3J0IHsgc2xlZXAgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcbmltcG9ydCB7IGlzVmlzaWJsZSB9IGZyb20gXCIuL3NlbGVjdG9yXCI7XG5cbi8qKiBNYXJnZW4gc2luIHBldGljaW9uZXMgYW50ZXMgZGUgZGFyIGxhIHJlZCBwb3IgdHJhbnF1aWxhIChjdWJyZSBjYWRlbmFzIGRlIHBldGljaW9uZXMgZW5jYWRlbmFkYXMpLiAqL1xuY29uc3QgTkVUX1FVSUVUID0gMzAwO1xuLyoqIE1hcmdlbiBzaW4gbXV0YWNpb25lcyBkZWwgRE9NLiAqL1xuY29uc3QgRE9NX1FVSUVUID0gMTUwO1xuLyoqIFdlYnMgY29uIHJlbG9qZXMsIGNhcnJ1c2VsZXPigKY6IGVsIERPTSBudW5jYSBwYXJhOyBubyBlc3BlcmFtb3MgbcOhcyBkZSBlc3RvIHBvciDDqWwuICovXG5jb25zdCBET01fQ0FQID0gMTUwMDtcblxuLy8gTG9hZGVycyBkZSBsaWJyZXLDrWFzIGhhYml0dWFsZXMuIFNvbG8gaW5kaWNhZG9yZXMgZGUgY2FyZ2EsIG5vIG1vZGFsZXMgKHN1IGZvbmRvIHRhbWJpw6luIHRhcGEsIHBlcm8gZXMgaW50ZW5jaW9uYWRvKS5cbmNvbnN0IExPQURFUlMgPSBbXG4gICdbYXJpYS1idXN5PVwidHJ1ZVwiXScsXG4gIFwiLmVsLWxvYWRpbmctbWFza1wiLCAvLyBFbGVtZW50IFBsdXMgLyBFbGVtZW50IFVJXG4gIFwiLmFudC1zcGluLXNwaW5uaW5nXCIsIC8vIEFudCBEZXNpZ25cbiAgXCIudi1wcm9ncmVzcy1jaXJjdWxhci0taW5kZXRlcm1pbmF0ZVwiLCBcIi52LXByb2dyZXNzLWxpbmVhci0tYWN0aXZlXCIsIC8vIFZ1ZXRpZnlcbiAgXCIuTXVpQ2lyY3VsYXJQcm9ncmVzcy1yb290XCIsIFwiLk11aUxpbmVhclByb2dyZXNzLXJvb3RcIiwgLy8gTVVJXG4gIFwiLnAtcHJvZ3Jlc3Mtc3Bpbm5lclwiLCBcIi5wLWJsb2NrdWlcIiwgLy8gUHJpbWVWdWUgLyBQcmltZU5HXG4gIFwiLnEtbG9hZGluZ1wiLCBcIi5xLXNwaW5uZXJcIiwgLy8gUXVhc2FyXG4gIFwiLnNwaW5uZXItYm9yZGVyXCIsIFwiLnNwaW5uZXItZ3Jvd1wiLCAvLyBCb290c3RyYXBcbiAgXCIuYmxvY2tVSVwiLCBcIi5sb2FkaW5nLW92ZXJsYXlcIiwgXCIubG9hZGluZy1tYXNrXCIsIFwiLmxvYWRlclwiLCBcIi5zcGlubmVyXCIsXG5dLmpvaW4oXCIsIFwiKTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIFJlZCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxubGV0IHBlbmRpbmcgPSAwO1xubGV0IG5ldENoYW5nZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcblxuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIl9fcmFzdHJvX25ldFwiLCAoZSkgPT4ge1xuICBjb25zdCBuID0gKGUgYXMgQ3VzdG9tRXZlbnQpLmRldGFpbDtcbiAgaWYgKHR5cGVvZiBuICE9PSBcIm51bWJlclwiKSByZXR1cm47XG4gIHBlbmRpbmcgPSBuO1xuICBuZXRDaGFuZ2VkID0gcGVyZm9ybWFuY2Uubm93KCk7XG59KTtcbmRvY3VtZW50LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiX19yYXN0cm9fbmV0P1wiKSk7XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBET00g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmxldCBkb21DaGFuZ2VkID0gcGVyZm9ybWFuY2Uubm93KCk7XG5sZXQgZG9tT2JzZXJ2ZXI6IE11dGF0aW9uT2JzZXJ2ZXIgfCBudWxsID0gbnVsbDtcblxuZnVuY3Rpb24gd2F0Y2hEb20oKSB7XG4gIGlmIChkb21PYnNlcnZlcikgcmV0dXJuO1xuICBkb21PYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKChyZWNvcmRzKSA9PiB7XG4gICAgaWYgKHJlY29yZHMuc29tZSgocikgPT4gIShyLnRhcmdldCBhcyBFbGVtZW50KS5jbG9zZXN0Py4oXCIjX19yYXN0cm9faG9zdFwiKSkpIGRvbUNoYW5nZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgfSk7XG4gIGRvbU9ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LCB7IHN1YnRyZWU6IHRydWUsIGNoaWxkTGlzdDogdHJ1ZSwgYXR0cmlidXRlczogdHJ1ZSwgY2hhcmFjdGVyRGF0YTogdHJ1ZSB9KTtcbn1cblxuLyoqIFNlbGVjdG9yIGRlIGxvYWRlcnM6IGxvcyBpbnRlZ3JhZG9zICsgZWwgcGVyc29uYWxpemFkbyBkZSBhanVzdGVzIChzaSBlcyB1biBzZWxlY3RvciB2w6FsaWRvKS4gKi9cbmZ1bmN0aW9uIGxvYWRlclNlbGVjdG9yKGV4dHJhPzogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgeCA9IGV4dHJhPy50cmltKCk7XG4gIGlmICgheCkgcmV0dXJuIExPQURFUlM7XG4gIHRyeSB7XG4gICAgZG9jdW1lbnQucXVlcnlTZWxlY3Rvcih4KTtcbiAgICByZXR1cm4gYCR7TE9BREVSU30sICR7eH1gO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gTE9BREVSUztcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdmlzaWJsZUxvYWRlcihleHRyYT86IHN0cmluZyk6IEVsZW1lbnQgfCB1bmRlZmluZWQge1xuICBmb3IgKGNvbnN0IGVsIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwobG9hZGVyU2VsZWN0b3IoZXh0cmEpKSkge1xuICAgIGlmIChlbC5jbG9zZXN0KFwiI19fcmFzdHJvX2hvc3RcIikgfHwgIWlzVmlzaWJsZShlbCkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBpZiAoci53aWR0aCA+IDAgJiYgci5oZWlnaHQgPiAwKSByZXR1cm4gZWw7XG4gIH1cbn1cblxuLyoqXG4gKiBFc3BlcmEgYSBxdWUgbGEgcMOhZ2luYSBlc3TDqSB0cmFucXVpbGEuIE51bmNhIGZhbGxhOiBwYXNhZG8gYG1heE1zYCBzaWd1ZSBhZGVsYW50ZVxuICogKHBvbGxpbmcsIGFuaW1hY2lvbmVzIGluZmluaXRhc+KApikgeSBxdWUgZWwgcGFzbyBkZWNpZGEgc2kgZW5jdWVudHJhIHN1IGVsZW1lbnRvLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0dGxlKG1heE1zOiBudW1iZXIsIGV4dHJhTG9hZGVyPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIHdhdGNoRG9tKCk7XG4gIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgY29uc3Qgbm93ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgY29uc3QgbmV0UXVpZXQgPSBwZW5kaW5nID09PSAwICYmIG5vdyAtIG5ldENoYW5nZWQgPj0gTkVUX1FVSUVUO1xuICAgIGNvbnN0IGRvbVF1aWV0ID0gbm93IC0gZG9tQ2hhbmdlZCA+PSBET01fUVVJRVQgfHwgbm93IC0gc3RhcnQgPiBET01fQ0FQO1xuICAgIGlmIChuZXRRdWlldCAmJiBkb21RdWlldCAmJiAhdmlzaWJsZUxvYWRlcihleHRyYUxvYWRlcikpIHJldHVybjtcbiAgICBpZiAobm93IC0gc3RhcnQgPiBtYXhNcykgcmV0dXJuO1xuICAgIGF3YWl0IHNsZWVwKDUwKTtcbiAgfVxufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRWxlbWVudG8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIGlzRGlzYWJsZWQoZWw6IEVsZW1lbnQsIHZpc2libGU6IGJvb2xlYW4pOiBib29sZWFuIHtcbiAgaWYgKGVsLm1hdGNoZXMoXCI6ZGlzYWJsZWRcIikpIHJldHVybiB0cnVlOyAvLyBpbmNsdXllIDxmaWVsZHNldCBkaXNhYmxlZD5cbiAgaWYgKGVsLmNsb3Nlc3QoJ1thcmlhLWRpc2FibGVkPVwidHJ1ZVwiXScpKSByZXR1cm4gdHJ1ZTtcbiAgLy8gQ29udHJvbGVzIG9jdWx0b3MgZGUgbGlicmVyw61hcyAoY2hlY2tib3ggY3VzdG9t4oCmKSBhIHZlY2VzIGxsZXZhbiBwb2ludGVyLWV2ZW50czogbm9uZSBhIHByb3DDs3NpdG8uXG4gIHJldHVybiB2aXNpYmxlICYmIGdldENvbXB1dGVkU3R5bGUoZWwpLnBvaW50ZXJFdmVudHMgPT09IFwibm9uZVwiO1xufVxuXG5mdW5jdGlvbiBhbmNlc3RvcihlbDogRWxlbWVudCwgbGV2ZWxzOiBudW1iZXIpOiBFbGVtZW50IHtcbiAgbGV0IGN1ciA9IGVsO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGxldmVscyAmJiBjdXIucGFyZW50RWxlbWVudDsgaSsrKSBjdXIgPSBjdXIucGFyZW50RWxlbWVudDtcbiAgcmV0dXJuIGN1cjtcbn1cblxuLyoqIMK/UXXDqSBoYXkgZW5jaW1hIGRlbCBjZW50cm8gZGVsIGVsZW1lbnRvLCBzaSBubyBlcyBlbCBwcm9waW8gZWxlbWVudG8gKG8gYWxnbyBkZSBzdSBlbnRvcm5vIGlubWVkaWF0byk/ICovXG5mdW5jdGlvbiBjb3ZlcmVkQnkoZWw6IEVsZW1lbnQsIGV4dHJhTG9hZGVyPzogc3RyaW5nKTogRWxlbWVudCB8IG51bGwge1xuICBpZiAoZWwuZ2V0Um9vdE5vZGUoKSAhPT0gZG9jdW1lbnQpIHJldHVybiBudWxsOyAvLyBzaGFkb3cgRE9NOiBlbGVtZW50RnJvbVBvaW50IGRldnVlbHZlIGVsIGhvc3QsIG5vIHBvZGVtb3Mgc2FiZXJsb1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGNvbnN0IHggPSByLmxlZnQgKyByLndpZHRoIC8gMjtcbiAgY29uc3QgeSA9IHIudG9wICsgci5oZWlnaHQgLyAyO1xuICBpZiAoeCA8IDAgfHwgeSA8IDAgfHwgeCA+IGlubmVyV2lkdGggfHwgeSA+IGlubmVySGVpZ2h0KSByZXR1cm4gbnVsbDtcbiAgY29uc3QgdG9wID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludCh4LCB5KTtcbiAgaWYgKCF0b3AgfHwgZWwuY29udGFpbnModG9wKSB8fCB0b3AuY2xvc2VzdChcIiNfX3Jhc3Ryb19ob3N0XCIpKSByZXR1cm4gbnVsbDtcbiAgaWYgKChlbCBhcyBIVE1MSW5wdXRFbGVtZW50KS5sYWJlbHMgJiYgWy4uLihlbCBhcyBIVE1MSW5wdXRFbGVtZW50KS5sYWJlbHMhXS5zb21lKChsKSA9PiBsLmNvbnRhaW5zKHRvcCkpKSByZXR1cm4gbnVsbDtcbiAgLy8gUGxhY2Vob2xkZXJzLCBpY29ub3MgbyB3cmFwcGVycyBoZXJtYW5vcyAoc2VsZWN0cyBkZSBsaWJyZXLDrWFzKTogcmVjaWJlbiBlbCBjbGljayB5IGxvIHByb3BhZ2FuIGlndWFsLlxuICBpZiAoIXRvcC5jbG9zZXN0KGxvYWRlclNlbGVjdG9yKGV4dHJhTG9hZGVyKSkgJiYgYW5jZXN0b3IoZWwsIDMpLmNvbnRhaW5zKHRvcCkpIHJldHVybiBudWxsO1xuICByZXR1cm4gdG9wO1xufVxuXG5mdW5jdGlvbiBkZXNjcmliZUVsKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgY29uc3QgY2xzID0gWy4uLmVsLmNsYXNzTGlzdF0uc2xpY2UoMCwgMikuam9pbihcIi5cIik7XG4gIHJldHVybiBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKCkgKyAoZWwuaWQgPyBcIiNcIiArIGVsLmlkIDogXCJcIikgKyAoY2xzID8gXCIuXCIgKyBjbHMgOiBcIlwiKTtcbn1cblxuLyoqXG4gKiBFc3BlcmEgYSBxdWUgZWwgZWxlbWVudG8gYWNlcHRlIGxhIGFjY2nDs246IGhhYmlsaXRhZG8sIHNpbiBtb3ZlcnNlIChhbmltYWNpb25lcyBkZSBlbnRyYWRhKVxuICogeSwgc2kgYGNoZWNrSGl0YCwgc2luIG5hZGEgZW5jaW1hLiBEZXZ1ZWx2ZSB1biBtb3Rpdm8gc2kgc2UgYWdvdGEgZWwgdGllbXBvLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdW50aWxBY3Rpb25hYmxlKGVsOiBFbGVtZW50LCB0aW1lb3V0OiBudW1iZXIsIGNoZWNrSGl0OiBib29sZWFuLCBleHRyYUxvYWRlcj86IHN0cmluZyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCBzdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICBsZXQgbGFzdFJlY3QgPSBcIlwiO1xuICBsZXQgd2h5OiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3QgcmVjdCA9IGAke3IueH0sJHtyLnl9LCR7ci53aWR0aH0sJHtyLmhlaWdodH1gO1xuICAgIGNvbnN0IHN0YWJsZSA9IHJlY3QgPT09IGxhc3RSZWN0O1xuICAgIGxhc3RSZWN0ID0gcmVjdDtcbiAgICBjb25zdCBjb3ZlciA9IGNoZWNrSGl0ID8gY292ZXJlZEJ5KGVsLCBleHRyYUxvYWRlcikgOiBudWxsO1xuICAgIGlmIChpc0Rpc2FibGVkKGVsLCBjaGVja0hpdCkpIHdoeSA9IFwiZXN0w6EgZGVzaGFiaWxpdGFkb1wiO1xuICAgIGVsc2UgaWYgKGNvdmVyKSB3aHkgPSBgZXN0w6EgdGFwYWRvIHBvciAke2Rlc2NyaWJlRWwoY292ZXIpfWA7XG4gICAgZWxzZSBpZiAoIXN0YWJsZSkgd2h5ID0gXCJzZSBlc3TDoSBtb3ZpZW5kb1wiO1xuICAgIGVsc2UgcmV0dXJuIG51bGw7XG4gICAgaWYgKHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhcnQgPiB0aW1lb3V0KSByZXR1cm4gd2h5O1xuICAgIGF3YWl0IHNsZWVwKDUwKTtcbiAgfVxufVxuIiwKICAgICIvLyBSZXByb2R1Y3RvcjogZWplY3V0YSB1biBwYXNvIHNvYnJlIGxhIHDDoWdpbmEgc2ltdWxhbmRvIGEgdW4gdXN1YXJpbyByZWFsXG4vLyAoc2VjdWVuY2lhIGNvbXBsZXRhIGRlIGV2ZW50b3MgZGUgcHVudGVyby90ZWNsYWRvLCBjb21wYXRpYmxlIGNvbiBSZWFjdC9WdWUvQW5ndWxhcikuXG5cbmltcG9ydCB0eXBlIHsgU3RlcFJlc3VsdCB9IGZyb20gXCIuLi9zaGFyZWQvbWVzc2FnZXNcIjtcbmltcG9ydCB0eXBlIHsgU2V0dGluZ3MsIFN0ZXAgfSBmcm9tIFwiLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgQ09MT1JTLCBvdmVybGF5IH0gZnJvbSBcIi4vb3ZlcmxheVwiO1xuaW1wb3J0IHsgY2hlY2tlZE9mLCBpc1Zpc2libGUsIGtpbmRPZiwgcmVzb2x2ZSwgdGV4dE9mLCB2YWx1ZU9mIH0gZnJvbSBcIi4vc2VsZWN0b3JcIjtcbmltcG9ydCB7IHNldHRsZSwgdW50aWxBY3Rpb25hYmxlIH0gZnJvbSBcIi4vd2FpdFwiO1xuXG5jbGFzcyBTdGVwRXJyb3IgZXh0ZW5kcyBFcnJvciB7fVxuXG4vKiogRXNwZXJhIGEgcXVlIGVsIGVsZW1lbnRvIGV4aXN0YSAoeSBwcmVmZXJpYmxlbWVudGUgc2VhIHZpc2libGUpLiAqL1xuYXN5bmMgZnVuY3Rpb24gZmluZChzdGVwOiBTdGVwLCB0aW1lb3V0OiBudW1iZXIsIHJlcXVpcmVWaXNpYmxlOiBib29sZWFuKTogUHJvbWlzZTx7IGVsOiBFbGVtZW50OyBzZWxlY3Rvcjogc3RyaW5nIH0+IHtcbiAgY29uc3Qgc2VsZWN0b3JzID0gW3N0ZXAuc2VsZWN0b3IsIC4uLihzdGVwLmZhbGxiYWNrcyA/PyBbXSldLmZpbHRlcihCb29sZWFuKSBhcyBzdHJpbmdbXTtcbiAgaWYgKCFzZWxlY3RvcnMubGVuZ3RoKSB0aHJvdyBuZXcgU3RlcEVycm9yKFwiRWwgcGFzbyBubyB0aWVuZSBzZWxlY3RvclwiKTtcbiAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgbGV0IGhpZGRlblNpbmNlID0gMDtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCByID0gcmVzb2x2ZShzZWxlY3RvcnMpO1xuICAgIGlmIChyKSB7XG4gICAgICBpZiAoaXNWaXNpYmxlKHIuZWwpKSByZXR1cm4gcjtcbiAgICAgIC8vIENvbnRyb2xlcyBvY3VsdG9zIChjaGVja2JveCBjdXN0b20sIGlucHV0cyBjb24gbGFiZWwgZXN0aWxpemFkb+KApik6IHNlIGFjZXB0YW4gdHJhcyAxcy5cbiAgICAgIGlmICghcmVxdWlyZVZpc2libGUpIHtcbiAgICAgICAgaGlkZGVuU2luY2UgfHw9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBoaWRkZW5TaW5jZSA+IDEwMDApIHJldHVybiByO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHtcbiAgICAgIGlmIChyKSB0aHJvdyBuZXcgU3RlcEVycm9yKGBFbCBlbGVtZW50byDCqyR7c3RlcC5sYWJlbCA/PyBzZWxlY3RvcnNbMF19wrsgZXhpc3RlIHBlcm8gbm8gZXMgdmlzaWJsZWApO1xuICAgICAgdGhyb3cgbmV3IFN0ZXBFcnJvcihgTm8gc2UgZW5jb250csOzIMKrJHtzdGVwLmxhYmVsID8/IHNlbGVjdG9yc1swXX3CuyAoJHtzZWxlY3RvcnNbMF19KWApO1xuICAgIH1cbiAgICBhd2FpdCBzbGVlcCgxMDApO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNlbnRlcihlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHJldHVybiB7IHg6IHIubGVmdCArIHIud2lkdGggLyAyLCB5OiByLnRvcCArIHIuaGVpZ2h0IC8gMiB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBzY3JvbGxUbyhlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGlmIChyLnRvcCA8IDAgfHwgci5ib3R0b20gPiBpbm5lckhlaWdodCB8fCByLmxlZnQgPCAwIHx8IHIucmlnaHQgPiBpbm5lcldpZHRoKSB7XG4gICAgZWwuc2Nyb2xsSW50b1ZpZXcoeyBibG9jazogXCJjZW50ZXJcIiwgaW5saW5lOiBcImNlbnRlclwiLCBiZWhhdmlvcjogXCJpbnN0YW50XCIgYXMgU2Nyb2xsQmVoYXZpb3IgfSk7XG4gICAgYXdhaXQgc2xlZXAoNTApO1xuICB9XG59XG5cbmZ1bmN0aW9uIG1vdXNlKHRhcmdldDogRWxlbWVudCwgdHlwZTogc3RyaW5nLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICBjb25zdCBpbml0OiBQb2ludGVyRXZlbnRJbml0ID0ge1xuICAgIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUsIGNvbXBvc2VkOiB0cnVlLCB2aWV3OiB3aW5kb3csXG4gICAgY2xpZW50WDogeCwgY2xpZW50WTogeSwgc2NyZWVuWDogeCArIHNjcmVlblgsIHNjcmVlblk6IHkgKyBzY3JlZW5ZLFxuICAgIGJ1dHRvbjogMCwgYnV0dG9uczogdHlwZS5lbmRzV2l0aChcImRvd25cIikgPyAxIDogMCwgcG9pbnRlcklkOiAxLCBwb2ludGVyVHlwZTogXCJtb3VzZVwiLCBpc1ByaW1hcnk6IHRydWUsXG4gIH07XG4gIGNvbnN0IEN0b3IgPSB0eXBlLnN0YXJ0c1dpdGgoXCJwb2ludGVyXCIpID8gUG9pbnRlckV2ZW50IDogTW91c2VFdmVudDtcbiAgcmV0dXJuIHRhcmdldC5kaXNwYXRjaEV2ZW50KG5ldyBDdG9yKHR5cGUsIGluaXQpKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVhbENsaWNrKGVsOiBFbGVtZW50KSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgY29uc3QgeyB4LCB5IH0gPSBjZW50ZXIoZWwpO1xuICAvLyBTaSBoYXkgYWxnbyBlbmNpbWEgcGVybyBlcyB1biBoaWpvIChpY29ubyBkZW50cm8gZGVsIGJvdMOzbiksIGRpc3BhcmFtb3Mgc29icmUgw6lsIGNvbW8gaGFyw61hIGVsIG5hdmVnYWRvci5cbiAgY29uc3QgdG9wID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludCh4LCB5KTtcbiAgY29uc3QgdGFyZ2V0ID0gdG9wICYmIGVsLmNvbnRhaW5zKHRvcCkgPyB0b3AgOiBlbDtcbiAgbW91c2UodGFyZ2V0LCBcInBvaW50ZXJvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2VvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcm1vdmVcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJtb3VzZW1vdmVcIiwgeCwgeSk7XG4gIGNvbnN0IGRvd24gPSBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcmRvd25cIiwgeCwgeSkgJiYgbW91c2UodGFyZ2V0LCBcIm1vdXNlZG93blwiLCB4LCB5KTtcbiAgaWYgKGRvd24gJiYgZWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCAmJiBlbC50YWJJbmRleCA+PSAtMSkgZWwuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcnVwXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2V1cFwiLCB4LCB5KTtcbiAgLy8gY2xpY2sgc2ludMOpdGljbzogZWwgbmF2ZWdhZG9yIGVqZWN1dGEgbGEgYWNjacOzbiBwb3IgZGVmZWN0byAoc2VndWlyIGVubGFjZSwgZW52aWFyIGZvcm3igKYpLlxuICBtb3VzZSh0YXJnZXQsIFwiY2xpY2tcIiwgeCwgeSk7XG59XG5cbmNvbnN0IE5PX1RZUElORyA9IG5ldyBTZXQoW1wiZGF0ZVwiLCBcImRhdGV0aW1lLWxvY2FsXCIsIFwibW9udGhcIiwgXCJ3ZWVrXCIsIFwidGltZVwiLCBcImNvbG9yXCIsIFwicmFuZ2VcIl0pO1xuXG5mdW5jdGlvbiBzZXROYXRpdmUoZWw6IEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50LCB2OiBzdHJpbmcpIHtcbiAgLy8gRXN0YW1vcyBlbiBlbCDCq2lzb2xhdGVkIHdvcmxkwrsgZGVsIGNvbnRlbnQgc2NyaXB0OiBlc3RlIHNldHRlciBlcyBlbCBuYXRpdm8sXG4gIC8vIGFzw60gcXVlIGVsIHZhbHVlIHRyYWNrZXIgZGUgUmVhY3QgZGV0ZWN0YSBlbCBjYW1iaW8gYWwgcmVjaWJpciBlbCBldmVudG8gaW5wdXQuXG4gIGNvbnN0IHByb3RvID0gZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50ID8gSFRNTFRleHRBcmVhRWxlbWVudC5wcm90b3R5cGUgOiBIVE1MSW5wdXRFbGVtZW50LnByb3RvdHlwZTtcbiAgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90bywgXCJ2YWx1ZVwiKSEuc2V0IS5jYWxsKGVsLCB2KTtcbn1cblxuZnVuY3Rpb24gZmlyZUlucHV0KGVsOiBFbGVtZW50LCBkYXRhOiBzdHJpbmcgfCBudWxsLCBpbnB1dFR5cGUgPSBcImluc2VydFRleHRcIikge1xuICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBJbnB1dEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSwgZGF0YSwgaW5wdXRUeXBlIH0pKTtcbn1cblxuZnVuY3Rpb24ga2V5KGVsOiBFbGVtZW50LCB0eXBlOiBcImtleWRvd25cIiB8IFwia2V5cHJlc3NcIiB8IFwia2V5dXBcIiwgazogc3RyaW5nKSB7XG4gIHJldHVybiBlbC5kaXNwYXRjaEV2ZW50KFxuICAgIG5ldyBLZXlib2FyZEV2ZW50KHR5cGUsIHsga2V5OiBrLCBjb2RlOiBjb2RlRm9yKGspLCBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSB9KSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gY29kZUZvcihrOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoay5sZW5ndGggPT09IDEpIHtcbiAgICBpZiAoL1thLXpdL2kudGVzdChrKSkgcmV0dXJuIFwiS2V5XCIgKyBrLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKC9cXGQvLnRlc3QoaykpIHJldHVybiBcIkRpZ2l0XCIgKyBrO1xuICAgIGlmIChrID09PSBcIiBcIikgcmV0dXJuIFwiU3BhY2VcIjtcbiAgICByZXR1cm4gXCJcIjtcbiAgfVxuICByZXR1cm4gaztcbn1cblxuZnVuY3Rpb24gc2VsZWN0QWxsKGVsOiBIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudCkge1xuICB0cnkge1xuICAgIGVsLnNlbGVjdCgpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBudW1iZXIvZW1haWwgbm8gc29wb3J0YW4gc2VsZWNjacOzbiBlbiBhbGd1bm9zIG5hdmVnYWRvcmVzICovXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gdHlwZUludG8oZWw6IEVsZW1lbnQsIHZhbHVlOiBzdHJpbmcsIHM6IFNldHRpbmdzKSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgKGVsIGFzIEhUTUxFbGVtZW50KS5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG5cbiAgaWYgKChlbCBhcyBIVE1MRWxlbWVudCkuaXNDb250ZW50RWRpdGFibGUpIHtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZChcInNlbGVjdEFsbFwiKTtcbiAgICBpZiAodmFsdWUpIGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiaW5zZXJ0VGV4dFwiLCBmYWxzZSwgdmFsdWUpO1xuICAgIGVsc2UgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJkZWxldGVcIik7XG4gICAgaWYgKHRleHRPZihlbCkgIT09IHZhbHVlLnJlcGxhY2UoL1xccysvZywgXCIgXCIpLnRyaW0oKSkge1xuICAgICAgZWwudGV4dENvbnRlbnQgPSB2YWx1ZTtcbiAgICAgIGZpcmVJbnB1dChlbCwgdmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIGVkaXRhYmxlXCIpO1xuICBpZiAoZWwuZGlzYWJsZWQpIHRocm93IG5ldyBTdGVwRXJyb3IoYMKrJHtlbC5uYW1lIHx8IGVsLmlkfcK7IGVzdMOhIGRlc2hhYmlsaXRhZG9gKTtcblxuICBjb25zdCB0eXBlYWJsZSA9ICEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIE5PX1RZUElORy5oYXMoZWwudHlwZSkpO1xuXG4gIGlmICghdHlwZWFibGUgfHwgcy50eXBlTW9kZSA9PT0gXCJpbnN0YW50XCIpIHtcbiAgICBzZWxlY3RBbGwoZWwpO1xuICAgIGNvbnN0IG9rID0gdHlwZWFibGUgJiYgKHZhbHVlID8gZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJpbnNlcnRUZXh0XCIsIGZhbHNlLCB2YWx1ZSkgOiBkb2N1bWVudC5leGVjQ29tbWFuZChcImRlbGV0ZVwiKSk7XG4gICAgaWYgKCFvayB8fCBlbC52YWx1ZSAhPT0gdmFsdWUpIHtcbiAgICAgIHNldE5hdGl2ZShlbCwgdmFsdWUpO1xuICAgICAgZmlyZUlucHV0KGVsLCB2YWx1ZSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIENhcsOhY3RlciBhIGNhcsOhY3RlcjogbcOhcyBsZW50bywgcGVybyBkaXNwYXJhIGtleWRvd24va2V5dXAgcGFyYSB2YWxpZGFjaW9uZXMgeSBhdXRvY29tcGxldGFkb3MuXG4gICAgc2VsZWN0QWxsKGVsKTtcbiAgICBpZiAoIWRvY3VtZW50LmV4ZWNDb21tYW5kKFwiZGVsZXRlXCIpIHx8IGVsLnZhbHVlICE9PSBcIlwiKSB7XG4gICAgICBzZXROYXRpdmUoZWwsIFwiXCIpO1xuICAgICAgZmlyZUlucHV0KGVsLCBudWxsLCBcImRlbGV0ZUNvbnRlbnRCYWNrd2FyZFwiKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjaCBvZiB2YWx1ZSkge1xuICAgICAgY29uc3QgYWxsb3dlZCA9IGtleShlbCwgXCJrZXlkb3duXCIsIGNoKTtcbiAgICAgIGtleShlbCwgXCJrZXlwcmVzc1wiLCBjaCk7XG4gICAgICBpZiAoYWxsb3dlZCkge1xuICAgICAgICBjb25zdCBiZWZvcmUgPSBlbC52YWx1ZTtcbiAgICAgICAgaWYgKCFkb2N1bWVudC5leGVjQ29tbWFuZChcImluc2VydFRleHRcIiwgZmFsc2UsIGNoKSB8fCBlbC52YWx1ZSA9PT0gYmVmb3JlKSB7XG4gICAgICAgICAgc2V0TmF0aXZlKGVsLCBiZWZvcmUgKyBjaCk7XG4gICAgICAgICAgZmlyZUlucHV0KGVsLCBjaCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGtleShlbCwgXCJrZXl1cFwiLCBjaCk7XG4gICAgICBpZiAocy5rZXlEZWxheSkgYXdhaXQgc2xlZXAocy5rZXlEZWxheSk7XG4gICAgfVxuICB9XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG59XG5cbmZ1bmN0aW9uIHNlbGVjdE9wdGlvbihlbDogRWxlbWVudCwgdmFsdWU6IHN0cmluZywgb3B0aW9uVGV4dD86IHN0cmluZykge1xuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIHVuIDxzZWxlY3Q+XCIpO1xuICBjb25zdCBvcHRzID0gWy4uLmVsLm9wdGlvbnNdO1xuICBjb25zdCBvcHQgPVxuICAgIG9wdHMuZmluZCgobykgPT4gby52YWx1ZSA9PT0gdmFsdWUpID8/XG4gICAgKG9wdGlvblRleHQgPyBvcHRzLmZpbmQoKG8pID0+IG8udGV4dC50cmltKCkgPT09IG9wdGlvblRleHQpIDogdW5kZWZpbmVkKSA/P1xuICAgIG9wdHMuZmluZCgobykgPT4gby50ZXh0LnRyaW0oKSA9PT0gdmFsdWUpID8/XG4gICAgb3B0cy5maW5kKChvKSA9PiBvLnRleHQudHJpbSgpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModmFsdWUudG9Mb3dlckNhc2UoKSkpO1xuICBpZiAoIW9wdCkgdGhyb3cgbmV3IFN0ZXBFcnJvcihgRWwgc2VsZWN0IG5vIHRpZW5lIGxhIG9wY2nDs24gwqske29wdGlvblRleHQgPz8gdmFsdWV9wrtgKTtcbiAgZWwuZm9jdXMoKTtcbiAgZWwudmFsdWUgPSBvcHQudmFsdWU7XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0Q2hlY2tlZChlbDogRWxlbWVudCwgd2FudDogYm9vbGVhbikge1xuICBpZiAoY2hlY2tlZE9mKGVsKSA9PT0gd2FudCkgcmV0dXJuO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGVsLnR5cGUgPT09IFwicmFkaW9cIiAmJiAhd2FudCkge1xuICAgIHRocm93IG5ldyBTdGVwRXJyb3IoXCJVbiByYWRpbyBubyBzZSBwdWVkZSBkZXNtYXJjYXI7IG1hcmNhIG90cmEgb3BjacOzbiBkZWwgZ3J1cG9cIik7XG4gIH1cbiAgaWYgKGlzVmlzaWJsZShlbCkpIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gIGVsc2UgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5sYWJlbHM/LlswXSAmJiBpc1Zpc2libGUoZWwubGFiZWxzWzBdKSkgYXdhaXQgcmVhbENsaWNrKGVsLmxhYmVsc1swXSk7XG4gIGVsc2UgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICBpZiAoY2hlY2tlZE9mKGVsKSAhPT0gd2FudCAmJiBlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHtcbiAgICBlbC5jaGVja2VkID0gd2FudDtcbiAgICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG4gICAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgfVxufVxuXG5jb25zdCBGT0NVU0FCTEUgPSAnYVtocmVmXSwgYnV0dG9uLCBpbnB1dCwgc2VsZWN0LCB0ZXh0YXJlYSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCBbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT1cImZhbHNlXCJdKSc7XG5cbmFzeW5jIGZ1bmN0aW9uIHByZXNzKGVsOiBFbGVtZW50LCBrOiBzdHJpbmcpIHtcbiAgY29uc3QgZG93biA9IGtleShlbCwgXCJrZXlkb3duXCIsIGspO1xuICBpZiAoayA9PT0gXCJFbnRlclwiKSBrZXkoZWwsIFwia2V5cHJlc3NcIiwgayk7XG4gIGlmIChkb3duKSB7XG4gICAgaWYgKGsgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5mb3JtKSB7XG4gICAgICAgIC8vIEVudsOtbyBpbXBsw61jaXRvOiBlbCBuYXZlZ2Fkb3IgY2xpY2EgZWwgYm90w7NuIGRlIHN1Ym1pdCBwb3IgZGVmZWN0by5cbiAgICAgICAgY29uc3QgYnRuID0gZWwuZm9ybS5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PignYnV0dG9uW3R5cGU9XCJzdWJtaXRcIl0sIGJ1dHRvbjpub3QoW3R5cGVdKSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgaW5wdXRbdHlwZT1cImltYWdlXCJdJyk7XG4gICAgICAgIGlmIChidG4pIGF3YWl0IHJlYWxDbGljayhidG4pO1xuICAgICAgICBlbHNlIGVsLmZvcm0ucmVxdWVzdFN1Ym1pdCgpO1xuICAgICAgfSBlbHNlIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoayA9PT0gXCJUYWJcIikge1xuICAgICAgY29uc3QgYWxsID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KEZPQ1VTQUJMRSldLmZpbHRlcigoZSkgPT4gaXNWaXNpYmxlKGUpICYmICEoZSBhcyBIVE1MSW5wdXRFbGVtZW50KS5kaXNhYmxlZCk7XG4gICAgICBjb25zdCBpID0gYWxsLmluZGV4T2YoZWwgYXMgSFRNTEVsZW1lbnQpO1xuICAgICAgYWxsWyhpICsgMSkgJSBhbGwubGVuZ3RoXT8uZm9jdXMoKTtcbiAgICB9XG4gIH1cbiAga2V5KGVsLCBcImtleXVwXCIsIGspO1xufVxuXG4vKiogwr9BY3RpdmFyIGVzdGUgZWxlbWVudG8gcHVlZGUgY2FtYmlhciBkZSBww6FnaW5hPyAqL1xuZnVuY3Rpb24gbWF5TmF2aWdhdGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKGVsLmNsb3Nlc3QoXCJhW2hyZWZdXCIpKSByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgYnRuID0gZWwuY2xvc2VzdChcImJ1dHRvbiwgaW5wdXRcIik7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MQnV0dG9uRWxlbWVudCkgcmV0dXJuICEhYnRuLmZvcm0gJiYgYnRuLnR5cGUgPT09IFwic3VibWl0XCI7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSByZXR1cm4gISFidG4uZm9ybSAmJiAoW1wic3VibWl0XCIsIFwiaW1hZ2VcIl0uaW5jbHVkZXMoYnRuLnR5cGUpIHx8IGtpbmRPZihidG4pID09PSBcImZpbGxcIik7XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJ1blN0ZXAoc3RlcDogU3RlcCwgczogU2V0dGluZ3MpOiBQcm9taXNlPFN0ZXBSZXN1bHQ+IHtcbiAgY29uc3QgdGltZW91dCA9IHN0ZXAudGltZW91dCA/PyBzLnRpbWVvdXQ7XG4gIGxldCBuYXYgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBsZXQgdXNlZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIC8vIEFudGVzIGRlIGFjdHVhciwgcXVlIGxhIHDDoWdpbmEgdGVybWluZSBsbyBxdWUgZXN0w6EgaGFjaWVuZG8gKHBldGljaW9uZXMsIGxvYWRlcnMsIHJlbmRlcnMpLlxuICAgIGNvbnN0IGFjdHMgPSAhW1wid2FpdEZvclwiLCBcImFzc2VydFRleHRcIl0uaW5jbHVkZXMoc3RlcC50eXBlKTtcbiAgICBpZiAocy5hdXRvV2FpdCAmJiBhY3RzKSBhd2FpdCBzZXR0bGUodGltZW91dCwgcy5sb2FkZXJTZWxlY3Rvcik7XG4gICAgY29uc3QgdGFyZ2V0ID0gYXN5bmMgKHZpc2libGUgPSB0cnVlKSA9PiB7XG4gICAgICBjb25zdCByID0gYXdhaXQgZmluZChzdGVwLCB0aW1lb3V0LCB2aXNpYmxlKTtcbiAgICAgIHVzZWQgPSByLnNlbGVjdG9yO1xuICAgICAgaWYgKHMuYXV0b1dhaXQgJiYgYWN0cykge1xuICAgICAgICBpZiAoaXNWaXNpYmxlKHIuZWwpKSBhd2FpdCBzY3JvbGxUbyhyLmVsKTtcbiAgICAgICAgY29uc3Qgd2h5ID0gYXdhaXQgdW50aWxBY3Rpb25hYmxlKHIuZWwsIHRpbWVvdXQsIGlzVmlzaWJsZShyLmVsKSwgcy5sb2FkZXJTZWxlY3Rvcik7XG4gICAgICAgIGlmICh3aHkpIHRocm93IG5ldyBTdGVwRXJyb3IoYMKrJHtzdGVwLmxhYmVsID8/IHIuc2VsZWN0b3J9wrsgJHt3aHl9YCk7XG4gICAgICB9XG4gICAgICBpZiAocy5oaWdobGlnaHQpIG92ZXJsYXkuZmxhc2goci5lbCwgc3RlcC5sYWJlbCA/PyBzdGVwLnR5cGUsIE1hdGgubWF4KDQwMCwgcy5zdGVwRGVsYXkgKyAyMDApLCBDT0xPUlMucnVuKTtcbiAgICAgIHJldHVybiByLmVsO1xuICAgIH07XG5cbiAgICBzd2l0Y2ggKHN0ZXAudHlwZSkge1xuICAgICAgY2FzZSBcImNsaWNrXCI6IHtcbiAgICAgICAgY29uc3QgZWwgPSBhd2FpdCB0YXJnZXQoKTtcbiAgICAgICAgbmF2ID0gbWF5TmF2aWdhdGUoZWwpO1xuICAgICAgICBhd2FpdCByZWFsQ2xpY2soZWwpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJmaWxsXCI6IHtcbiAgICAgICAgLy8gVG9sZXJhbnRlOiB1biDCq2ZpbGzCuyBzb2JyZSB1biBzZWxlY3QgbyBjaGVja2JveCAocC4gZWouIGltcG9ydGFkbyBkZSBEZXZUb29scykgaGFjZSBsbyBsw7NnaWNvLlxuICAgICAgICBjb25zdCBlbCA9IGF3YWl0IHRhcmdldChmYWxzZSk7XG4gICAgICAgIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSBzZWxlY3RPcHRpb24oZWwsIHN0ZXAudmFsdWUgPz8gXCJcIik7XG4gICAgICAgIGVsc2UgaWYgKGtpbmRPZihlbCkgPT09IFwiY2hlY2tcIikgYXdhaXQgc2V0Q2hlY2tlZChlbCwgIVtcIlwiLCBcImZhbHNlXCIsIFwib2ZmXCIsIFwiMFwiXS5pbmNsdWRlcyhzdGVwLnZhbHVlID8/IFwiXCIpKTtcbiAgICAgICAgZWxzZSBhd2FpdCB0eXBlSW50byhlbCwgc3RlcC52YWx1ZSA/PyBcIlwiLCBzKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwic2VsZWN0XCI6XG4gICAgICAgIHNlbGVjdE9wdGlvbihhd2FpdCB0YXJnZXQoZmFsc2UpLCBzdGVwLnZhbHVlID8/IFwiXCIsIHN0ZXAub3B0aW9uVGV4dCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNoZWNrXCI6XG4gICAgICAgIGF3YWl0IHNldENoZWNrZWQoYXdhaXQgdGFyZ2V0KGZhbHNlKSwgc3RlcC52YWx1ZSAhPT0gXCJmYWxzZVwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwicHJlc3NcIjoge1xuICAgICAgICBjb25zdCBlbCA9IHN0ZXAuc2VsZWN0b3IgPyBhd2FpdCB0YXJnZXQoZmFsc2UpIDogKGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgPz8gZG9jdW1lbnQuYm9keSk7XG4gICAgICAgIG5hdiA9IChzdGVwLnZhbHVlIHx8IFwiRW50ZXJcIikgPT09IFwiRW50ZXJcIiAmJiBtYXlOYXZpZ2F0ZShlbCk7XG4gICAgICAgIGF3YWl0IHByZXNzKGVsLCBzdGVwLnZhbHVlIHx8IFwiRW50ZXJcIik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBcIndhaXRGb3JcIjpcbiAgICAgICAgYXdhaXQgdGFyZ2V0KCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImFzc2VydFRleHRcIjoge1xuICAgICAgICBjb25zdCBlbCA9IGF3YWl0IHRhcmdldChmYWxzZSk7XG4gICAgICAgIGNvbnN0IHdhbnQgPSAoc3RlcC52YWx1ZSA/PyBcIlwiKS50cmltKCk7XG4gICAgICAgIC8vIFJlaW50ZW50YSBoYXN0YSBlbCB0aW1lb3V0OiBlbCB0ZXh0byBwdWVkZSB0YXJkYXIgZW4gYXBhcmVjZXIgKHJlc3B1ZXN0YSBkZWwgc2Vydmlkb3IpLlxuICAgICAgICBjb25zdCBzdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICBsZXQgaGF2ZSA9IFwiXCI7XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgaGF2ZSA9IGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCA/IHZhbHVlT2YoZWwpIDogdGV4dE9mKGVsKTtcbiAgICAgICAgICBpZiAoaGF2ZS5pbmNsdWRlcyh3YW50KSkgYnJlYWs7XG4gICAgICAgICAgaWYgKHBlcmZvcm1hbmNlLm5vdygpIC0gc3RhcnQgPiB0aW1lb3V0KSB0aHJvdyBuZXcgU3RlcEVycm9yKGBTZSBlc3BlcmFiYSDCqyR7d2FudH3CuyB5IGhheSDCqyR7aGF2ZS5zbGljZSgwLCA4MCl9wrtgKTtcbiAgICAgICAgICBhd2FpdCBzbGVlcCgxNTApO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IFN0ZXBFcnJvcihgVGlwbyBkZSBwYXNvIMKrJHtzdGVwLnR5cGV9wrsgbm8gc2UgZWplY3V0YSBlbiBsYSBww6FnaW5hYCk7XG4gICAgfVxuICAgIHJldHVybiB7IG9rOiB0cnVlLCB1c2VkU2VsZWN0b3I6IHVzZWQsIG1heU5hdmlnYXRlOiBuYXYgfTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiB7IG9rOiBmYWxzZSwgZXJyb3I6IGUgaW5zdGFuY2VvZiBFcnJvciA/IGUubWVzc2FnZSA6IFN0cmluZyhlKSB9O1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoaWdobGlnaHQoc2VsZWN0b3JzOiBzdHJpbmdbXSk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICBjb25zdCByID0gcmVzb2x2ZShzZWxlY3RvcnMpO1xuICBpZiAoIXIpIHJldHVybiBmYWxzZTtcbiAgYXdhaXQgc2Nyb2xsVG8oci5lbCk7XG4gIG92ZXJsYXkuZmxhc2goci5lbCwgci5zZWxlY3RvciwgMTUwMCwgQ09MT1JTLmNsaWNrKTtcbiAgcmV0dXJuIHRydWU7XG59XG4iLAogICAgIi8vIEdyYWJhZG9yLiBEb3MgbW9kb3M6XG4vLyAgIHJlY29yZCDihpIgbGFzIGludGVyYWNjaW9uZXMgb2N1cnJlbiBkZSB2ZXJkYWQgeSBzZSB2YW4gYW5vdGFuZG8uXG4vLyAgIHBvaW50ICDihpIgwqtzZcOxYWxhcsK7OiBsb3MgY2xpY2tzIGVuIGJvdG9uZXMvZW5sYWNlcyBOTyBzZSBlamVjdXRhbiwgc29sbyBzZSBhbm90YW4uXG4vLyAgICAgICAgICAgIElucHV0cywgc2VsZWN0cyB5IGNoZWNrYm94ZXMgZnVuY2lvbmFuIG5vcm1hbCwgYXPDrSBxdWUgc2UgZ3JhYmEgc3UgZXN0YWRvLlxuLy9cbi8vIFJlZ2xhIGNsYXZlOiBjbGljYXIgdW4gaW5wdXQgbm8gZ2VuZXJhIHVuIMKrY2xpY2vCuzsgZ2VuZXJhIHVuIMKrZmlsbMK7IGNvbiBzdSBjb250ZW5pZG8sXG4vLyBxdWUgc2UgdmEgYWN0dWFsaXphbmRvIG1pZW50cmFzIGVzY3JpYmVzIChlbCBiYWNrZ3JvdW5kIGZ1c2lvbmEgcGFzb3MgZGVsIG1pc21vIGNhbXBvKS5cblxuaW1wb3J0IHR5cGUgeyBSZWNvcmRlZFN0ZXAgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgeyBDT0xPUlMsIG92ZXJsYXkgfSBmcm9tIFwiLi9vdmVybGF5XCI7XG5pbXBvcnQgeyBhY3Rpb25hYmxlLCBidWlsZFNlbGVjdG9ycywgY2hlY2tlZE9mLCBkZXNjcmliZSwga2luZE9mLCB0cmFja1ZvbGF0aWxlQ2xhc3NlcywgdmFsdWVPZiwgdHlwZSBBY3Rpb25LaW5kIH0gZnJvbSBcIi4vc2VsZWN0b3JcIjtcblxudHlwZSBNb2RlID0gXCJyZWNvcmRcIiB8IFwicG9pbnRcIjtcblxubGV0IG1vZGU6IE1vZGUgfCBudWxsID0gbnVsbDtcbmxldCBzZW5kOiAoczogUmVjb3JkZWRTdGVwKSA9PiB2b2lkID0gKCkgPT4ge307XG5jb25zdCBwZW5kaW5nRmlsbCA9IG5ldyBNYXA8RWxlbWVudCwgUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4+KCk7XG5cbmNvbnN0IFZFUkI6IFJlY29yZDxBY3Rpb25LaW5kLCBzdHJpbmc+ID0geyBjbGljazogXCJDbGlja1wiLCBmaWxsOiBcIkVzY3JpYmlyXCIsIHNlbGVjdDogXCJTZWxlY2Npb25hclwiLCBjaGVjazogXCJNYXJjYXJcIiwgZmlsZTogXCJGaWNoZXJvXCIgfTtcblxuLyoqIENvbnZpZXJ0ZSB1biBlbGVtZW50byBlbiBlbCBwYXNvIHF1ZSBsZSBjb3JyZXNwb25kZSwgY29uIHN1IGVzdGFkbyBhY3R1YWwuICovXG5leHBvcnQgZnVuY3Rpb24gY2FwdHVyZShlbDogRWxlbWVudCk6IFJlY29yZGVkU3RlcCB8IG51bGwge1xuICBjb25zdCBraW5kID0ga2luZE9mKGVsKTtcbiAgaWYgKGtpbmQgPT09IFwiZmlsZVwiKSByZXR1cm4gbnVsbDtcbiAgY29uc3QgW3NlbGVjdG9yLCAuLi5mYWxsYmFja3NdID0gYnVpbGRTZWxlY3RvcnMoZWwpO1xuICBjb25zdCBiYXNlID0geyBzZWxlY3RvciwgZmFsbGJhY2tzLCBsYWJlbDogZGVzY3JpYmUoZWwpIH07XG4gIHN3aXRjaCAoa2luZCkge1xuICAgIGNhc2UgXCJmaWxsXCI6XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCB0eXBlOiBcImZpbGxcIiwgdmFsdWU6IHZhbHVlT2YoZWwpLCBzZWNyZXQ6IChlbCBhcyBIVE1MSW5wdXRFbGVtZW50KS50eXBlID09PSBcInBhc3N3b3JkXCIgfHwgdW5kZWZpbmVkIH07XG4gICAgY2FzZSBcInNlbGVjdFwiOiB7XG4gICAgICBjb25zdCBzID0gZWwgYXMgSFRNTFNlbGVjdEVsZW1lbnQ7XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCB0eXBlOiBcInNlbGVjdFwiLCB2YWx1ZTogcy52YWx1ZSwgb3B0aW9uVGV4dDogcy5zZWxlY3RlZE9wdGlvbnNbMF0/LnRleHQudHJpbSgpIH07XG4gICAgfVxuICAgIGNhc2UgXCJjaGVja1wiOlxuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgdHlwZTogXCJjaGVja1wiLCB2YWx1ZTogU3RyaW5nKGNoZWNrZWRPZihlbCkpIH07XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwiY2xpY2tcIiB9O1xuICB9XG59XG5cbmZ1bmN0aW9uIGVtaXQoZWw6IEVsZW1lbnQsIHN0ZXA6IFJlY29yZGVkU3RlcCB8IG51bGwpIHtcbiAgaWYgKCFzdGVwKSByZXR1cm47XG4gIHNlbmQoc3RlcCk7XG4gIGNvbnN0IHdoYXQgPSBzdGVwLnR5cGUgPT09IFwiZmlsbFwiID8gKHN0ZXAuc2VjcmV0ID8gXCLigKLigKLigKLigKJcIiA6IGDCqyR7KHN0ZXAudmFsdWUgPz8gXCJcIikuc2xpY2UoMCwgMzApfcK7YCkgOiBcIlwiO1xuICBvdmVybGF5LnRvYXN0KGDinJMgJHtWRVJCW3N0ZXAudHlwZSBhcyBBY3Rpb25LaW5kXSA/PyBzdGVwLnR5cGV9OiAke3N0ZXAubGFiZWx9ICR7d2hhdH1gLnRyaW0oKSwgQ09MT1JTW2tpbmRPZihlbCldKTtcbn1cblxuZnVuY3Rpb24gZmx1c2hGaWxscygpIHtcbiAgZm9yIChjb25zdCBbZWwsIHRdIG9mIHBlbmRpbmdGaWxsKSB7XG4gICAgY2xlYXJUaW1lb3V0KHQpO1xuICAgIHNlbmQoY2FwdHVyZShlbCkhKTtcbiAgfVxuICBwZW5kaW5nRmlsbC5jbGVhcigpO1xufVxuXG5mdW5jdGlvbiBzY2hlZHVsZUZpbGwoZWw6IEVsZW1lbnQpIHtcbiAgY2xlYXJUaW1lb3V0KHBlbmRpbmdGaWxsLmdldChlbCkpO1xuICBwZW5kaW5nRmlsbC5zZXQoXG4gICAgZWwsXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBwZW5kaW5nRmlsbC5kZWxldGUoZWwpO1xuICAgICAgY29uc3QgcyA9IGNhcHR1cmUoZWwpO1xuICAgICAgaWYgKHMpIHNlbmQocyk7XG4gICAgfSwgMzUwKSxcbiAgKTtcbn1cblxuY29uc3QgdGFyZ2V0T2YgPSAoZTogRXZlbnQpOiBFbGVtZW50IHwgbnVsbCA9PiB7XG4gIGNvbnN0IHQgPSBlLmNvbXBvc2VkUGF0aCgpWzBdO1xuICByZXR1cm4gdCBpbnN0YW5jZW9mIEVsZW1lbnQgPyB0IDogbnVsbDtcbn07XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBMaXN0ZW5lcnMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIG9uTW92ZShlOiBNb3VzZUV2ZW50KSB7XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0IHx8IG92ZXJsYXkub3ducyh0KSkgcmV0dXJuO1xuICBjb25zdCBlbCA9IGFjdGlvbmFibGUodCk7XG4gIGNvbnN0IGsgPSBraW5kT2YoZWwpO1xuICBjb25zdCBoaW50ID0gayA9PT0gXCJmaWxlXCIgPyBcIkZpY2hlcm8gKG5vIGF1dG9tYXRpemFibGUpXCIgOiBgJHtWRVJCW2tdfSDCtyAke2Rlc2NyaWJlKGVsKX1gO1xuICBvdmVybGF5LnNob3coZWwsIGhpbnQsIENPTE9SU1trXSk7XG59XG5cbi8qKiBFbiBtb2RvIHNlw7FhbGFyLCBibG9xdWVhIGJvdG9uZXMvZW5sYWNlcyBwYXJhIHF1ZSBubyBoYWdhbiBuYWRhIChlbCByZXN0byBmdW5jaW9uYSBub3JtYWwpLiAqL1xuZnVuY3Rpb24gYmxvY2tJblBvaW50KGU6IEV2ZW50KSB7XG4gIGlmIChtb2RlICE9PSBcInBvaW50XCIgfHwgIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0IHx8IG92ZXJsYXkub3ducyh0KSkgcmV0dXJuO1xuICBpZiAoa2luZE9mKGFjdGlvbmFibGUodCkpID09PSBcImNsaWNrXCIpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBvbkNsaWNrKGU6IE1vdXNlRXZlbnQpIHtcbiAgaWYgKCFlLmlzVHJ1c3RlZCkgcmV0dXJuO1xuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCB8fCBvdmVybGF5Lm93bnModCkpIHJldHVybjtcbiAgYmxvY2tJblBvaW50KGUpO1xuICBjb25zdCBlbCA9IGFjdGlvbmFibGUodCk7XG4gIGNvbnN0IGsgPSBraW5kT2YoZWwpO1xuICBpZiAoayA9PT0gXCJmaWxlXCIpIHJldHVybiBvdmVybGF5LnRvYXN0KFwiTG9zIGlucHV0cyBkZSBmaWNoZXJvIG5vIHNlIHB1ZWRlbiBhdXRvbWF0aXphclwiLCB1bmRlZmluZWQsIHRydWUpO1xuICBpZiAoayA9PT0gXCJjaGVja1wiIHx8IGsgPT09IFwic2VsZWN0XCIpIHJldHVybjsgLy8gc2UgZ3JhYmFuIGVuIFwiY2hhbmdlXCIgY29uIGVsIGVzdGFkbyBmaW5hbFxuICBmbHVzaEZpbGxzKCk7XG4gIGlmIChrID09PSBcImZpbGxcIikge1xuICAgIC8vIENsaWNhciB1biBpbnB1dCBjb24gY29udGVuaWRvID0gcmVsbGVuYXJsbyBjb24gZXNlIGNvbnRlbmlkby5cbiAgICAvLyBTaSBlc3TDoSB2YWPDrW8sIGVsIHBhc28gc2UgY3JlYSBlbiBjdWFudG8gZXNjcmliYXMuXG4gICAgaWYgKHZhbHVlT2YoZWwpKSBlbWl0KGVsLCBjYXB0dXJlKGVsKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGVtaXQoZWwsIGNhcHR1cmUoZWwpKTtcbn1cblxuZnVuY3Rpb24gb25JbnB1dChlOiBFdmVudCkge1xuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCkgcmV0dXJuO1xuICBjb25zdCBlbCA9IGFjdGlvbmFibGUodCk7XG4gIGlmIChraW5kT2YoZWwpID09PSBcImZpbGxcIikgc2NoZWR1bGVGaWxsKGVsKTtcbn1cblxuZnVuY3Rpb24gb25DaGFuZ2UoZTogRXZlbnQpIHtcbiAgaWYgKCFlLmlzVHJ1c3RlZCkgcmV0dXJuO1xuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCkgcmV0dXJuO1xuICBjb25zdCBlbCA9IGFjdGlvbmFibGUodCk7XG4gIGNvbnN0IGsgPSBraW5kT2YoZWwpO1xuICBpZiAoayA9PT0gXCJmaWxsXCIpIHtcbiAgICBjbGVhclRpbWVvdXQocGVuZGluZ0ZpbGwuZ2V0KGVsKSk7XG4gICAgcGVuZGluZ0ZpbGwuZGVsZXRlKGVsKTtcbiAgICBzZW5kKGNhcHR1cmUoZWwpISk7XG4gIH0gZWxzZSBpZiAoayA9PT0gXCJzZWxlY3RcIiB8fCBrID09PSBcImNoZWNrXCIpIHtcbiAgICBmbHVzaEZpbGxzKCk7XG4gICAgZW1pdChlbCwgY2FwdHVyZShlbCkpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uS2V5KGU6IEtleWJvYXJkRXZlbnQpIHtcbiAgaWYgKCFlLmlzVHJ1c3RlZCkgcmV0dXJuO1xuICBpZiAobW9kZSA9PT0gXCJwb2ludFwiICYmIGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHN0b3BIYW5kbGVyKCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGlmIChlLmtleSA9PT0gXCJFbnRlclwiICYmIHQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGtpbmRPZih0KSA9PT0gXCJmaWxsXCIpIHtcbiAgICBmbHVzaEZpbGxzKCk7XG4gICAgc2VuZCh7IHR5cGU6IFwicHJlc3NcIiwgdmFsdWU6IFwiRW50ZXJcIiwgc2VsZWN0b3I6IGJ1aWxkU2VsZWN0b3JzKHQpWzBdLCBsYWJlbDogZGVzY3JpYmUodCkgfSk7XG4gICAgb3ZlcmxheS50b2FzdChg4pyTIFRlY2xhOiBFbnRlciBlbiAke2Rlc2NyaWJlKHQpfWApO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uTGVhdmUoKSB7XG4gIGZsdXNoRmlsbHMoKTtcbn1cblxuY29uc3Qgb25TY3JvbGwgPSAoKSA9PiBvdmVybGF5LmhpZGUoKTtcblxubGV0IHN0b3BIYW5kbGVyOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbmNvbnN0IGxpc3RlbmVyczogW3N0cmluZywgRXZlbnRMaXN0ZW5lcl1bXSA9IFtcbiAgW1wibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyXSxcbiAgW1wicG9pbnRlcmRvd25cIiwgYmxvY2tJblBvaW50XSxcbiAgW1wibW91c2Vkb3duXCIsIGJsb2NrSW5Qb2ludF0sXG4gIFtcInBvaW50ZXJ1cFwiLCBibG9ja0luUG9pbnRdLFxuICBbXCJtb3VzZXVwXCIsIGJsb2NrSW5Qb2ludF0sXG4gIFtcImNsaWNrXCIsIG9uQ2xpY2sgYXMgRXZlbnRMaXN0ZW5lcl0sXG4gIFtcImlucHV0XCIsIG9uSW5wdXRdLFxuICBbXCJjaGFuZ2VcIiwgb25DaGFuZ2VdLFxuICBbXCJrZXlkb3duXCIsIG9uS2V5IGFzIEV2ZW50TGlzdGVuZXJdLFxuXTtcblxuZXhwb3J0IGZ1bmN0aW9uIHN0YXJ0UmVjb3JkaW5nKG06IE1vZGUsIHNpbms6IChzOiBSZWNvcmRlZFN0ZXApID0+IHZvaWQsIG9uU3RvcDogKCkgPT4gdm9pZCkge1xuICBpZiAobW9kZSkgc3RvcFJlY29yZGluZygpO1xuICBtb2RlID0gbTtcbiAgc2VuZCA9IHNpbms7XG4gIHN0b3BIYW5kbGVyID0gb25TdG9wO1xuICBvdmVybGF5Lm9uU3RvcCA9IG9uU3RvcDtcbiAgdHJhY2tWb2xhdGlsZUNsYXNzZXModHJ1ZSk7XG4gIGZvciAoY29uc3QgW2V2LCBmbl0gb2YgbGlzdGVuZXJzKSB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihldiwgZm4sIHRydWUpO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIG9uTGVhdmUpO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBvblNjcm9sbCwgdHJ1ZSk7XG4gIC8vIExhIHDDrWxkb3JhIHNvbG8gZW4gbGEgcMOhZ2luYSBwcmluY2lwYWwsIG5vIGVuIGNhZGEgaWZyYW1lLlxuICBpZiAod2luZG93ID09PSB3aW5kb3cudG9wKSBvdmVybGF5LnNldFBpbGwobSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdG9wUmVjb3JkaW5nKCkge1xuICBmbHVzaEZpbGxzKCk7XG4gIGZvciAoY29uc3QgW2V2LCBmbl0gb2YgbGlzdGVuZXJzKSB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihldiwgZm4sIHRydWUpO1xuICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIG9uTGVhdmUpO1xuICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBvblNjcm9sbCwgdHJ1ZSk7XG4gIHRyYWNrVm9sYXRpbGVDbGFzc2VzKGZhbHNlKTtcbiAgbW9kZSA9IG51bGw7XG4gIG92ZXJsYXkuaGlkZSgpO1xuICBvdmVybGF5LnNldFBpbGwobnVsbCk7XG59XG5cbi8qKiBTZWxlY2Npw7NuIGRlIHVuIMO6bmljbyBlbGVtZW50byAocGFyYSByZS1hcHVudGFyIHVuIHBhc28pLiBDbGlja3MgYmxvcXVlYWRvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwaWNrT25jZSgpOiBQcm9taXNlPFJlY29yZGVkU3RlcCB8IG51bGw+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgY29uc3QgYmxvY2sgPSAoZTogRXZlbnQpID0+IHtcbiAgICAgIGlmIChvdmVybGF5Lm93bnModGFyZ2V0T2YoZSkpKSByZXR1cm47XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICAgIH07XG4gICAgY29uc3QgZG9uZSA9IChyOiBSZWNvcmRlZFN0ZXAgfCBudWxsKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCBvbk1vdmUgYXMgRXZlbnRMaXN0ZW5lciwgdHJ1ZSk7XG4gICAgICBmb3IgKGNvbnN0IGV2IG9mIFtcInBvaW50ZXJkb3duXCIsIFwibW91c2Vkb3duXCIsIFwicG9pbnRlcnVwXCIsIFwibW91c2V1cFwiXSkgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoZXYsIGJsb2NrLCB0cnVlKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY2xpY2ssIHRydWUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGtleSwgdHJ1ZSk7XG4gICAgICBvdmVybGF5LmhpZGUoKTtcbiAgICAgIGNhbmNlbFBpY2sgPSAoKSA9PiB7fTtcbiAgICAgIGlmICghbW9kZSkgdHJhY2tWb2xhdGlsZUNsYXNzZXMoZmFsc2UpO1xuICAgICAgcmVzb2x2ZShyKTtcbiAgICB9O1xuICAgIGNvbnN0IGNsaWNrID0gKGU6IE1vdXNlRXZlbnQpID0+IHtcbiAgICAgIGJsb2NrKGUpO1xuICAgICAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICAgICAgaWYgKCF0IHx8IG92ZXJsYXkub3ducyh0KSkgcmV0dXJuO1xuICAgICAgZG9uZShjYXB0dXJlKGFjdGlvbmFibGUodCkpID8/IG51bGwpO1xuICAgIH07XG4gICAgY29uc3Qga2V5ID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJFc2NhcGVcIikge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGRvbmUobnVsbCk7XG4gICAgICB9XG4gICAgfTtcbiAgICB0cmFja1ZvbGF0aWxlQ2xhc3Nlcyh0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCBvbk1vdmUgYXMgRXZlbnRMaXN0ZW5lciwgdHJ1ZSk7XG4gICAgZm9yIChjb25zdCBldiBvZiBbXCJwb2ludGVyZG93blwiLCBcIm1vdXNlZG93blwiLCBcInBvaW50ZXJ1cFwiLCBcIm1vdXNldXBcIl0pIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2LCBibG9jaywgdHJ1ZSk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBjbGljaywgdHJ1ZSk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIGtleSwgdHJ1ZSk7XG4gICAgY2FuY2VsUGljayA9ICgpID0+IGRvbmUobnVsbCk7XG4gICAgaWYgKHdpbmRvdyA9PT0gd2luZG93LnRvcCkgb3ZlcmxheS50b2FzdChcIkNsaWNhIGVsIGVsZW1lbnRvIChFc2MgcGFyYSBjYW5jZWxhcilcIik7XG4gIH0pO1xufVxuXG5leHBvcnQgbGV0IGNhbmNlbFBpY2s6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcbiIsCiAgICAiLy8gQ29udGVudCBzY3JpcHQ6IHB1ZW50ZSBlbnRyZSBsYSBww6FnaW5hIHkgbGEgZXh0ZW5zacOzbi4gU2UgaW55ZWN0YSBlbiB0b2RvcyBsb3MgZnJhbWVzLlxuaW1wb3J0IHR5cGUgeyBSZWNvcmRlZFN0ZXAsIFRvQmFja2dyb3VuZCwgVG9Db250ZW50IH0gZnJvbSBcIi4uL3NoYXJlZC9tZXNzYWdlc1wiO1xuaW1wb3J0IHsgc2xlZXAgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcbmltcG9ydCB7IGhpZ2hsaWdodCwgcnVuU3RlcCB9IGZyb20gXCIuL3BsYXllclwiO1xuaW1wb3J0IHsgY2FuY2VsUGljaywgcGlja09uY2UsIHN0YXJ0UmVjb3JkaW5nLCBzdG9wUmVjb3JkaW5nIH0gZnJvbSBcIi4vcmVjb3JkZXJcIjtcbmltcG9ydCB7IGJ1aWxkU2VsZWN0b3JzLCByZXNvbHZlIH0gZnJvbSBcIi4vc2VsZWN0b3JcIjtcblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICBfX3Jhc3Rybz86IGJvb2xlYW47XG4gIH1cbn1cblxuZnVuY3Rpb24gdG9CZzxUID0gYW55Pihtc2c6IFRvQmFja2dyb3VuZCk6IFByb21pc2U8VCB8IHVuZGVmaW5lZD4ge1xuICB0cnkge1xuICAgIHJldHVybiBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShtc2cpLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gIH0gY2F0Y2gge1xuICAgIC8vIExhIGV4dGVuc2nDs24gc2UgcmVjYXJnw7MgeSBlc3RlIHNjcmlwdCBxdWVkw7MgaHXDqXJmYW5vLlxuICAgIHN0b3BSZWNvcmRpbmcoKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHVuZGVmaW5lZCk7XG4gIH1cbn1cblxuY29uc3Qgc2luayA9IChzdGVwOiBSZWNvcmRlZFN0ZXApID0+IHZvaWQgdG9CZyh7IGtpbmQ6IFwicmVjb3JkOnN0ZXBcIiwgc3RlcCB9KTtcbmNvbnN0IG9uU3RvcCA9ICgpID0+IHZvaWQgdG9CZyh7IGtpbmQ6IFwicmVjb3JkOnN0b3BcIiB9KTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIEZyYW1lczogaGFuZHNoYWtlIHBvciBwb3N0TWVzc2FnZSAoZnVuY2lvbmEgdGFtYmnDqW4gY3Jvc3Mtb3JpZ2luKSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY29uc3QgTVNHID0gXCJfX3Jhc3Ryb19mcmFtZVwiO1xuLyoqIHRva2VuIOKGkiA8aWZyYW1lPiBoaWpvIHF1ZSBzZSBhbnVuY2nDsyBjb24gw6lsLiAqL1xuY29uc3QgYW5ub3VuY2VkID0gbmV3IE1hcDxzdHJpbmcsIEVsZW1lbnQ+KCk7XG5cbmZ1bmN0aW9uIGZyYW1lRWxlbWVudEZvcihzb3VyY2U6IE1lc3NhZ2VFdmVudFNvdXJjZSB8IG51bGwpOiBFbGVtZW50IHwgdW5kZWZpbmVkIHtcbiAgaWYgKCFzb3VyY2UpIHJldHVybjtcbiAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lLCBmcmFtZVwiKV0uZmluZCgoZikgPT4gKGYgYXMgSFRNTElGcmFtZUVsZW1lbnQpLmNvbnRlbnRXaW5kb3cgPT09IHNvdXJjZSk7XG59XG5cbmZ1bmN0aW9uIG9uRnJhbWVNZXNzYWdlKGU6IE1lc3NhZ2VFdmVudCkge1xuICBjb25zdCBkID0gZS5kYXRhO1xuICBpZiAoIWQgfHwgdHlwZW9mIGQgIT09IFwib2JqZWN0XCIgfHwgZFtNU0ddID09IG51bGwgfHwgdHlwZW9mIGQudG9rZW4gIT09IFwic3RyaW5nXCIpIHJldHVybjtcbiAgaWYgKGRbTVNHXSA9PT0gXCJhbm5vdW5jZVwiKSB7XG4gICAgY29uc3QgZWwgPSBmcmFtZUVsZW1lbnRGb3IoZS5zb3VyY2UpO1xuICAgIGlmIChlbCkgYW5ub3VuY2VkLnNldChkLnRva2VuLCBlbCk7XG4gIH0gZWxzZSBpZiAoZFtNU0ddID09PSBcInByb2JlXCIgJiYgZS5zb3VyY2UgPT09IHdpbmRvdy5wYXJlbnQgJiYgd2luZG93ICE9PSB3aW5kb3cudG9wKSB7XG4gICAgdm9pZCB0b0JnKHsga2luZDogXCJmcmFtZTpwcm9iZVwiLCB0b2tlbjogZC50b2tlbiB9KTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBzZWxlY3RvcnNGb3JBbm5vdW5jZWQodG9rZW46IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10gfCBudWxsPiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMjAgJiYgIWFubm91bmNlZC5oYXModG9rZW4pOyBpKyspIGF3YWl0IHNsZWVwKDUwKTtcbiAgY29uc3QgZWwgPSBhbm5vdW5jZWQuZ2V0KHRva2VuKTtcbiAgYW5ub3VuY2VkLmRlbGV0ZSh0b2tlbik7XG4gIHJldHVybiBlbCA/IGJ1aWxkU2VsZWN0b3JzKGVsKSA6IG51bGw7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlc29sdmVGcmFtZShzZWxlY3RvcnM6IHN0cmluZ1tdLCB0aW1lb3V0OiBudW1iZXIpOiBQcm9taXNlPHsgdG9rZW4/OiBzdHJpbmc7IGVycm9yPzogc3RyaW5nIH0+IHtcbiAgY29uc3QgZW5kID0gcGVyZm9ybWFuY2Uubm93KCkgKyB0aW1lb3V0O1xuICB3aGlsZSAodHJ1ZSkge1xuICAgIGNvbnN0IHIgPSByZXNvbHZlKHNlbGVjdG9ycyk7XG4gICAgY29uc3Qgd2luID0gciAmJiAoci5lbCBhcyBIVE1MSUZyYW1lRWxlbWVudCkuY29udGVudFdpbmRvdztcbiAgICBpZiAod2luKSB7XG4gICAgICBjb25zdCB0b2tlbiA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgICB3aW4ucG9zdE1lc3NhZ2UoeyBbTVNHXTogXCJwcm9iZVwiLCB0b2tlbiB9LCBcIipcIik7XG4gICAgICByZXR1cm4geyB0b2tlbiB9O1xuICAgIH1cbiAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgPiBlbmQpIHJldHVybiB7IGVycm9yOiBgTm8gc2UgZW5jb250csOzIGVsIGlmcmFtZSDCqyR7c2VsZWN0b3JzWzBdfcK7YCB9O1xuICAgIGF3YWl0IHNsZWVwKDEwMCk7XG4gIH1cbn1cblxuaWYgKCF3aW5kb3cuX19yYXN0cm8pIHtcbiAgd2luZG93Ll9fcmFzdHJvID0gdHJ1ZTtcbiAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIG9uRnJhbWVNZXNzYWdlKTtcblxuICBjaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1zZzogVG9Db250ZW50LCBfc2VuZGVyLCByZXBseSkgPT4ge1xuICAgIHN3aXRjaCAobXNnLmtpbmQpIHtcbiAgICAgIGNhc2UgXCJwaW5nXCI6XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJyZWNvcmQ6b25cIjpcbiAgICAgICAgc3RhcnRSZWNvcmRpbmcobXNnLm1vZGUsIHNpbmssIG9uU3RvcCk7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJyZWNvcmQ6b2ZmXCI6XG4gICAgICAgIHN0b3BSZWNvcmRpbmcoKTtcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJ1bi1zdGVwXCI6XG4gICAgICAgIHJ1blN0ZXAobXNnLnN0ZXAsIG1zZy5zZXR0aW5ncykudGhlbihyZXBseSk7XG4gICAgICAgIHJldHVybiB0cnVlOyAvLyByZXNwdWVzdGEgYXPDrW5jcm9uYVxuICAgICAgY2FzZSBcImhpZ2hsaWdodFwiOlxuICAgICAgICBoaWdobGlnaHQoW21zZy5zZWxlY3RvciwgLi4uKG1zZy5mYWxsYmFja3MgPz8gW10pXSkudGhlbigoZm91bmQpID0+IHJlcGx5KHsgb2s6IGZvdW5kIH0pKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICBjYXNlIFwicGlja1wiOlxuICAgICAgICAvLyBTZSBkaWZ1bmRlIGEgdG9kb3MgbG9zIGZyYW1lczsgcmVzcG9uZGUgZWwgZnJhbWUgZG9uZGUgY2xpcXVlIGVsIHVzdWFyaW8sXG4gICAgICAgIC8vIHRyYXMgcGVkaXIgYWwgYmFja2dyb3VuZCBxdWUgYcOxYWRhIGxhIHJ1dGEgZGUgaWZyYW1lcy5cbiAgICAgICAgcGlja09uY2UoKS50aGVuKGFzeW5jIChzdGVwKSA9PiByZXBseShzdGVwID8gKChhd2FpdCB0b0JnPFJlY29yZGVkU3RlcD4oeyBraW5kOiBcImZyYW1lOmxvY2F0ZVwiLCBzdGVwIH0pKSA/PyBzdGVwKSA6IG51bGwpKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICBjYXNlIFwicGljazpjYW5jZWxcIjpcbiAgICAgICAgY2FuY2VsUGljaygpO1xuICAgICAgICByZXBseSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICBjYXNlIFwiZnJhbWU6YW5ub3VuY2VcIjpcbiAgICAgICAgd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZSh7IFtNU0ddOiBcImFubm91bmNlXCIsIHRva2VuOiBtc2cudG9rZW4gfSwgXCIqXCIpO1xuICAgICAgICByZXBseSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICBjYXNlIFwiZnJhbWU6c2VsZWN0b3JzXCI6XG4gICAgICAgIHNlbGVjdG9yc0ZvckFubm91bmNlZChtc2cudG9rZW4pLnRoZW4ocmVwbHkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJmcmFtZTpyZXNvbHZlXCI6XG4gICAgICAgIHJlc29sdmVGcmFtZShtc2cuc2VsZWN0b3JzLCBtc2cudGltZW91dCkudGhlbihyZXBseSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gQWwgY2FyZ2FyIHVuYSBww6FnaW5hIG51ZXZhLCDCv3NlZ3VpbW9zIGdyYWJhbmRvIGVuIGVzdGEgcGVzdGHDsWE/XG4gIHRvQmc8eyBtb2RlPzogXCJyZWNvcmRcIiB8IFwicG9pbnRcIiB9Pih7IGtpbmQ6IFwicmVjb3JkOnN0YXR1c1wiIH0pLnRoZW4oKHIpID0+IHtcbiAgICBpZiAocj8ubW9kZSkgc3RhcnRSZWNvcmRpbmcoci5tb2RlLCBzaW5rLCBvblN0b3ApO1xuICB9KTtcbn1cbiIKICBdLAogICJtYXBwaW5ncyI6ICI7O0VBR08sU0FBUyxjQUFjLENBQUMsR0FBb0I7QUFBQSxJQUNqRCxPQUNFLEVBQUUsU0FBUyxNQUNYLFNBQVMsS0FBSyxDQUFDLEtBQ2Ysb0JBQW9CLEtBQUssQ0FBQyxLQUMxQixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLGtCQUFrQixLQUFLLENBQUMsS0FDeEIsdUZBQXVGLEtBQUssQ0FBQyxLQUM1Rix1QkFBdUIsS0FBSyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsS0FDNUQsMkNBQTJDLEtBQUssQ0FBQztBQUFBO0FBQUEsRUFJOUMsSUFBTSxRQUFRLENBQUMsT0FBZSxJQUFJLFFBQWMsQ0FBQyxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUM7OztFQ2QvRSxJQUFNLE9BQU07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFxQ0wsSUFBTSxTQUFTLEVBQUUsT0FBTyxXQUFXLE1BQU0sV0FBVyxRQUFRLFdBQVcsT0FBTyxXQUFXLE1BQU0sV0FBVyxLQUFLLFVBQVU7QUFBQTtBQUFBLEVBRWhJLE1BQU0sUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNRO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ1IsU0FBcUIsTUFBTTtBQUFBLElBRW5CLE1BQU0sR0FBRztBQUFBLE1BQ2YsSUFBSSxLQUFLLE1BQU07QUFBQSxRQUFhO0FBQUEsTUFDNUIsS0FBSyxPQUFPLFNBQVMsY0FBYyxLQUFLO0FBQUEsTUFDeEMsS0FBSyxLQUFLLEtBQUs7QUFBQSxNQUNmLE1BQU0sT0FBTyxLQUFLLEtBQUssYUFBYSxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBQUEsTUFDcEQsS0FBSyxZQUFZLFVBQVU7QUFBQTtBQUFBO0FBQUEsTUFHM0IsS0FBSyxNQUFNLEtBQUssY0FBYyxNQUFNO0FBQUEsTUFDcEMsS0FBSyxNQUFNLEtBQUssY0FBYyxNQUFNO0FBQUEsTUFDcEMsS0FBSyxPQUFPLEtBQUssY0FBYyxPQUFPO0FBQUEsTUFDdEMsS0FBSyxXQUFXLEtBQUssY0FBYyxNQUFNO0FBQUEsTUFDekMsS0FBSyxTQUFTLEtBQUssY0FBYyxTQUFTO0FBQUEsTUFDMUMsS0FBSyxjQUFjLFFBQVEsRUFBRyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFBQSxRQUM3RCxFQUFFLGdCQUFnQjtBQUFBLFFBQ2xCLEtBQUssT0FBTztBQUFBLE9BQ2I7QUFBQSxNQUNELFNBQVMsZ0JBQWdCLFlBQVksS0FBSyxJQUFJO0FBQUE7QUFBQSxJQUdoRCxJQUFJLENBQUMsSUFBaUM7QUFBQSxNQUNwQyxPQUFPLENBQUMsQ0FBQyxLQUFLLFFBQVEsY0FBYyxTQUFTLE9BQU8sS0FBSyxRQUFRLEtBQUssS0FBSyxTQUFTLEVBQUU7QUFBQTtBQUFBLElBR3hGLElBQUksQ0FBQyxJQUFhLE1BQWMsUUFBZ0IsT0FBTyxPQUFPO0FBQUEsTUFDNUQsS0FBSyxPQUFPO0FBQUEsTUFDWixNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxNQUNuQyxPQUFPLE9BQU8sS0FBSyxJQUFJLE9BQU87QUFBQSxRQUM1QixTQUFTO0FBQUEsUUFBUyxNQUFNLEdBQUcsRUFBRSxPQUFPO0FBQUEsUUFBTyxLQUFLLEdBQUcsRUFBRSxNQUFNO0FBQUEsUUFBTyxPQUFPLEdBQUcsRUFBRSxRQUFRO0FBQUEsUUFBTyxRQUFRLEdBQUcsRUFBRSxTQUFTO0FBQUEsTUFDckgsQ0FBQztBQUFBLE1BQ0QsS0FBSyxJQUFJLE1BQU0sWUFBWSxPQUFPLEtBQUs7QUFBQSxNQUN2QyxLQUFLLElBQUksTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQ3ZDLEtBQUssSUFBSSxjQUFjO0FBQUEsTUFDdkIsS0FBSyxJQUFJLE1BQU0sVUFBVTtBQUFBLE1BQ3pCLE1BQU0sUUFBUSxFQUFFLE1BQU07QUFBQSxNQUN0QixLQUFLLElBQUksTUFBTSxPQUFPLEdBQUcsS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUUsT0FBTyxHQUFHLGFBQWEsR0FBRyxDQUFDO0FBQUEsTUFDM0UsS0FBSyxJQUFJLE1BQU0sTUFBTSxRQUFRLEdBQUcsRUFBRSxNQUFNLFNBQVMsR0FBRyxFQUFFLFNBQVM7QUFBQTtBQUFBLElBR2pFLElBQUksR0FBRztBQUFBLE1BQ0wsSUFBSSxDQUFDLEtBQUs7QUFBQSxRQUFLO0FBQUEsTUFDZixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUEsTUFDekIsS0FBSyxJQUFJLE1BQU0sVUFBVTtBQUFBO0FBQUEsSUFJM0IsS0FBSyxDQUFDLElBQWEsTUFBYyxLQUFLLEtBQUssUUFBZ0IsT0FBTyxLQUFLO0FBQUEsTUFDckUsS0FBSyxLQUFLLElBQUksTUFBTSxLQUFLO0FBQUEsTUFDekIsV0FBVyxNQUFNLEtBQUssS0FBSyxHQUFHLEVBQUU7QUFBQTtBQUFBLElBR2xDLE9BQU8sQ0FBQyxNQUFpQztBQUFBLE1BQ3ZDLEtBQUssT0FBTztBQUFBLE1BQ1osSUFBSSxDQUFDLE1BQU07QUFBQSxRQUNULEtBQUssS0FBSyxNQUFNLFVBQVU7QUFBQSxRQUMxQjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLEtBQUssS0FBSyxZQUFZLFVBQVU7QUFBQSxNQUNoQyxLQUFLLFNBQVMsY0FBYyxTQUFTLFdBQVcsb0JBQW9CO0FBQUEsTUFDcEUsS0FBSyxLQUFLLE1BQU0sVUFBVTtBQUFBO0FBQUEsSUFHNUIsS0FBSyxDQUFDLE1BQWMsT0FBZ0IsT0FBTyxPQUFPO0FBQUEsTUFDaEQsS0FBSyxPQUFPO0FBQUEsTUFDWixNQUFNLElBQUksU0FBUyxjQUFjLEtBQUs7QUFBQSxNQUN0QyxFQUFFLFlBQVksV0FBVyxPQUFPLFVBQVU7QUFBQSxNQUMxQyxJQUFJO0FBQUEsUUFBTyxFQUFFLE1BQU0sWUFBWSxPQUFPLEtBQUs7QUFBQSxNQUMzQyxFQUFFLGNBQWM7QUFBQSxNQUNoQixLQUFLLE9BQU8sWUFBWSxDQUFDO0FBQUEsTUFDekIsV0FBVyxNQUFNLEVBQUUsT0FBTyxHQUFHLElBQUk7QUFBQSxNQUNqQyxPQUFPLEtBQUssT0FBTyxTQUFTLFNBQVM7QUFBQSxRQUFHLEtBQUssT0FBTyxrQkFBbUIsT0FBTztBQUFBO0FBQUEsRUFFbEY7QUFBQSxFQUVPLElBQU0sVUFBVSxJQUFJOzs7RUM5RzNCLElBQU0sYUFBYSxDQUFDLGVBQWUsZ0JBQWdCLGFBQWEsV0FBVyxXQUFXLFlBQVksb0JBQW9CO0FBQUEsRUFFdEgsSUFBTSxZQUNKLHdHQUNBLHFHQUNBO0FBQUEsRUFFSyxJQUFNLFVBQVU7QUFBQSxFQUV2QixJQUFNLE9BQU8sQ0FBQyxPQUFrQyxLQUFLLElBQUksUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLO0FBQUEsRUFFbkYsSUFBTSxnQkFBZ0I7QUFBQSxFQUl0QixJQUFNLGNBQWMsSUFBSSxJQUFJO0FBQUEsSUFDMUI7QUFBQSxJQUFVO0FBQUEsSUFBUztBQUFBLElBQVc7QUFBQSxJQUFnQjtBQUFBLElBQWU7QUFBQSxJQUFTO0FBQUEsSUFBVztBQUFBLElBQVk7QUFBQSxJQUFhO0FBQUEsSUFDMUc7QUFBQSxJQUFZO0FBQUEsSUFBVztBQUFBLElBQVE7QUFBQSxJQUFVO0FBQUEsSUFBWTtBQUFBLElBQWE7QUFBQSxJQUFXO0FBQUEsSUFBWTtBQUFBLElBQVc7QUFBQSxJQUFXO0FBQUEsSUFDL0c7QUFBQSxJQUFTO0FBQUEsSUFBUztBQUFBLElBQVk7QUFBQSxJQUFTO0FBQUEsSUFBVztBQUFBLElBQVc7QUFBQSxJQUFTO0FBQUEsSUFBWTtBQUFBLElBQVM7QUFBQSxJQUFXO0FBQUEsRUFDeEcsQ0FBQztBQUFBLEVBRUQsU0FBUyxZQUFZLENBQUMsR0FBb0I7QUFBQSxJQUN4QyxJQUFJLGNBQWMsS0FBSyxDQUFDO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDbEMsTUFBTSxRQUFRLEVBQUUsTUFBTSwyQkFBMkIsRUFBRSxPQUFPLE9BQU87QUFBQSxJQUNqRSxPQUFPLE1BQU0sU0FBUyxLQUFLLFlBQVksSUFBSSxNQUFNLEdBQUcsRUFBRSxFQUFHLFlBQVksQ0FBQztBQUFBO0FBQUEsRUFLeEUsSUFBTSxXQUFXLElBQUk7QUFBQSxFQUNyQixJQUFJLGdCQUF5QztBQUFBLEVBRTdDLFNBQVMsZ0JBQWdCLENBQUMsU0FBMkI7QUFBQSxJQUNuRCxXQUFXLEtBQUssU0FBUztBQUFBLE1BQ3ZCLE1BQU0sU0FBUyxJQUFJLEtBQUssRUFBRSxZQUFZLElBQUksTUFBTSxLQUFLLEVBQUUsT0FBTyxPQUFPLENBQUM7QUFBQSxNQUN0RSxNQUFNLFFBQVMsRUFBRSxPQUFtQjtBQUFBLE1BQ3BDLFdBQVcsS0FBSztBQUFBLFFBQU8sSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDO0FBQUEsVUFBRyxTQUFTLElBQUksQ0FBQztBQUFBLE1BQ3pELFdBQVcsS0FBSztBQUFBLFFBQVEsSUFBSSxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQUEsVUFBRyxTQUFTLElBQUksQ0FBQztBQUFBLElBQ2hFO0FBQUE7QUFBQSxFQUlLLFNBQVMsb0JBQW9CLENBQUMsSUFBYTtBQUFBLElBQ2hELElBQUksTUFBTSxDQUFDLGVBQWU7QUFBQSxNQUN4QixnQkFBZ0IsSUFBSSxpQkFBaUIsZ0JBQWdCO0FBQUEsTUFDckQsY0FBYyxRQUFRLFNBQVMsaUJBQWlCLEVBQUUsU0FBUyxNQUFNLFlBQVksTUFBTSxpQkFBaUIsQ0FBQyxPQUFPLEdBQUcsbUJBQW1CLEtBQUssQ0FBQztBQUFBLElBQzFJLEVBQU8sU0FBSSxDQUFDLE1BQU0sZUFBZTtBQUFBLE1BQy9CLGlCQUFpQixjQUFjLFlBQVksQ0FBQztBQUFBLE1BQzVDLGNBQWMsV0FBVztBQUFBLE1BQ3pCLGdCQUFnQjtBQUFBLElBQ2xCO0FBQUE7QUFBQSxFQUdGLFNBQVMsYUFBYSxDQUFDLElBQXVCO0FBQUEsSUFFNUMsSUFBSTtBQUFBLE1BQWUsaUJBQWlCLGNBQWMsWUFBWSxDQUFDO0FBQUEsSUFDL0QsT0FBTyxDQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FDdkIsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFNBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQUUsU0FBUyxFQUN0RztBQUFBO0FBQUEsRUFHRixJQUFNLElBQUksQ0FBQyxNQUFjLEtBQUssVUFBVSxDQUFDO0FBQUEsRUFJbEMsU0FBUyxTQUFTLENBQUMsSUFBc0I7QUFBQSxJQUM5QyxJQUFJLENBQUMsR0FBRztBQUFBLE1BQWEsT0FBTztBQUFBLElBQzVCLElBQUksR0FBRyxlQUFlLEVBQUUsV0FBVztBQUFBLE1BQUcsT0FBTztBQUFBLElBQzdDLE1BQU0sS0FBSyxpQkFBaUIsRUFBRTtBQUFBLElBQzlCLE9BQU8sR0FBRyxlQUFlLFlBQVksR0FBRyxZQUFZO0FBQUE7QUFBQSxFQUkvQyxTQUFTLE1BQU0sQ0FBQyxJQUFxQjtBQUFBLElBQzFDLElBQUksY0FBYyxvQkFBb0IsQ0FBQyxVQUFVLFVBQVUsT0FBTyxFQUFFLFNBQVMsR0FBRyxJQUFJO0FBQUEsTUFBRyxPQUFPLEtBQUssR0FBRyxLQUFLO0FBQUEsSUFDM0csT0FBTyxLQUFNLEdBQW1CLGFBQWEsR0FBRyxXQUFXO0FBQUE7QUFBQSxFQUc3RCxVQUFVLFdBQVcsQ0FBQyxPQUE4QixVQUE4QjtBQUFBLElBQ2hGLE1BQU0sU0FBUyxTQUFTLGlCQUFpQixNQUFNLFdBQVcsWUFBWTtBQUFBLElBQ3RFLElBQUksSUFBSSxPQUFPLFNBQVM7QUFBQSxJQUN4QixPQUFPLEdBQUc7QUFBQSxNQUNSLE1BQU07QUFBQSxNQUNOLE1BQU0sS0FBTSxFQUFjO0FBQUEsTUFDMUIsSUFBSTtBQUFBLFFBQUksT0FBTyxZQUFZLEVBQUU7QUFBQSxNQUM3QixJQUFJLE9BQU8sU0FBUztBQUFBLElBQ3RCO0FBQUE7QUFBQSxFQUdGLFNBQVMsTUFBTSxDQUFDLE1BQXlCO0FBQUEsSUFDdkMsTUFBTSxTQUFTLEtBQUssSUFBSTtBQUFBLElBQ3hCLE1BQU0sUUFBbUIsQ0FBQztBQUFBLElBQzFCLE1BQU0sVUFBcUIsQ0FBQztBQUFBLElBQzVCLE1BQU0sUUFBUSxPQUFPLFlBQVk7QUFBQSxJQUNqQyxXQUFXLE1BQU0sWUFBWSxHQUFHO0FBQUEsTUFDOUIsSUFBSSxHQUFHLFFBQVEsbURBQW1EO0FBQUEsUUFBRztBQUFBLE1BQ3JFLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSTtBQUFBLE1BRWxDLElBQUksRUFBRSxjQUFjLHFCQUFxQixLQUFLLEdBQUcsV0FBVyxFQUFFLFNBQVM7QUFBQSxRQUFPO0FBQUEsTUFDOUUsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQ25CLElBQUksQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUFBLFFBQU87QUFBQSxNQUM1QixJQUFJLE1BQU07QUFBQSxRQUFRLE1BQU0sS0FBSyxFQUFFO0FBQUEsTUFDMUIsU0FBSSxFQUFFLFlBQVksRUFBRSxTQUFTLEtBQUs7QUFBQSxRQUFHLFFBQVEsS0FBSyxFQUFFO0FBQUEsSUFDM0Q7QUFBQSxJQUNBLE1BQU0sT0FBTyxNQUFNLFNBQVMsUUFBUTtBQUFBLElBRXBDLE1BQU0sVUFBVSxLQUFLLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLENBQUMsTUFBTSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDakYsT0FBTyxPQUFPLFFBQVEsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLEVBR2hFLFNBQVMsT0FBTyxDQUFDLE1BQXlCO0FBQUEsSUFDeEMsTUFBTSxTQUFTLEtBQUssSUFBSSxFQUFFLFlBQVk7QUFBQSxJQUN0QyxNQUFNLE1BQWlCLENBQUM7QUFBQSxJQUN4QixXQUFXLFNBQVMsU0FBUyxpQkFBaUIsT0FBTyxHQUFHO0FBQUEsTUFDdEQsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFLFlBQVksRUFBRSxRQUFRLFVBQVUsRUFBRSxNQUFNLFVBQVUsTUFBTTtBQUFBLFFBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTztBQUFBLElBQ25IO0FBQUEsSUFDQSxXQUFXLE1BQU0sU0FBUyxpQkFBaUIsVUFBVSxtQ0FBbUMsR0FBRztBQUFBLE1BQ3pGLElBQUksS0FBSyxHQUFHLGFBQWEsWUFBWSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsUUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQzdFLE1BQU0sS0FBSyxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsTUFDNUMsSUFBSSxJQUFJO0FBQUEsUUFDTixNQUFNLElBQUksR0FDUCxNQUFNLEtBQUssRUFDWCxJQUFJLENBQUMsT0FBTyxTQUFTLGVBQWUsRUFBRSxHQUFHLGFBQWEsRUFBRSxFQUN4RCxLQUFLLEdBQUc7QUFBQSxRQUNYLElBQUksS0FBSyxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxDQUFDLElBQUksUUFBUTtBQUFBLE1BQ2YsV0FBVyxNQUFNLFNBQVMsaUJBQWlCLGVBQWUsR0FBRztBQUFBLFFBQzNELElBQUksS0FBSyxHQUFHLGFBQWEsYUFBYSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ2hGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBLEVBR25CLFNBQVMsT0FBTyxDQUFDLElBQXVCO0FBQUEsSUFDdEMsTUFBTSxNQUFNLFNBQVMsU0FBUyxJQUFJLFVBQVUsTUFBTSxZQUFZLDRCQUE0QixJQUFJO0FBQUEsSUFDOUYsTUFBTSxNQUFpQixDQUFDO0FBQUEsSUFDeEIsU0FBUyxJQUFJLEVBQUcsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0FBQUEsTUFDM0MsTUFBTSxJQUFJLElBQUksYUFBYSxDQUFDO0FBQUEsTUFDNUIsSUFBSSxhQUFhO0FBQUEsUUFBUyxJQUFJLEtBQUssQ0FBQztBQUFBLElBQ3RDO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsTUFBUyxDQUFDLEtBQWU7QUFBQSxJQUNoQyxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDO0FBQUE7QUFBQSxFQUlsQixTQUFTLFVBQVUsQ0FBQyxVQUE2QjtBQUFBLElBQ3RELElBQUk7QUFBQSxNQUNGLElBQUksU0FBUyxXQUFXLE9BQU87QUFBQSxRQUFHLE9BQU8sT0FBTyxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzFFLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzVFLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDbkUsSUFBSSxTQUFTLFdBQVcsUUFBUSxHQUFHO0FBQUEsUUFFakMsTUFBTSxJQUFJLFNBQVMsaUJBQWlCLGVBQWUsRUFBRSxPQUFPLFNBQVMsTUFBTSxDQUFDLENBQUM7QUFBQSxRQUM3RSxPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUFBLE1BQ3BCO0FBQUEsTUFDQSxPQUFPLENBQUMsR0FBRyxTQUFTLGlCQUFpQixRQUFRLENBQUM7QUFBQSxNQUM5QyxNQUFNO0FBQUEsTUFDTixPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUEsRUFJWixTQUFTLE9BQU8sQ0FBQyxHQUFtQjtBQUFBLElBQ2xDLE1BQU0sSUFBSSxFQUFFLEtBQUs7QUFBQSxJQUNqQixJQUFLLEVBQUUsV0FBVyxHQUFHLEtBQUssRUFBRSxTQUFTLEdBQUcsS0FBTyxFQUFFLFdBQVcsR0FBRyxLQUFLLEVBQUUsU0FBUyxHQUFHO0FBQUEsTUFBSSxPQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUMxRyxPQUFPO0FBQUE7QUFBQSxFQUlGLFNBQVMsT0FBTyxDQUFDLFdBQStEO0FBQUEsSUFDckYsV0FBVyxPQUFPLFdBQVc7QUFBQSxNQUMzQixNQUFNLFFBQVEsV0FBVyxHQUFHO0FBQUEsTUFDNUIsSUFBSSxNQUFNLFdBQVc7QUFBQSxRQUFHLE9BQU8sRUFBRSxJQUFJLE1BQU0sSUFBSyxVQUFVLElBQUk7QUFBQSxNQUM5RCxNQUFNLE1BQU0sTUFBTSxPQUFPLFNBQVM7QUFBQSxNQUNsQyxJQUFJLElBQUksVUFBVTtBQUFBLFFBQUcsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFLLFVBQVUsSUFBSTtBQUFBLE1BQ3pELElBQUksTUFBTTtBQUFBLFFBQVEsT0FBTyxFQUFFLElBQUksTUFBTSxJQUFLLFVBQVUsSUFBSTtBQUFBLElBQzFEO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUtULFNBQVMsUUFBUSxDQUFDLEtBQWEsSUFBc0I7QUFBQSxJQUNuRCxNQUFNLElBQUksV0FBVyxHQUFHO0FBQUEsSUFDeEIsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLE9BQU87QUFBQTtBQUFBLEVBR3BDLFNBQVMsT0FBTyxDQUFDLElBQXFCO0FBQUEsSUFDcEMsTUFBTSxRQUFrQixDQUFDO0FBQUEsSUFDekIsSUFBSSxNQUFzQjtBQUFBLElBQzFCLE9BQU8sT0FBTyxRQUFRLFNBQVMsaUJBQWlCO0FBQUEsTUFDOUMsTUFBTSxNQUFNLElBQUksUUFBUSxZQUFZO0FBQUEsTUFDcEMsSUFBSSxRQUFRLE1BQU0sSUFBSSxNQUFNLENBQUMsZUFBZSxJQUFJLEVBQUUsR0FBRztBQUFBLFFBQ25ELE1BQU0sUUFBUSxNQUFNLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQztBQUFBLFFBQ3RDLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSztBQUFBLFFBQzFCLElBQUksU0FBUyxHQUFHLEVBQUU7QUFBQSxVQUFHLE9BQU87QUFBQSxRQUM1QixNQUFNLE1BQU07QUFBQSxNQUNkO0FBQUEsTUFDQSxJQUFJLE1BQU07QUFBQSxNQUNWLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQ3pDLElBQUksSUFBSTtBQUFBLFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUFBLE1BRW5FLE1BQU0sYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsTUFDN0MsSUFBSSxTQUFTLFlBQVksRUFBRTtBQUFBLFFBQUcsT0FBTztBQUFBLE1BRXJDLE1BQU0sU0FBeUIsSUFBSTtBQUFBLE1BQ25DLElBQUksUUFBUTtBQUFBLFFBQ1YsTUFBTSxPQUFPLENBQUMsR0FBRyxPQUFPLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFlBQVksSUFBSyxPQUFPO0FBQUEsUUFDMUUsSUFBSSxLQUFLLFNBQVM7QUFBQSxVQUFHLE9BQU8sZ0JBQWdCLEtBQUssUUFBUSxHQUFHLElBQUk7QUFBQSxNQUNsRTtBQUFBLE1BQ0EsTUFBTSxRQUFRLEdBQUc7QUFBQSxNQUNqQixNQUFNLElBQUksTUFBTSxLQUFLLEtBQUs7QUFBQSxNQUMxQixJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQUEsUUFBRyxPQUFPO0FBQUEsTUFDNUIsTUFBTTtBQUFBLElBQ1I7QUFBQSxJQUNBLE9BQU8sTUFBTSxLQUFLLEtBQUs7QUFBQTtBQUFBLEVBSWxCLFNBQVMsY0FBYyxDQUFDLElBQXVCO0FBQUEsSUFDcEQsTUFBTSxNQUFNLEdBQUcsUUFBUSxZQUFZO0FBQUEsSUFDbkMsTUFBTSxJQUFjLENBQUM7QUFBQSxJQUVyQixXQUFXLEtBQUssWUFBWTtBQUFBLE1BQzFCLE1BQU0sSUFBSSxHQUFHLGFBQWEsQ0FBQztBQUFBLE1BQzNCLElBQUk7QUFBQSxRQUFHLEVBQUUsS0FBSyxJQUFJLEtBQUssRUFBRSxDQUFDLElBQUk7QUFBQSxJQUNoQztBQUFBLElBQ0EsSUFBSSxHQUFHLE1BQU0sQ0FBQyxlQUFlLEdBQUcsRUFBRTtBQUFBLE1BQUcsRUFBRSxLQUFLLE1BQU0sSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFFbkUsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsSUFDbkMsSUFBSSxNQUFNO0FBQUEsTUFDUixJQUFJLGNBQWMscUJBQXFCLEdBQUcsU0FBUyxXQUFXLEdBQUcsU0FBUyxlQUFlLEdBQUcsU0FBUyxHQUFHLFVBQVUsTUFBTTtBQUFBLFFBQ3RILEVBQUUsS0FBSyxHQUFHLFlBQVksRUFBRSxJQUFJLFlBQVksRUFBRSxHQUFHLEtBQUssSUFBSTtBQUFBLE1BQ3hELEVBQU87QUFBQSxVQUFFLEtBQUssR0FBRyxZQUFZLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDekM7QUFBQSxJQUVBLE1BQU0sWUFBWSxHQUFHLFFBQVEsT0FBTztBQUFBLElBQ3BDLElBQUksV0FBVztBQUFBLE1BQ2IsTUFBTSxNQUFNLFVBQVUsRUFBRTtBQUFBLE1BQ3hCLElBQUksT0FBTyxJQUFJLFVBQVU7QUFBQSxRQUFJLEVBQUUsS0FBSyxTQUFTLEtBQUs7QUFBQSxJQUNwRDtBQUFBLElBRUEsTUFBTSxPQUFPLEdBQUcsYUFBYSxZQUFZO0FBQUEsSUFDekMsSUFBSTtBQUFBLE1BQU0sRUFBRSxLQUFLLEdBQUcsa0JBQWtCLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDaEQsTUFBTSxLQUFLLEdBQUcsYUFBYSxhQUFhO0FBQUEsSUFDeEMsSUFBSTtBQUFBLE1BQUksRUFBRSxLQUFLLEdBQUcsbUJBQW1CLEVBQUUsRUFBRSxJQUFJO0FBQUEsSUFFN0MsSUFBSSxDQUFDLFdBQVc7QUFBQSxNQUNkLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUNuQixJQUFJLEtBQUssRUFBRSxVQUFVLE1BQU0sQ0FBQyxHQUFHLGNBQWMsT0FBTztBQUFBLFFBQUcsRUFBRSxLQUFLLFFBQVEsR0FBRztBQUFBLElBQzNFO0FBQUEsSUFFQSxJQUFJLGNBQWMsbUJBQW1CO0FBQUEsTUFDbkMsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsTUFDbkMsSUFBSSxRQUFRLEtBQUssU0FBUyxNQUFNLENBQUMsS0FBSyxXQUFXLGFBQWEsS0FBSyxTQUFTO0FBQUEsUUFBSyxFQUFFLEtBQUssVUFBVSxFQUFFLElBQUksSUFBSTtBQUFBLElBQzlHO0FBQUEsSUFDQSxJQUFJLGNBQWMscUJBQXFCLGNBQWMsa0JBQWtCO0FBQUEsTUFDckUsTUFBTSxNQUFNLEdBQUcsYUFBYSxLQUFLO0FBQUEsTUFDakMsSUFBSSxPQUFPLENBQUMsSUFBSSxXQUFXLE9BQU8sS0FBSyxDQUFDLElBQUksV0FBVyxhQUFhLEdBQUc7QUFBQSxRQUVyRSxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU0sRUFBRTtBQUFBLFFBQy9CLEVBQUUsS0FBSyxTQUFTLE1BQU0sR0FBRyxXQUFXLEVBQUUsR0FBRyxPQUFPLEdBQUcsWUFBWSxFQUFFLElBQUksSUFBSTtBQUFBLE1BQzNFO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTSxRQUFRLEdBQUcsYUFBYSxPQUFPO0FBQUEsSUFDckMsSUFBSTtBQUFBLE1BQU8sRUFBRSxLQUFLLEdBQUcsYUFBYSxFQUFFLEtBQUssSUFBSTtBQUFBLElBRzdDLE1BQU0sYUFBYSxDQUFDLE1BQWM7QUFBQSxNQUNoQyxNQUFNLFNBQVMsRUFBRSxXQUFXLE9BQU87QUFBQSxNQUNuQyxNQUFNLE1BQU0sQ0FBQyxNQUFlLE1BQU0sTUFBTyxVQUFVLEdBQUcsU0FBUyxDQUFDLEtBQUssT0FBTyxDQUFDLE1BQU0sT0FBTyxFQUFFO0FBQUEsTUFDNUYsTUFBTSxJQUFJLFdBQVcsQ0FBQztBQUFBLE1BQ3RCLElBQUksRUFBRSxXQUFXO0FBQUEsUUFBRyxPQUFPLElBQUksRUFBRSxFQUFHO0FBQUEsTUFHcEMsSUFBSSxDQUFDO0FBQUEsUUFBUSxPQUFPO0FBQUEsTUFDcEIsTUFBTSxNQUFNLEVBQUUsT0FBTyxTQUFTO0FBQUEsTUFDOUIsT0FBTyxJQUFJLFdBQVcsS0FBSyxJQUFJLElBQUksRUFBRztBQUFBO0FBQUEsSUFFeEMsTUFBTSxTQUFTLE9BQU8sQ0FBQyxFQUFFLE9BQU8sVUFBVTtBQUFBLElBQzFDLE9BQU8sS0FBSyxRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ3ZCLE9BQU8sT0FBTyxNQUFNLEVBQUUsTUFBTSxHQUFHLENBQUM7QUFBQTtBQUFBLEVBSzNCLFNBQVMsU0FBUyxDQUFDLElBQXFCO0FBQUEsSUFDN0MsSUFBSyxHQUF3QixRQUFRLFFBQVE7QUFBQSxNQUMzQyxNQUFNLElBQUksS0FBTSxHQUF3QixPQUFRLEdBQUksU0FBUyxFQUFFLFFBQVEsVUFBVSxFQUFFO0FBQUEsTUFDbkYsSUFBSTtBQUFBLFFBQUcsT0FBTztBQUFBLElBQ2hCO0FBQUEsSUFDQSxNQUFNLE9BQU8sR0FBRyxhQUFhLFlBQVk7QUFBQSxJQUN6QyxJQUFJO0FBQUEsTUFBTSxPQUFPLEtBQUssSUFBSTtBQUFBLElBQzFCLE1BQU0sS0FBSyxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsSUFDNUMsSUFBSSxJQUFJO0FBQUEsTUFDTixNQUFNLElBQUksS0FBSyxHQUFHLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLFNBQVMsZUFBZSxFQUFFLEdBQUcsYUFBYSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUM7QUFBQSxNQUNsRyxJQUFJO0FBQUEsUUFBRyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxJQUNBLE9BQU87QUFBQTtBQUFBLEVBSUYsU0FBUyxRQUFRLENBQUMsSUFBcUI7QUFBQSxJQUM1QyxJQUFJLEdBQUcsUUFBUSxPQUFPLEdBQUc7QUFBQSxNQUN2QixRQUNFLFVBQVUsRUFBRSxLQUNaLEdBQUcsYUFBYSxhQUFhLEtBQzdCLEdBQUcsYUFBYSxNQUFNLEtBQ3RCLEdBQUcsTUFDSCxHQUFHLGFBQWEsT0FBTyxLQUN2QixHQUFHLFFBQVEsWUFBWSxHQUN2QixNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ2Y7QUFBQSxJQUNBLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixJQUFJO0FBQUEsTUFBRyxPQUFPLEVBQUUsU0FBUyxLQUFLLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNO0FBQUEsSUFDckQsUUFDRSxHQUFHLGFBQWEsWUFBWSxLQUM1QixHQUFHLGFBQWEsT0FBTyxLQUN2QixHQUFHLGNBQWMsS0FBSyxHQUFHLGFBQWEsS0FBSyxLQUMzQyxHQUFHLGFBQWEsTUFBTSxLQUN0QixHQUFHLFFBQVEsWUFBWSxHQUN2QixNQUFNLEdBQUcsRUFBRTtBQUFBO0FBQUEsRUFJUixTQUFTLFVBQVUsQ0FBQyxRQUEwQjtBQUFBLElBQ25ELE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTztBQUFBLElBQ25DLElBQUk7QUFBQSxNQUFNLE9BQU87QUFBQSxJQUNqQixNQUFNLFlBQVksT0FBTyxRQUFRLFNBQVM7QUFBQSxJQUMxQyxJQUFJLHFCQUFxQixvQkFBb0IsVUFBVTtBQUFBLE1BQVMsT0FBTyxVQUFVO0FBQUEsSUFDakYsT0FBTyxhQUFhO0FBQUE7QUFBQSxFQUd0QixJQUFNLFdBQVcsSUFBSSxJQUFJO0FBQUEsSUFDdkI7QUFBQSxJQUFJO0FBQUEsSUFBUTtBQUFBLElBQVM7QUFBQSxJQUFZO0FBQUEsSUFBVTtBQUFBLElBQU87QUFBQSxJQUFPO0FBQUEsSUFDekQ7QUFBQSxJQUFRO0FBQUEsSUFBa0I7QUFBQSxJQUFTO0FBQUEsSUFBUTtBQUFBLElBQVE7QUFBQSxJQUFTO0FBQUEsRUFDOUQsQ0FBQztBQUFBLEVBSU0sU0FBUyxNQUFNLENBQUMsSUFBeUI7QUFBQSxJQUM5QyxJQUFJLGNBQWM7QUFBQSxNQUFtQixPQUFPO0FBQUEsSUFDNUMsSUFBSSxjQUFjO0FBQUEsTUFBcUIsT0FBTyxHQUFHLFdBQVcsVUFBVTtBQUFBLElBQ3RFLElBQUksY0FBYyxrQkFBa0I7QUFBQSxNQUNsQyxJQUFJLEdBQUcsU0FBUyxjQUFjLEdBQUcsU0FBUztBQUFBLFFBQVMsT0FBTztBQUFBLE1BQzFELElBQUksR0FBRyxTQUFTO0FBQUEsUUFBUSxPQUFPO0FBQUEsTUFFL0IsSUFBSSxTQUFTLElBQUksR0FBRyxJQUFJO0FBQUEsUUFBRyxPQUFPLEdBQUcsV0FBVyxVQUFVO0FBQUEsTUFDMUQsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUssR0FBbUI7QUFBQSxNQUFtQixPQUFPO0FBQUEsSUFDbEQsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsSUFDbkMsSUFBSSxTQUFTLGNBQWMsU0FBUztBQUFBLE1BQVUsT0FBTztBQUFBLElBQ3JELE9BQU87QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsSUFBcUI7QUFBQSxJQUMzQyxJQUFJLGNBQWMsb0JBQW9CLGNBQWMsdUJBQXVCLGNBQWM7QUFBQSxNQUFtQixPQUFPLEdBQUc7QUFBQSxJQUN0SCxPQUFPLEtBQU0sR0FBbUIsU0FBUztBQUFBO0FBQUEsRUFHcEMsU0FBUyxTQUFTLENBQUMsSUFBc0I7QUFBQSxJQUM5QyxJQUFJLGNBQWM7QUFBQSxNQUFrQixPQUFPLEdBQUc7QUFBQSxJQUM5QyxPQUFPLEdBQUcsYUFBYSxjQUFjLE1BQU07QUFBQTs7O0VDclg3QyxJQUFNLFlBQVk7QUFBQSxFQUVsQixJQUFNLFlBQVk7QUFBQSxFQUVsQixJQUFNLFVBQVU7QUFBQSxFQUdoQixJQUFNLFVBQVU7QUFBQSxJQUNkO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFBdUM7QUFBQSxJQUN2QztBQUFBLElBQTZCO0FBQUEsSUFDN0I7QUFBQSxJQUF1QjtBQUFBLElBQ3ZCO0FBQUEsSUFBYztBQUFBLElBQ2Q7QUFBQSxJQUFtQjtBQUFBLElBQ25CO0FBQUEsSUFBWTtBQUFBLElBQW9CO0FBQUEsSUFBaUI7QUFBQSxJQUFXO0FBQUEsRUFDOUQsRUFBRSxLQUFLLElBQUk7QUFBQSxFQUlYLElBQUksVUFBVTtBQUFBLEVBQ2QsSUFBSSxhQUFhLFlBQVksSUFBSTtBQUFBLEVBRWpDLFNBQVMsaUJBQWlCLGdCQUFnQixDQUFDLE1BQU07QUFBQSxJQUMvQyxNQUFNLElBQUssRUFBa0I7QUFBQSxJQUM3QixJQUFJLE9BQU8sTUFBTTtBQUFBLE1BQVU7QUFBQSxJQUMzQixVQUFVO0FBQUEsSUFDVixhQUFhLFlBQVksSUFBSTtBQUFBLEdBQzlCO0FBQUEsRUFDRCxTQUFTLGNBQWMsSUFBSSxNQUFNLGVBQWUsQ0FBQztBQUFBLEVBSWpELElBQUksYUFBYSxZQUFZLElBQUk7QUFBQSxFQUNqQyxJQUFJLGNBQXVDO0FBQUEsRUFFM0MsU0FBUyxRQUFRLEdBQUc7QUFBQSxJQUNsQixJQUFJO0FBQUEsTUFBYTtBQUFBLElBQ2pCLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQyxZQUFZO0FBQUEsTUFDOUMsSUFBSSxRQUFRLEtBQUssQ0FBQyxNQUFNLENBQUUsRUFBRSxPQUFtQixVQUFVLGdCQUFnQixDQUFDO0FBQUEsUUFBRyxhQUFhLFlBQVksSUFBSTtBQUFBLEtBQzNHO0FBQUEsSUFDRCxZQUFZLFFBQVEsU0FBUyxpQkFBaUIsRUFBRSxTQUFTLE1BQU0sV0FBVyxNQUFNLFlBQVksTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBO0FBQUEsRUFJekgsU0FBUyxjQUFjLENBQUMsT0FBd0I7QUFBQSxJQUM5QyxNQUFNLElBQUksT0FBTyxLQUFLO0FBQUEsSUFDdEIsSUFBSSxDQUFDO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDZixJQUFJO0FBQUEsTUFDRixTQUFTLGNBQWMsQ0FBQztBQUFBLE1BQ3hCLE9BQU8sR0FBRyxZQUFZO0FBQUEsTUFDdEIsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBO0FBQUE7QUFBQSxFQUlKLFNBQVMsYUFBYSxDQUFDLE9BQXFDO0FBQUEsSUFDakUsV0FBVyxNQUFNLFNBQVMsaUJBQWlCLGVBQWUsS0FBSyxDQUFDLEdBQUc7QUFBQSxNQUNqRSxJQUFJLEdBQUcsUUFBUSxnQkFBZ0IsS0FBSyxDQUFDLFVBQVUsRUFBRTtBQUFBLFFBQUc7QUFBQSxNQUNwRCxNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxNQUNuQyxJQUFJLEVBQUUsUUFBUSxLQUFLLEVBQUUsU0FBUztBQUFBLFFBQUcsT0FBTztBQUFBLElBQzFDO0FBQUE7QUFBQSxFQU9GLGVBQXNCLE1BQU0sQ0FBQyxPQUFlLGFBQXFDO0FBQUEsSUFDL0UsU0FBUztBQUFBLElBQ1QsTUFBTSxRQUFRLFlBQVksSUFBSTtBQUFBLElBQzlCLE9BQU8sTUFBTTtBQUFBLE1BQ1gsTUFBTSxNQUFNLFlBQVksSUFBSTtBQUFBLE1BQzVCLE1BQU0sV0FBVyxZQUFZLEtBQUssTUFBTSxjQUFjO0FBQUEsTUFDdEQsTUFBTSxXQUFXLE1BQU0sY0FBYyxhQUFhLE1BQU0sUUFBUTtBQUFBLE1BQ2hFLElBQUksWUFBWSxZQUFZLENBQUMsY0FBYyxXQUFXO0FBQUEsUUFBRztBQUFBLE1BQ3pELElBQUksTUFBTSxRQUFRO0FBQUEsUUFBTztBQUFBLE1BQ3pCLE1BQU0sTUFBTSxFQUFFO0FBQUEsSUFDaEI7QUFBQTtBQUFBLEVBS0YsU0FBUyxVQUFVLENBQUMsSUFBYSxTQUEyQjtBQUFBLElBQzFELElBQUksR0FBRyxRQUFRLFdBQVc7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNwQyxJQUFJLEdBQUcsUUFBUSx3QkFBd0I7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUVqRCxPQUFPLFdBQVcsaUJBQWlCLEVBQUUsRUFBRSxrQkFBa0I7QUFBQTtBQUFBLEVBRzNELFNBQVMsUUFBUSxDQUFDLElBQWEsUUFBeUI7QUFBQSxJQUN0RCxJQUFJLE1BQU07QUFBQSxJQUNWLFNBQVMsSUFBSSxFQUFHLElBQUksVUFBVSxJQUFJLGVBQWU7QUFBQSxNQUFLLE1BQU0sSUFBSTtBQUFBLElBQ2hFLE9BQU87QUFBQTtBQUFBLEVBSVQsU0FBUyxTQUFTLENBQUMsSUFBYSxhQUFzQztBQUFBLElBQ3BFLElBQUksR0FBRyxZQUFZLE1BQU07QUFBQSxNQUFVLE9BQU87QUFBQSxJQUMxQyxNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxJQUNuQyxNQUFNLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUTtBQUFBLElBQzdCLE1BQU0sSUFBSSxFQUFFLE1BQU0sRUFBRSxTQUFTO0FBQUEsSUFDN0IsSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksY0FBYyxJQUFJO0FBQUEsTUFBYSxPQUFPO0FBQUEsSUFDaEUsTUFBTSxNQUFNLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQztBQUFBLElBQzFDLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxHQUFHLEtBQUssSUFBSSxRQUFRLGdCQUFnQjtBQUFBLE1BQUcsT0FBTztBQUFBLElBQ3RFLElBQUssR0FBd0IsVUFBVSxDQUFDLEdBQUksR0FBd0IsTUFBTyxFQUFFLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxHQUFHLENBQUM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUVsSCxJQUFJLENBQUMsSUFBSSxRQUFRLGVBQWUsV0FBVyxDQUFDLEtBQUssU0FBUyxJQUFJLENBQUMsRUFBRSxTQUFTLEdBQUc7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUN2RixPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsVUFBVSxDQUFDLElBQXFCO0FBQUEsSUFDdkMsTUFBTSxNQUFNLENBQUMsR0FBRyxHQUFHLFNBQVMsRUFBRSxNQUFNLEdBQUcsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUFBLElBQ2xELE9BQU8sR0FBRyxRQUFRLFlBQVksS0FBSyxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUssT0FBTyxNQUFNLE1BQU0sTUFBTTtBQUFBO0FBQUEsRUFPcEYsZUFBc0IsZUFBZSxDQUFDLElBQWEsU0FBaUIsVUFBbUIsYUFBOEM7QUFBQSxJQUNuSSxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsSUFDOUIsSUFBSSxXQUFXO0FBQUEsSUFDZixJQUFJLE1BQXFCO0FBQUEsSUFDekIsT0FBTyxNQUFNO0FBQUEsTUFDWCxNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxNQUNuQyxNQUFNLE9BQU8sR0FBRyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFO0FBQUEsTUFDM0MsTUFBTSxTQUFTLFNBQVM7QUFBQSxNQUN4QixXQUFXO0FBQUEsTUFDWCxNQUFNLFFBQVEsV0FBVyxVQUFVLElBQUksV0FBVyxJQUFJO0FBQUEsTUFDdEQsSUFBSSxXQUFXLElBQUksUUFBUTtBQUFBLFFBQUcsTUFBTTtBQUFBLE1BQy9CLFNBQUk7QUFBQSxRQUFPLE1BQU0sbUJBQW1CLFdBQVcsS0FBSztBQUFBLE1BQ3BELFNBQUksQ0FBQztBQUFBLFFBQVEsTUFBTTtBQUFBLE1BQ25CO0FBQUEsZUFBTztBQUFBLE1BQ1osSUFBSSxZQUFZLElBQUksSUFBSSxRQUFRO0FBQUEsUUFBUyxPQUFPO0FBQUEsTUFDaEQsTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNoQjtBQUFBOzs7RUN2SUYsTUFBTSxrQkFBa0IsTUFBTTtBQUFBLEVBQUM7QUFBQSxFQUcvQixlQUFlLElBQUksQ0FBQyxNQUFZLFNBQWlCLGdCQUFxRTtBQUFBLElBQ3BILE1BQU0sWUFBWSxDQUFDLEtBQUssVUFBVSxHQUFJLEtBQUssYUFBYSxDQUFDLENBQUUsRUFBRSxPQUFPLE9BQU87QUFBQSxJQUMzRSxJQUFJLENBQUMsVUFBVTtBQUFBLE1BQVEsTUFBTSxJQUFJLFVBQVUsMkJBQTJCO0FBQUEsSUFDdEUsTUFBTSxRQUFRLFlBQVksSUFBSTtBQUFBLElBQzlCLElBQUksY0FBYztBQUFBLElBQ2xCLE9BQU8sTUFBTTtBQUFBLE1BQ1gsTUFBTSxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQzNCLElBQUksR0FBRztBQUFBLFFBQ0wsSUFBSSxVQUFVLEVBQUUsRUFBRTtBQUFBLFVBQUcsT0FBTztBQUFBLFFBRTVCLElBQUksQ0FBQyxnQkFBZ0I7QUFBQSxVQUNuQixnQkFBZ0IsWUFBWSxJQUFJO0FBQUEsVUFDaEMsSUFBSSxZQUFZLElBQUksSUFBSSxjQUFjO0FBQUEsWUFBTSxPQUFPO0FBQUEsUUFDckQ7QUFBQSxNQUNGO0FBQUEsTUFDQSxJQUFJLFlBQVksSUFBSSxJQUFJLFFBQVEsU0FBUztBQUFBLFFBQ3ZDLElBQUk7QUFBQSxVQUFHLE1BQU0sSUFBSSxVQUFVLGdCQUFnQixLQUFLLFNBQVMsVUFBVSwrQkFBK0I7QUFBQSxRQUNsRyxNQUFNLElBQUksVUFBVSxtQkFBbUIsS0FBSyxTQUFTLFVBQVUsUUFBUSxVQUFVLEtBQUs7QUFBQSxNQUN4RjtBQUFBLE1BQ0EsTUFBTSxNQUFNLEdBQUc7QUFBQSxJQUNqQjtBQUFBO0FBQUEsRUFHRixTQUFTLE1BQU0sQ0FBQyxJQUFhO0FBQUEsSUFDM0IsTUFBTSxJQUFJLEdBQUcsc0JBQXNCO0FBQUEsSUFDbkMsT0FBTyxFQUFFLEdBQUcsRUFBRSxPQUFPLEVBQUUsUUFBUSxHQUFHLEdBQUcsRUFBRSxNQUFNLEVBQUUsU0FBUyxFQUFFO0FBQUE7QUFBQSxFQUc1RCxlQUFlLFFBQVEsQ0FBQyxJQUFhO0FBQUEsSUFDbkMsTUFBTSxJQUFJLEdBQUcsc0JBQXNCO0FBQUEsSUFDbkMsSUFBSSxFQUFFLE1BQU0sS0FBSyxFQUFFLFNBQVMsZUFBZSxFQUFFLE9BQU8sS0FBSyxFQUFFLFFBQVEsWUFBWTtBQUFBLE1BQzdFLEdBQUcsZUFBZSxFQUFFLE9BQU8sVUFBVSxRQUFRLFVBQVUsVUFBVSxVQUE0QixDQUFDO0FBQUEsTUFDOUYsTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNoQjtBQUFBO0FBQUEsRUFHRixTQUFTLEtBQUssQ0FBQyxRQUFpQixNQUFjLEdBQVcsR0FBVztBQUFBLElBQ2xFLE1BQU0sT0FBeUI7QUFBQSxNQUM3QixTQUFTO0FBQUEsTUFBTSxZQUFZO0FBQUEsTUFBTSxVQUFVO0FBQUEsTUFBTSxNQUFNO0FBQUEsTUFDdkQsU0FBUztBQUFBLE1BQUcsU0FBUztBQUFBLE1BQUcsU0FBUyxJQUFJO0FBQUEsTUFBUyxTQUFTLElBQUk7QUFBQSxNQUMzRCxRQUFRO0FBQUEsTUFBRyxTQUFTLEtBQUssU0FBUyxNQUFNLElBQUksSUFBSTtBQUFBLE1BQUcsV0FBVztBQUFBLE1BQUcsYUFBYTtBQUFBLE1BQVMsV0FBVztBQUFBLElBQ3BHO0FBQUEsSUFDQSxNQUFNLE9BQU8sS0FBSyxXQUFXLFNBQVMsSUFBSSxlQUFlO0FBQUEsSUFDekQsT0FBTyxPQUFPLGNBQWMsSUFBSSxLQUFLLE1BQU0sSUFBSSxDQUFDO0FBQUE7QUFBQSxFQUdsRCxlQUFlLFNBQVMsQ0FBQyxJQUFhO0FBQUEsSUFDcEMsTUFBTSxTQUFTLEVBQUU7QUFBQSxJQUNqQixRQUFRLEdBQUcsTUFBTSxPQUFPLEVBQUU7QUFBQSxJQUUxQixNQUFNLE1BQU0sU0FBUyxpQkFBaUIsR0FBRyxDQUFDO0FBQUEsSUFDMUMsTUFBTSxTQUFTLE9BQU8sR0FBRyxTQUFTLEdBQUcsSUFBSSxNQUFNO0FBQUEsSUFDL0MsTUFBTSxRQUFRLGVBQWUsR0FBRyxDQUFDO0FBQUEsSUFDakMsTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDL0IsTUFBTSxRQUFRLGVBQWUsR0FBRyxDQUFDO0FBQUEsSUFDakMsTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDL0IsTUFBTSxPQUFPLE1BQU0sUUFBUSxlQUFlLEdBQUcsQ0FBQyxLQUFLLE1BQU0sUUFBUSxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQ2xGLElBQUksUUFBUSxjQUFjLGVBQWUsR0FBRyxZQUFZO0FBQUEsTUFBSSxHQUFHLE1BQU0sRUFBRSxlQUFlLEtBQUssQ0FBQztBQUFBLElBQzVGLE1BQU0sUUFBUSxhQUFhLEdBQUcsQ0FBQztBQUFBLElBQy9CLE1BQU0sUUFBUSxXQUFXLEdBQUcsQ0FBQztBQUFBLElBRTdCLE1BQU0sUUFBUSxTQUFTLEdBQUcsQ0FBQztBQUFBO0FBQUEsRUFHN0IsSUFBTSxZQUFZLElBQUksSUFBSSxDQUFDLFFBQVEsa0JBQWtCLFNBQVMsUUFBUSxRQUFRLFNBQVMsT0FBTyxDQUFDO0FBQUEsRUFFL0YsU0FBUyxTQUFTLENBQUMsSUFBNEMsR0FBVztBQUFBLElBR3hFLE1BQU0sUUFBUSxjQUFjLHNCQUFzQixvQkFBb0IsWUFBWSxpQkFBaUI7QUFBQSxJQUNuRyxPQUFPLHlCQUF5QixPQUFPLE9BQU8sRUFBRyxJQUFLLEtBQUssSUFBSSxDQUFDO0FBQUE7QUFBQSxFQUdsRSxTQUFTLFNBQVMsQ0FBQyxJQUFhLE1BQXFCLFlBQVksY0FBYztBQUFBLElBQzdFLEdBQUcsY0FBYyxJQUFJLFdBQVcsU0FBUyxFQUFFLFNBQVMsTUFBTSxVQUFVLE1BQU0sTUFBTSxVQUFVLENBQUMsQ0FBQztBQUFBO0FBQUEsRUFHOUYsU0FBUyxHQUFHLENBQUMsSUFBYSxNQUF3QyxHQUFXO0FBQUEsSUFDM0UsT0FBTyxHQUFHLGNBQ1IsSUFBSSxjQUFjLE1BQU0sRUFBRSxLQUFLLEdBQUcsTUFBTSxRQUFRLENBQUMsR0FBRyxTQUFTLE1BQU0sWUFBWSxNQUFNLFVBQVUsS0FBSyxDQUFDLENBQ3ZHO0FBQUE7QUFBQSxFQUdGLFNBQVMsT0FBTyxDQUFDLEdBQW1CO0FBQUEsSUFDbEMsSUFBSSxFQUFFLFdBQVcsR0FBRztBQUFBLE1BQ2xCLElBQUksU0FBUyxLQUFLLENBQUM7QUFBQSxRQUFHLE9BQU8sUUFBUSxFQUFFLFlBQVk7QUFBQSxNQUNuRCxJQUFJLEtBQUssS0FBSyxDQUFDO0FBQUEsUUFBRyxPQUFPLFVBQVU7QUFBQSxNQUNuQyxJQUFJLE1BQU07QUFBQSxRQUFLLE9BQU87QUFBQSxNQUN0QixPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsT0FBTztBQUFBO0FBQUEsRUFHVCxTQUFTLFNBQVMsQ0FBQyxJQUE0QztBQUFBLElBQzdELElBQUk7QUFBQSxNQUNGLEdBQUcsT0FBTztBQUFBLE1BQ1YsTUFBTTtBQUFBO0FBQUEsRUFLVixlQUFlLFFBQVEsQ0FBQyxJQUFhLE9BQWUsR0FBYTtBQUFBLElBQy9ELE1BQU0sU0FBUyxFQUFFO0FBQUEsSUFDaEIsR0FBbUIsTUFBTSxFQUFFLGVBQWUsS0FBSyxDQUFDO0FBQUEsSUFFakQsSUFBSyxHQUFtQixtQkFBbUI7QUFBQSxNQUN6QyxTQUFTLFlBQVksV0FBVztBQUFBLE1BQ2hDLElBQUk7QUFBQSxRQUFPLFNBQVMsWUFBWSxjQUFjLE9BQU8sS0FBSztBQUFBLE1BQ3JEO0FBQUEsaUJBQVMsWUFBWSxRQUFRO0FBQUEsTUFDbEMsSUFBSSxPQUFPLEVBQUUsTUFBTSxNQUFNLFFBQVEsUUFBUSxHQUFHLEVBQUUsS0FBSyxHQUFHO0FBQUEsUUFDcEQsR0FBRyxjQUFjO0FBQUEsUUFDakIsVUFBVSxJQUFJLEtBQUs7QUFBQSxNQUNyQjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsSUFFQSxJQUFJLEVBQUUsY0FBYyxvQkFBb0IsY0FBYztBQUFBLE1BQXNCLE1BQU0sSUFBSSxVQUFVLDRCQUE0QjtBQUFBLElBQzVILElBQUksR0FBRztBQUFBLE1BQVUsTUFBTSxJQUFJLFVBQVUsSUFBSSxHQUFHLFFBQVEsR0FBRyx3QkFBd0I7QUFBQSxJQUUvRSxNQUFNLFdBQVcsRUFBRSxjQUFjLG9CQUFvQixVQUFVLElBQUksR0FBRyxJQUFJO0FBQUEsSUFFMUUsSUFBSSxDQUFDLFlBQVksRUFBRSxhQUFhLFdBQVc7QUFBQSxNQUN6QyxVQUFVLEVBQUU7QUFBQSxNQUNaLE1BQU0sS0FBSyxhQUFhLFFBQVEsU0FBUyxZQUFZLGNBQWMsT0FBTyxLQUFLLElBQUksU0FBUyxZQUFZLFFBQVE7QUFBQSxNQUNoSCxJQUFJLENBQUMsTUFBTSxHQUFHLFVBQVUsT0FBTztBQUFBLFFBQzdCLFVBQVUsSUFBSSxLQUFLO0FBQUEsUUFDbkIsVUFBVSxJQUFJLEtBQUs7QUFBQSxNQUNyQjtBQUFBLElBQ0YsRUFBTztBQUFBLE1BRUwsVUFBVSxFQUFFO0FBQUEsTUFDWixJQUFJLENBQUMsU0FBUyxZQUFZLFFBQVEsS0FBSyxHQUFHLFVBQVUsSUFBSTtBQUFBLFFBQ3RELFVBQVUsSUFBSSxFQUFFO0FBQUEsUUFDaEIsVUFBVSxJQUFJLE1BQU0sdUJBQXVCO0FBQUEsTUFDN0M7QUFBQSxNQUNBLFdBQVcsTUFBTSxPQUFPO0FBQUEsUUFDdEIsTUFBTSxVQUFVLElBQUksSUFBSSxXQUFXLEVBQUU7QUFBQSxRQUNyQyxJQUFJLElBQUksWUFBWSxFQUFFO0FBQUEsUUFDdEIsSUFBSSxTQUFTO0FBQUEsVUFDWCxNQUFNLFNBQVMsR0FBRztBQUFBLFVBQ2xCLElBQUksQ0FBQyxTQUFTLFlBQVksY0FBYyxPQUFPLEVBQUUsS0FBSyxHQUFHLFVBQVUsUUFBUTtBQUFBLFlBQ3pFLFVBQVUsSUFBSSxTQUFTLEVBQUU7QUFBQSxZQUN6QixVQUFVLElBQUksRUFBRTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUFBLFFBQ0EsSUFBSSxJQUFJLFNBQVMsRUFBRTtBQUFBLFFBQ25CLElBQUksRUFBRTtBQUFBLFVBQVUsTUFBTSxNQUFNLEVBQUUsUUFBUTtBQUFBLE1BQ3hDO0FBQUE7QUFBQSxJQUVGLEdBQUcsY0FBYyxJQUFJLE1BQU0sVUFBVSxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQTtBQUFBLEVBR3pELFNBQVMsWUFBWSxDQUFDLElBQWEsT0FBZSxZQUFxQjtBQUFBLElBQ3JFLElBQUksRUFBRSxjQUFjO0FBQUEsTUFBb0IsTUFBTSxJQUFJLFVBQVUsK0JBQStCO0FBQUEsSUFDM0YsTUFBTSxPQUFPLENBQUMsR0FBRyxHQUFHLE9BQU87QUFBQSxJQUMzQixNQUFNLE1BQ0osS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQVUsS0FBSyxNQUNqQyxhQUFhLEtBQUssS0FBSyxDQUFDLE1BQU0sRUFBRSxLQUFLLEtBQUssTUFBTSxVQUFVLElBQUksY0FDL0QsS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssS0FBSyxNQUFNLEtBQUssS0FDeEMsS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssS0FBSyxFQUFFLFlBQVksRUFBRSxTQUFTLE1BQU0sWUFBWSxDQUFDLENBQUM7QUFBQSxJQUM1RSxJQUFJLENBQUM7QUFBQSxNQUFLLE1BQU0sSUFBSSxVQUFVLGlDQUFpQyxjQUFjLFFBQVE7QUFBQSxJQUNyRixHQUFHLE1BQU07QUFBQSxJQUNULEdBQUcsUUFBUSxJQUFJO0FBQUEsSUFDZixHQUFHLGNBQWMsSUFBSSxNQUFNLFNBQVMsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUEsSUFDdEQsR0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBO0FBQUEsRUFHekQsZUFBZSxVQUFVLENBQUMsSUFBYSxNQUFlO0FBQUEsSUFDcEQsSUFBSSxVQUFVLEVBQUUsTUFBTTtBQUFBLE1BQU07QUFBQSxJQUM1QixJQUFJLGNBQWMsb0JBQW9CLEdBQUcsU0FBUyxXQUFXLENBQUMsTUFBTTtBQUFBLE1BQ2xFLE1BQU0sSUFBSSxVQUFVLDZEQUE2RDtBQUFBLElBQ25GO0FBQUEsSUFDQSxJQUFJLFVBQVUsRUFBRTtBQUFBLE1BQUcsTUFBTSxVQUFVLEVBQUU7QUFBQSxJQUNoQyxTQUFJLGNBQWMsb0JBQW9CLEdBQUcsU0FBUyxNQUFNLFVBQVUsR0FBRyxPQUFPLEVBQUU7QUFBQSxNQUFHLE1BQU0sVUFBVSxHQUFHLE9BQU8sRUFBRTtBQUFBLElBQzdHO0FBQUEsTUFBQyxHQUFtQixNQUFNO0FBQUEsSUFDL0IsSUFBSSxVQUFVLEVBQUUsTUFBTSxRQUFRLGNBQWMsa0JBQWtCO0FBQUEsTUFDNUQsR0FBRyxVQUFVO0FBQUEsTUFDYixHQUFHLGNBQWMsSUFBSSxNQUFNLFNBQVMsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUEsTUFDdEQsR0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQ3pEO0FBQUE7QUFBQSxFQUdGLElBQU0sWUFBWTtBQUFBLEVBRWxCLGVBQWUsS0FBSyxDQUFDLElBQWEsR0FBVztBQUFBLElBQzNDLE1BQU0sT0FBTyxJQUFJLElBQUksV0FBVyxDQUFDO0FBQUEsSUFDakMsSUFBSSxNQUFNO0FBQUEsTUFBUyxJQUFJLElBQUksWUFBWSxDQUFDO0FBQUEsSUFDeEMsSUFBSSxNQUFNO0FBQUEsTUFDUixJQUFJLE1BQU0sU0FBUztBQUFBLFFBQ2pCLElBQUksY0FBYyxvQkFBb0IsR0FBRyxNQUFNO0FBQUEsVUFFN0MsTUFBTSxNQUFNLEdBQUcsS0FBSyxjQUEyQixzRkFBc0Y7QUFBQSxVQUNySSxJQUFJO0FBQUEsWUFBSyxNQUFNLFVBQVUsR0FBRztBQUFBLFVBQ3ZCO0FBQUEsZUFBRyxLQUFLLGNBQWM7QUFBQSxRQUM3QixFQUFPLFNBQUksY0FBYyxxQkFBcUIsY0FBYyxtQkFBbUI7QUFBQSxVQUM1RSxHQUFtQixNQUFNO0FBQUEsUUFDNUI7QUFBQSxNQUNGLEVBQU8sU0FBSSxNQUFNLE9BQU87QUFBQSxRQUN0QixNQUFNLE1BQU0sQ0FBQyxHQUFHLFNBQVMsaUJBQThCLFNBQVMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxNQUFNLFVBQVUsQ0FBQyxLQUFLLENBQUUsRUFBdUIsUUFBUTtBQUFBLFFBQ2xJLE1BQU0sSUFBSSxJQUFJLFFBQVEsRUFBaUI7QUFBQSxRQUN2QyxJQUFLLEtBQUksS0FBSyxJQUFJLFNBQVMsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxJQUFJLFNBQVMsQ0FBQztBQUFBO0FBQUEsRUFJcEIsU0FBUyxXQUFXLENBQUMsSUFBc0I7QUFBQSxJQUN6QyxJQUFJLEdBQUcsUUFBUSxTQUFTO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDbEMsTUFBTSxNQUFNLEdBQUcsUUFBUSxlQUFlO0FBQUEsSUFDdEMsSUFBSSxlQUFlO0FBQUEsTUFBbUIsT0FBTyxDQUFDLENBQUMsSUFBSSxRQUFRLElBQUksU0FBUztBQUFBLElBQ3hFLElBQUksZUFBZTtBQUFBLE1BQWtCLE9BQU8sQ0FBQyxDQUFDLElBQUksU0FBUyxDQUFDLFVBQVUsT0FBTyxFQUFFLFNBQVMsSUFBSSxJQUFJLEtBQUssT0FBTyxHQUFHLE1BQU07QUFBQSxJQUNySCxPQUFPO0FBQUE7QUFBQSxFQUdULGVBQXNCLE9BQU8sQ0FBQyxNQUFZLEdBQWtDO0FBQUEsSUFDMUUsTUFBTSxVQUFVLEtBQUssV0FBVyxFQUFFO0FBQUEsSUFDbEMsSUFBSSxNQUFNO0FBQUEsSUFDVixJQUFJO0FBQUEsTUFDRixJQUFJO0FBQUEsTUFFSixNQUFNLE9BQU8sQ0FBQyxDQUFDLFdBQVcsWUFBWSxFQUFFLFNBQVMsS0FBSyxJQUFJO0FBQUEsTUFDMUQsSUFBSSxFQUFFLFlBQVk7QUFBQSxRQUFNLE1BQU0sT0FBTyxTQUFTLEVBQUUsY0FBYztBQUFBLE1BQzlELE1BQU0sU0FBUyxPQUFPLFVBQVUsU0FBUztBQUFBLFFBQ3ZDLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxTQUFTLE9BQU87QUFBQSxRQUMzQyxPQUFPLEVBQUU7QUFBQSxRQUNULElBQUksRUFBRSxZQUFZLE1BQU07QUFBQSxVQUN0QixJQUFJLFVBQVUsRUFBRSxFQUFFO0FBQUEsWUFBRyxNQUFNLFNBQVMsRUFBRSxFQUFFO0FBQUEsVUFDeEMsTUFBTSxNQUFNLE1BQU0sZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLFVBQVUsRUFBRSxFQUFFLEdBQUcsRUFBRSxjQUFjO0FBQUEsVUFDbEYsSUFBSTtBQUFBLFlBQUssTUFBTSxJQUFJLFVBQVUsSUFBSSxLQUFLLFNBQVMsRUFBRSxhQUFhLEtBQUs7QUFBQSxRQUNyRTtBQUFBLFFBQ0EsSUFBSSxFQUFFO0FBQUEsVUFBVyxRQUFRLE1BQU0sRUFBRSxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRSxZQUFZLEdBQUcsR0FBRyxPQUFPLEdBQUc7QUFBQSxRQUMxRyxPQUFPLEVBQUU7QUFBQTtBQUFBLE1BR1gsUUFBUSxLQUFLO0FBQUEsYUFDTixTQUFTO0FBQUEsVUFDWixNQUFNLEtBQUssTUFBTSxPQUFPO0FBQUEsVUFDeEIsTUFBTSxZQUFZLEVBQUU7QUFBQSxVQUNwQixNQUFNLFVBQVUsRUFBRTtBQUFBLFVBQ2xCO0FBQUEsUUFDRjtBQUFBLGFBQ0ssUUFBUTtBQUFBLFVBRVgsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQUEsVUFDN0IsSUFBSSxjQUFjO0FBQUEsWUFBbUIsYUFBYSxJQUFJLEtBQUssU0FBUyxFQUFFO0FBQUEsVUFDakUsU0FBSSxPQUFPLEVBQUUsTUFBTTtBQUFBLFlBQVMsTUFBTSxXQUFXLElBQUksQ0FBQyxDQUFDLElBQUksU0FBUyxPQUFPLEdBQUcsRUFBRSxTQUFTLEtBQUssU0FBUyxFQUFFLENBQUM7QUFBQSxVQUN0RztBQUFBLGtCQUFNLFNBQVMsSUFBSSxLQUFLLFNBQVMsSUFBSSxDQUFDO0FBQUEsVUFDM0M7QUFBQSxRQUNGO0FBQUEsYUFDSztBQUFBLFVBQ0gsYUFBYSxNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssU0FBUyxJQUFJLEtBQUssVUFBVTtBQUFBLFVBQ25FO0FBQUEsYUFDRztBQUFBLFVBQ0gsTUFBTSxXQUFXLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxVQUFVLE9BQU87QUFBQSxVQUM1RDtBQUFBLGFBQ0csU0FBUztBQUFBLFVBQ1osTUFBTSxLQUFLLEtBQUssV0FBVyxNQUFNLE9BQU8sS0FBSyxJQUFLLFNBQVMsaUJBQWlCLFNBQVM7QUFBQSxVQUNyRixPQUFPLEtBQUssU0FBUyxhQUFhLFdBQVcsWUFBWSxFQUFFO0FBQUEsVUFDM0QsTUFBTSxNQUFNLElBQUksS0FBSyxTQUFTLE9BQU87QUFBQSxVQUNyQztBQUFBLFFBQ0Y7QUFBQSxhQUNLO0FBQUEsVUFDSCxNQUFNLE9BQU87QUFBQSxVQUNiO0FBQUEsYUFDRyxjQUFjO0FBQUEsVUFDakIsTUFBTSxLQUFLLE1BQU0sT0FBTyxLQUFLO0FBQUEsVUFDN0IsTUFBTSxRQUFRLEtBQUssU0FBUyxJQUFJLEtBQUs7QUFBQSxVQUVyQyxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsVUFDOUIsSUFBSSxPQUFPO0FBQUEsVUFDWCxPQUFPLE1BQU07QUFBQSxZQUNYLE9BQU8sY0FBYyxvQkFBb0IsY0FBYyx1QkFBdUIsY0FBYyxvQkFBb0IsUUFBUSxFQUFFLElBQUksT0FBTyxFQUFFO0FBQUEsWUFDdkksSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUFBLGNBQUc7QUFBQSxZQUN6QixJQUFJLFlBQVksSUFBSSxJQUFJLFFBQVE7QUFBQSxjQUFTLE1BQU0sSUFBSSxVQUFVLGdCQUFnQixnQkFBZ0IsS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJO0FBQUEsWUFDakgsTUFBTSxNQUFNLEdBQUc7QUFBQSxVQUNqQjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUE7QUFBQSxVQUVFLE1BQU0sSUFBSSxVQUFVLGlCQUFpQixLQUFLLGtDQUFrQztBQUFBO0FBQUEsTUFFaEYsT0FBTyxFQUFFLElBQUksTUFBTSxjQUFjLE1BQU0sYUFBYSxJQUFJO0FBQUEsTUFDeEQsT0FBTyxHQUFHO0FBQUEsTUFDVixPQUFPLEVBQUUsSUFBSSxPQUFPLE9BQU8sYUFBYSxRQUFRLEVBQUUsVUFBVSxPQUFPLENBQUMsRUFBRTtBQUFBO0FBQUE7QUFBQSxFQUkxRSxlQUFzQixTQUFTLENBQUMsV0FBdUM7QUFBQSxJQUNyRSxNQUFNLElBQUksUUFBUSxTQUFTO0FBQUEsSUFDM0IsSUFBSSxDQUFDO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDZixNQUFNLFNBQVMsRUFBRSxFQUFFO0FBQUEsSUFDbkIsUUFBUSxNQUFNLEVBQUUsSUFBSSxFQUFFLFVBQVUsTUFBTSxPQUFPLEtBQUs7QUFBQSxJQUNsRCxPQUFPO0FBQUE7OztFQ3BTVCxJQUFJLE9BQW9CO0FBQUEsRUFDeEIsSUFBSSxPQUFrQyxNQUFNO0FBQUEsRUFDNUMsSUFBTSxjQUFjLElBQUk7QUFBQSxFQUV4QixJQUFNLE9BQW1DLEVBQUUsT0FBTyxTQUFTLE1BQU0sWUFBWSxRQUFRLGVBQWUsT0FBTyxVQUFVLE1BQU0sVUFBVTtBQUFBLEVBRzlILFNBQVMsT0FBTyxDQUFDLElBQWtDO0FBQUEsSUFDeEQsTUFBTSxPQUFPLE9BQU8sRUFBRTtBQUFBLElBQ3RCLElBQUksU0FBUztBQUFBLE1BQVEsT0FBTztBQUFBLElBQzVCLE9BQU8sYUFBYSxhQUFhLGVBQWUsRUFBRTtBQUFBLElBQ2xELE1BQU0sT0FBTyxFQUFFLFVBQVUsV0FBVyxPQUFPLFNBQVMsRUFBRSxFQUFFO0FBQUEsSUFDeEQsUUFBUTtBQUFBLFdBQ0Q7QUFBQSxRQUNILE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUSxPQUFPLFFBQVEsRUFBRSxHQUFHLFFBQVMsR0FBd0IsU0FBUyxjQUFjLFVBQVU7QUFBQSxXQUNuSCxVQUFVO0FBQUEsUUFDYixNQUFNLElBQUk7QUFBQSxRQUNWLE9BQU8sS0FBSyxNQUFNLE1BQU0sVUFBVSxPQUFPLEVBQUUsT0FBTyxZQUFZLEVBQUUsZ0JBQWdCLElBQUksS0FBSyxLQUFLLEVBQUU7QUFBQSxNQUNsRztBQUFBLFdBQ0s7QUFBQSxRQUNILE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUyxPQUFPLE9BQU8sVUFBVSxFQUFFLENBQUMsRUFBRTtBQUFBO0FBQUEsUUFFOUQsT0FBTyxLQUFLLE1BQU0sTUFBTSxRQUFRO0FBQUE7QUFBQTtBQUFBLEVBSXRDLFNBQVMsSUFBSSxDQUFDLElBQWEsTUFBMkI7QUFBQSxJQUNwRCxJQUFJLENBQUM7QUFBQSxNQUFNO0FBQUEsSUFDWCxLQUFLLElBQUk7QUFBQSxJQUNULE1BQU0sT0FBTyxLQUFLLFNBQVMsU0FBVSxLQUFLLFNBQVMsU0FBUyxLQUFLLEtBQUssU0FBUyxJQUFJLE1BQU0sR0FBRyxFQUFFLE9BQVE7QUFBQSxJQUN0RyxRQUFRLE1BQU0sS0FBSyxLQUFLLEtBQUssU0FBdUIsS0FBSyxTQUFTLEtBQUssU0FBUyxPQUFPLEtBQUssR0FBRyxPQUFPLE9BQU8sRUFBRSxFQUFFO0FBQUE7QUFBQSxFQUduSCxTQUFTLFVBQVUsR0FBRztBQUFBLElBQ3BCLFlBQVksSUFBSSxNQUFNLGFBQWE7QUFBQSxNQUNqQyxhQUFhLENBQUM7QUFBQSxNQUNkLEtBQUssUUFBUSxFQUFFLENBQUU7QUFBQSxJQUNuQjtBQUFBLElBQ0EsWUFBWSxNQUFNO0FBQUE7QUFBQSxFQUdwQixTQUFTLFlBQVksQ0FBQyxJQUFhO0FBQUEsSUFDakMsYUFBYSxZQUFZLElBQUksRUFBRSxDQUFDO0FBQUEsSUFDaEMsWUFBWSxJQUNWLElBQ0EsV0FBVyxNQUFNO0FBQUEsTUFDZixZQUFZLE9BQU8sRUFBRTtBQUFBLE1BQ3JCLE1BQU0sSUFBSSxRQUFRLEVBQUU7QUFBQSxNQUNwQixJQUFJO0FBQUEsUUFBRyxLQUFLLENBQUM7QUFBQSxPQUNaLEdBQUcsQ0FDUjtBQUFBO0FBQUEsRUFHRixJQUFNLFdBQVcsQ0FBQyxNQUE2QjtBQUFBLElBQzdDLE1BQU0sSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUFBLElBQzNCLE9BQU8sYUFBYSxVQUFVLElBQUk7QUFBQTtBQUFBLEVBS3BDLFNBQVMsTUFBTSxDQUFDLEdBQWU7QUFBQSxJQUM3QixNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDM0IsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQ3ZCLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixNQUFNLE9BQU8sTUFBTSxTQUFTLCtCQUErQixHQUFHLEtBQUssUUFBUSxTQUFTLEVBQUU7QUFBQSxJQUN0RixRQUFRLEtBQUssSUFBSSxNQUFNLE9BQU8sRUFBRTtBQUFBO0FBQUEsRUFJbEMsU0FBUyxZQUFZLENBQUMsR0FBVTtBQUFBLElBQzlCLElBQUksU0FBUyxXQUFXLENBQUMsRUFBRTtBQUFBLE1BQVc7QUFBQSxJQUN0QyxNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDM0IsSUFBSSxPQUFPLFdBQVcsQ0FBQyxDQUFDLE1BQU0sU0FBUztBQUFBLE1BQ3JDLEVBQUUsZUFBZTtBQUFBLE1BQ2pCLEVBQUUseUJBQXlCO0FBQUEsSUFDN0I7QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsR0FBZTtBQUFBLElBQzlCLElBQUksQ0FBQyxFQUFFO0FBQUEsTUFBVztBQUFBLElBQ2xCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUMzQixhQUFhLENBQUM7QUFBQSxJQUNkLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDbkIsSUFBSSxNQUFNO0FBQUEsTUFBUSxPQUFPLFFBQVEsTUFBTSxrREFBa0QsV0FBVyxJQUFJO0FBQUEsSUFDeEcsSUFBSSxNQUFNLFdBQVcsTUFBTTtBQUFBLE1BQVU7QUFBQSxJQUNyQyxXQUFXO0FBQUEsSUFDWCxJQUFJLE1BQU0sUUFBUTtBQUFBLE1BR2hCLElBQUksUUFBUSxFQUFFO0FBQUEsUUFBRyxLQUFLLElBQUksUUFBUSxFQUFFLENBQUM7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFBQSxJQUNBLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztBQUFBO0FBQUEsRUFHdEIsU0FBUyxPQUFPLENBQUMsR0FBVTtBQUFBLElBQ3pCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDUixNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsSUFDdkIsSUFBSSxPQUFPLEVBQUUsTUFBTTtBQUFBLE1BQVEsYUFBYSxFQUFFO0FBQUE7QUFBQSxFQUc1QyxTQUFTLFFBQVEsQ0FBQyxHQUFVO0FBQUEsSUFDMUIsSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDbEIsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUNSLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDbkIsSUFBSSxNQUFNLFFBQVE7QUFBQSxNQUNoQixhQUFhLFlBQVksSUFBSSxFQUFFLENBQUM7QUFBQSxNQUNoQyxZQUFZLE9BQU8sRUFBRTtBQUFBLE1BQ3JCLEtBQUssUUFBUSxFQUFFLENBQUU7QUFBQSxJQUNuQixFQUFPLFNBQUksTUFBTSxZQUFZLE1BQU0sU0FBUztBQUFBLE1BQzFDLFdBQVc7QUFBQSxNQUNYLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ3RCO0FBQUE7QUFBQSxFQUdGLFNBQVMsS0FBSyxDQUFDLEdBQWtCO0FBQUEsSUFDL0IsSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDbEIsSUFBSSxTQUFTLFdBQVcsRUFBRSxRQUFRLFVBQVU7QUFBQSxNQUMxQyxFQUFFLGVBQWU7QUFBQSxNQUNqQixZQUFZO0FBQUEsTUFDWjtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDUixJQUFJLEVBQUUsUUFBUSxXQUFXLGFBQWEsb0JBQW9CLE9BQU8sQ0FBQyxNQUFNLFFBQVE7QUFBQSxNQUM5RSxXQUFXO0FBQUEsTUFDWCxLQUFLLEVBQUUsTUFBTSxTQUFTLE9BQU8sU0FBUyxVQUFVLGVBQWUsQ0FBQyxFQUFFLElBQUksT0FBTyxTQUFTLENBQUMsRUFBRSxDQUFDO0FBQUEsTUFDMUYsUUFBUSxNQUFNLHFCQUFxQixTQUFTLENBQUMsR0FBRztBQUFBLElBQ2xEO0FBQUE7QUFBQSxFQUdGLFNBQVMsT0FBTyxHQUFHO0FBQUEsSUFDakIsV0FBVztBQUFBO0FBQUEsRUFHYixJQUFNLFdBQVcsTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUVwQyxJQUFJLGNBQTBCLE1BQU07QUFBQSxFQUVwQyxJQUFNLFlBQXVDO0FBQUEsSUFDM0MsQ0FBQyxhQUFhLE1BQXVCO0FBQUEsSUFDckMsQ0FBQyxlQUFlLFlBQVk7QUFBQSxJQUM1QixDQUFDLGFBQWEsWUFBWTtBQUFBLElBQzFCLENBQUMsYUFBYSxZQUFZO0FBQUEsSUFDMUIsQ0FBQyxXQUFXLFlBQVk7QUFBQSxJQUN4QixDQUFDLFNBQVMsT0FBd0I7QUFBQSxJQUNsQyxDQUFDLFNBQVMsT0FBTztBQUFBLElBQ2pCLENBQUMsVUFBVSxRQUFRO0FBQUEsSUFDbkIsQ0FBQyxXQUFXLEtBQXNCO0FBQUEsRUFDcEM7QUFBQSxFQUVPLFNBQVMsY0FBYyxDQUFDLEdBQVMsTUFBaUMsUUFBb0I7QUFBQSxJQUMzRixJQUFJO0FBQUEsTUFBTSxjQUFjO0FBQUEsSUFDeEIsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsY0FBYztBQUFBLElBQ2QsUUFBUSxTQUFTO0FBQUEsSUFDakIscUJBQXFCLElBQUk7QUFBQSxJQUN6QixZQUFZLElBQUksT0FBTztBQUFBLE1BQVcsT0FBTyxpQkFBaUIsSUFBSSxJQUFJLElBQUk7QUFBQSxJQUN0RSxPQUFPLGlCQUFpQixZQUFZLE9BQU87QUFBQSxJQUMzQyxPQUFPLGlCQUFpQixVQUFVLFVBQVUsSUFBSTtBQUFBLElBRWhELElBQUksV0FBVyxPQUFPO0FBQUEsTUFBSyxRQUFRLFFBQVEsQ0FBQztBQUFBO0FBQUEsRUFHdkMsU0FBUyxhQUFhLEdBQUc7QUFBQSxJQUM5QixXQUFXO0FBQUEsSUFDWCxZQUFZLElBQUksT0FBTztBQUFBLE1BQVcsT0FBTyxvQkFBb0IsSUFBSSxJQUFJLElBQUk7QUFBQSxJQUN6RSxPQUFPLG9CQUFvQixZQUFZLE9BQU87QUFBQSxJQUM5QyxPQUFPLG9CQUFvQixVQUFVLFVBQVUsSUFBSTtBQUFBLElBQ25ELHFCQUFxQixLQUFLO0FBQUEsSUFDMUIsT0FBTztBQUFBLElBQ1AsUUFBUSxLQUFLO0FBQUEsSUFDYixRQUFRLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFJZixTQUFTLFFBQVEsR0FBaUM7QUFBQSxJQUN2RCxPQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFBQSxNQUM5QixNQUFNLFFBQVEsQ0FBQyxNQUFhO0FBQUEsUUFDMUIsSUFBSSxRQUFRLEtBQUssU0FBUyxDQUFDLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDL0IsRUFBRSxlQUFlO0FBQUEsUUFDakIsRUFBRSx5QkFBeUI7QUFBQTtBQUFBLE1BRTdCLE1BQU0sT0FBTyxDQUFDLE1BQTJCO0FBQUEsUUFDdkMsT0FBTyxvQkFBb0IsYUFBYSxRQUF5QixJQUFJO0FBQUEsUUFDckUsV0FBVyxNQUFNLENBQUMsZUFBZSxhQUFhLGFBQWEsU0FBUztBQUFBLFVBQUcsT0FBTyxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxRQUNqSCxPQUFPLG9CQUFvQixTQUFTLE9BQU8sSUFBSTtBQUFBLFFBQy9DLE9BQU8sb0JBQW9CLFdBQVcsS0FBSyxJQUFJO0FBQUEsUUFDL0MsUUFBUSxLQUFLO0FBQUEsUUFDYixhQUFhLE1BQU07QUFBQSxRQUNuQixJQUFJLENBQUM7QUFBQSxVQUFNLHFCQUFxQixLQUFLO0FBQUEsUUFDckMsUUFBUSxDQUFDO0FBQUE7QUFBQSxNQUVYLE1BQU0sUUFBUSxDQUFDLE1BQWtCO0FBQUEsUUFDL0IsTUFBTSxDQUFDO0FBQUEsUUFDUCxNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsUUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDM0IsS0FBSyxRQUFRLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSTtBQUFBO0FBQUEsTUFFckMsTUFBTSxNQUFNLENBQUMsTUFBcUI7QUFBQSxRQUNoQyxJQUFJLEVBQUUsUUFBUSxVQUFVO0FBQUEsVUFDdEIsRUFBRSxlQUFlO0FBQUEsVUFDakIsS0FBSyxJQUFJO0FBQUEsUUFDWDtBQUFBO0FBQUEsTUFFRixxQkFBcUIsSUFBSTtBQUFBLE1BQ3pCLE9BQU8saUJBQWlCLGFBQWEsUUFBeUIsSUFBSTtBQUFBLE1BQ2xFLFdBQVcsTUFBTSxDQUFDLGVBQWUsYUFBYSxhQUFhLFNBQVM7QUFBQSxRQUFHLE9BQU8saUJBQWlCLElBQUksT0FBTyxJQUFJO0FBQUEsTUFDOUcsT0FBTyxpQkFBaUIsU0FBUyxPQUFPLElBQUk7QUFBQSxNQUM1QyxPQUFPLGlCQUFpQixXQUFXLEtBQUssSUFBSTtBQUFBLE1BQzVDLGFBQWEsTUFBTSxLQUFLLElBQUk7QUFBQSxNQUM1QixJQUFJLFdBQVcsT0FBTztBQUFBLFFBQUssUUFBUSxNQUFNLHVDQUF1QztBQUFBLEtBQ2pGO0FBQUE7QUFBQSxFQUdJLElBQUksYUFBeUIsTUFBTTs7O0VDaE8xQyxTQUFTLElBQWEsQ0FBQyxLQUEyQztBQUFBLElBQ2hFLElBQUk7QUFBQSxNQUNGLE9BQU8sT0FBTyxRQUFRLFlBQVksR0FBRyxFQUFFLE1BQU0sTUFBRztBQUFBLFFBQUc7QUFBQSxPQUFTO0FBQUEsTUFDNUQsTUFBTTtBQUFBLE1BRU4sY0FBYztBQUFBLE1BQ2QsT0FBTyxRQUFRLFFBQVEsU0FBUztBQUFBO0FBQUE7QUFBQSxFQUlwQyxJQUFNLE9BQU8sQ0FBQyxTQUF1QixLQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDNUUsSUFBTSxTQUFTLE1BQU0sS0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUl0RCxJQUFNLE1BQU07QUFBQSxFQUVaLElBQU0sWUFBWSxJQUFJO0FBQUEsRUFFdEIsU0FBUyxlQUFlLENBQUMsUUFBd0Q7QUFBQSxJQUMvRSxJQUFJLENBQUM7QUFBQSxNQUFRO0FBQUEsSUFDYixPQUFPLENBQUMsR0FBRyxTQUFTLGlCQUFpQixlQUFlLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTyxFQUF3QixrQkFBa0IsTUFBTTtBQUFBO0FBQUEsRUFHdEgsU0FBUyxjQUFjLENBQUMsR0FBaUI7QUFBQSxJQUN2QyxNQUFNLElBQUksRUFBRTtBQUFBLElBQ1osSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksRUFBRSxRQUFRLFFBQVEsT0FBTyxFQUFFLFVBQVU7QUFBQSxNQUFVO0FBQUEsSUFDbEYsSUFBSSxFQUFFLFNBQVMsWUFBWTtBQUFBLE1BQ3pCLE1BQU0sS0FBSyxnQkFBZ0IsRUFBRSxNQUFNO0FBQUEsTUFDbkMsSUFBSTtBQUFBLFFBQUksVUFBVSxJQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUEsSUFDbkMsRUFBTyxTQUFJLEVBQUUsU0FBUyxXQUFXLEVBQUUsV0FBVyxPQUFPLFVBQVUsV0FBVyxPQUFPLEtBQUs7QUFBQSxNQUMvRSxLQUFLLEVBQUUsTUFBTSxlQUFlLE9BQU8sRUFBRSxNQUFNLENBQUM7QUFBQSxJQUNuRDtBQUFBO0FBQUEsRUFHRixlQUFlLHFCQUFxQixDQUFDLE9BQXlDO0FBQUEsSUFDNUUsU0FBUyxJQUFJLEVBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxJQUFJLEtBQUssR0FBRztBQUFBLE1BQUssTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNwRSxNQUFNLEtBQUssVUFBVSxJQUFJLEtBQUs7QUFBQSxJQUM5QixVQUFVLE9BQU8sS0FBSztBQUFBLElBQ3RCLE9BQU8sS0FBSyxlQUFlLEVBQUUsSUFBSTtBQUFBO0FBQUEsRUFHbkMsZUFBZSxZQUFZLENBQUMsV0FBcUIsU0FBOEQ7QUFBQSxJQUM3RyxNQUFNLE1BQU0sWUFBWSxJQUFJLElBQUk7QUFBQSxJQUNoQyxPQUFPLE1BQU07QUFBQSxNQUNYLE1BQU0sSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUMzQixNQUFNLE1BQU0sS0FBTSxFQUFFLEdBQXlCO0FBQUEsTUFDN0MsSUFBSSxLQUFLO0FBQUEsUUFDUCxNQUFNLFFBQVEsT0FBTyxXQUFXO0FBQUEsUUFDaEMsSUFBSSxZQUFZLEdBQUcsTUFBTSxTQUFTLE1BQU0sR0FBRyxHQUFHO0FBQUEsUUFDOUMsT0FBTyxFQUFFLE1BQU07QUFBQSxNQUNqQjtBQUFBLE1BQ0EsSUFBSSxZQUFZLElBQUksSUFBSTtBQUFBLFFBQUssT0FBTyxFQUFFLE9BQU8sNkJBQTZCLFVBQVUsTUFBTTtBQUFBLE1BQzFGLE1BQU0sTUFBTSxHQUFHO0FBQUEsSUFDakI7QUFBQTtBQUFBLEVBR0YsSUFBSSxDQUFDLE9BQU8sVUFBVTtBQUFBLElBQ3BCLE9BQU8sV0FBVztBQUFBLElBQ2xCLE9BQU8saUJBQWlCLFdBQVcsY0FBYztBQUFBLElBRWpELE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFnQixTQUFTLFVBQVU7QUFBQSxNQUN2RSxRQUFRLElBQUk7QUFBQSxhQUNMO0FBQUEsVUFDSCxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFBQSxVQUNsQjtBQUFBLGFBQ0c7QUFBQSxVQUNILGVBQWUsSUFBSSxNQUFNLE1BQU0sTUFBTTtBQUFBLFVBQ3JDLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsY0FBYztBQUFBLFVBQ2QsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxRQUFRLElBQUksTUFBTSxJQUFJLFFBQVEsRUFBRSxLQUFLLEtBQUs7QUFBQSxVQUMxQyxPQUFPO0FBQUEsYUFDSjtBQUFBLFVBQ0gsVUFBVSxDQUFDLElBQUksVUFBVSxHQUFJLElBQUksYUFBYSxDQUFDLENBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxVQUFVLE1BQU0sRUFBRSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsVUFDeEYsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUdILFNBQVMsRUFBRSxLQUFLLE9BQU8sU0FBUyxNQUFNLE9BQVMsTUFBTSxLQUFtQixFQUFFLE1BQU0sZ0JBQWdCLEtBQUssQ0FBQyxLQUFNLE9BQVEsSUFBSSxDQUFDO0FBQUEsVUFDekgsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILFdBQVc7QUFBQSxVQUNYLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsT0FBTyxPQUFPLFlBQVksR0FBRyxNQUFNLFlBQVksT0FBTyxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBQUEsVUFDdEUsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxzQkFBc0IsSUFBSSxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsVUFDM0MsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILGFBQWEsSUFBSSxXQUFXLElBQUksT0FBTyxFQUFFLEtBQUssS0FBSztBQUFBLFVBQ25ELE9BQU87QUFBQTtBQUFBLEtBRVo7QUFBQSxJQUdELEtBQW9DLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNO0FBQUEsTUFDekUsSUFBSSxHQUFHO0FBQUEsUUFBTSxlQUFlLEVBQUUsTUFBTSxNQUFNLE1BQU07QUFBQSxLQUNqRDtBQUFBLEVBQ0g7IiwKICAiZGVidWdJZCI6ICI1NUEwN0E3QUMxODYwNjI1NjQ3NTZFMjE2NDc1NkUyMSIsCiAgIm5hbWVzIjogW10KfQ==
