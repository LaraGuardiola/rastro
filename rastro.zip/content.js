(() => {
  // src/shared/util.ts
  function looksGenerated(s) {
    return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/content/overlay.ts
  var CSS2 = `
:host { all: initial; }
.box {
  position: fixed; pointer-events: none; z-index: 2147483646; display: none;
  border: 2px solid var(--c, #7c5cff); background: color-mix(in srgb, var(--c, #7c5cff) 12%, transparent);
  border-radius: 4px; transition: all 60ms ease-out; box-sizing: border-box;
}
.tag {
  position: fixed; pointer-events: none; z-index: 2147483647; display: none;
  font: 600 11px/1.2 ui-sans-serif, system-ui, sans-serif; color: #fff; background: var(--c, #7c5cff);
  padding: 4px 7px; border-radius: 5px; white-space: nowrap; max-width: 360px; overflow: hidden; text-overflow: ellipsis;
  box-shadow: 0 2px 8px rgb(0 0 0 / .25);
}
.pill {
  position: fixed; z-index: 2147483647; left: 50%; bottom: 18px; transform: translateX(-50%);
  display: none; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px;
  font: 600 12px/1 ui-sans-serif, system-ui, sans-serif; color: #f4f2ff; background: #1b1830ee;
  box-shadow: 0 6px 24px rgb(0 0 0 / .35); backdrop-filter: blur(6px); user-select: none;
}
.dot { width: 9px; height: 9px; border-radius: 50%; background: #ff4d6d; animation: pulse 1.2s infinite; }
.pill.point .dot { background: #7c5cff; }
@keyframes pulse { 50% { opacity: .35; } }
.pill button {
  all: unset; cursor: pointer; padding: 5px 10px; border-radius: 999px; background: #ffffff1f; color: #fff;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
}
.pill button:hover { background: #ffffff38; }
.toasts { position: fixed; z-index: 2147483647; right: 16px; bottom: 64px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; pointer-events: none; }
.toast {
  font: 500 12px/1.3 ui-sans-serif, system-ui, sans-serif; color: #fff; background: #1b1830ee; padding: 7px 11px;
  border-radius: 8px; border-left: 3px solid var(--c, #7c5cff); box-shadow: 0 4px 14px rgb(0 0 0 / .3);
  animation: in .18s ease-out; max-width: 340px;
}
.toast.warn { --c: #ffb020; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } }
`;
  var COLORS = { click: "#7c5cff", fill: "#14b8a6", select: "#0ea5e9", check: "#22c55e", file: "#ffb020", run: "#f97316" };

  class Overlay {
    host;
    box;
    tag;
    pill;
    pillText;
    toasts;
    onStop = () => {};
    ensure() {
      if (this.host?.isConnected)
        return;
      this.host = document.createElement("div");
      this.host.id = "__rastro_host";
      const root = this.host.attachShadow({ mode: "open" });
      root.innerHTML = `<style>${CSS2}</style><div class="box"></div><div class="tag"></div>
      <div class="pill"><span class="dot"></span><span class="txt"></span><button type="button">Terminar</button></div>
      <div class="toasts"></div>`;
      this.box = root.querySelector(".box");
      this.tag = root.querySelector(".tag");
      this.pill = root.querySelector(".pill");
      this.pillText = root.querySelector(".txt");
      this.toasts = root.querySelector(".toasts");
      root.querySelector("button").addEventListener("click", (e) => {
        e.stopPropagation();
        this.onStop();
      });
      document.documentElement.appendChild(this.host);
    }
    owns(el) {
      return !!this.host && el instanceof Node && (el === this.host || this.host.contains(el));
    }
    show(el, text, color = COLORS.click) {
      this.ensure();
      const r = el.getBoundingClientRect();
      Object.assign(this.box.style, {
        display: "block",
        left: `${r.left - 3}px`,
        top: `${r.top - 3}px`,
        width: `${r.width + 6}px`,
        height: `${r.height + 6}px`
      });
      this.box.style.setProperty("--c", color);
      this.tag.style.setProperty("--c", color);
      this.tag.textContent = text;
      this.tag.style.display = "block";
      const above = r.top > 30;
      this.tag.style.left = `${Math.max(4, Math.min(r.left - 3, innerWidth - 370))}px`;
      this.tag.style.top = above ? `${r.top - 27}px` : `${r.bottom + 6}px`;
    }
    hide() {
      if (!this.box)
        return;
      this.box.style.display = "none";
      this.tag.style.display = "none";
    }
    flash(el, text, ms = 700, color = COLORS.run) {
      this.show(el, text, color);
      setTimeout(() => this.hide(), ms);
    }
    setPill(mode) {
      this.ensure();
      if (!mode) {
        this.pill.style.display = "none";
        return;
      }
      this.pill.className = "pill " + mode;
      this.pillText.textContent = mode === "record" ? "Rastro grabando" : "Rastro · modo señalar (Esc para salir)";
      this.pill.style.display = "flex";
    }
    toast(text, color, warn = false) {
      this.ensure();
      const t = document.createElement("div");
      t.className = "toast" + (warn ? " warn" : "");
      if (color)
        t.style.setProperty("--c", color);
      t.textContent = text;
      this.toasts.appendChild(t);
      setTimeout(() => t.remove(), 2200);
      while (this.toasts.children.length > 4)
        this.toasts.firstElementChild.remove();
    }
  }
  var overlay = new Overlay;

  // src/content/selector.ts
  var TEST_ATTRS = ["data-testid", "data-test-id", "data-test", "data-cy", "data-qa", "data-e2e", "data-automation-id"];
  var CLICKABLE = 'button, a[href], [role="button"], [role="link"], [role="menuitem"], [role="tab"], [role="option"], ' + '[role="checkbox"], [role="radio"], [role="switch"], input[type="submit"], input[type="button"], ' + 'input[type="reset"], input[type="image"], summary, label, [onclick]';
  var CONTROL = 'input, textarea, select, [contenteditable]:not([contenteditable="false"])';
  var norm = (s) => (s ?? "").replace(/\s+/g, " ").trim();
  var STATE_CLASSES = /^(is-|has-)?(active|focus(ed)?|hover(ed)?|selected|open(ed)?|disabled|checked|visible|hidden|show|in|ng-.*)$/i;
  var STATE_WORDS = new Set([
    "active",
    "focus",
    "focused",
    "focusvisible",
    "focuswithin",
    "hover",
    "hovered",
    "hovering",
    "highlight",
    "highlighted",
    "selected",
    "current",
    "open",
    "opened",
    "expanded",
    "collapsed",
    "pressed",
    "disabled",
    "checked",
    "visible",
    "hidden",
    "shown",
    "enter",
    "entering",
    "leave",
    "leaving",
    "touched",
    "dirty",
    "pristine",
    "valid",
    "invalid",
    "error"
  ]);
  function isStateClass(c) {
    if (STATE_CLASSES.test(c))
      return true;
    const words = c.split(/[-_]+|(?<=[a-z])(?=[A-Z])/).filter(Boolean);
    return words.length > 1 && STATE_WORDS.has(words.at(-1).toLowerCase());
  }
  var volatile = new Set;
  var classObserver = null;
  function noteClassChanges(records) {
    for (const r of records) {
      const before = new Set((r.oldValue ?? "").split(/\s+/).filter(Boolean));
      const after = r.target.classList;
      for (const c of after)
        if (!before.has(c))
          volatile.add(c);
      for (const c of before)
        if (!after.contains(c))
          volatile.add(c);
    }
  }
  function trackVolatileClasses(on) {
    if (on && !classObserver) {
      classObserver = new MutationObserver(noteClassChanges);
      classObserver.observe(document.documentElement, { subtree: true, attributes: true, attributeFilter: ["class"], attributeOldValue: true });
    } else if (!on && classObserver) {
      noteClassChanges(classObserver.takeRecords());
      classObserver.disconnect();
      classObserver = null;
    }
  }
  function stableClasses(el) {
    if (classObserver)
      noteClassChanges(classObserver.takeRecords());
    return [...el.classList].filter((c) => !looksGenerated(c) && !isStateClass(c) && !volatile.has(c) && !c.includes(":") && c.length < 32);
  }
  var q = (v) => JSON.stringify(v);
  function isVisible(el) {
    if (!el.isConnected)
      return false;
    if (el.getClientRects().length === 0)
      return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.opacity !== "0";
  }
  function textOf(el) {
    if (el instanceof HTMLInputElement && ["submit", "button", "reset"].includes(el.type))
      return norm(el.value);
    return norm(el.innerText ?? el.textContent);
  }
  function* allElements(root = document) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let n = walker.nextNode();
    while (n) {
      yield n;
      const sr = n.shadowRoot;
      if (sr)
        yield* allElements(sr);
      n = walker.nextNode();
    }
  }
  function byText(text, root = document) {
    const target = norm(text);
    const exact = [];
    const partial = [];
    const lower = target.toLowerCase();
    for (const el of allElements(root)) {
      if (el.closest("script, style, noscript, template, #__rastro_host"))
        continue;
      const limit = target.length * 3 + 20;
      if (!(el instanceof HTMLInputElement) && norm(el.textContent).length > limit)
        continue;
      const t = textOf(el);
      if (!t || t.length > limit)
        continue;
      if (t === target)
        exact.push(el);
      else if (t.toLowerCase().includes(lower))
        partial.push(el);
    }
    const pick = exact.length ? exact : partial;
    const deepest = pick.filter((el) => !pick.some((o) => o !== el && el.contains(o)));
    return dedupe(deepest.map((el) => el.closest(CLICKABLE) ?? el));
  }
  function byLabel(text) {
    const target = norm(text).toLowerCase();
    const out = [];
    for (const label of document.querySelectorAll("label")) {
      if (norm(label.innerText).toLowerCase().replace(/\s*\*$/, "") === target && label.control)
        out.push(label.control);
    }
    for (const el of document.querySelectorAll(CONTROL + ", [aria-label], [aria-labelledby]")) {
      if (norm(el.getAttribute("aria-label")).toLowerCase() === target)
        out.push(el);
      const lb = el.getAttribute("aria-labelledby");
      if (lb) {
        const t = lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" ");
        if (norm(t).toLowerCase() === target)
          out.push(el);
      }
    }
    if (!out.length) {
      for (const el of document.querySelectorAll("[placeholder]")) {
        if (norm(el.getAttribute("placeholder")).toLowerCase() === target)
          out.push(el);
      }
    }
    return dedupe(out);
  }
  function byXPath(xp) {
    const res = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const out = [];
    for (let i = 0;i < res.snapshotLength; i++) {
      const n = res.snapshotItem(i);
      if (n instanceof Element)
        out.push(n);
    }
    return out;
  }
  function dedupe(arr) {
    return [...new Set(arr)];
  }
  var CHAIN = " >> ";
  var endsInText = (sel) => sel.startsWith("text=") || sel.includes(CHAIN + "text=");
  function resolveAll(selector, root = document) {
    try {
      if (selector.startsWith("text="))
        return byText(unquote(selector.slice(5)), root);
      const i = selector.indexOf(CHAIN);
      if (i > 0) {
        const scopes = resolveAll(selector.slice(0, i), root);
        return dedupe(scopes.flatMap((sc) => resolveAll(selector.slice(i + CHAIN.length), sc)));
      }
      if (selector.startsWith("label="))
        return byLabel(unquote(selector.slice(6)));
      if (selector.startsWith("xpath="))
        return byXPath(selector.slice(6));
      if (selector.startsWith("frame=")) {
        const f = document.querySelectorAll("iframe, frame")[Number(selector.slice(6))];
        return f ? [f] : [];
      }
      return [...root.querySelectorAll(selector)];
    } catch {
      return [];
    }
  }
  function unquote(s) {
    const t = s.trim();
    if (t.startsWith('"') && t.endsWith('"') || t.startsWith("'") && t.endsWith("'"))
      return t.slice(1, -1);
    return t;
  }
  function resolve(selectors) {
    for (const sel of selectors) {
      const found = resolveAll(sel);
      if (found.length === 1)
        return { el: found[0], selector: sel };
      const vis = found.filter(isVisible);
      if (vis.length >= 1)
        return { el: vis[0], selector: sel };
      if (found.length)
        return { el: found[0], selector: sel };
    }
    return null;
  }
  function isUnique(sel, el) {
    const r = resolveAll(sel);
    return r.length === 1 && r[0] === el;
  }
  function cssPath(el) {
    const parts = [];
    let cur = el;
    while (cur && cur !== document.documentElement) {
      const tag = cur.tagName.toLowerCase();
      if (cur !== el && cur.id && !looksGenerated(cur.id)) {
        parts.unshift("#" + CSS.escape(cur.id));
        const s = parts.join(" > ");
        if (isUnique(s, el))
          return s;
        parts.shift();
      }
      let seg = tag;
      const cls = stableClasses(cur).slice(0, 2);
      if (cls.length)
        seg += "." + cls.map((c) => CSS.escape(c)).join(".");
      const withoutNth = [seg, ...parts].join(" > ");
      if (isUnique(withoutNth, el))
        return withoutNth;
      const parent = cur.parentElement;
      if (parent) {
        const same = [...parent.children].filter((c) => c.tagName === cur.tagName);
        if (same.length > 1)
          seg += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(seg);
      const s = parts.join(" > ");
      if (isUnique(s, el))
        return s;
      cur = parent;
    }
    return parts.join(" > ");
  }
  var OPTION_LIST = '[role="listbox"], [role="menu"], [role="tree"], [role="grid"], ul, ol, ' + '[class*="dropdown"], [class*="popper"], [class*="popover"], [class*="menu"], [class*="option"], [class*="select"], [class*="list"]';
  function containerSelectors(box) {
    const tag = box.tagName.toLowerCase();
    const out = [];
    const role = box.getAttribute("role");
    if (role)
      out.push(`[role=${q(role)}]`);
    for (const a of TEST_ATTRS) {
      const v = box.getAttribute(a);
      if (v)
        out.unshift(`[${a}=${q(v)}]`);
    }
    if (box.id && !looksGenerated(box.id))
      out.unshift("#" + CSS.escape(box.id));
    const cls = stableClasses(box).slice(0, 3);
    if (cls.length)
      out.push(tag + "." + cls.map((c) => CSS.escape(c)).join("."));
    return out;
  }
  function scopedText(el, text) {
    const out = [];
    let box = el.parentElement?.closest(OPTION_LIST);
    for (let i = 0;box && box !== document.body && i < 4; i++) {
      for (const sc of containerSelectors(box))
        out.push(`${sc}${CHAIN}text=${text}`);
      box = box.parentElement?.closest(OPTION_LIST);
    }
    return out;
  }
  function buildSelectors(el) {
    const tag = el.tagName.toLowerCase();
    const c = [];
    for (const a of TEST_ATTRS) {
      const v = el.getAttribute(a);
      if (v)
        c.push(`[${a}=${q(v)}]`);
    }
    if (el.id && !looksGenerated(el.id))
      c.push("#" + CSS.escape(el.id));
    const name = el.getAttribute("name");
    if (name) {
      if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.value && el.value !== "on") {
        c.push(`${tag}[name=${q(name)}][value=${q(el.value)}]`);
      } else
        c.push(`${tag}[name=${q(name)}]`);
    }
    const isControl = el.matches(CONTROL);
    if (isControl) {
      const lbl = labelText(el);
      if (lbl && lbl.length <= 60)
        c.push(`label=${lbl}`);
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      c.push(`${tag}[aria-label=${q(aria)}]`);
    const ph = el.getAttribute("placeholder");
    if (ph)
      c.push(`${tag}[placeholder=${q(ph)}]`);
    if (!isControl) {
      const t = textOf(el);
      if (t && t.length <= 80 && !el.querySelector(CONTROL)) {
        if (t.length <= 50)
          c.push(`text=${t}`);
        c.push(...scopedText(el, t));
      }
    }
    if (el instanceof HTMLAnchorElement) {
      const href = el.getAttribute("href");
      if (href && href.length < 80 && !href.startsWith("javascript:") && href !== "#")
        c.push(`a[href=${q(href)}]`);
    }
    if (el instanceof HTMLIFrameElement || el instanceof HTMLFrameElement) {
      const src = el.getAttribute("src");
      if (src && !src.startsWith("data:") && !src.startsWith("javascript:")) {
        const base = src.split(/[?#]/)[0];
        c.push(base === src ? `${tag}[src=${q(src)}]` : `${tag}[src^=${q(base)}]`);
      }
    }
    const title = el.getAttribute("title");
    if (title)
      c.push(`${tag}[title=${q(title)}]`);
    const sameTarget = (s) => {
      const isText = endsInText(s);
      const hit = (x) => x === el || isText && el.contains(x) && textOf(x) === textOf(el);
      const r = resolveAll(s);
      if (r.length === 1)
        return hit(r[0]);
      if (!isText)
        return false;
      const vis = r.filter(isVisible);
      return vis.length === 1 && hit(vis[0]);
    };
    const unique = dedupe(c).filter(sameTarget);
    unique.push(cssPath(el));
    return dedupe(unique).slice(0, 5);
  }
  function labelText(el) {
    if (el.labels?.length) {
      const t = norm(el.labels[0].innerText).replace(/\s*\*$/, "");
      if (t)
        return t;
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      return norm(aria);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = norm(lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" "));
      if (t)
        return t;
    }
    return "";
  }
  function describe(el) {
    if (el.matches(CONTROL)) {
      return (labelText(el) || el.getAttribute("placeholder") || el.getAttribute("name") || el.id || el.getAttribute("title") || el.tagName.toLowerCase()).slice(0, 60);
    }
    const t = textOf(el);
    if (t)
      return t.length > 50 ? t.slice(0, 47) + "…" : t;
    return (el.getAttribute("aria-label") || el.getAttribute("title") || el.querySelector("img")?.getAttribute("alt") || el.getAttribute("name") || el.tagName.toLowerCase()).slice(0, 60);
  }
  function actionable(target) {
    const ctrl = target.closest(CONTROL);
    if (ctrl)
      return ctrl;
    const clickable = target.closest(CLICKABLE);
    if (clickable instanceof HTMLLabelElement && clickable.control)
      return clickable.control;
    return clickable ?? target;
  }
  var TEXTLIKE = new Set([
    "",
    "text",
    "email",
    "password",
    "search",
    "tel",
    "url",
    "number",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "color",
    "range"
  ]);
  function kindOf(el) {
    if (el instanceof HTMLSelectElement)
      return "select";
    if (el instanceof HTMLTextAreaElement)
      return el.readOnly ? "click" : "fill";
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio")
        return "check";
      if (el.type === "file")
        return "file";
      if (TEXTLIKE.has(el.type))
        return el.readOnly ? "click" : "fill";
      return "click";
    }
    if (el.isContentEditable)
      return "fill";
    const role = el.getAttribute("role");
    if (role === "checkbox" || role === "switch")
      return "check";
    return "click";
  }
  function valueOf(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)
      return el.value;
    return norm(el.innerText);
  }
  function checkedOf(el) {
    if (el instanceof HTMLInputElement)
      return el.checked;
    return el.getAttribute("aria-checked") === "true";
  }

  // src/content/wait.ts
  var NET_QUIET = 300;
  var DOM_QUIET = 150;
  var DOM_CAP = 1500;
  var LOADERS = [
    '[aria-busy="true"]',
    ".el-loading-mask",
    ".ant-spin-spinning",
    ".v-progress-circular--indeterminate",
    ".v-progress-linear--active",
    ".MuiCircularProgress-root",
    ".MuiLinearProgress-root",
    ".p-progress-spinner",
    ".p-blockui",
    ".q-loading",
    ".q-spinner",
    ".spinner-border",
    ".spinner-grow",
    ".blockUI",
    ".loading-overlay",
    ".loading-mask",
    ".loader",
    ".spinner"
  ].join(", ");
  var pending = 0;
  var netChanged = performance.now();
  document.addEventListener("__rastro_net", (e) => {
    const n = e.detail;
    if (typeof n !== "number")
      return;
    pending = n;
    netChanged = performance.now();
  });
  document.dispatchEvent(new Event("__rastro_net?"));
  var domChanged = performance.now();
  var domObserver = null;
  function watchDom() {
    if (domObserver)
      return;
    domObserver = new MutationObserver((records) => {
      if (records.some((r) => !r.target.closest?.("#__rastro_host")))
        domChanged = performance.now();
    });
    domObserver.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
  }
  function loaderSelector(extra) {
    const x = extra?.trim();
    if (!x)
      return LOADERS;
    try {
      document.querySelector(x);
      return `${LOADERS}, ${x}`;
    } catch {
      return LOADERS;
    }
  }
  function visibleLoader(extra) {
    for (const el of document.querySelectorAll(loaderSelector(extra))) {
      if (el.closest("#__rastro_host") || !isVisible(el))
        continue;
      const r = el.getBoundingClientRect();
      if (r.width > 0 && r.height > 0)
        return el;
    }
  }
  async function settle(maxMs, extraLoader) {
    watchDom();
    const start = performance.now();
    while (true) {
      const now = performance.now();
      const netQuiet = pending === 0 && now - netChanged >= NET_QUIET;
      const domQuiet = now - domChanged >= DOM_QUIET || now - start > DOM_CAP;
      if (netQuiet && domQuiet && !visibleLoader(extraLoader))
        return;
      if (now - start > maxMs)
        return;
      await sleep(50);
    }
  }
  function isDisabled(el, visible) {
    if (el.matches(":disabled"))
      return true;
    if (el.closest('[aria-disabled="true"]'))
      return true;
    return visible && getComputedStyle(el).pointerEvents === "none";
  }
  function ancestor(el, levels) {
    let cur = el;
    for (let i = 0;i < levels && cur.parentElement; i++)
      cur = cur.parentElement;
    return cur;
  }
  function coveredBy(el, extraLoader) {
    if (el.getRootNode() !== document)
      return null;
    const r = el.getBoundingClientRect();
    const x = r.left + r.width / 2;
    const y = r.top + r.height / 2;
    if (x < 0 || y < 0 || x > innerWidth || y > innerHeight)
      return null;
    const top = document.elementFromPoint(x, y);
    if (!top || el.contains(top) || top.closest("#__rastro_host"))
      return null;
    if (el.labels && [...el.labels].some((l) => l.contains(top)))
      return null;
    if (!top.closest(loaderSelector(extraLoader)) && ancestor(el, 3).contains(top))
      return null;
    return top;
  }
  function describeEl(el) {
    const cls = [...el.classList].slice(0, 2).join(".");
    return el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (cls ? "." + cls : "");
  }
  async function untilActionable(el, timeout, checkHit, extraLoader) {
    const start = performance.now();
    let lastRect = "";
    let why = null;
    while (true) {
      const r = el.getBoundingClientRect();
      const rect = `${r.x},${r.y},${r.width},${r.height}`;
      const stable = rect === lastRect;
      lastRect = rect;
      const cover = checkHit ? coveredBy(el, extraLoader) : null;
      if (isDisabled(el, checkHit))
        why = "está deshabilitado";
      else if (cover)
        why = `está tapado por ${describeEl(cover)}`;
      else if (!stable)
        why = "se está moviendo";
      else
        return null;
      if (performance.now() - start > timeout)
        return why;
      await sleep(50);
    }
  }

  // src/content/player.ts
  class StepError extends Error {
  }
  async function find(step, timeout, requireVisible) {
    const selectors = [step.selector, ...step.fallbacks ?? []].filter(Boolean);
    if (!selectors.length)
      throw new StepError("El paso no tiene selector");
    const start = performance.now();
    let hiddenSince = 0;
    while (true) {
      const r = resolve(selectors);
      if (r) {
        if (isVisible(r.el))
          return r;
        if (!requireVisible) {
          hiddenSince ||= performance.now();
          if (performance.now() - hiddenSince > 1000)
            return r;
        }
      }
      if (performance.now() - start > timeout) {
        if (r)
          throw new StepError(`El elemento «${step.label ?? selectors[0]}» existe pero no es visible`);
        throw new StepError(`No se encontró «${step.label ?? selectors[0]}» (${selectors[0]})`);
      }
      await sleep(100);
    }
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }
  async function scrollTo(el) {
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      await sleep(50);
    }
  }
  function mouse(target, type, x, y) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + screenX,
      screenY: y + screenY,
      button: 0,
      buttons: type.endsWith("down") ? 1 : 0,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };
    const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
    return target.dispatchEvent(new Ctor(type, init));
  }
  async function realClick(el) {
    await scrollTo(el);
    const { x, y } = center(el);
    const top = document.elementFromPoint(x, y);
    const target = top && el.contains(top) ? top : el;
    mouse(target, "pointerover", x, y);
    mouse(target, "mouseover", x, y);
    mouse(target, "pointermove", x, y);
    mouse(target, "mousemove", x, y);
    const down = mouse(target, "pointerdown", x, y) && mouse(target, "mousedown", x, y);
    if (down && el instanceof HTMLElement && el.tabIndex >= -1)
      el.focus({ preventScroll: true });
    mouse(target, "pointerup", x, y);
    mouse(target, "mouseup", x, y);
    mouse(target, "click", x, y);
  }
  var NO_TYPING = new Set(["date", "datetime-local", "month", "week", "time", "color", "range"]);
  function setNative(el, v) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  }
  function fireInput(el, data, inputType = "insertText") {
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, data, inputType }));
  }
  function key(el, type, k) {
    return el.dispatchEvent(new KeyboardEvent(type, { key: k, code: codeFor(k), bubbles: true, cancelable: true, composed: true }));
  }
  function codeFor(k) {
    if (k.length === 1) {
      if (/[a-z]/i.test(k))
        return "Key" + k.toUpperCase();
      if (/\d/.test(k))
        return "Digit" + k;
      if (k === " ")
        return "Space";
      return "";
    }
    return k;
  }
  function selectAll(el) {
    try {
      el.select();
    } catch {}
  }
  async function typeInto(el, value, s) {
    await scrollTo(el);
    el.focus({ preventScroll: true });
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      if (value)
        document.execCommand("insertText", false, value);
      else
        document.execCommand("delete");
      if (textOf(el) !== value.replace(/\s+/g, " ").trim()) {
        el.textContent = value;
        fireInput(el, value);
      }
      return;
    }
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement))
      throw new StepError("El elemento no es editable");
    if (el.disabled)
      throw new StepError(`«${el.name || el.id}» está deshabilitado`);
    const typeable = !(el instanceof HTMLInputElement && NO_TYPING.has(el.type));
    if (!typeable || s.typeMode === "instant") {
      selectAll(el);
      const ok = typeable && (value ? document.execCommand("insertText", false, value) : document.execCommand("delete"));
      if (!ok || el.value !== value) {
        setNative(el, value);
        fireInput(el, value);
      }
    } else {
      selectAll(el);
      if (!document.execCommand("delete") || el.value !== "") {
        setNative(el, "");
        fireInput(el, null, "deleteContentBackward");
      }
      for (const ch of value) {
        const allowed = key(el, "keydown", ch);
        key(el, "keypress", ch);
        if (allowed) {
          const before = el.value;
          if (!document.execCommand("insertText", false, ch) || el.value === before) {
            setNative(el, before + ch);
            fireInput(el, ch);
          }
        }
        key(el, "keyup", ch);
        if (s.keyDelay)
          await sleep(s.keyDelay);
      }
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectOption(el, value, optionText) {
    if (!(el instanceof HTMLSelectElement))
      throw new StepError("El elemento no es un <select>");
    const opts = [...el.options];
    const byValue = opts.find((o) => o.value === value);
    const byText = optionText ? opts.find((o) => o.text.trim() === optionText) : undefined;
    const opt = (byValue && byText && byValue.text.trim() !== optionText ? byText : byValue) ?? byText ?? opts.find((o) => o.text.trim() === value) ?? opts.find((o) => o.text.trim().toLowerCase().includes(value.toLowerCase()));
    if (!opt)
      throw new StepError(`El select no tiene la opción «${optionText ?? value}»`);
    el.focus();
    el.value = opt.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function setChecked(el, want) {
    if (checkedOf(el) === want)
      return;
    if (el instanceof HTMLInputElement && el.type === "radio" && !want) {
      throw new StepError("Un radio no se puede desmarcar; marca otra opción del grupo");
    }
    if (isVisible(el))
      await realClick(el);
    else if (el instanceof HTMLInputElement && el.labels?.[0] && isVisible(el.labels[0]))
      await realClick(el.labels[0]);
    else
      el.click();
    if (checkedOf(el) !== want && el instanceof HTMLInputElement) {
      el.checked = want;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  var FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"]), [contenteditable]:not([contenteditable="false"])';
  async function press(el, k) {
    const down = key(el, "keydown", k);
    if (k === "Enter")
      key(el, "keypress", k);
    if (down) {
      if (k === "Enter") {
        if (el instanceof HTMLInputElement && el.form) {
          const btn = el.form.querySelector('button[type="submit"], button:not([type]), input[type="submit"], input[type="image"]');
          if (btn)
            await realClick(btn);
          else
            el.form.requestSubmit();
        } else if (el instanceof HTMLButtonElement || el instanceof HTMLAnchorElement) {
          el.click();
        }
      } else if (k === "Tab") {
        const all = [...document.querySelectorAll(FOCUSABLE)].filter((e) => isVisible(e) && !e.disabled);
        const i = all.indexOf(el);
        all[(i + 1) % all.length]?.focus();
      }
    }
    key(el, "keyup", k);
  }
  function mayNavigate(el) {
    if (el.closest("a[href]"))
      return true;
    const btn = el.closest("button, input");
    if (btn instanceof HTMLButtonElement)
      return !!btn.form && btn.type === "submit";
    if (btn instanceof HTMLInputElement)
      return !!btn.form && (["submit", "image"].includes(btn.type) || kindOf(btn) === "fill");
    return false;
  }
  async function runStep(step, s) {
    const timeout = step.timeout ?? s.timeout;
    let nav = false;
    try {
      let used;
      const acts = !["waitFor", "assertText"].includes(step.type);
      if (s.autoWait && acts)
        await settle(timeout, s.loaderSelector);
      const target = async (visible = true) => {
        const r = await find(step, timeout, visible);
        used = r.selector;
        if (s.autoWait && acts) {
          if (isVisible(r.el))
            await scrollTo(r.el);
          const why = await untilActionable(r.el, timeout, isVisible(r.el), s.loaderSelector);
          if (why)
            throw new StepError(`«${step.label ?? r.selector}» ${why}`);
        }
        if (s.highlight)
          overlay.flash(r.el, step.label ?? step.type, Math.max(400, s.stepDelay + 200), COLORS.run);
        return r.el;
      };
      switch (step.type) {
        case "click": {
          const el = await target();
          nav = mayNavigate(el);
          await realClick(el);
          break;
        }
        case "fill": {
          const el = await target(false);
          if (el instanceof HTMLSelectElement)
            selectOption(el, step.value ?? "");
          else if (kindOf(el) === "check")
            await setChecked(el, !["", "false", "off", "0"].includes(step.value ?? ""));
          else
            await typeInto(el, step.value ?? "", s);
          break;
        }
        case "select":
          selectOption(await target(false), step.value ?? "", step.optionText);
          break;
        case "check":
          await setChecked(await target(false), step.value !== "false");
          break;
        case "press": {
          const el = step.selector ? await target(false) : document.activeElement ?? document.body;
          nav = (step.value || "Enter") === "Enter" && mayNavigate(el);
          await press(el, step.value || "Enter");
          break;
        }
        case "waitFor":
          await target();
          break;
        case "assertText": {
          const el = await target(false);
          const want = (step.value ?? "").trim();
          const start = performance.now();
          let have = "";
          while (true) {
            have = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement ? valueOf(el) : textOf(el);
            if (have.includes(want))
              break;
            if (performance.now() - start > timeout)
              throw new StepError(`Se esperaba «${want}» y hay «${have.slice(0, 80)}»`);
            await sleep(150);
          }
          break;
        }
        default:
          throw new StepError(`Tipo de paso «${step.type}» no se ejecuta en la página`);
      }
      return { ok: true, usedSelector: used, mayNavigate: nav };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }
  async function highlight(selectors) {
    const r = resolve(selectors);
    if (!r)
      return false;
    await scrollTo(r.el);
    overlay.flash(r.el, r.selector, 1500, COLORS.click);
    return true;
  }

  // src/content/recorder.ts
  var mode = null;
  var send = () => {};
  var pendingFill = new Map;
  var VERB = { click: "Click", fill: "Escribir", select: "Seleccionar", check: "Marcar", file: "Fichero" };
  function capture(el) {
    const kind = kindOf(el);
    if (kind === "file")
      return null;
    const [selector, ...fallbacks] = buildSelectors(el);
    const base = { selector, fallbacks, label: describe(el) };
    switch (kind) {
      case "fill":
        return { ...base, type: "fill", value: valueOf(el), secret: el.type === "password" || undefined };
      case "select": {
        const s = el;
        return { ...base, type: "select", value: s.value, optionText: s.selectedOptions[0]?.text.trim() };
      }
      case "check":
        return { ...base, type: "check", value: String(checkedOf(el)) };
      default:
        return { ...base, type: "click" };
    }
  }
  function emit(el, step) {
    if (!step)
      return;
    send(step);
    const what = step.type === "fill" ? step.secret ? "••••" : `«${(step.value ?? "").slice(0, 30)}»` : "";
    overlay.toast(`✓ ${VERB[step.type] ?? step.type}: ${step.label} ${what}`.trim(), COLORS[kindOf(el)]);
  }
  function flushFills() {
    for (const [el, t] of pendingFill) {
      clearTimeout(t);
      send(capture(el));
    }
    pendingFill.clear();
  }
  function scheduleFill(el) {
    clearTimeout(pendingFill.get(el));
    pendingFill.set(el, setTimeout(() => {
      pendingFill.delete(el);
      const s = capture(el);
      if (s)
        send(s);
    }, 350));
  }
  var targetOf = (e) => {
    const t = e.composedPath()[0];
    return t instanceof Element ? t : null;
  };
  function onMove(e) {
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    const el = actionable(t);
    const k = kindOf(el);
    const hint = k === "file" ? "Fichero (no automatizable)" : `${VERB[k]} · ${describe(el)}`;
    overlay.show(el, hint, COLORS[k]);
  }
  function blockInPoint(e) {
    if (mode !== "point" || !e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    if (kindOf(actionable(t)) === "click") {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  function onClick(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    blockInPoint(e);
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "file")
      return overlay.toast("Los inputs de fichero no se pueden automatizar", undefined, true);
    if (k === "check" || k === "select")
      return;
    flushFills();
    if (k === "fill") {
      if (valueOf(el))
        emit(el, capture(el));
      return;
    }
    emit(el, capture(el));
  }
  function onInput(e) {
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    if (kindOf(el) === "fill")
      scheduleFill(el);
  }
  function onChange(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "fill") {
      clearTimeout(pendingFill.get(el));
      pendingFill.delete(el);
      send(capture(el));
    } else if (k === "select" || k === "check") {
      flushFills();
      emit(el, capture(el));
    }
  }
  function onKey(e) {
    if (!e.isTrusted)
      return;
    if (mode === "point" && e.key === "Escape") {
      e.preventDefault();
      stopHandler();
      return;
    }
    const t = targetOf(e);
    if (!t)
      return;
    if (e.key === "Enter" && t instanceof HTMLInputElement && kindOf(t) === "fill") {
      flushFills();
      send({ type: "press", value: "Enter", selector: buildSelectors(t)[0], label: describe(t) });
      overlay.toast(`✓ Tecla: Enter en ${describe(t)}`);
    }
  }
  function onLeave() {
    flushFills();
  }
  var onScroll = () => overlay.hide();
  var stopHandler = () => {};
  var listeners = [
    ["mousemove", onMove],
    ["pointerdown", blockInPoint],
    ["mousedown", blockInPoint],
    ["pointerup", blockInPoint],
    ["mouseup", blockInPoint],
    ["click", onClick],
    ["input", onInput],
    ["change", onChange],
    ["keydown", onKey]
  ];
  function startRecording(m, sink, onStop) {
    if (mode)
      stopRecording();
    mode = m;
    send = sink;
    stopHandler = onStop;
    overlay.onStop = onStop;
    trackVolatileClasses(true);
    for (const [ev, fn] of listeners)
      window.addEventListener(ev, fn, true);
    window.addEventListener("pagehide", onLeave);
    window.addEventListener("scroll", onScroll, true);
    if (window === window.top)
      overlay.setPill(m);
  }
  function stopRecording() {
    flushFills();
    for (const [ev, fn] of listeners)
      window.removeEventListener(ev, fn, true);
    window.removeEventListener("pagehide", onLeave);
    window.removeEventListener("scroll", onScroll, true);
    trackVolatileClasses(false);
    mode = null;
    overlay.hide();
    overlay.setPill(null);
  }
  function pickOnce() {
    return new Promise((resolve) => {
      const block = (e) => {
        if (overlay.owns(targetOf(e)))
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
      };
      const done = (r) => {
        window.removeEventListener("mousemove", onMove, true);
        for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
          window.removeEventListener(ev, block, true);
        window.removeEventListener("click", click, true);
        window.removeEventListener("keydown", key, true);
        overlay.hide();
        cancelPick = () => {};
        if (!mode)
          trackVolatileClasses(false);
        resolve(r);
      };
      const click = (e) => {
        block(e);
        const t = targetOf(e);
        if (!t || overlay.owns(t))
          return;
        done(capture(actionable(t)) ?? null);
      };
      const key = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          done(null);
        }
      };
      trackVolatileClasses(true);
      window.addEventListener("mousemove", onMove, true);
      for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
        window.addEventListener(ev, block, true);
      window.addEventListener("click", click, true);
      window.addEventListener("keydown", key, true);
      cancelPick = () => done(null);
      if (window === window.top)
        overlay.toast("Clica el elemento (Esc para cancelar)");
    });
  }
  var cancelPick = () => {};

  // src/content/index.ts
  function toBg(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => {
        return;
      });
    } catch {
      stopRecording();
      return Promise.resolve(undefined);
    }
  }
  var sink = (step) => void toBg({ kind: "record:step", step });
  var onStop = () => void toBg({ kind: "record:stop" });
  var MSG = "__rastro_frame";
  var announced = new Map;
  function frameElementFor(source) {
    if (!source)
      return;
    return [...document.querySelectorAll("iframe, frame")].find((f) => f.contentWindow === source);
  }
  function onFrameMessage(e) {
    const d = e.data;
    if (!d || typeof d !== "object" || d[MSG] == null || typeof d.token !== "string")
      return;
    if (d[MSG] === "announce") {
      const el = frameElementFor(e.source);
      if (el)
        announced.set(d.token, el);
    } else if (d[MSG] === "probe" && e.source === window.parent && window !== window.top) {
      toBg({ kind: "frame:probe", token: d.token });
    }
  }
  async function selectorsForAnnounced(token) {
    for (let i = 0;i < 20 && !announced.has(token); i++)
      await sleep(50);
    const el = announced.get(token);
    announced.delete(token);
    return el ? buildSelectors(el) : null;
  }
  async function resolveFrame(selectors, timeout) {
    const end = performance.now() + timeout;
    while (true) {
      const r = resolve(selectors);
      const win = r && r.el.contentWindow;
      if (win) {
        const token = crypto.randomUUID();
        win.postMessage({ [MSG]: "probe", token }, "*");
        return { token };
      }
      if (performance.now() > end)
        return { error: `No se encontró el iframe «${selectors[0]}»` };
      await sleep(100);
    }
  }
  if (!window.__rastro) {
    window.__rastro = true;
    window.addEventListener("message", onFrameMessage);
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
      switch (msg.kind) {
        case "ping":
          reply({ ok: true });
          return;
        case "record:on":
          startRecording(msg.mode, sink, onStop);
          reply({ ok: true });
          return;
        case "record:off":
          stopRecording();
          reply({ ok: true });
          return;
        case "run-step":
          runStep(msg.step, msg.settings).then(reply);
          return true;
        case "highlight":
          highlight([msg.selector, ...msg.fallbacks ?? []]).then((found) => reply({ ok: found }));
          return true;
        case "pick":
          pickOnce().then(async (step) => reply(step ? await toBg({ kind: "frame:locate", step }) ?? step : null));
          return true;
        case "pick:cancel":
          cancelPick();
          reply({ ok: true });
          return;
        case "frame:announce":
          window.parent.postMessage({ [MSG]: "announce", token: msg.token }, "*");
          reply({ ok: true });
          return;
        case "frame:selectors":
          selectorsForAnnounced(msg.token).then(reply);
          return true;
        case "frame:resolve":
          resolveFrame(msg.selectors, msg.timeout).then(reply);
          return true;
      }
    });
    toBg({ kind: "record:status" }).then((r) => {
      if (r?.mode)
        startRecording(r.mode, sink, onStop);
    });
  }
})();

//# debugId=CCB4208FA5C1A6FC64756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC91dGlsLnRzIiwgInNyYy9jb250ZW50L292ZXJsYXkudHMiLCAic3JjL2NvbnRlbnQvc2VsZWN0b3IudHMiLCAic3JjL2NvbnRlbnQvd2FpdC50cyIsICJzcmMvY29udGVudC9wbGF5ZXIudHMiLCAic3JjL2NvbnRlbnQvcmVjb3JkZXIudHMiLCAic3JjL2NvbnRlbnQvaW5kZXgudHMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbCiAgICAiZXhwb3J0IGNvbnN0IHVpZCA9ICgpOiBzdHJpbmcgPT4gY3J5cHRvLnJhbmRvbVVVSUQoKS5zbGljZSgwLCA4KSArIERhdGUubm93KCkudG9TdHJpbmcoMzYpLnNsaWNlKC00KTtcblxuLyoqIMK/UGFyZWNlIHVuIGlkL2NsYXNlIGF1dG9nZW5lcmFkbyAoaGFzaGVzLCBjb250YWRvcmVzLCBpZHMgZGUgUmVhY3QvRWxlbWVudCBQbHVz4oCmKT8gKi9cbmV4cG9ydCBmdW5jdGlvbiBsb29rc0dlbmVyYXRlZChzOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgcmV0dXJuIChcbiAgICBzLmxlbmd0aCA+IDQwIHx8XG4gICAgL1xcZHs0LH0vLnRlc3QocykgfHxcbiAgICAvWy1fOl1cXGQrWy1fOl1cXGQrJC8udGVzdChzKSB8fCAvLyBwcmVmaWpvLWFsZWF0b3Jpby1jb250YWRvcjogZWwtaWQtNzQ0LTE2NSwgaW5wdXQtMTItM1xuICAgIC9eW2EtZjAtOS1dezEwLH0kL2kudGVzdChzKSB8fFxuICAgIC9eOnJbMC05YS16XSs6PyQvLnRlc3QocykgfHwgLy8gUmVhY3QgdXNlSWRcbiAgICAvXihlbWJlcnxleHQtZ2VufHJlYWN0LXxtdWktfHJhZGl4LXxoZWFkbGVzc3VpLXxkb3duc2hpZnQtfHJjLXxlbC1pZC18di1cXGR8aW5wdXQtXFxkKS9pLnRlc3QocykgfHxcbiAgICAoL1tfLV1bYS16QS1aMC05XXs1LH0kLy50ZXN0KHMpICYmIC9cXGQuKlxcZC8udGVzdChzLnNsaWNlKC02KSkpIHx8IC8vIGNzcy1tb2R1bGVzOiBidG5feDNGOWFcbiAgICAvXihjc3N8c2N8anN4fGVtb3Rpb258c3ZlbHRlKS1bYS16MC05XSskL2kudGVzdChzKVxuICApO1xufVxuXG5leHBvcnQgY29uc3Qgc2xlZXAgPSAobXM6IG51bWJlcikgPT4gbmV3IFByb21pc2U8dm9pZD4oKHIpID0+IHNldFRpbWVvdXQociwgbXMpKTtcblxuLyoqIFZhcmlhYmxlcyBpbnRlZ3JhZGFzOiB7eyR0aW1lc3RhbXB9fSwge3skdXVpZH19LCB7eyRyYW5kb21FbWFpbH19LCB7eyRyYW5kb21JbnR9fSwge3skdG9kYXl9fSAqL1xuZnVuY3Rpb24gYnVpbHRpbihuYW1lOiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICBzd2l0Y2ggKG5hbWUpIHtcbiAgICBjYXNlIFwiJHRpbWVzdGFtcFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhEYXRlLm5vdygpKTtcbiAgICBjYXNlIFwiJHV1aWRcIjpcbiAgICAgIHJldHVybiBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgIGNhc2UgXCIkcmFuZG9tSW50XCI6XG4gICAgICByZXR1cm4gU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDFfMDAwXzAwMCkpO1xuICAgIGNhc2UgXCIkcmFuZG9tRW1haWxcIjpcbiAgICAgIHJldHVybiBgdGVzdCske0RhdGUubm93KCkudG9TdHJpbmcoMzYpfSR7TWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogMTAwMCl9QGV4YW1wbGUuY29tYDtcbiAgICBjYXNlIFwiJHRvZGF5XCI6XG4gICAgICByZXR1cm4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vKiogU3VzdGl0dXllIHt7dmFyaWFibGV9fSBwb3Igc3UgdmFsb3IuIExhcyBkZXNjb25vY2lkYXMgc2UgZGVqYW4gdGFsIGN1YWwuICovXG5leHBvcnQgZnVuY3Rpb24gaW50ZXJwb2xhdGUodGV4dDogc3RyaW5nLCB2YXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogc3RyaW5nIHtcbiAgcmV0dXJuIHRleHQucmVwbGFjZSgvXFx7XFx7XFxzKihbJFxcdy4tXSspXFxzKlxcfVxcfS9nLCAobSwgbmFtZTogc3RyaW5nKSA9PiB2YXJzW25hbWVdID8/IGJ1aWx0aW4obmFtZSkgPz8gbSk7XG59XG5cbmV4cG9ydCBjb25zdCBCVUlMVElOX1ZBUlMgPSBbXCIkdGltZXN0YW1wXCIsIFwiJHV1aWRcIiwgXCIkcmFuZG9tRW1haWxcIiwgXCIkcmFuZG9tSW50XCIsIFwiJHRvZGF5XCJdO1xuIiwKICAgICIvLyBDYXBhIHZpc3VhbCBkZW50cm8gZGUgbGEgcMOhZ2luYSwgYWlzbGFkYSBlbiB1biBzaGFkb3cgcm9vdCBwYXJhIG5vIGhlcmVkYXIgbmkgcm9tcGVyIGVzdGlsb3MuXG5cbmNvbnN0IENTUyA9IGBcbjpob3N0IHsgYWxsOiBpbml0aWFsOyB9XG4uYm94IHtcbiAgcG9zaXRpb246IGZpeGVkOyBwb2ludGVyLWV2ZW50czogbm9uZTsgei1pbmRleDogMjE0NzQ4MzY0NjsgZGlzcGxheTogbm9uZTtcbiAgYm9yZGVyOiAycHggc29saWQgdmFyKC0tYywgIzdjNWNmZik7IGJhY2tncm91bmQ6IGNvbG9yLW1peChpbiBzcmdiLCB2YXIoLS1jLCAjN2M1Y2ZmKSAxMiUsIHRyYW5zcGFyZW50KTtcbiAgYm9yZGVyLXJhZGl1czogNHB4OyB0cmFuc2l0aW9uOiBhbGwgNjBtcyBlYXNlLW91dDsgYm94LXNpemluZzogYm9yZGVyLWJveDtcbn1cbi50YWcge1xuICBwb3NpdGlvbjogZml4ZWQ7IHBvaW50ZXItZXZlbnRzOiBub25lOyB6LWluZGV4OiAyMTQ3NDgzNjQ3OyBkaXNwbGF5OiBub25lO1xuICBmb250OiA2MDAgMTFweC8xLjIgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2ZmZjsgYmFja2dyb3VuZDogdmFyKC0tYywgIzdjNWNmZik7XG4gIHBhZGRpbmc6IDRweCA3cHg7IGJvcmRlci1yYWRpdXM6IDVweDsgd2hpdGUtc3BhY2U6IG5vd3JhcDsgbWF4LXdpZHRoOiAzNjBweDsgb3ZlcmZsb3c6IGhpZGRlbjsgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XG4gIGJveC1zaGFkb3c6IDAgMnB4IDhweCByZ2IoMCAwIDAgLyAuMjUpO1xufVxuLnBpbGwge1xuICBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDIxNDc0ODM2NDc7IGxlZnQ6IDUwJTsgYm90dG9tOiAxOHB4OyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XG4gIGRpc3BsYXk6IG5vbmU7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogMTBweDsgcGFkZGluZzogN3B4IDhweCA3cHggMTRweDsgYm9yZGVyLXJhZGl1czogOTk5cHg7XG4gIGZvbnQ6IDYwMCAxMnB4LzEgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2Y0ZjJmZjsgYmFja2dyb3VuZDogIzFiMTgzMGVlO1xuICBib3gtc2hhZG93OiAwIDZweCAyNHB4IHJnYigwIDAgMCAvIC4zNSk7IGJhY2tkcm9wLWZpbHRlcjogYmx1cig2cHgpOyB1c2VyLXNlbGVjdDogbm9uZTtcbn1cbi5kb3QgeyB3aWR0aDogOXB4OyBoZWlnaHQ6IDlweDsgYm9yZGVyLXJhZGl1czogNTAlOyBiYWNrZ3JvdW5kOiAjZmY0ZDZkOyBhbmltYXRpb246IHB1bHNlIDEuMnMgaW5maW5pdGU7IH1cbi5waWxsLnBvaW50IC5kb3QgeyBiYWNrZ3JvdW5kOiAjN2M1Y2ZmOyB9XG5Aa2V5ZnJhbWVzIHB1bHNlIHsgNTAlIHsgb3BhY2l0eTogLjM1OyB9IH1cbi5waWxsIGJ1dHRvbiB7XG4gIGFsbDogdW5zZXQ7IGN1cnNvcjogcG9pbnRlcjsgcGFkZGluZzogNXB4IDEwcHg7IGJvcmRlci1yYWRpdXM6IDk5OXB4OyBiYWNrZ3JvdW5kOiAjZmZmZmZmMWY7IGNvbG9yOiAjZmZmO1xuICBmb250OiA2MDAgMTFweC8xIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjtcbn1cbi5waWxsIGJ1dHRvbjpob3ZlciB7IGJhY2tncm91bmQ6ICNmZmZmZmYzODsgfVxuLnRvYXN0cyB7IHBvc2l0aW9uOiBmaXhlZDsgei1pbmRleDogMjE0NzQ4MzY0NzsgcmlnaHQ6IDE2cHg7IGJvdHRvbTogNjRweDsgZGlzcGxheTogZmxleDsgZmxleC1kaXJlY3Rpb246IGNvbHVtbjsgZ2FwOiA2cHg7IGFsaWduLWl0ZW1zOiBmbGV4LWVuZDsgcG9pbnRlci1ldmVudHM6IG5vbmU7IH1cbi50b2FzdCB7XG4gIGZvbnQ6IDUwMCAxMnB4LzEuMyB1aS1zYW5zLXNlcmlmLCBzeXN0ZW0tdWksIHNhbnMtc2VyaWY7IGNvbG9yOiAjZmZmOyBiYWNrZ3JvdW5kOiAjMWIxODMwZWU7IHBhZGRpbmc6IDdweCAxMXB4O1xuICBib3JkZXItcmFkaXVzOiA4cHg7IGJvcmRlci1sZWZ0OiAzcHggc29saWQgdmFyKC0tYywgIzdjNWNmZik7IGJveC1zaGFkb3c6IDAgNHB4IDE0cHggcmdiKDAgMCAwIC8gLjMpO1xuICBhbmltYXRpb246IGluIC4xOHMgZWFzZS1vdXQ7IG1heC13aWR0aDogMzQwcHg7XG59XG4udG9hc3Qud2FybiB7IC0tYzogI2ZmYjAyMDsgfVxuQGtleWZyYW1lcyBpbiB7IGZyb20geyBvcGFjaXR5OiAwOyB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNnB4KTsgfSB9XG5gO1xuXG5leHBvcnQgY29uc3QgQ09MT1JTID0geyBjbGljazogXCIjN2M1Y2ZmXCIsIGZpbGw6IFwiIzE0YjhhNlwiLCBzZWxlY3Q6IFwiIzBlYTVlOVwiLCBjaGVjazogXCIjMjJjNTVlXCIsIGZpbGU6IFwiI2ZmYjAyMFwiLCBydW46IFwiI2Y5NzMxNlwiIH0gYXMgY29uc3Q7XG5cbmNsYXNzIE92ZXJsYXkge1xuICBob3N0ITogSFRNTEVsZW1lbnQ7XG4gIHByaXZhdGUgYm94ITogSFRNTERpdkVsZW1lbnQ7XG4gIHByaXZhdGUgdGFnITogSFRNTERpdkVsZW1lbnQ7XG4gIHByaXZhdGUgcGlsbCE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHBpbGxUZXh0ITogSFRNTFNwYW5FbGVtZW50O1xuICBwcml2YXRlIHRvYXN0cyE6IEhUTUxEaXZFbGVtZW50O1xuICBvblN0b3A6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuICBwcml2YXRlIGVuc3VyZSgpIHtcbiAgICBpZiAodGhpcy5ob3N0Py5pc0Nvbm5lY3RlZCkgcmV0dXJuO1xuICAgIHRoaXMuaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgdGhpcy5ob3N0LmlkID0gXCJfX3Jhc3Ryb19ob3N0XCI7XG4gICAgY29uc3Qgcm9vdCA9IHRoaXMuaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiBcIm9wZW5cIiB9KTtcbiAgICByb290LmlubmVySFRNTCA9IGA8c3R5bGU+JHtDU1N9PC9zdHlsZT48ZGl2IGNsYXNzPVwiYm94XCI+PC9kaXY+PGRpdiBjbGFzcz1cInRhZ1wiPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInBpbGxcIj48c3BhbiBjbGFzcz1cImRvdFwiPjwvc3Bhbj48c3BhbiBjbGFzcz1cInR4dFwiPjwvc3Bhbj48YnV0dG9uIHR5cGU9XCJidXR0b25cIj5UZXJtaW5hcjwvYnV0dG9uPjwvZGl2PlxuICAgICAgPGRpdiBjbGFzcz1cInRvYXN0c1wiPjwvZGl2PmA7XG4gICAgdGhpcy5ib3ggPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIuYm94XCIpITtcbiAgICB0aGlzLnRhZyA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi50YWdcIikhO1xuICAgIHRoaXMucGlsbCA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi5waWxsXCIpITtcbiAgICB0aGlzLnBpbGxUZXh0ID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLnR4dFwiKSE7XG4gICAgdGhpcy50b2FzdHMgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIudG9hc3RzXCIpITtcbiAgICByb290LnF1ZXJ5U2VsZWN0b3IoXCJidXR0b25cIikhLmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCAoZSkgPT4ge1xuICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgIHRoaXMub25TdG9wKCk7XG4gICAgfSk7XG4gICAgZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFwcGVuZENoaWxkKHRoaXMuaG9zdCk7XG4gIH1cblxuICBvd25zKGVsOiBFdmVudFRhcmdldCB8IG51bGwpOiBib29sZWFuIHtcbiAgICByZXR1cm4gISF0aGlzLmhvc3QgJiYgZWwgaW5zdGFuY2VvZiBOb2RlICYmIChlbCA9PT0gdGhpcy5ob3N0IHx8IHRoaXMuaG9zdC5jb250YWlucyhlbCkpO1xuICB9XG5cbiAgc2hvdyhlbDogRWxlbWVudCwgdGV4dDogc3RyaW5nLCBjb2xvcjogc3RyaW5nID0gQ09MT1JTLmNsaWNrKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgT2JqZWN0LmFzc2lnbih0aGlzLmJveC5zdHlsZSwge1xuICAgICAgZGlzcGxheTogXCJibG9ja1wiLCBsZWZ0OiBgJHtyLmxlZnQgLSAzfXB4YCwgdG9wOiBgJHtyLnRvcCAtIDN9cHhgLCB3aWR0aDogYCR7ci53aWR0aCArIDZ9cHhgLCBoZWlnaHQ6IGAke3IuaGVpZ2h0ICsgNn1weGAsXG4gICAgfSk7XG4gICAgdGhpcy5ib3guc3R5bGUuc2V0UHJvcGVydHkoXCItLWNcIiwgY29sb3IpO1xuICAgIHRoaXMudGFnLnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0aGlzLnRhZy50ZXh0Q29udGVudCA9IHRleHQ7XG4gICAgdGhpcy50YWcuc3R5bGUuZGlzcGxheSA9IFwiYmxvY2tcIjtcbiAgICBjb25zdCBhYm92ZSA9IHIudG9wID4gMzA7XG4gICAgdGhpcy50YWcuc3R5bGUubGVmdCA9IGAke01hdGgubWF4KDQsIE1hdGgubWluKHIubGVmdCAtIDMsIGlubmVyV2lkdGggLSAzNzApKX1weGA7XG4gICAgdGhpcy50YWcuc3R5bGUudG9wID0gYWJvdmUgPyBgJHtyLnRvcCAtIDI3fXB4YCA6IGAke3IuYm90dG9tICsgNn1weGA7XG4gIH1cblxuICBoaWRlKCkge1xuICAgIGlmICghdGhpcy5ib3gpIHJldHVybjtcbiAgICB0aGlzLmJveC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgdGhpcy50YWcuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICB9XG5cbiAgLyoqIFJlc2FsdGEgYnJldmVtZW50ZSAocmVwcm9kdWNjacOzbiAvIFwidmVyIGVsZW1lbnRvXCIpLiAqL1xuICBmbGFzaChlbDogRWxlbWVudCwgdGV4dDogc3RyaW5nLCBtcyA9IDcwMCwgY29sb3I6IHN0cmluZyA9IENPTE9SUy5ydW4pIHtcbiAgICB0aGlzLnNob3coZWwsIHRleHQsIGNvbG9yKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHRoaXMuaGlkZSgpLCBtcyk7XG4gIH1cblxuICBzZXRQaWxsKG1vZGU6IFwicmVjb3JkXCIgfCBcInBvaW50XCIgfCBudWxsKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBpZiAoIW1vZGUpIHtcbiAgICAgIHRoaXMucGlsbC5zdHlsZS5kaXNwbGF5ID0gXCJub25lXCI7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMucGlsbC5jbGFzc05hbWUgPSBcInBpbGwgXCIgKyBtb2RlO1xuICAgIHRoaXMucGlsbFRleHQudGV4dENvbnRlbnQgPSBtb2RlID09PSBcInJlY29yZFwiID8gXCJSYXN0cm8gZ3JhYmFuZG9cIiA6IFwiUmFzdHJvIMK3IG1vZG8gc2XDsWFsYXIgKEVzYyBwYXJhIHNhbGlyKVwiO1xuICAgIHRoaXMucGlsbC5zdHlsZS5kaXNwbGF5ID0gXCJmbGV4XCI7XG4gIH1cblxuICB0b2FzdCh0ZXh0OiBzdHJpbmcsIGNvbG9yPzogc3RyaW5nLCB3YXJuID0gZmFsc2UpIHtcbiAgICB0aGlzLmVuc3VyZSgpO1xuICAgIGNvbnN0IHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHQuY2xhc3NOYW1lID0gXCJ0b2FzdFwiICsgKHdhcm4gPyBcIiB3YXJuXCIgOiBcIlwiKTtcbiAgICBpZiAoY29sb3IpIHQuc3R5bGUuc2V0UHJvcGVydHkoXCItLWNcIiwgY29sb3IpO1xuICAgIHQudGV4dENvbnRlbnQgPSB0ZXh0O1xuICAgIHRoaXMudG9hc3RzLmFwcGVuZENoaWxkKHQpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gdC5yZW1vdmUoKSwgMjIwMCk7XG4gICAgd2hpbGUgKHRoaXMudG9hc3RzLmNoaWxkcmVuLmxlbmd0aCA+IDQpIHRoaXMudG9hc3RzLmZpcnN0RWxlbWVudENoaWxkIS5yZW1vdmUoKTtcbiAgfVxufVxuXG5leHBvcnQgY29uc3Qgb3ZlcmxheSA9IG5ldyBPdmVybGF5KCk7XG4iLAogICAgIi8vIE1vdG9yIGRlIHNlbGVjdG9yZXMgcHJvcGlvLlxuLy9cbi8vIFNpbnRheGlzIHNvcG9ydGFkYTpcbi8vICAgY3NzICAgICAgICAgICAg4oaSIGN1YWxxdWllciBzZWxlY3RvciBDU1MgKHBvciBkZWZlY3RvKVxuLy8gICBmcmFtZT0yICAgICAgICDihpIgZWwgdGVyY2VyIDxpZnJhbWU+IGRlbCBkb2N1bWVudG8gKHBhcmEgcnV0YXMgZGUgZnJhbWVzIGltcG9ydGFkYXMpXG4vLyAgIHRleHQ9RW52aWFyICAgIOKGkiBlbGVtZW50byBjdXlvIHRleHRvIHZpc2libGUgZXMgZXhhY3RhbWVudGUgwqtFbnZpYXLCuyAobywgc2kgbm8gaGF5LCBxdWUgbG8gY29udGllbmUpXG4vLyAgIGxhYmVsPUVtYWlsICAgIOKGkiBjb250cm9sIGRlIGZvcm11bGFyaW8gYXNvY2lhZG8gYSBsYSBldGlxdWV0YS9hcmlhLWxhYmVsIMKrRW1haWzCu1xuLy8gICB4cGF0aD0vL2RpdlsxXSDihpIgWFBhdGhcbi8vICAgQSA+PiBCICAgICAgICAg4oaSIGJ1c2NhIEIgc29sbyBkZW50cm8gZGUgbG8gcXVlIGVuY3VlbnRyZSBBIChwLiBlai4gYC5lbC1zZWxlY3QtZHJvcGRvd24gPj4gdGV4dD1Fc3Bhw7FhYClcbi8vXG4vLyBBbCBnZW5lcmFyLCBzZSBwcm9kdWNlbiB2YXJpb3MgY2FuZGlkYXRvcyBvcmRlbmFkb3MgcG9yIHJvYnVzdGV6LiBFbCByZXByb2R1Y3RvclxuLy8gcHJ1ZWJhIGVsIHByaW5jaXBhbCB5LCBzaSBmYWxsYSwgbG9zIGFsdGVybmF0aXZvcy5cblxuaW1wb3J0IHsgbG9va3NHZW5lcmF0ZWQgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcblxuY29uc3QgVEVTVF9BVFRSUyA9IFtcImRhdGEtdGVzdGlkXCIsIFwiZGF0YS10ZXN0LWlkXCIsIFwiZGF0YS10ZXN0XCIsIFwiZGF0YS1jeVwiLCBcImRhdGEtcWFcIiwgXCJkYXRhLWUyZVwiLCBcImRhdGEtYXV0b21hdGlvbi1pZFwiXTtcblxuY29uc3QgQ0xJQ0tBQkxFID1cbiAgJ2J1dHRvbiwgYVtocmVmXSwgW3JvbGU9XCJidXR0b25cIl0sIFtyb2xlPVwibGlua1wiXSwgW3JvbGU9XCJtZW51aXRlbVwiXSwgW3JvbGU9XCJ0YWJcIl0sIFtyb2xlPVwib3B0aW9uXCJdLCAnICtcbiAgJ1tyb2xlPVwiY2hlY2tib3hcIl0sIFtyb2xlPVwicmFkaW9cIl0sIFtyb2xlPVwic3dpdGNoXCJdLCBpbnB1dFt0eXBlPVwic3VibWl0XCJdLCBpbnB1dFt0eXBlPVwiYnV0dG9uXCJdLCAnICtcbiAgJ2lucHV0W3R5cGU9XCJyZXNldFwiXSwgaW5wdXRbdHlwZT1cImltYWdlXCJdLCBzdW1tYXJ5LCBsYWJlbCwgW29uY2xpY2tdJztcblxuZXhwb3J0IGNvbnN0IENPTlRST0wgPSAnaW5wdXQsIHRleHRhcmVhLCBzZWxlY3QsIFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pJztcblxuY29uc3Qgbm9ybSA9IChzOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKSA9PiAocyA/PyBcIlwiKS5yZXBsYWNlKC9cXHMrL2csIFwiIFwiKS50cmltKCk7XG5cbmNvbnN0IFNUQVRFX0NMQVNTRVMgPSAvXihpcy18aGFzLSk/KGFjdGl2ZXxmb2N1cyhlZCk/fGhvdmVyKGVkKT98c2VsZWN0ZWR8b3BlbihlZCk/fGRpc2FibGVkfGNoZWNrZWR8dmlzaWJsZXxoaWRkZW58c2hvd3xpbnxuZy0uKikkL2k7XG5cbi8vIMOabHRpbWEgcGFsYWJyYSBkZSB1bmEgY2xhc2UgQkVNL3V0aWxpdGFyaWEgcXVlIGluZGljYSBlc3RhZG86IGlzLWhvdmVyaW5nLCBhbnQtc2VsZWN0LWl0ZW0tb3B0aW9uLWFjdGl2ZSxcbi8vIHYtbGlzdC1pdGVtLS1oaWdobGlnaHRlZCwgTXVpLWZvY3VzVmlzaWJsZSwgcm91dGVyLWxpbmstZXhhY3QtYWN0aXZl4oCmXG5jb25zdCBTVEFURV9XT1JEUyA9IG5ldyBTZXQoW1xuICBcImFjdGl2ZVwiLCBcImZvY3VzXCIsIFwiZm9jdXNlZFwiLCBcImZvY3VzdmlzaWJsZVwiLCBcImZvY3Vzd2l0aGluXCIsIFwiaG92ZXJcIiwgXCJob3ZlcmVkXCIsIFwiaG92ZXJpbmdcIiwgXCJoaWdobGlnaHRcIiwgXCJoaWdobGlnaHRlZFwiLFxuICBcInNlbGVjdGVkXCIsIFwiY3VycmVudFwiLCBcIm9wZW5cIiwgXCJvcGVuZWRcIiwgXCJleHBhbmRlZFwiLCBcImNvbGxhcHNlZFwiLCBcInByZXNzZWRcIiwgXCJkaXNhYmxlZFwiLCBcImNoZWNrZWRcIiwgXCJ2aXNpYmxlXCIsIFwiaGlkZGVuXCIsXG4gIFwic2hvd25cIiwgXCJlbnRlclwiLCBcImVudGVyaW5nXCIsIFwibGVhdmVcIiwgXCJsZWF2aW5nXCIsIFwidG91Y2hlZFwiLCBcImRpcnR5XCIsIFwicHJpc3RpbmVcIiwgXCJ2YWxpZFwiLCBcImludmFsaWRcIiwgXCJlcnJvclwiLFxuXSk7XG5cbmZ1bmN0aW9uIGlzU3RhdGVDbGFzcyhjOiBzdHJpbmcpOiBib29sZWFuIHtcbiAgaWYgKFNUQVRFX0NMQVNTRVMudGVzdChjKSkgcmV0dXJuIHRydWU7XG4gIGNvbnN0IHdvcmRzID0gYy5zcGxpdCgvWy1fXSt8KD88PVthLXpdKSg/PVtBLVpdKS8pLmZpbHRlcihCb29sZWFuKTtcbiAgcmV0dXJuIHdvcmRzLmxlbmd0aCA+IDEgJiYgU1RBVEVfV09SRFMuaGFzKHdvcmRzLmF0KC0xKSEudG9Mb3dlckNhc2UoKSk7XG59XG5cbi8vIENsYXNlcyBxdWUgc2UgaGFuIHZpc3RvIGFwYXJlY2VyL2Rlc2FwYXJlY2VyIGR1cmFudGUgbGEgZ3JhYmFjacOzbiAoaG92ZXIsIGZvY3VzLCBhYmllcnRv4oCmKTpcbi8vIGRlcGVuZGVuIGRlbCBlc3RhZG8gZGVsIHJhdMOzbiBvIGRlIGxhIFVJLCBhc8OtIHF1ZSBubyBzaXJ2ZW4gcGFyYSByZWVuY29udHJhciBlbCBlbGVtZW50by5cbmNvbnN0IHZvbGF0aWxlID0gbmV3IFNldDxzdHJpbmc+KCk7XG5sZXQgY2xhc3NPYnNlcnZlcjogTXV0YXRpb25PYnNlcnZlciB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiBub3RlQ2xhc3NDaGFuZ2VzKHJlY29yZHM6IE11dGF0aW9uUmVjb3JkW10pIHtcbiAgZm9yIChjb25zdCByIG9mIHJlY29yZHMpIHtcbiAgICBjb25zdCBiZWZvcmUgPSBuZXcgU2V0KChyLm9sZFZhbHVlID8/IFwiXCIpLnNwbGl0KC9cXHMrLykuZmlsdGVyKEJvb2xlYW4pKTtcbiAgICBjb25zdCBhZnRlciA9IChyLnRhcmdldCBhcyBFbGVtZW50KS5jbGFzc0xpc3Q7XG4gICAgZm9yIChjb25zdCBjIG9mIGFmdGVyKSBpZiAoIWJlZm9yZS5oYXMoYykpIHZvbGF0aWxlLmFkZChjKTtcbiAgICBmb3IgKGNvbnN0IGMgb2YgYmVmb3JlKSBpZiAoIWFmdGVyLmNvbnRhaW5zKGMpKSB2b2xhdGlsZS5hZGQoYyk7XG4gIH1cbn1cblxuLyoqIEVtcGllemEvcGFyYSBkZSBhbm90YXIgY2xhc2VzIHF1ZSBjYW1iaWFuLiBTZSBhY3RpdmEgbWllbnRyYXMgc2UgZ3JhYmEgbyBzZSBzZcOxYWxhLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRyYWNrVm9sYXRpbGVDbGFzc2VzKG9uOiBib29sZWFuKSB7XG4gIGlmIChvbiAmJiAhY2xhc3NPYnNlcnZlcikge1xuICAgIGNsYXNzT2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihub3RlQ2xhc3NDaGFuZ2VzKTtcbiAgICBjbGFzc09ic2VydmVyLm9ic2VydmUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LCB7IHN1YnRyZWU6IHRydWUsIGF0dHJpYnV0ZXM6IHRydWUsIGF0dHJpYnV0ZUZpbHRlcjogW1wiY2xhc3NcIl0sIGF0dHJpYnV0ZU9sZFZhbHVlOiB0cnVlIH0pO1xuICB9IGVsc2UgaWYgKCFvbiAmJiBjbGFzc09ic2VydmVyKSB7XG4gICAgbm90ZUNsYXNzQ2hhbmdlcyhjbGFzc09ic2VydmVyLnRha2VSZWNvcmRzKCkpO1xuICAgIGNsYXNzT2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgIGNsYXNzT2JzZXJ2ZXIgPSBudWxsO1xuICB9XG59XG5cbmZ1bmN0aW9uIHN0YWJsZUNsYXNzZXMoZWw6IEVsZW1lbnQpOiBzdHJpbmdbXSB7XG4gIC8vIFByb2Nlc2FyIG11dGFjaW9uZXMgcGVuZGllbnRlczogbGEgY2xhc2UgZGUgaG92ZXIgcHVlZGUgaGFiZXJzZSBhw7FhZGlkbyBqdXN0byBhbnRlcyBkZWwgY2xpY2suXG4gIGlmIChjbGFzc09ic2VydmVyKSBub3RlQ2xhc3NDaGFuZ2VzKGNsYXNzT2JzZXJ2ZXIudGFrZVJlY29yZHMoKSk7XG4gIHJldHVybiBbLi4uZWwuY2xhc3NMaXN0XS5maWx0ZXIoXG4gICAgKGMpID0+ICFsb29rc0dlbmVyYXRlZChjKSAmJiAhaXNTdGF0ZUNsYXNzKGMpICYmICF2b2xhdGlsZS5oYXMoYykgJiYgIWMuaW5jbHVkZXMoXCI6XCIpICYmIGMubGVuZ3RoIDwgMzIsXG4gICk7XG59XG5cbmNvbnN0IHEgPSAodjogc3RyaW5nKSA9PiBKU09OLnN0cmluZ2lmeSh2KTsgLy8gY29taWxsYXMgKyBlc2NhcGVzIHbDoWxpZG9zIGVuIENTU1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUmVzb2x1Y2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKCFlbC5pc0Nvbm5lY3RlZCkgcmV0dXJuIGZhbHNlO1xuICBpZiAoZWwuZ2V0Q2xpZW50UmVjdHMoKS5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3QgPSBnZXRDb21wdXRlZFN0eWxlKGVsKTtcbiAgcmV0dXJuIHN0LnZpc2liaWxpdHkgIT09IFwiaGlkZGVuXCIgJiYgc3Qub3BhY2l0eSAhPT0gXCIwXCI7XG59XG5cbi8qKiBUZXh0byDCq3Zpc2libGXCuyBkZSB1biBlbGVtZW50bywgY29tbyBsbyB2ZXLDrWEgZWwgdXN1YXJpby4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXh0T2YoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIFtcInN1Ym1pdFwiLCBcImJ1dHRvblwiLCBcInJlc2V0XCJdLmluY2x1ZGVzKGVsLnR5cGUpKSByZXR1cm4gbm9ybShlbC52YWx1ZSk7XG4gIHJldHVybiBub3JtKChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0ID8/IGVsLnRleHRDb250ZW50KTtcbn1cblxuZnVuY3Rpb24qIGFsbEVsZW1lbnRzKHJvb3Q6IERvY3VtZW50IHwgU2hhZG93Um9vdCB8IEVsZW1lbnQgPSBkb2N1bWVudCk6IEdlbmVyYXRvcjxFbGVtZW50PiB7XG4gIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIocm9vdCwgTm9kZUZpbHRlci5TSE9XX0VMRU1FTlQpO1xuICBsZXQgbiA9IHdhbGtlci5uZXh0Tm9kZSgpO1xuICB3aGlsZSAobikge1xuICAgIHlpZWxkIG4gYXMgRWxlbWVudDtcbiAgICBjb25zdCBzciA9IChuIGFzIEVsZW1lbnQpLnNoYWRvd1Jvb3Q7XG4gICAgaWYgKHNyKSB5aWVsZCogYWxsRWxlbWVudHMoc3IpO1xuICAgIG4gPSB3YWxrZXIubmV4dE5vZGUoKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBieVRleHQodGV4dDogc3RyaW5nLCByb290OiBEb2N1bWVudCB8IEVsZW1lbnQgPSBkb2N1bWVudCk6IEVsZW1lbnRbXSB7XG4gIGNvbnN0IHRhcmdldCA9IG5vcm0odGV4dCk7XG4gIGNvbnN0IGV4YWN0OiBFbGVtZW50W10gPSBbXTtcbiAgY29uc3QgcGFydGlhbDogRWxlbWVudFtdID0gW107XG4gIGNvbnN0IGxvd2VyID0gdGFyZ2V0LnRvTG93ZXJDYXNlKCk7XG4gIGZvciAoY29uc3QgZWwgb2YgYWxsRWxlbWVudHMocm9vdCkpIHtcbiAgICBpZiAoZWwuY2xvc2VzdChcInNjcmlwdCwgc3R5bGUsIG5vc2NyaXB0LCB0ZW1wbGF0ZSwgI19fcmFzdHJvX2hvc3RcIikpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxpbWl0ID0gdGFyZ2V0Lmxlbmd0aCAqIDMgKyAyMDtcbiAgICAvLyB0ZXh0Q29udGVudCBlcyBiYXJhdG87IGlubmVyVGV4dCBmdWVyemEgbGF5b3V0LCBhc8OtIHF1ZSBzb2xvIHBhcmEgY2FuZGlkYXRvcyBjb3J0b3MuXG4gICAgaWYgKCEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSAmJiBub3JtKGVsLnRleHRDb250ZW50KS5sZW5ndGggPiBsaW1pdCkgY29udGludWU7XG4gICAgY29uc3QgdCA9IHRleHRPZihlbCk7XG4gICAgaWYgKCF0IHx8IHQubGVuZ3RoID4gbGltaXQpIGNvbnRpbnVlO1xuICAgIGlmICh0ID09PSB0YXJnZXQpIGV4YWN0LnB1c2goZWwpO1xuICAgIGVsc2UgaWYgKHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlcikpIHBhcnRpYWwucHVzaChlbCk7XG4gIH1cbiAgY29uc3QgcGljayA9IGV4YWN0Lmxlbmd0aCA/IGV4YWN0IDogcGFydGlhbDtcbiAgLy8gUXVlZGFyc2UgY29uIGVsIG3DoXMgcHJvZnVuZG8geSBzdWJpciBhIHN1IGFuY2VzdHJvIGNsaWNhYmxlIHNpIGxvIGhheS5cbiAgY29uc3QgZGVlcGVzdCA9IHBpY2suZmlsdGVyKChlbCkgPT4gIXBpY2suc29tZSgobykgPT4gbyAhPT0gZWwgJiYgZWwuY29udGFpbnMobykpKTtcbiAgcmV0dXJuIGRlZHVwZShkZWVwZXN0Lm1hcCgoZWwpID0+IGVsLmNsb3Nlc3QoQ0xJQ0tBQkxFKSA/PyBlbCkpO1xufVxuXG5mdW5jdGlvbiBieUxhYmVsKHRleHQ6IHN0cmluZyk6IEVsZW1lbnRbXSB7XG4gIGNvbnN0IHRhcmdldCA9IG5vcm0odGV4dCkudG9Mb3dlckNhc2UoKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChjb25zdCBsYWJlbCBvZiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxcIikpIHtcbiAgICBpZiAobm9ybShsYWJlbC5pbm5lclRleHQpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKlxcKiQvLCBcIlwiKSA9PT0gdGFyZ2V0ICYmIGxhYmVsLmNvbnRyb2wpIG91dC5wdXNoKGxhYmVsLmNvbnRyb2wpO1xuICB9XG4gIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChDT05UUk9MICsgXCIsIFthcmlhLWxhYmVsXSwgW2FyaWEtbGFiZWxsZWRieV1cIikpIHtcbiAgICBpZiAobm9ybShlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICBjb25zdCBsYiA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxsZWRieVwiKTtcbiAgICBpZiAobGIpIHtcbiAgICAgIGNvbnN0IHQgPSBsYlxuICAgICAgICAuc3BsaXQoL1xccysvKVxuICAgICAgICAubWFwKChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpPy5pbm5lclRleHQgPz8gXCJcIilcbiAgICAgICAgLmpvaW4oXCIgXCIpO1xuICAgICAgaWYgKG5vcm0odCkudG9Mb3dlckNhc2UoKSA9PT0gdGFyZ2V0KSBvdXQucHVzaChlbCk7XG4gICAgfVxuICB9XG4gIGlmICghb3V0Lmxlbmd0aCkge1xuICAgIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIltwbGFjZWhvbGRlcl1cIikpIHtcbiAgICAgIGlmIChub3JtKGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRlZHVwZShvdXQpO1xufVxuXG5mdW5jdGlvbiBieVhQYXRoKHhwOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCByZXMgPSBkb2N1bWVudC5ldmFsdWF0ZSh4cCwgZG9jdW1lbnQsIG51bGwsIFhQYXRoUmVzdWx0Lk9SREVSRURfTk9ERV9TTkFQU0hPVF9UWVBFLCBudWxsKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXMuc25hcHNob3RMZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG4gPSByZXMuc25hcHNob3RJdGVtKGkpO1xuICAgIGlmIChuIGluc3RhbmNlb2YgRWxlbWVudCkgb3V0LnB1c2gobik7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZGVkdXBlPFQ+KGFycjogVFtdKTogVFtdIHtcbiAgcmV0dXJuIFsuLi5uZXcgU2V0KGFycildO1xufVxuXG5jb25zdCBDSEFJTiA9IFwiID4+IFwiO1xuXG4vKiogwr9FbCDDumx0aW1vIGVzbGFiw7NuIGRlbCBzZWxlY3RvciBlcyB1biB0ZXh0PT8gKi9cbmNvbnN0IGVuZHNJblRleHQgPSAoc2VsOiBzdHJpbmcpID0+IHNlbC5zdGFydHNXaXRoKFwidGV4dD1cIikgfHwgc2VsLmluY2x1ZGVzKENIQUlOICsgXCJ0ZXh0PVwiKTtcblxuLyoqIERldnVlbHZlIHRvZG9zIGxvcyBlbGVtZW50b3MgcXVlIGNhc2FuIGNvbiB1biBzZWxlY3RvciBkZSBSYXN0cm8gKGRlbnRybyBkZSBgcm9vdGAsIHNpIHNlIGRhKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQWxsKHNlbGVjdG9yOiBzdHJpbmcsIHJvb3Q6IERvY3VtZW50IHwgRWxlbWVudCA9IGRvY3VtZW50KTogRWxlbWVudFtdIHtcbiAgdHJ5IHtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcInRleHQ9XCIpKSByZXR1cm4gYnlUZXh0KHVucXVvdGUoc2VsZWN0b3Iuc2xpY2UoNSkpLCByb290KTtcbiAgICAvLyBFbmNhZGVuYWRvOiDCq0EgPj4gQsK7LiBMbyBxdWUgdmEgdHJhcyB0ZXh0PSBlcyB0ZXh0byBsaXRlcmFsLCBhc8OtIHF1ZSBzb2xvIHNlIHBhcnRlIGFudGVzLlxuICAgIGNvbnN0IGkgPSBzZWxlY3Rvci5pbmRleE9mKENIQUlOKTtcbiAgICBpZiAoaSA+IDApIHtcbiAgICAgIGNvbnN0IHNjb3BlcyA9IHJlc29sdmVBbGwoc2VsZWN0b3Iuc2xpY2UoMCwgaSksIHJvb3QpO1xuICAgICAgcmV0dXJuIGRlZHVwZShzY29wZXMuZmxhdE1hcCgoc2MpID0+IHJlc29sdmVBbGwoc2VsZWN0b3Iuc2xpY2UoaSArIENIQUlOLmxlbmd0aCksIHNjKSkpO1xuICAgIH1cbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcImxhYmVsPVwiKSkgcmV0dXJuIGJ5TGFiZWwodW5xdW90ZShzZWxlY3Rvci5zbGljZSg2KSkpO1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwieHBhdGg9XCIpKSByZXR1cm4gYnlYUGF0aChzZWxlY3Rvci5zbGljZSg2KSk7XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJmcmFtZT1cIikpIHtcbiAgICAgIC8vIE4tw6lzaW1vIGlmcmFtZSBkZWwgZG9jdW1lbnRvIChmb3JtYXRvIGRlIERldlRvb2xzIFJlY29yZGVyKS5cbiAgICAgIGNvbnN0IGYgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lLCBmcmFtZVwiKVtOdW1iZXIoc2VsZWN0b3Iuc2xpY2UoNikpXTtcbiAgICAgIHJldHVybiBmID8gW2ZdIDogW107XG4gICAgfVxuICAgIHJldHVybiBbLi4ucm9vdC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKV07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBbXTtcbiAgfVxufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHQgPSBzLnRyaW0oKTtcbiAgaWYgKCh0LnN0YXJ0c1dpdGgoJ1wiJykgJiYgdC5lbmRzV2l0aCgnXCInKSkgfHwgKHQuc3RhcnRzV2l0aChcIidcIikgJiYgdC5lbmRzV2l0aChcIidcIikpKSByZXR1cm4gdC5zbGljZSgxLCAtMSk7XG4gIHJldHVybiB0O1xufVxuXG4vKiogRW5jdWVudHJhIGVsIHByaW1lciBzZWxlY3RvciBxdWUgcmVzdWVsdmUgYSBleGFjdGFtZW50ZSB1biBlbGVtZW50byAobyBhbCBwcmltZXJvIHZpc2libGUpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmUoc2VsZWN0b3JzOiBzdHJpbmdbXSk6IHsgZWw6IEVsZW1lbnQ7IHNlbGVjdG9yOiBzdHJpbmcgfSB8IG51bGwge1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBjb25zdCBmb3VuZCA9IHJlc29sdmVBbGwoc2VsKTtcbiAgICBpZiAoZm91bmQubGVuZ3RoID09PSAxKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gICAgY29uc3QgdmlzID0gZm91bmQuZmlsdGVyKGlzVmlzaWJsZSk7XG4gICAgaWYgKHZpcy5sZW5ndGggPj0gMSkgcmV0dXJuIHsgZWw6IHZpc1swXSEsIHNlbGVjdG9yOiBzZWwgfTtcbiAgICBpZiAoZm91bmQubGVuZ3RoKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBHZW5lcmFjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gaXNVbmlxdWUoc2VsOiBzdHJpbmcsIGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlQWxsKHNlbCk7XG4gIHJldHVybiByLmxlbmd0aCA9PT0gMSAmJiByWzBdID09PSBlbDtcbn1cblxuZnVuY3Rpb24gY3NzUGF0aChlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgY3VyOiBFbGVtZW50IHwgbnVsbCA9IGVsO1xuICB3aGlsZSAoY3VyICYmIGN1ciAhPT0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KSB7XG4gICAgY29uc3QgdGFnID0gY3VyLnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoY3VyICE9PSBlbCAmJiBjdXIuaWQgJiYgIWxvb2tzR2VuZXJhdGVkKGN1ci5pZCkpIHtcbiAgICAgIHBhcnRzLnVuc2hpZnQoXCIjXCIgKyBDU1MuZXNjYXBlKGN1ci5pZCkpO1xuICAgICAgY29uc3QgcyA9IHBhcnRzLmpvaW4oXCIgPiBcIik7XG4gICAgICBpZiAoaXNVbmlxdWUocywgZWwpKSByZXR1cm4gcztcbiAgICAgIHBhcnRzLnNoaWZ0KCk7XG4gICAgfVxuICAgIGxldCBzZWcgPSB0YWc7XG4gICAgY29uc3QgY2xzID0gc3RhYmxlQ2xhc3NlcyhjdXIpLnNsaWNlKDAsIDIpO1xuICAgIGlmIChjbHMubGVuZ3RoKSBzZWcgKz0gXCIuXCIgKyBjbHMubWFwKChjKSA9PiBDU1MuZXNjYXBlKGMpKS5qb2luKFwiLlwiKTtcblxuICAgIGNvbnN0IHdpdGhvdXROdGggPSBbc2VnLCAuLi5wYXJ0c10uam9pbihcIiA+IFwiKTtcbiAgICBpZiAoaXNVbmlxdWUod2l0aG91dE50aCwgZWwpKSByZXR1cm4gd2l0aG91dE50aDtcblxuICAgIGNvbnN0IHBhcmVudDogRWxlbWVudCB8IG51bGwgPSBjdXIucGFyZW50RWxlbWVudDtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICBjb25zdCBzYW1lID0gWy4uLnBhcmVudC5jaGlsZHJlbl0uZmlsdGVyKChjKSA9PiBjLnRhZ05hbWUgPT09IGN1ciEudGFnTmFtZSk7XG4gICAgICBpZiAoc2FtZS5sZW5ndGggPiAxKSBzZWcgKz0gYDpudGgtb2YtdHlwZSgke3NhbWUuaW5kZXhPZihjdXIpICsgMX0pYDtcbiAgICB9XG4gICAgcGFydHMudW5zaGlmdChzZWcpO1xuICAgIGNvbnN0IHMgPSBwYXJ0cy5qb2luKFwiID4gXCIpO1xuICAgIGlmIChpc1VuaXF1ZShzLCBlbCkpIHJldHVybiBzO1xuICAgIGN1ciA9IHBhcmVudDtcbiAgfVxuICByZXR1cm4gcGFydHMuam9pbihcIiA+IFwiKTtcbn1cblxuLy8gQ29udGVuZWRvcmVzIHTDrXBpY29zIGRlIG9wY2lvbmVzIGRlIGRlc3BsZWdhYmxlcywgbWVuw7pzIHkgbGlzdGFzIGRlIGxpYnJlcsOtYXMuXG5jb25zdCBPUFRJT05fTElTVCA9XG4gICdbcm9sZT1cImxpc3Rib3hcIl0sIFtyb2xlPVwibWVudVwiXSwgW3JvbGU9XCJ0cmVlXCJdLCBbcm9sZT1cImdyaWRcIl0sIHVsLCBvbCwgJyArXG4gICdbY2xhc3MqPVwiZHJvcGRvd25cIl0sIFtjbGFzcyo9XCJwb3BwZXJcIl0sIFtjbGFzcyo9XCJwb3BvdmVyXCJdLCBbY2xhc3MqPVwibWVudVwiXSwgW2NsYXNzKj1cIm9wdGlvblwiXSwgW2NsYXNzKj1cInNlbGVjdFwiXSwgW2NsYXNzKj1cImxpc3RcIl0nO1xuXG4vKiogU2VsZWN0b3JlcyBzZW5jaWxsb3MgKHNpbiBwb3NpY2nDs24pIHBhcmEgdW4gY29udGVuZWRvci4gKi9cbmZ1bmN0aW9uIGNvbnRhaW5lclNlbGVjdG9ycyhib3g6IEVsZW1lbnQpOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHRhZyA9IGJveC50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IG91dDogc3RyaW5nW10gPSBbXTtcbiAgY29uc3Qgcm9sZSA9IGJveC5nZXRBdHRyaWJ1dGUoXCJyb2xlXCIpO1xuICBpZiAocm9sZSkgb3V0LnB1c2goYFtyb2xlPSR7cShyb2xlKX1dYCk7XG4gIGZvciAoY29uc3QgYSBvZiBURVNUX0FUVFJTKSB7XG4gICAgY29uc3QgdiA9IGJveC5nZXRBdHRyaWJ1dGUoYSk7XG4gICAgaWYgKHYpIG91dC51bnNoaWZ0KGBbJHthfT0ke3Eodil9XWApO1xuICB9XG4gIGlmIChib3guaWQgJiYgIWxvb2tzR2VuZXJhdGVkKGJveC5pZCkpIG91dC51bnNoaWZ0KFwiI1wiICsgQ1NTLmVzY2FwZShib3guaWQpKTtcbiAgY29uc3QgY2xzID0gc3RhYmxlQ2xhc3Nlcyhib3gpLnNsaWNlKDAsIDMpO1xuICBpZiAoY2xzLmxlbmd0aCkgb3V0LnB1c2godGFnICsgXCIuXCIgKyBjbHMubWFwKChjKSA9PiBDU1MuZXNjYXBlKGMpKS5qb2luKFwiLlwiKSk7XG4gIHJldHVybiBvdXQ7XG59XG5cbi8qKlxuICogUGFyYSBvcGNpb25lcyBkZSBkZXNwbGVnYWJsZXM6IHRleHRvIGFjb3RhZG8gYSBzdSBsaXN0YSwgwqsuZWwtc2VsZWN0LWRyb3Bkb3duID4+IHRleHQ9RXNwYcOxYcK7LlxuICogTm8gZGVwZW5kZSBkZSBsYSBwb3NpY2nDs24gZGUgbGEgb3BjacOzbiAocXVlIGNhbWJpYSBzaSBjYW1iaWEgZWwgb3JkZW4pIHkgbm8gY2hvY2EgY29uIGVsXG4gKiBtaXNtbyB0ZXh0byBlbiBvdHJhIHBhcnRlIGRlIGxhIHDDoWdpbmEgKGVsIHZhbG9yIHlhIGVsZWdpZG8sIHVuYSBldGlxdWV0YeKApikuXG4gKi9cbmZ1bmN0aW9uIHNjb3BlZFRleHQoZWw6IEVsZW1lbnQsIHRleHQ6IHN0cmluZyk6IHN0cmluZ1tdIHtcbiAgY29uc3Qgb3V0OiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgYm94ID0gZWwucGFyZW50RWxlbWVudD8uY2xvc2VzdChPUFRJT05fTElTVCk7XG4gIGZvciAobGV0IGkgPSAwOyBib3ggJiYgYm94ICE9PSBkb2N1bWVudC5ib2R5ICYmIGkgPCA0OyBpKyspIHtcbiAgICBmb3IgKGNvbnN0IHNjIG9mIGNvbnRhaW5lclNlbGVjdG9ycyhib3gpKSBvdXQucHVzaChgJHtzY30ke0NIQUlOfXRleHQ9JHt0ZXh0fWApO1xuICAgIGJveCA9IGJveC5wYXJlbnRFbGVtZW50Py5jbG9zZXN0KE9QVElPTl9MSVNUKTtcbiAgfVxuICByZXR1cm4gb3V0O1xufVxuXG4vKiogR2VuZXJhIHNlbGVjdG9yZXMgY2FuZGlkYXRvcyBvcmRlbmFkb3MgZGUgbcOhcyBhIG1lbm9zIHJvYnVzdG8uIFRvZG9zIMO6bmljb3MuICovXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRTZWxlY3RvcnMoZWw6IEVsZW1lbnQpOiBzdHJpbmdbXSB7XG4gIGNvbnN0IHRhZyA9IGVsLnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgY29uc3QgYzogc3RyaW5nW10gPSBbXTtcblxuICBmb3IgKGNvbnN0IGEgb2YgVEVTVF9BVFRSUykge1xuICAgIGNvbnN0IHYgPSBlbC5nZXRBdHRyaWJ1dGUoYSk7XG4gICAgaWYgKHYpIGMucHVzaChgWyR7YX09JHtxKHYpfV1gKTtcbiAgfVxuICBpZiAoZWwuaWQgJiYgIWxvb2tzR2VuZXJhdGVkKGVsLmlkKSkgYy5wdXNoKFwiI1wiICsgQ1NTLmVzY2FwZShlbC5pZCkpO1xuXG4gIGNvbnN0IG5hbWUgPSBlbC5nZXRBdHRyaWJ1dGUoXCJuYW1lXCIpO1xuICBpZiAobmFtZSkge1xuICAgIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgKGVsLnR5cGUgPT09IFwicmFkaW9cIiB8fCBlbC50eXBlID09PSBcImNoZWNrYm94XCIpICYmIGVsLnZhbHVlICYmIGVsLnZhbHVlICE9PSBcIm9uXCIpIHtcbiAgICAgIGMucHVzaChgJHt0YWd9W25hbWU9JHtxKG5hbWUpfV1bdmFsdWU9JHtxKGVsLnZhbHVlKX1dYCk7XG4gICAgfSBlbHNlIGMucHVzaChgJHt0YWd9W25hbWU9JHtxKG5hbWUpfV1gKTtcbiAgfVxuXG4gIGNvbnN0IGlzQ29udHJvbCA9IGVsLm1hdGNoZXMoQ09OVFJPTCk7XG4gIGlmIChpc0NvbnRyb2wpIHtcbiAgICBjb25zdCBsYmwgPSBsYWJlbFRleHQoZWwpO1xuICAgIGlmIChsYmwgJiYgbGJsLmxlbmd0aCA8PSA2MCkgYy5wdXNoKGBsYWJlbD0ke2xibH1gKTtcbiAgfVxuXG4gIGNvbnN0IGFyaWEgPSBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpO1xuICBpZiAoYXJpYSkgYy5wdXNoKGAke3RhZ31bYXJpYS1sYWJlbD0ke3EoYXJpYSl9XWApO1xuICBjb25zdCBwaCA9IGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpO1xuICBpZiAocGgpIGMucHVzaChgJHt0YWd9W3BsYWNlaG9sZGVyPSR7cShwaCl9XWApO1xuXG4gIGlmICghaXNDb250cm9sKSB7XG4gICAgY29uc3QgdCA9IHRleHRPZihlbCk7XG4gICAgaWYgKHQgJiYgdC5sZW5ndGggPD0gODAgJiYgIWVsLnF1ZXJ5U2VsZWN0b3IoQ09OVFJPTCkpIHtcbiAgICAgIGlmICh0Lmxlbmd0aCA8PSA1MCkgYy5wdXNoKGB0ZXh0PSR7dH1gKTtcbiAgICAgIGMucHVzaCguLi5zY29wZWRUZXh0KGVsLCB0KSk7XG4gICAgfVxuICB9XG5cbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICBjb25zdCBocmVmID0gZWwuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKTtcbiAgICBpZiAoaHJlZiAmJiBocmVmLmxlbmd0aCA8IDgwICYmICFocmVmLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSAmJiBocmVmICE9PSBcIiNcIikgYy5wdXNoKGBhW2hyZWY9JHtxKGhyZWYpfV1gKTtcbiAgfVxuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSUZyYW1lRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxGcmFtZUVsZW1lbnQpIHtcbiAgICBjb25zdCBzcmMgPSBlbC5nZXRBdHRyaWJ1dGUoXCJzcmNcIik7XG4gICAgaWYgKHNyYyAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJkYXRhOlwiKSAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSkge1xuICAgICAgLy8gU2luIHF1ZXJ5IHN0cmluZzogc3VlbGUgbGxldmFyIHRva2VucyBxdWUgY2FtYmlhbiBlbiBjYWRhIGNhcmdhLlxuICAgICAgY29uc3QgYmFzZSA9IHNyYy5zcGxpdCgvWz8jXS8pWzBdITtcbiAgICAgIGMucHVzaChiYXNlID09PSBzcmMgPyBgJHt0YWd9W3NyYz0ke3Eoc3JjKX1dYCA6IGAke3RhZ31bc3JjXj0ke3EoYmFzZSl9XWApO1xuICAgIH1cbiAgfVxuICBjb25zdCB0aXRsZSA9IGVsLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpO1xuICBpZiAodGl0bGUpIGMucHVzaChgJHt0YWd9W3RpdGxlPSR7cSh0aXRsZSl9XWApO1xuXG4gIC8vIHRleHQ9IGFwdW50YSBhbCBub2RvIG3DoXMgcHJvZnVuZG8gY29uIGVzZSB0ZXh0byAocC4gZWouIGVsIDxzcGFuPiBkZSB1biA8bGk+IGRlIGRlc3BsZWdhYmxlKTogY2xpY2FybG8gZXF1aXZhbGUuXG4gIGNvbnN0IHNhbWVUYXJnZXQgPSAoczogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgaXNUZXh0ID0gZW5kc0luVGV4dChzKTtcbiAgICBjb25zdCBoaXQgPSAoeDogRWxlbWVudCkgPT4geCA9PT0gZWwgfHwgKGlzVGV4dCAmJiBlbC5jb250YWlucyh4KSAmJiB0ZXh0T2YoeCkgPT09IHRleHRPZihlbCkpO1xuICAgIGNvbnN0IHIgPSByZXNvbHZlQWxsKHMpO1xuICAgIGlmIChyLmxlbmd0aCA9PT0gMSkgcmV0dXJuIGhpdChyWzBdISk7XG4gICAgLy8gRGVzcGxlZ2FibGVzIHRlbGV0cmFuc3BvcnRhZG9zIChFbGVtZW50IFBsdXMsIEFudOKApik6IGxhcyBvcGNpb25lcyBkZSBvdHJvcyBzZWxlY3RzIHNpZ3VlbiBlbiBlbCBET01cbiAgICAvLyBwZXJvIG9jdWx0YXMuIFNpIGVsIMO6bmljbyB2aXNpYmxlIGVzIGVsIG51ZXN0cm8sIHJlc29sdmUoKSBsbyBlbGVnaXLDoSB0YW1iacOpbiBhbCByZXByb2R1Y2lyLlxuICAgIGlmICghaXNUZXh0KSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgdmlzID0gci5maWx0ZXIoaXNWaXNpYmxlKTtcbiAgICByZXR1cm4gdmlzLmxlbmd0aCA9PT0gMSAmJiBoaXQodmlzWzBdISk7XG4gIH07XG4gIGNvbnN0IHVuaXF1ZSA9IGRlZHVwZShjKS5maWx0ZXIoc2FtZVRhcmdldCk7XG4gIHVuaXF1ZS5wdXNoKGNzc1BhdGgoZWwpKTtcbiAgcmV0dXJuIGRlZHVwZSh1bmlxdWUpLnNsaWNlKDAsIDUpO1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRGVzY3JpcGNpw7NuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgZnVuY3Rpb24gbGFiZWxUZXh0KGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgaWYgKChlbCBhcyBIVE1MSW5wdXRFbGVtZW50KS5sYWJlbHM/Lmxlbmd0aCkge1xuICAgIGNvbnN0IHQgPSBub3JtKChlbCBhcyBIVE1MSW5wdXRFbGVtZW50KS5sYWJlbHMhWzBdIS5pbm5lclRleHQpLnJlcGxhY2UoL1xccypcXCokLywgXCJcIik7XG4gICAgaWYgKHQpIHJldHVybiB0O1xuICB9XG4gIGNvbnN0IGFyaWEgPSBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpO1xuICBpZiAoYXJpYSkgcmV0dXJuIG5vcm0oYXJpYSk7XG4gIGNvbnN0IGxiID0gZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbGxlZGJ5XCIpO1xuICBpZiAobGIpIHtcbiAgICBjb25zdCB0ID0gbm9ybShsYi5zcGxpdCgvXFxzKy8pLm1hcCgoaWQpID0+IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKT8uaW5uZXJUZXh0ID8/IFwiXCIpLmpvaW4oXCIgXCIpKTtcbiAgICBpZiAodCkgcmV0dXJuIHQ7XG4gIH1cbiAgcmV0dXJuIFwiXCI7XG59XG5cbi8qKiBOb21icmUgbGVnaWJsZSBwYXJhIG1vc3RyYXIgZW4gbGEgbGlzdGEgZGUgcGFzb3MuICovXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmUoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwubWF0Y2hlcyhDT05UUk9MKSkge1xuICAgIHJldHVybiAoXG4gICAgICBsYWJlbFRleHQoZWwpIHx8XG4gICAgICBlbC5nZXRBdHRyaWJ1dGUoXCJwbGFjZWhvbGRlclwiKSB8fFxuICAgICAgZWwuZ2V0QXR0cmlidXRlKFwibmFtZVwiKSB8fFxuICAgICAgZWwuaWQgfHxcbiAgICAgIGVsLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpIHx8XG4gICAgICBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKClcbiAgICApLnNsaWNlKDAsIDYwKTtcbiAgfVxuICBjb25zdCB0ID0gdGV4dE9mKGVsKTtcbiAgaWYgKHQpIHJldHVybiB0Lmxlbmd0aCA+IDUwID8gdC5zbGljZSgwLCA0NykgKyBcIuKAplwiIDogdDtcbiAgcmV0dXJuIChcbiAgICBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpIHx8XG4gICAgZWwuZ2V0QXR0cmlidXRlKFwidGl0bGVcIikgfHxcbiAgICBlbC5xdWVyeVNlbGVjdG9yKFwiaW1nXCIpPy5nZXRBdHRyaWJ1dGUoXCJhbHRcIikgfHxcbiAgICBlbC5nZXRBdHRyaWJ1dGUoXCJuYW1lXCIpIHx8XG4gICAgZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpXG4gICkuc2xpY2UoMCwgNjApO1xufVxuXG4vKiogRWxlbWVudG8gc29icmUgZWwgcXVlIGFjdMO6YSBlbCB1c3VhcmlvOiBlbCBjb250cm9sIG8gZWwgYW5jZXN0cm8gY2xpY2FibGUuICovXG5leHBvcnQgZnVuY3Rpb24gYWN0aW9uYWJsZSh0YXJnZXQ6IEVsZW1lbnQpOiBFbGVtZW50IHtcbiAgY29uc3QgY3RybCA9IHRhcmdldC5jbG9zZXN0KENPTlRST0wpO1xuICBpZiAoY3RybCkgcmV0dXJuIGN0cmw7XG4gIGNvbnN0IGNsaWNrYWJsZSA9IHRhcmdldC5jbG9zZXN0KENMSUNLQUJMRSk7XG4gIGlmIChjbGlja2FibGUgaW5zdGFuY2VvZiBIVE1MTGFiZWxFbGVtZW50ICYmIGNsaWNrYWJsZS5jb250cm9sKSByZXR1cm4gY2xpY2thYmxlLmNvbnRyb2w7XG4gIHJldHVybiBjbGlja2FibGUgPz8gdGFyZ2V0O1xufVxuXG5jb25zdCBURVhUTElLRSA9IG5ldyBTZXQoW1xuICBcIlwiLCBcInRleHRcIiwgXCJlbWFpbFwiLCBcInBhc3N3b3JkXCIsIFwic2VhcmNoXCIsIFwidGVsXCIsIFwidXJsXCIsIFwibnVtYmVyXCIsXG4gIFwiZGF0ZVwiLCBcImRhdGV0aW1lLWxvY2FsXCIsIFwibW9udGhcIiwgXCJ3ZWVrXCIsIFwidGltZVwiLCBcImNvbG9yXCIsIFwicmFuZ2VcIixcbl0pO1xuXG5leHBvcnQgdHlwZSBBY3Rpb25LaW5kID0gXCJjbGlja1wiIHwgXCJmaWxsXCIgfCBcInNlbGVjdFwiIHwgXCJjaGVja1wiIHwgXCJmaWxlXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiBraW5kT2YoZWw6IEVsZW1lbnQpOiBBY3Rpb25LaW5kIHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHJldHVybiBcInNlbGVjdFwiO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50KSByZXR1cm4gZWwucmVhZE9ubHkgPyBcImNsaWNrXCIgOiBcImZpbGxcIjtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCkge1xuICAgIGlmIChlbC50eXBlID09PSBcImNoZWNrYm94XCIgfHwgZWwudHlwZSA9PT0gXCJyYWRpb1wiKSByZXR1cm4gXCJjaGVja1wiO1xuICAgIGlmIChlbC50eXBlID09PSBcImZpbGVcIikgcmV0dXJuIFwiZmlsZVwiO1xuICAgIC8vIFJlYWRvbmx5ID0gc2VsZWN0cy9kYXRlcGlja2VycyBkZSBsaWJyZXLDrWFzIChFbGVtZW50IFBsdXMsIFZ1ZXRpZnnigKYpOiBhYnJlbiB1biBkZXNwbGVnYWJsZSwgbm8gc2UgZXNjcmliZS5cbiAgICBpZiAoVEVYVExJS0UuaGFzKGVsLnR5cGUpKSByZXR1cm4gZWwucmVhZE9ubHkgPyBcImNsaWNrXCIgOiBcImZpbGxcIjtcbiAgICByZXR1cm4gXCJjbGlja1wiO1xuICB9XG4gIGlmICgoZWwgYXMgSFRNTEVsZW1lbnQpLmlzQ29udGVudEVkaXRhYmxlKSByZXR1cm4gXCJmaWxsXCI7XG4gIGNvbnN0IHJvbGUgPSBlbC5nZXRBdHRyaWJ1dGUoXCJyb2xlXCIpO1xuICBpZiAocm9sZSA9PT0gXCJjaGVja2JveFwiIHx8IHJvbGUgPT09IFwic3dpdGNoXCIpIHJldHVybiBcImNoZWNrXCI7XG4gIHJldHVybiBcImNsaWNrXCI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWx1ZU9mKGVsOiBFbGVtZW50KTogc3RyaW5nIHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCkgcmV0dXJuIGVsLnZhbHVlO1xuICByZXR1cm4gbm9ybSgoZWwgYXMgSFRNTEVsZW1lbnQpLmlubmVyVGV4dCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjaGVja2VkT2YoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCkgcmV0dXJuIGVsLmNoZWNrZWQ7XG4gIHJldHVybiBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWNoZWNrZWRcIikgPT09IFwidHJ1ZVwiO1xufVxuIiwKICAgICIvLyBFc3BlcmEgYXV0b23DoXRpY2EgYW50ZXMgZGUgY2FkYSBhY2Npw7NuOiBxdWUgbGEgcMOhZ2luYSBlc3TDqSDCq3RyYW5xdWlsYcK7IChzaW4gcGV0aWNpb25lcyBlbiB2dWVsbyxcbi8vIHNpbiBjYW1iaW9zIGVuIGVsIERPTSwgc2luIGxvYWRlcnMgdmlzaWJsZXMpIHkgcXVlIGVsIGVsZW1lbnRvIGVzdMOpIGxpc3RvIHBhcmEgcmVjaWJpciBsYSBhY2Npw7NuXG4vLyAoaGFiaWxpdGFkbywgcXVpZXRvIHkgc2luIG5hZGEgZW5jaW1hKS4gRXZpdGEgY2xpY2tzIHF1ZSDCq25vIGhhY2VuIG5hZGHCuyBwb3JxdWUgYcO6biBoYXkgdW4gbG9hZGVyLlxuXG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgaXNWaXNpYmxlIH0gZnJvbSBcIi4vc2VsZWN0b3JcIjtcblxuLyoqIE1hcmdlbiBzaW4gcGV0aWNpb25lcyBhbnRlcyBkZSBkYXIgbGEgcmVkIHBvciB0cmFucXVpbGEgKGN1YnJlIGNhZGVuYXMgZGUgcGV0aWNpb25lcyBlbmNhZGVuYWRhcykuICovXG5jb25zdCBORVRfUVVJRVQgPSAzMDA7XG4vKiogTWFyZ2VuIHNpbiBtdXRhY2lvbmVzIGRlbCBET00uICovXG5jb25zdCBET01fUVVJRVQgPSAxNTA7XG4vKiogV2VicyBjb24gcmVsb2plcywgY2FycnVzZWxlc+KApjogZWwgRE9NIG51bmNhIHBhcmE7IG5vIGVzcGVyYW1vcyBtw6FzIGRlIGVzdG8gcG9yIMOpbC4gKi9cbmNvbnN0IERPTV9DQVAgPSAxNTAwO1xuXG4vLyBMb2FkZXJzIGRlIGxpYnJlcsOtYXMgaGFiaXR1YWxlcy4gU29sbyBpbmRpY2Fkb3JlcyBkZSBjYXJnYSwgbm8gbW9kYWxlcyAoc3UgZm9uZG8gdGFtYmnDqW4gdGFwYSwgcGVybyBlcyBpbnRlbmNpb25hZG8pLlxuY29uc3QgTE9BREVSUyA9IFtcbiAgJ1thcmlhLWJ1c3k9XCJ0cnVlXCJdJyxcbiAgXCIuZWwtbG9hZGluZy1tYXNrXCIsIC8vIEVsZW1lbnQgUGx1cyAvIEVsZW1lbnQgVUlcbiAgXCIuYW50LXNwaW4tc3Bpbm5pbmdcIiwgLy8gQW50IERlc2lnblxuICBcIi52LXByb2dyZXNzLWNpcmN1bGFyLS1pbmRldGVybWluYXRlXCIsIFwiLnYtcHJvZ3Jlc3MtbGluZWFyLS1hY3RpdmVcIiwgLy8gVnVldGlmeVxuICBcIi5NdWlDaXJjdWxhclByb2dyZXNzLXJvb3RcIiwgXCIuTXVpTGluZWFyUHJvZ3Jlc3Mtcm9vdFwiLCAvLyBNVUlcbiAgXCIucC1wcm9ncmVzcy1zcGlubmVyXCIsIFwiLnAtYmxvY2t1aVwiLCAvLyBQcmltZVZ1ZSAvIFByaW1lTkdcbiAgXCIucS1sb2FkaW5nXCIsIFwiLnEtc3Bpbm5lclwiLCAvLyBRdWFzYXJcbiAgXCIuc3Bpbm5lci1ib3JkZXJcIiwgXCIuc3Bpbm5lci1ncm93XCIsIC8vIEJvb3RzdHJhcFxuICBcIi5ibG9ja1VJXCIsIFwiLmxvYWRpbmctb3ZlcmxheVwiLCBcIi5sb2FkaW5nLW1hc2tcIiwgXCIubG9hZGVyXCIsIFwiLnNwaW5uZXJcIixcbl0uam9pbihcIiwgXCIpO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUmVkIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5sZXQgcGVuZGluZyA9IDA7XG5sZXQgbmV0Q2hhbmdlZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiX19yYXN0cm9fbmV0XCIsIChlKSA9PiB7XG4gIGNvbnN0IG4gPSAoZSBhcyBDdXN0b21FdmVudCkuZGV0YWlsO1xuICBpZiAodHlwZW9mIG4gIT09IFwibnVtYmVyXCIpIHJldHVybjtcbiAgcGVuZGluZyA9IG47XG4gIG5ldENoYW5nZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbn0pO1xuZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJfX3Jhc3Ryb19uZXQ/XCIpKTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIERPTSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxubGV0IGRvbUNoYW5nZWQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbmxldCBkb21PYnNlcnZlcjogTXV0YXRpb25PYnNlcnZlciB8IG51bGwgPSBudWxsO1xuXG5mdW5jdGlvbiB3YXRjaERvbSgpIHtcbiAgaWYgKGRvbU9ic2VydmVyKSByZXR1cm47XG4gIGRvbU9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKHJlY29yZHMpID0+IHtcbiAgICBpZiAocmVjb3Jkcy5zb21lKChyKSA9PiAhKHIudGFyZ2V0IGFzIEVsZW1lbnQpLmNsb3Nlc3Q/LihcIiNfX3Jhc3Ryb19ob3N0XCIpKSkgZG9tQ2hhbmdlZCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICB9KTtcbiAgZG9tT2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsIHsgc3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlLCBhdHRyaWJ1dGVzOiB0cnVlLCBjaGFyYWN0ZXJEYXRhOiB0cnVlIH0pO1xufVxuXG4vKiogU2VsZWN0b3IgZGUgbG9hZGVyczogbG9zIGludGVncmFkb3MgKyBlbCBwZXJzb25hbGl6YWRvIGRlIGFqdXN0ZXMgKHNpIGVzIHVuIHNlbGVjdG9yIHbDoWxpZG8pLiAqL1xuZnVuY3Rpb24gbG9hZGVyU2VsZWN0b3IoZXh0cmE/OiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB4ID0gZXh0cmE/LnRyaW0oKTtcbiAgaWYgKCF4KSByZXR1cm4gTE9BREVSUztcbiAgdHJ5IHtcbiAgICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHgpO1xuICAgIHJldHVybiBgJHtMT0FERVJTfSwgJHt4fWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBMT0FERVJTO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2aXNpYmxlTG9hZGVyKGV4dHJhPzogc3RyaW5nKTogRWxlbWVudCB8IHVuZGVmaW5lZCB7XG4gIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChsb2FkZXJTZWxlY3RvcihleHRyYSkpKSB7XG4gICAgaWYgKGVsLmNsb3Nlc3QoXCIjX19yYXN0cm9faG9zdFwiKSB8fCAhaXNWaXNpYmxlKGVsKSkgY29udGludWU7XG4gICAgY29uc3QgciA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGlmIChyLndpZHRoID4gMCAmJiByLmhlaWdodCA+IDApIHJldHVybiBlbDtcbiAgfVxufVxuXG4vKipcbiAqIEVzcGVyYSBhIHF1ZSBsYSBww6FnaW5hIGVzdMOpIHRyYW5xdWlsYS4gTnVuY2EgZmFsbGE6IHBhc2FkbyBgbWF4TXNgIHNpZ3VlIGFkZWxhbnRlXG4gKiAocG9sbGluZywgYW5pbWFjaW9uZXMgaW5maW5pdGFz4oCmKSB5IHF1ZSBlbCBwYXNvIGRlY2lkYSBzaSBlbmN1ZW50cmEgc3UgZWxlbWVudG8uXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXR0bGUobWF4TXM6IG51bWJlciwgZXh0cmFMb2FkZXI/OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgd2F0Y2hEb20oKTtcbiAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCBub3cgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICBjb25zdCBuZXRRdWlldCA9IHBlbmRpbmcgPT09IDAgJiYgbm93IC0gbmV0Q2hhbmdlZCA+PSBORVRfUVVJRVQ7XG4gICAgY29uc3QgZG9tUXVpZXQgPSBub3cgLSBkb21DaGFuZ2VkID49IERPTV9RVUlFVCB8fCBub3cgLSBzdGFydCA+IERPTV9DQVA7XG4gICAgaWYgKG5ldFF1aWV0ICYmIGRvbVF1aWV0ICYmICF2aXNpYmxlTG9hZGVyKGV4dHJhTG9hZGVyKSkgcmV0dXJuO1xuICAgIGlmIChub3cgLSBzdGFydCA+IG1heE1zKSByZXR1cm47XG4gICAgYXdhaXQgc2xlZXAoNTApO1xuICB9XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBFbGVtZW50byDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gaXNEaXNhYmxlZChlbDogRWxlbWVudCwgdmlzaWJsZTogYm9vbGVhbik6IGJvb2xlYW4ge1xuICBpZiAoZWwubWF0Y2hlcyhcIjpkaXNhYmxlZFwiKSkgcmV0dXJuIHRydWU7IC8vIGluY2x1eWUgPGZpZWxkc2V0IGRpc2FibGVkPlxuICBpZiAoZWwuY2xvc2VzdCgnW2FyaWEtZGlzYWJsZWQ9XCJ0cnVlXCJdJykpIHJldHVybiB0cnVlO1xuICAvLyBDb250cm9sZXMgb2N1bHRvcyBkZSBsaWJyZXLDrWFzIChjaGVja2JveCBjdXN0b23igKYpIGEgdmVjZXMgbGxldmFuIHBvaW50ZXItZXZlbnRzOiBub25lIGEgcHJvcMOzc2l0by5cbiAgcmV0dXJuIHZpc2libGUgJiYgZ2V0Q29tcHV0ZWRTdHlsZShlbCkucG9pbnRlckV2ZW50cyA9PT0gXCJub25lXCI7XG59XG5cbmZ1bmN0aW9uIGFuY2VzdG9yKGVsOiBFbGVtZW50LCBsZXZlbHM6IG51bWJlcik6IEVsZW1lbnQge1xuICBsZXQgY3VyID0gZWw7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGV2ZWxzICYmIGN1ci5wYXJlbnRFbGVtZW50OyBpKyspIGN1ciA9IGN1ci5wYXJlbnRFbGVtZW50O1xuICByZXR1cm4gY3VyO1xufVxuXG4vKiogwr9RdcOpIGhheSBlbmNpbWEgZGVsIGNlbnRybyBkZWwgZWxlbWVudG8sIHNpIG5vIGVzIGVsIHByb3BpbyBlbGVtZW50byAobyBhbGdvIGRlIHN1IGVudG9ybm8gaW5tZWRpYXRvKT8gKi9cbmZ1bmN0aW9uIGNvdmVyZWRCeShlbDogRWxlbWVudCwgZXh0cmFMb2FkZXI/OiBzdHJpbmcpOiBFbGVtZW50IHwgbnVsbCB7XG4gIGlmIChlbC5nZXRSb290Tm9kZSgpICE9PSBkb2N1bWVudCkgcmV0dXJuIG51bGw7IC8vIHNoYWRvdyBET006IGVsZW1lbnRGcm9tUG9pbnQgZGV2dWVsdmUgZWwgaG9zdCwgbm8gcG9kZW1vcyBzYWJlcmxvXG4gIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgeCA9IHIubGVmdCArIHIud2lkdGggLyAyO1xuICBjb25zdCB5ID0gci50b3AgKyByLmhlaWdodCAvIDI7XG4gIGlmICh4IDwgMCB8fCB5IDwgMCB8fCB4ID4gaW5uZXJXaWR0aCB8fCB5ID4gaW5uZXJIZWlnaHQpIHJldHVybiBudWxsO1xuICBjb25zdCB0b3AgPSBkb2N1bWVudC5lbGVtZW50RnJvbVBvaW50KHgsIHkpO1xuICBpZiAoIXRvcCB8fCBlbC5jb250YWlucyh0b3ApIHx8IHRvcC5jbG9zZXN0KFwiI19fcmFzdHJvX2hvc3RcIikpIHJldHVybiBudWxsO1xuICBpZiAoKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscyAmJiBbLi4uKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscyFdLnNvbWUoKGwpID0+IGwuY29udGFpbnModG9wKSkpIHJldHVybiBudWxsO1xuICAvLyBQbGFjZWhvbGRlcnMsIGljb25vcyBvIHdyYXBwZXJzIGhlcm1hbm9zIChzZWxlY3RzIGRlIGxpYnJlcsOtYXMpOiByZWNpYmVuIGVsIGNsaWNrIHkgbG8gcHJvcGFnYW4gaWd1YWwuXG4gIGlmICghdG9wLmNsb3Nlc3QobG9hZGVyU2VsZWN0b3IoZXh0cmFMb2FkZXIpKSAmJiBhbmNlc3RvcihlbCwgMykuY29udGFpbnModG9wKSkgcmV0dXJuIG51bGw7XG4gIHJldHVybiB0b3A7XG59XG5cbmZ1bmN0aW9uIGRlc2NyaWJlRWwoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBjb25zdCBjbHMgPSBbLi4uZWwuY2xhc3NMaXN0XS5zbGljZSgwLCAyKS5qb2luKFwiLlwiKTtcbiAgcmV0dXJuIGVsLnRhZ05hbWUudG9Mb3dlckNhc2UoKSArIChlbC5pZCA/IFwiI1wiICsgZWwuaWQgOiBcIlwiKSArIChjbHMgPyBcIi5cIiArIGNscyA6IFwiXCIpO1xufVxuXG4vKipcbiAqIEVzcGVyYSBhIHF1ZSBlbCBlbGVtZW50byBhY2VwdGUgbGEgYWNjacOzbjogaGFiaWxpdGFkbywgc2luIG1vdmVyc2UgKGFuaW1hY2lvbmVzIGRlIGVudHJhZGEpXG4gKiB5LCBzaSBgY2hlY2tIaXRgLCBzaW4gbmFkYSBlbmNpbWEuIERldnVlbHZlIHVuIG1vdGl2byBzaSBzZSBhZ290YSBlbCB0aWVtcG8uXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1bnRpbEFjdGlvbmFibGUoZWw6IEVsZW1lbnQsIHRpbWVvdXQ6IG51bWJlciwgY2hlY2tIaXQ6IGJvb2xlYW4sIGV4dHJhTG9hZGVyPzogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gIGxldCBsYXN0UmVjdCA9IFwiXCI7XG4gIGxldCB3aHk6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICB3aGlsZSAodHJ1ZSkge1xuICAgIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCByZWN0ID0gYCR7ci54fSwke3IueX0sJHtyLndpZHRofSwke3IuaGVpZ2h0fWA7XG4gICAgY29uc3Qgc3RhYmxlID0gcmVjdCA9PT0gbGFzdFJlY3Q7XG4gICAgbGFzdFJlY3QgPSByZWN0O1xuICAgIGNvbnN0IGNvdmVyID0gY2hlY2tIaXQgPyBjb3ZlcmVkQnkoZWwsIGV4dHJhTG9hZGVyKSA6IG51bGw7XG4gICAgaWYgKGlzRGlzYWJsZWQoZWwsIGNoZWNrSGl0KSkgd2h5ID0gXCJlc3TDoSBkZXNoYWJpbGl0YWRvXCI7XG4gICAgZWxzZSBpZiAoY292ZXIpIHdoeSA9IGBlc3TDoSB0YXBhZG8gcG9yICR7ZGVzY3JpYmVFbChjb3Zlcil9YDtcbiAgICBlbHNlIGlmICghc3RhYmxlKSB3aHkgPSBcInNlIGVzdMOhIG1vdmllbmRvXCI7XG4gICAgZWxzZSByZXR1cm4gbnVsbDtcbiAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHJldHVybiB3aHk7XG4gICAgYXdhaXQgc2xlZXAoNTApO1xuICB9XG59XG4iLAogICAgIi8vIFJlcHJvZHVjdG9yOiBlamVjdXRhIHVuIHBhc28gc29icmUgbGEgcMOhZ2luYSBzaW11bGFuZG8gYSB1biB1c3VhcmlvIHJlYWxcbi8vIChzZWN1ZW5jaWEgY29tcGxldGEgZGUgZXZlbnRvcyBkZSBwdW50ZXJvL3RlY2xhZG8sIGNvbXBhdGlibGUgY29uIFJlYWN0L1Z1ZS9Bbmd1bGFyKS5cblxuaW1wb3J0IHR5cGUgeyBTdGVwUmVzdWx0IH0gZnJvbSBcIi4uL3NoYXJlZC9tZXNzYWdlc1wiO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncywgU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5pbXBvcnQgeyBDT0xPUlMsIG92ZXJsYXkgfSBmcm9tIFwiLi9vdmVybGF5XCI7XG5pbXBvcnQgeyBjaGVja2VkT2YsIGlzVmlzaWJsZSwga2luZE9mLCByZXNvbHZlLCB0ZXh0T2YsIHZhbHVlT2YgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuaW1wb3J0IHsgc2V0dGxlLCB1bnRpbEFjdGlvbmFibGUgfSBmcm9tIFwiLi93YWl0XCI7XG5cbmNsYXNzIFN0ZXBFcnJvciBleHRlbmRzIEVycm9yIHt9XG5cbi8qKiBFc3BlcmEgYSBxdWUgZWwgZWxlbWVudG8gZXhpc3RhICh5IHByZWZlcmlibGVtZW50ZSBzZWEgdmlzaWJsZSkuICovXG5hc3luYyBmdW5jdGlvbiBmaW5kKHN0ZXA6IFN0ZXAsIHRpbWVvdXQ6IG51bWJlciwgcmVxdWlyZVZpc2libGU6IGJvb2xlYW4pOiBQcm9taXNlPHsgZWw6IEVsZW1lbnQ7IHNlbGVjdG9yOiBzdHJpbmcgfT4ge1xuICBjb25zdCBzZWxlY3RvcnMgPSBbc3RlcC5zZWxlY3RvciwgLi4uKHN0ZXAuZmFsbGJhY2tzID8/IFtdKV0uZmlsdGVyKEJvb2xlYW4pIGFzIHN0cmluZ1tdO1xuICBpZiAoIXNlbGVjdG9ycy5sZW5ndGgpIHRocm93IG5ldyBTdGVwRXJyb3IoXCJFbCBwYXNvIG5vIHRpZW5lIHNlbGVjdG9yXCIpO1xuICBjb25zdCBzdGFydCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuICBsZXQgaGlkZGVuU2luY2UgPSAwO1xuICB3aGlsZSAodHJ1ZSkge1xuICAgIGNvbnN0IHIgPSByZXNvbHZlKHNlbGVjdG9ycyk7XG4gICAgaWYgKHIpIHtcbiAgICAgIGlmIChpc1Zpc2libGUoci5lbCkpIHJldHVybiByO1xuICAgICAgLy8gQ29udHJvbGVzIG9jdWx0b3MgKGNoZWNrYm94IGN1c3RvbSwgaW5wdXRzIGNvbiBsYWJlbCBlc3RpbGl6YWRv4oCmKTogc2UgYWNlcHRhbiB0cmFzIDFzLlxuICAgICAgaWYgKCFyZXF1aXJlVmlzaWJsZSkge1xuICAgICAgICBoaWRkZW5TaW5jZSB8fD0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIGlmIChwZXJmb3JtYW5jZS5ub3coKSAtIGhpZGRlblNpbmNlID4gMTAwMCkgcmV0dXJuIHI7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChwZXJmb3JtYW5jZS5ub3coKSAtIHN0YXJ0ID4gdGltZW91dCkge1xuICAgICAgaWYgKHIpIHRocm93IG5ldyBTdGVwRXJyb3IoYEVsIGVsZW1lbnRvIMKrJHtzdGVwLmxhYmVsID8/IHNlbGVjdG9yc1swXX3CuyBleGlzdGUgcGVybyBubyBlcyB2aXNpYmxlYCk7XG4gICAgICB0aHJvdyBuZXcgU3RlcEVycm9yKGBObyBzZSBlbmNvbnRyw7Mgwqske3N0ZXAubGFiZWwgPz8gc2VsZWN0b3JzWzBdfcK7ICgke3NlbGVjdG9yc1swXX0pYCk7XG4gICAgfVxuICAgIGF3YWl0IHNsZWVwKDEwMCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gY2VudGVyKGVsOiBFbGVtZW50KSB7XG4gIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgcmV0dXJuIHsgeDogci5sZWZ0ICsgci53aWR0aCAvIDIsIHk6IHIudG9wICsgci5oZWlnaHQgLyAyIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNjcm9sbFRvKGVsOiBFbGVtZW50KSB7XG4gIGNvbnN0IHIgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgaWYgKHIudG9wIDwgMCB8fCByLmJvdHRvbSA+IGlubmVySGVpZ2h0IHx8IHIubGVmdCA8IDAgfHwgci5yaWdodCA+IGlubmVyV2lkdGgpIHtcbiAgICBlbC5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiBcImNlbnRlclwiLCBpbmxpbmU6IFwiY2VudGVyXCIsIGJlaGF2aW9yOiBcImluc3RhbnRcIiBhcyBTY3JvbGxCZWhhdmlvciB9KTtcbiAgICBhd2FpdCBzbGVlcCg1MCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gbW91c2UodGFyZ2V0OiBFbGVtZW50LCB0eXBlOiBzdHJpbmcsIHg6IG51bWJlciwgeTogbnVtYmVyKSB7XG4gIGNvbnN0IGluaXQ6IFBvaW50ZXJFdmVudEluaXQgPSB7XG4gICAgYnViYmxlczogdHJ1ZSwgY2FuY2VsYWJsZTogdHJ1ZSwgY29tcG9zZWQ6IHRydWUsIHZpZXc6IHdpbmRvdyxcbiAgICBjbGllbnRYOiB4LCBjbGllbnRZOiB5LCBzY3JlZW5YOiB4ICsgc2NyZWVuWCwgc2NyZWVuWTogeSArIHNjcmVlblksXG4gICAgYnV0dG9uOiAwLCBidXR0b25zOiB0eXBlLmVuZHNXaXRoKFwiZG93blwiKSA/IDEgOiAwLCBwb2ludGVySWQ6IDEsIHBvaW50ZXJUeXBlOiBcIm1vdXNlXCIsIGlzUHJpbWFyeTogdHJ1ZSxcbiAgfTtcbiAgY29uc3QgQ3RvciA9IHR5cGUuc3RhcnRzV2l0aChcInBvaW50ZXJcIikgPyBQb2ludGVyRXZlbnQgOiBNb3VzZUV2ZW50O1xuICByZXR1cm4gdGFyZ2V0LmRpc3BhdGNoRXZlbnQobmV3IEN0b3IodHlwZSwgaW5pdCkpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWFsQ2xpY2soZWw6IEVsZW1lbnQpIHtcbiAgYXdhaXQgc2Nyb2xsVG8oZWwpO1xuICBjb25zdCB7IHgsIHkgfSA9IGNlbnRlcihlbCk7XG4gIC8vIFNpIGhheSBhbGdvIGVuY2ltYSBwZXJvIGVzIHVuIGhpam8gKGljb25vIGRlbnRybyBkZWwgYm90w7NuKSwgZGlzcGFyYW1vcyBzb2JyZSDDqWwgY29tbyBoYXLDrWEgZWwgbmF2ZWdhZG9yLlxuICBjb25zdCB0b3AgPSBkb2N1bWVudC5lbGVtZW50RnJvbVBvaW50KHgsIHkpO1xuICBjb25zdCB0YXJnZXQgPSB0b3AgJiYgZWwuY29udGFpbnModG9wKSA/IHRvcCA6IGVsO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcm92ZXJcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJtb3VzZW92ZXJcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJwb2ludGVybW92ZVwiLCB4LCB5KTtcbiAgbW91c2UodGFyZ2V0LCBcIm1vdXNlbW92ZVwiLCB4LCB5KTtcbiAgY29uc3QgZG93biA9IG1vdXNlKHRhcmdldCwgXCJwb2ludGVyZG93blwiLCB4LCB5KSAmJiBtb3VzZSh0YXJnZXQsIFwibW91c2Vkb3duXCIsIHgsIHkpO1xuICBpZiAoZG93biAmJiBlbCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50ICYmIGVsLnRhYkluZGV4ID49IC0xKSBlbC5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gIG1vdXNlKHRhcmdldCwgXCJwb2ludGVydXBcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJtb3VzZXVwXCIsIHgsIHkpO1xuICAvLyBjbGljayBzaW50w6l0aWNvOiBlbCBuYXZlZ2Fkb3IgZWplY3V0YSBsYSBhY2Npw7NuIHBvciBkZWZlY3RvIChzZWd1aXIgZW5sYWNlLCBlbnZpYXIgZm9ybeKApikuXG4gIG1vdXNlKHRhcmdldCwgXCJjbGlja1wiLCB4LCB5KTtcbn1cblxuY29uc3QgTk9fVFlQSU5HID0gbmV3IFNldChbXCJkYXRlXCIsIFwiZGF0ZXRpbWUtbG9jYWxcIiwgXCJtb250aFwiLCBcIndlZWtcIiwgXCJ0aW1lXCIsIFwiY29sb3JcIiwgXCJyYW5nZVwiXSk7XG5cbmZ1bmN0aW9uIHNldE5hdGl2ZShlbDogSFRNTElucHV0RWxlbWVudCB8IEhUTUxUZXh0QXJlYUVsZW1lbnQsIHY6IHN0cmluZykge1xuICAvLyBFc3RhbW9zIGVuIGVsIMKraXNvbGF0ZWQgd29ybGTCuyBkZWwgY29udGVudCBzY3JpcHQ6IGVzdGUgc2V0dGVyIGVzIGVsIG5hdGl2byxcbiAgLy8gYXPDrSBxdWUgZWwgdmFsdWUgdHJhY2tlciBkZSBSZWFjdCBkZXRlY3RhIGVsIGNhbWJpbyBhbCByZWNpYmlyIGVsIGV2ZW50byBpbnB1dC5cbiAgY29uc3QgcHJvdG8gPSBlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQgPyBIVE1MVGV4dEFyZWFFbGVtZW50LnByb3RvdHlwZSA6IEhUTUxJbnB1dEVsZW1lbnQucHJvdG90eXBlO1xuICBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHByb3RvLCBcInZhbHVlXCIpIS5zZXQhLmNhbGwoZWwsIHYpO1xufVxuXG5mdW5jdGlvbiBmaXJlSW5wdXQoZWw6IEVsZW1lbnQsIGRhdGE6IHN0cmluZyB8IG51bGwsIGlucHV0VHlwZSA9IFwiaW5zZXJ0VGV4dFwiKSB7XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IElucHV0RXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUsIGNvbXBvc2VkOiB0cnVlLCBkYXRhLCBpbnB1dFR5cGUgfSkpO1xufVxuXG5mdW5jdGlvbiBrZXkoZWw6IEVsZW1lbnQsIHR5cGU6IFwia2V5ZG93blwiIHwgXCJrZXlwcmVzc1wiIHwgXCJrZXl1cFwiLCBrOiBzdHJpbmcpIHtcbiAgcmV0dXJuIGVsLmRpc3BhdGNoRXZlbnQoXG4gICAgbmV3IEtleWJvYXJkRXZlbnQodHlwZSwgeyBrZXk6IGssIGNvZGU6IGNvZGVGb3IoayksIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUsIGNvbXBvc2VkOiB0cnVlIH0pLFxuICApO1xufVxuXG5mdW5jdGlvbiBjb2RlRm9yKGs6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmIChrLmxlbmd0aCA9PT0gMSkge1xuICAgIGlmICgvW2Etel0vaS50ZXN0KGspKSByZXR1cm4gXCJLZXlcIiArIGsudG9VcHBlckNhc2UoKTtcbiAgICBpZiAoL1xcZC8udGVzdChrKSkgcmV0dXJuIFwiRGlnaXRcIiArIGs7XG4gICAgaWYgKGsgPT09IFwiIFwiKSByZXR1cm4gXCJTcGFjZVwiO1xuICAgIHJldHVybiBcIlwiO1xuICB9XG4gIHJldHVybiBrO1xufVxuXG5mdW5jdGlvbiBzZWxlY3RBbGwoZWw6IEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50KSB7XG4gIHRyeSB7XG4gICAgZWwuc2VsZWN0KCk7XG4gIH0gY2F0Y2gge1xuICAgIC8qIG51bWJlci9lbWFpbCBubyBzb3BvcnRhbiBzZWxlY2Npw7NuIGVuIGFsZ3Vub3MgbmF2ZWdhZG9yZXMgKi9cbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiB0eXBlSW50byhlbDogRWxlbWVudCwgdmFsdWU6IHN0cmluZywgczogU2V0dGluZ3MpIHtcbiAgYXdhaXQgc2Nyb2xsVG8oZWwpO1xuICAoZWwgYXMgSFRNTEVsZW1lbnQpLmZvY3VzKHsgcHJldmVudFNjcm9sbDogdHJ1ZSB9KTtcblxuICBpZiAoKGVsIGFzIEhUTUxFbGVtZW50KS5pc0NvbnRlbnRFZGl0YWJsZSkge1xuICAgIGRvY3VtZW50LmV4ZWNDb21tYW5kKFwic2VsZWN0QWxsXCIpO1xuICAgIGlmICh2YWx1ZSkgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJpbnNlcnRUZXh0XCIsIGZhbHNlLCB2YWx1ZSk7XG4gICAgZWxzZSBkb2N1bWVudC5leGVjQ29tbWFuZChcImRlbGV0ZVwiKTtcbiAgICBpZiAodGV4dE9mKGVsKSAhPT0gdmFsdWUucmVwbGFjZSgvXFxzKy9nLCBcIiBcIikudHJpbSgpKSB7XG4gICAgICBlbC50ZXh0Q29udGVudCA9IHZhbHVlO1xuICAgICAgZmlyZUlucHV0KGVsLCB2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmICghKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQpKSB0aHJvdyBuZXcgU3RlcEVycm9yKFwiRWwgZWxlbWVudG8gbm8gZXMgZWRpdGFibGVcIik7XG4gIGlmIChlbC5kaXNhYmxlZCkgdGhyb3cgbmV3IFN0ZXBFcnJvcihgwqske2VsLm5hbWUgfHwgZWwuaWR9wrsgZXN0w6EgZGVzaGFiaWxpdGFkb2ApO1xuXG4gIGNvbnN0IHR5cGVhYmxlID0gIShlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgTk9fVFlQSU5HLmhhcyhlbC50eXBlKSk7XG5cbiAgaWYgKCF0eXBlYWJsZSB8fCBzLnR5cGVNb2RlID09PSBcImluc3RhbnRcIikge1xuICAgIHNlbGVjdEFsbChlbCk7XG4gICAgY29uc3Qgb2sgPSB0eXBlYWJsZSAmJiAodmFsdWUgPyBkb2N1bWVudC5leGVjQ29tbWFuZChcImluc2VydFRleHRcIiwgZmFsc2UsIHZhbHVlKSA6IGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiZGVsZXRlXCIpKTtcbiAgICBpZiAoIW9rIHx8IGVsLnZhbHVlICE9PSB2YWx1ZSkge1xuICAgICAgc2V0TmF0aXZlKGVsLCB2YWx1ZSk7XG4gICAgICBmaXJlSW5wdXQoZWwsIHZhbHVlKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgLy8gQ2Fyw6FjdGVyIGEgY2Fyw6FjdGVyOiBtw6FzIGxlbnRvLCBwZXJvIGRpc3BhcmEga2V5ZG93bi9rZXl1cCBwYXJhIHZhbGlkYWNpb25lcyB5IGF1dG9jb21wbGV0YWRvcy5cbiAgICBzZWxlY3RBbGwoZWwpO1xuICAgIGlmICghZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJkZWxldGVcIikgfHwgZWwudmFsdWUgIT09IFwiXCIpIHtcbiAgICAgIHNldE5hdGl2ZShlbCwgXCJcIik7XG4gICAgICBmaXJlSW5wdXQoZWwsIG51bGwsIFwiZGVsZXRlQ29udGVudEJhY2t3YXJkXCIpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGNoIG9mIHZhbHVlKSB7XG4gICAgICBjb25zdCBhbGxvd2VkID0ga2V5KGVsLCBcImtleWRvd25cIiwgY2gpO1xuICAgICAga2V5KGVsLCBcImtleXByZXNzXCIsIGNoKTtcbiAgICAgIGlmIChhbGxvd2VkKSB7XG4gICAgICAgIGNvbnN0IGJlZm9yZSA9IGVsLnZhbHVlO1xuICAgICAgICBpZiAoIWRvY3VtZW50LmV4ZWNDb21tYW5kKFwiaW5zZXJ0VGV4dFwiLCBmYWxzZSwgY2gpIHx8IGVsLnZhbHVlID09PSBiZWZvcmUpIHtcbiAgICAgICAgICBzZXROYXRpdmUoZWwsIGJlZm9yZSArIGNoKTtcbiAgICAgICAgICBmaXJlSW5wdXQoZWwsIGNoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAga2V5KGVsLCBcImtleXVwXCIsIGNoKTtcbiAgICAgIGlmIChzLmtleURlbGF5KSBhd2FpdCBzbGVlcChzLmtleURlbGF5KTtcbiAgICB9XG4gIH1cbiAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbn1cblxuZnVuY3Rpb24gc2VsZWN0T3B0aW9uKGVsOiBFbGVtZW50LCB2YWx1ZTogc3RyaW5nLCBvcHRpb25UZXh0Pzogc3RyaW5nKSB7XG4gIGlmICghKGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpKSB0aHJvdyBuZXcgU3RlcEVycm9yKFwiRWwgZWxlbWVudG8gbm8gZXMgdW4gPHNlbGVjdD5cIik7XG4gIGNvbnN0IG9wdHMgPSBbLi4uZWwub3B0aW9uc107XG4gIGNvbnN0IGJ5VmFsdWUgPSBvcHRzLmZpbmQoKG8pID0+IG8udmFsdWUgPT09IHZhbHVlKTtcbiAgY29uc3QgYnlUZXh0ID0gb3B0aW9uVGV4dCA/IG9wdHMuZmluZCgobykgPT4gby50ZXh0LnRyaW0oKSA9PT0gb3B0aW9uVGV4dCkgOiB1bmRlZmluZWQ7XG4gIC8vIFNpIGVsIHZhbHVlIGFwdW50YSBhIG90cmEgb3BjacOzbiAodmFsdWVzIHBvciDDrW5kaWNlIHF1ZSBjYW1iaWFuKSwgbWFuZGEgZWwgdGV4dG8gdmlzaWJsZS5cbiAgY29uc3Qgb3B0ID1cbiAgICAoYnlWYWx1ZSAmJiBieVRleHQgJiYgYnlWYWx1ZS50ZXh0LnRyaW0oKSAhPT0gb3B0aW9uVGV4dCA/IGJ5VGV4dCA6IGJ5VmFsdWUpID8/XG4gICAgYnlUZXh0ID8/XG4gICAgb3B0cy5maW5kKChvKSA9PiBvLnRleHQudHJpbSgpID09PSB2YWx1ZSkgPz9cbiAgICBvcHRzLmZpbmQoKG8pID0+IG8udGV4dC50cmltKCkudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyh2YWx1ZS50b0xvd2VyQ2FzZSgpKSk7XG4gIGlmICghb3B0KSB0aHJvdyBuZXcgU3RlcEVycm9yKGBFbCBzZWxlY3Qgbm8gdGllbmUgbGEgb3BjacOzbiDCqyR7b3B0aW9uVGV4dCA/PyB2YWx1ZX3Cu2ApO1xuICBlbC5mb2N1cygpO1xuICBlbC52YWx1ZSA9IG9wdC52YWx1ZTtcbiAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJpbnB1dFwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRDaGVja2VkKGVsOiBFbGVtZW50LCB3YW50OiBib29sZWFuKSB7XG4gIGlmIChjaGVja2VkT2YoZWwpID09PSB3YW50KSByZXR1cm47XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYgZWwudHlwZSA9PT0gXCJyYWRpb1wiICYmICF3YW50KSB7XG4gICAgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIlVuIHJhZGlvIG5vIHNlIHB1ZWRlIGRlc21hcmNhcjsgbWFyY2Egb3RyYSBvcGNpw7NuIGRlbCBncnVwb1wiKTtcbiAgfVxuICBpZiAoaXNWaXNpYmxlKGVsKSkgYXdhaXQgcmVhbENsaWNrKGVsKTtcbiAgZWxzZSBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGVsLmxhYmVscz8uWzBdICYmIGlzVmlzaWJsZShlbC5sYWJlbHNbMF0pKSBhd2FpdCByZWFsQ2xpY2soZWwubGFiZWxzWzBdKTtcbiAgZWxzZSAoZWwgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XG4gIGlmIChjaGVja2VkT2YoZWwpICE9PSB3YW50ICYmIGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCkge1xuICAgIGVsLmNoZWNrZWQgPSB3YW50O1xuICAgIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImNoYW5nZVwiLCB7IGJ1YmJsZXM6IHRydWUgfSkpO1xuICB9XG59XG5cbmNvbnN0IEZPQ1VTQUJMRSA9ICdhW2hyZWZdLCBidXR0b24sIGlucHV0LCBzZWxlY3QsIHRleHRhcmVhLCBbdGFiaW5kZXhdOm5vdChbdGFiaW5kZXg9XCItMVwiXSksIFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pJztcblxuYXN5bmMgZnVuY3Rpb24gcHJlc3MoZWw6IEVsZW1lbnQsIGs6IHN0cmluZykge1xuICBjb25zdCBkb3duID0ga2V5KGVsLCBcImtleWRvd25cIiwgayk7XG4gIGlmIChrID09PSBcIkVudGVyXCIpIGtleShlbCwgXCJrZXlwcmVzc1wiLCBrKTtcbiAgaWYgKGRvd24pIHtcbiAgICBpZiAoayA9PT0gXCJFbnRlclwiKSB7XG4gICAgICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGVsLmZvcm0pIHtcbiAgICAgICAgLy8gRW52w61vIGltcGzDrWNpdG86IGVsIG5hdmVnYWRvciBjbGljYSBlbCBib3TDs24gZGUgc3VibWl0IHBvciBkZWZlY3RvLlxuICAgICAgICBjb25zdCBidG4gPSBlbC5mb3JtLnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KCdidXR0b25bdHlwZT1cInN1Ym1pdFwiXSwgYnV0dG9uOm5vdChbdHlwZV0pLCBpbnB1dFt0eXBlPVwic3VibWl0XCJdLCBpbnB1dFt0eXBlPVwiaW1hZ2VcIl0nKTtcbiAgICAgICAgaWYgKGJ0bikgYXdhaXQgcmVhbENsaWNrKGJ0bik7XG4gICAgICAgIGVsc2UgZWwuZm9ybS5yZXF1ZXN0U3VibWl0KCk7XG4gICAgICB9IGVsc2UgaWYgKGVsIGluc3RhbmNlb2YgSFRNTEJ1dHRvbkVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MQW5jaG9yRWxlbWVudCkge1xuICAgICAgICAoZWwgYXMgSFRNTEVsZW1lbnQpLmNsaWNrKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChrID09PSBcIlRhYlwiKSB7XG4gICAgICBjb25zdCBhbGwgPSBbLi4uZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oRk9DVVNBQkxFKV0uZmlsdGVyKChlKSA9PiBpc1Zpc2libGUoZSkgJiYgIShlIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmRpc2FibGVkKTtcbiAgICAgIGNvbnN0IGkgPSBhbGwuaW5kZXhPZihlbCBhcyBIVE1MRWxlbWVudCk7XG4gICAgICBhbGxbKGkgKyAxKSAlIGFsbC5sZW5ndGhdPy5mb2N1cygpO1xuICAgIH1cbiAgfVxuICBrZXkoZWwsIFwia2V5dXBcIiwgayk7XG59XG5cbi8qKiDCv0FjdGl2YXIgZXN0ZSBlbGVtZW50byBwdWVkZSBjYW1iaWFyIGRlIHDDoWdpbmE/ICovXG5mdW5jdGlvbiBtYXlOYXZpZ2F0ZShlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICBpZiAoZWwuY2xvc2VzdChcImFbaHJlZl1cIikpIHJldHVybiB0cnVlO1xuICBjb25zdCBidG4gPSBlbC5jbG9zZXN0KFwiYnV0dG9uLCBpbnB1dFwiKTtcbiAgaWYgKGJ0biBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50KSByZXR1cm4gISFidG4uZm9ybSAmJiBidG4udHlwZSA9PT0gXCJzdWJtaXRcIjtcbiAgaWYgKGJ0biBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHJldHVybiAhIWJ0bi5mb3JtICYmIChbXCJzdWJtaXRcIiwgXCJpbWFnZVwiXS5pbmNsdWRlcyhidG4udHlwZSkgfHwga2luZE9mKGJ0bikgPT09IFwiZmlsbFwiKTtcbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcnVuU3RlcChzdGVwOiBTdGVwLCBzOiBTZXR0aW5ncyk6IFByb21pc2U8U3RlcFJlc3VsdD4ge1xuICBjb25zdCB0aW1lb3V0ID0gc3RlcC50aW1lb3V0ID8/IHMudGltZW91dDtcbiAgbGV0IG5hdiA9IGZhbHNlO1xuICB0cnkge1xuICAgIGxldCB1c2VkOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gICAgLy8gQW50ZXMgZGUgYWN0dWFyLCBxdWUgbGEgcMOhZ2luYSB0ZXJtaW5lIGxvIHF1ZSBlc3TDoSBoYWNpZW5kbyAocGV0aWNpb25lcywgbG9hZGVycywgcmVuZGVycykuXG4gICAgY29uc3QgYWN0cyA9ICFbXCJ3YWl0Rm9yXCIsIFwiYXNzZXJ0VGV4dFwiXS5pbmNsdWRlcyhzdGVwLnR5cGUpO1xuICAgIGlmIChzLmF1dG9XYWl0ICYmIGFjdHMpIGF3YWl0IHNldHRsZSh0aW1lb3V0LCBzLmxvYWRlclNlbGVjdG9yKTtcbiAgICBjb25zdCB0YXJnZXQgPSBhc3luYyAodmlzaWJsZSA9IHRydWUpID0+IHtcbiAgICAgIGNvbnN0IHIgPSBhd2FpdCBmaW5kKHN0ZXAsIHRpbWVvdXQsIHZpc2libGUpO1xuICAgICAgdXNlZCA9IHIuc2VsZWN0b3I7XG4gICAgICBpZiAocy5hdXRvV2FpdCAmJiBhY3RzKSB7XG4gICAgICAgIGlmIChpc1Zpc2libGUoci5lbCkpIGF3YWl0IHNjcm9sbFRvKHIuZWwpO1xuICAgICAgICBjb25zdCB3aHkgPSBhd2FpdCB1bnRpbEFjdGlvbmFibGUoci5lbCwgdGltZW91dCwgaXNWaXNpYmxlKHIuZWwpLCBzLmxvYWRlclNlbGVjdG9yKTtcbiAgICAgICAgaWYgKHdoeSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihgwqske3N0ZXAubGFiZWwgPz8gci5zZWxlY3Rvcn3CuyAke3doeX1gKTtcbiAgICAgIH1cbiAgICAgIGlmIChzLmhpZ2hsaWdodCkgb3ZlcmxheS5mbGFzaChyLmVsLCBzdGVwLmxhYmVsID8/IHN0ZXAudHlwZSwgTWF0aC5tYXgoNDAwLCBzLnN0ZXBEZWxheSArIDIwMCksIENPTE9SUy5ydW4pO1xuICAgICAgcmV0dXJuIHIuZWw7XG4gICAgfTtcblxuICAgIHN3aXRjaCAoc3RlcC50eXBlKSB7XG4gICAgICBjYXNlIFwiY2xpY2tcIjoge1xuICAgICAgICBjb25zdCBlbCA9IGF3YWl0IHRhcmdldCgpO1xuICAgICAgICBuYXYgPSBtYXlOYXZpZ2F0ZShlbCk7XG4gICAgICAgIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBcImZpbGxcIjoge1xuICAgICAgICAvLyBUb2xlcmFudGU6IHVuIMKrZmlsbMK7IHNvYnJlIHVuIHNlbGVjdCBvIGNoZWNrYm94IChwLiBlai4gaW1wb3J0YWRvIGRlIERldlRvb2xzKSBoYWNlIGxvIGzDs2dpY28uXG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHNlbGVjdE9wdGlvbihlbCwgc3RlcC52YWx1ZSA/PyBcIlwiKTtcbiAgICAgICAgZWxzZSBpZiAoa2luZE9mKGVsKSA9PT0gXCJjaGVja1wiKSBhd2FpdCBzZXRDaGVja2VkKGVsLCAhW1wiXCIsIFwiZmFsc2VcIiwgXCJvZmZcIiwgXCIwXCJdLmluY2x1ZGVzKHN0ZXAudmFsdWUgPz8gXCJcIikpO1xuICAgICAgICBlbHNlIGF3YWl0IHR5cGVJbnRvKGVsLCBzdGVwLnZhbHVlID8/IFwiXCIsIHMpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJzZWxlY3RcIjpcbiAgICAgICAgc2VsZWN0T3B0aW9uKGF3YWl0IHRhcmdldChmYWxzZSksIHN0ZXAudmFsdWUgPz8gXCJcIiwgc3RlcC5vcHRpb25UZXh0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiY2hlY2tcIjpcbiAgICAgICAgYXdhaXQgc2V0Q2hlY2tlZChhd2FpdCB0YXJnZXQoZmFsc2UpLCBzdGVwLnZhbHVlICE9PSBcImZhbHNlXCIpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJwcmVzc1wiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gc3RlcC5zZWxlY3RvciA/IGF3YWl0IHRhcmdldChmYWxzZSkgOiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA/PyBkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgbmF2ID0gKHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKSA9PT0gXCJFbnRlclwiICYmIG1heU5hdmlnYXRlKGVsKTtcbiAgICAgICAgYXdhaXQgcHJlc3MoZWwsIHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwid2FpdEZvclwiOlxuICAgICAgICBhd2FpdCB0YXJnZXQoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYXNzZXJ0VGV4dFwiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgY29uc3Qgd2FudCA9IChzdGVwLnZhbHVlID8/IFwiXCIpLnRyaW0oKTtcbiAgICAgICAgLy8gUmVpbnRlbnRhIGhhc3RhIGVsIHRpbWVvdXQ6IGVsIHRleHRvIHB1ZWRlIHRhcmRhciBlbiBhcGFyZWNlciAocmVzcHVlc3RhIGRlbCBzZXJ2aWRvcikuXG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIGxldCBoYXZlID0gXCJcIjtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICBoYXZlID0gZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50ID8gdmFsdWVPZihlbCkgOiB0ZXh0T2YoZWwpO1xuICAgICAgICAgIGlmIChoYXZlLmluY2x1ZGVzKHdhbnQpKSBicmVhaztcbiAgICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHRocm93IG5ldyBTdGVwRXJyb3IoYFNlIGVzcGVyYWJhIMKrJHt3YW50fcK7IHkgaGF5IMKrJHtoYXZlLnNsaWNlKDAsIDgwKX3Cu2ApO1xuICAgICAgICAgIGF3YWl0IHNsZWVwKDE1MCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgU3RlcEVycm9yKGBUaXBvIGRlIHBhc28gwqske3N0ZXAudHlwZX3CuyBubyBzZSBlamVjdXRhIGVuIGxhIHDDoWdpbmFgKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHVzZWRTZWxlY3RvcjogdXNlZCwgbWF5TmF2aWdhdGU6IG5hdiB9O1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpIH07XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhpZ2hsaWdodChzZWxlY3RvcnM6IHN0cmluZ1tdKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlKHNlbGVjdG9ycyk7XG4gIGlmICghcikgcmV0dXJuIGZhbHNlO1xuICBhd2FpdCBzY3JvbGxUbyhyLmVsKTtcbiAgb3ZlcmxheS5mbGFzaChyLmVsLCByLnNlbGVjdG9yLCAxNTAwLCBDT0xPUlMuY2xpY2spO1xuICByZXR1cm4gdHJ1ZTtcbn1cbiIsCiAgICAiLy8gR3JhYmFkb3IuIERvcyBtb2Rvczpcbi8vICAgcmVjb3JkIOKGkiBsYXMgaW50ZXJhY2Npb25lcyBvY3VycmVuIGRlIHZlcmRhZCB5IHNlIHZhbiBhbm90YW5kby5cbi8vICAgcG9pbnQgIOKGkiDCq3Nlw7FhbGFywrs6IGxvcyBjbGlja3MgZW4gYm90b25lcy9lbmxhY2VzIE5PIHNlIGVqZWN1dGFuLCBzb2xvIHNlIGFub3Rhbi5cbi8vICAgICAgICAgICAgSW5wdXRzLCBzZWxlY3RzIHkgY2hlY2tib3hlcyBmdW5jaW9uYW4gbm9ybWFsLCBhc8OtIHF1ZSBzZSBncmFiYSBzdSBlc3RhZG8uXG4vL1xuLy8gUmVnbGEgY2xhdmU6IGNsaWNhciB1biBpbnB1dCBubyBnZW5lcmEgdW4gwqtjbGlja8K7OyBnZW5lcmEgdW4gwqtmaWxswrsgY29uIHN1IGNvbnRlbmlkbyxcbi8vIHF1ZSBzZSB2YSBhY3R1YWxpemFuZG8gbWllbnRyYXMgZXNjcmliZXMgKGVsIGJhY2tncm91bmQgZnVzaW9uYSBwYXNvcyBkZWwgbWlzbW8gY2FtcG8pLlxuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvbWVzc2FnZXNcIjtcbmltcG9ydCB7IENPTE9SUywgb3ZlcmxheSB9IGZyb20gXCIuL292ZXJsYXlcIjtcbmltcG9ydCB7IGFjdGlvbmFibGUsIGJ1aWxkU2VsZWN0b3JzLCBjaGVja2VkT2YsIGRlc2NyaWJlLCBraW5kT2YsIHRyYWNrVm9sYXRpbGVDbGFzc2VzLCB2YWx1ZU9mLCB0eXBlIEFjdGlvbktpbmQgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG50eXBlIE1vZGUgPSBcInJlY29yZFwiIHwgXCJwb2ludFwiO1xuXG5sZXQgbW9kZTogTW9kZSB8IG51bGwgPSBudWxsO1xubGV0IHNlbmQ6IChzOiBSZWNvcmRlZFN0ZXApID0+IHZvaWQgPSAoKSA9PiB7fTtcbmNvbnN0IHBlbmRpbmdGaWxsID0gbmV3IE1hcDxFbGVtZW50LCBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0Pj4oKTtcblxuY29uc3QgVkVSQjogUmVjb3JkPEFjdGlvbktpbmQsIHN0cmluZz4gPSB7IGNsaWNrOiBcIkNsaWNrXCIsIGZpbGw6IFwiRXNjcmliaXJcIiwgc2VsZWN0OiBcIlNlbGVjY2lvbmFyXCIsIGNoZWNrOiBcIk1hcmNhclwiLCBmaWxlOiBcIkZpY2hlcm9cIiB9O1xuXG4vKiogQ29udmllcnRlIHVuIGVsZW1lbnRvIGVuIGVsIHBhc28gcXVlIGxlIGNvcnJlc3BvbmRlLCBjb24gc3UgZXN0YWRvIGFjdHVhbC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjYXB0dXJlKGVsOiBFbGVtZW50KTogUmVjb3JkZWRTdGVwIHwgbnVsbCB7XG4gIGNvbnN0IGtpbmQgPSBraW5kT2YoZWwpO1xuICBpZiAoa2luZCA9PT0gXCJmaWxlXCIpIHJldHVybiBudWxsO1xuICBjb25zdCBbc2VsZWN0b3IsIC4uLmZhbGxiYWNrc10gPSBidWlsZFNlbGVjdG9ycyhlbCk7XG4gIGNvbnN0IGJhc2UgPSB7IHNlbGVjdG9yLCBmYWxsYmFja3MsIGxhYmVsOiBkZXNjcmliZShlbCkgfTtcbiAgc3dpdGNoIChraW5kKSB7XG4gICAgY2FzZSBcImZpbGxcIjpcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwiZmlsbFwiLCB2YWx1ZTogdmFsdWVPZihlbCksIHNlY3JldDogKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLnR5cGUgPT09IFwicGFzc3dvcmRcIiB8fCB1bmRlZmluZWQgfTtcbiAgICBjYXNlIFwic2VsZWN0XCI6IHtcbiAgICAgIGNvbnN0IHMgPSBlbCBhcyBIVE1MU2VsZWN0RWxlbWVudDtcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwic2VsZWN0XCIsIHZhbHVlOiBzLnZhbHVlLCBvcHRpb25UZXh0OiBzLnNlbGVjdGVkT3B0aW9uc1swXT8udGV4dC50cmltKCkgfTtcbiAgICB9XG4gICAgY2FzZSBcImNoZWNrXCI6XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCB0eXBlOiBcImNoZWNrXCIsIHZhbHVlOiBTdHJpbmcoY2hlY2tlZE9mKGVsKSkgfTtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgdHlwZTogXCJjbGlja1wiIH07XG4gIH1cbn1cblxuZnVuY3Rpb24gZW1pdChlbDogRWxlbWVudCwgc3RlcDogUmVjb3JkZWRTdGVwIHwgbnVsbCkge1xuICBpZiAoIXN0ZXApIHJldHVybjtcbiAgc2VuZChzdGVwKTtcbiAgY29uc3Qgd2hhdCA9IHN0ZXAudHlwZSA9PT0gXCJmaWxsXCIgPyAoc3RlcC5zZWNyZXQgPyBcIuKAouKAouKAouKAolwiIDogYMKrJHsoc3RlcC52YWx1ZSA/PyBcIlwiKS5zbGljZSgwLCAzMCl9wrtgKSA6IFwiXCI7XG4gIG92ZXJsYXkudG9hc3QoYOKckyAke1ZFUkJbc3RlcC50eXBlIGFzIEFjdGlvbktpbmRdID8/IHN0ZXAudHlwZX06ICR7c3RlcC5sYWJlbH0gJHt3aGF0fWAudHJpbSgpLCBDT0xPUlNba2luZE9mKGVsKV0pO1xufVxuXG5mdW5jdGlvbiBmbHVzaEZpbGxzKCkge1xuICBmb3IgKGNvbnN0IFtlbCwgdF0gb2YgcGVuZGluZ0ZpbGwpIHtcbiAgICBjbGVhclRpbWVvdXQodCk7XG4gICAgc2VuZChjYXB0dXJlKGVsKSEpO1xuICB9XG4gIHBlbmRpbmdGaWxsLmNsZWFyKCk7XG59XG5cbmZ1bmN0aW9uIHNjaGVkdWxlRmlsbChlbDogRWxlbWVudCkge1xuICBjbGVhclRpbWVvdXQocGVuZGluZ0ZpbGwuZ2V0KGVsKSk7XG4gIHBlbmRpbmdGaWxsLnNldChcbiAgICBlbCxcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHBlbmRpbmdGaWxsLmRlbGV0ZShlbCk7XG4gICAgICBjb25zdCBzID0gY2FwdHVyZShlbCk7XG4gICAgICBpZiAocykgc2VuZChzKTtcbiAgICB9LCAzNTApLFxuICApO1xufVxuXG5jb25zdCB0YXJnZXRPZiA9IChlOiBFdmVudCk6IEVsZW1lbnQgfCBudWxsID0+IHtcbiAgY29uc3QgdCA9IGUuY29tcG9zZWRQYXRoKClbMF07XG4gIHJldHVybiB0IGluc3RhbmNlb2YgRWxlbWVudCA/IHQgOiBudWxsO1xufTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIExpc3RlbmVycyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gb25Nb3ZlKGU6IE1vdXNlRXZlbnQpIHtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGNvbnN0IGhpbnQgPSBrID09PSBcImZpbGVcIiA/IFwiRmljaGVybyAobm8gYXV0b21hdGl6YWJsZSlcIiA6IGAke1ZFUkJba119IMK3ICR7ZGVzY3JpYmUoZWwpfWA7XG4gIG92ZXJsYXkuc2hvdyhlbCwgaGludCwgQ09MT1JTW2tdKTtcbn1cblxuLyoqIEVuIG1vZG8gc2XDsWFsYXIsIGJsb3F1ZWEgYm90b25lcy9lbmxhY2VzIHBhcmEgcXVlIG5vIGhhZ2FuIG5hZGEgKGVsIHJlc3RvIGZ1bmNpb25hIG5vcm1hbCkuICovXG5mdW5jdGlvbiBibG9ja0luUG9pbnQoZTogRXZlbnQpIHtcbiAgaWYgKG1vZGUgIT09IFwicG9pbnRcIiB8fCAhZS5pc1RydXN0ZWQpIHJldHVybjtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gIGlmIChraW5kT2YoYWN0aW9uYWJsZSh0KSkgPT09IFwiY2xpY2tcIikge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBlLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpO1xuICB9XG59XG5cbmZ1bmN0aW9uIG9uQ2xpY2soZTogTW91c2VFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0IHx8IG92ZXJsYXkub3ducyh0KSkgcmV0dXJuO1xuICBibG9ja0luUG9pbnQoZSk7XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGlmIChrID09PSBcImZpbGVcIikgcmV0dXJuIG92ZXJsYXkudG9hc3QoXCJMb3MgaW5wdXRzIGRlIGZpY2hlcm8gbm8gc2UgcHVlZGVuIGF1dG9tYXRpemFyXCIsIHVuZGVmaW5lZCwgdHJ1ZSk7XG4gIGlmIChrID09PSBcImNoZWNrXCIgfHwgayA9PT0gXCJzZWxlY3RcIikgcmV0dXJuOyAvLyBzZSBncmFiYW4gZW4gXCJjaGFuZ2VcIiBjb24gZWwgZXN0YWRvIGZpbmFsXG4gIGZsdXNoRmlsbHMoKTtcbiAgaWYgKGsgPT09IFwiZmlsbFwiKSB7XG4gICAgLy8gQ2xpY2FyIHVuIGlucHV0IGNvbiBjb250ZW5pZG8gPSByZWxsZW5hcmxvIGNvbiBlc2UgY29udGVuaWRvLlxuICAgIC8vIFNpIGVzdMOhIHZhY8OtbywgZWwgcGFzbyBzZSBjcmVhIGVuIGN1YW50byBlc2NyaWJhcy5cbiAgICBpZiAodmFsdWVPZihlbCkpIGVtaXQoZWwsIGNhcHR1cmUoZWwpKTtcbiAgICByZXR1cm47XG4gIH1cbiAgZW1pdChlbCwgY2FwdHVyZShlbCkpO1xufVxuXG5mdW5jdGlvbiBvbklucHV0KGU6IEV2ZW50KSB7XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgaWYgKGtpbmRPZihlbCkgPT09IFwiZmlsbFwiKSBzY2hlZHVsZUZpbGwoZWwpO1xufVxuXG5mdW5jdGlvbiBvbkNoYW5nZShlOiBFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGNvbnN0IHQgPSB0YXJnZXRPZihlKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGNvbnN0IGVsID0gYWN0aW9uYWJsZSh0KTtcbiAgY29uc3QgayA9IGtpbmRPZihlbCk7XG4gIGlmIChrID09PSBcImZpbGxcIikge1xuICAgIGNsZWFyVGltZW91dChwZW5kaW5nRmlsbC5nZXQoZWwpKTtcbiAgICBwZW5kaW5nRmlsbC5kZWxldGUoZWwpO1xuICAgIHNlbmQoY2FwdHVyZShlbCkhKTtcbiAgfSBlbHNlIGlmIChrID09PSBcInNlbGVjdFwiIHx8IGsgPT09IFwiY2hlY2tcIikge1xuICAgIGZsdXNoRmlsbHMoKTtcbiAgICBlbWl0KGVsLCBjYXB0dXJlKGVsKSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25LZXkoZTogS2V5Ym9hcmRFdmVudCkge1xuICBpZiAoIWUuaXNUcnVzdGVkKSByZXR1cm47XG4gIGlmIChtb2RlID09PSBcInBvaW50XCIgJiYgZS5rZXkgPT09IFwiRXNjYXBlXCIpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgc3RvcEhhbmRsZXIoKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQpIHJldHVybjtcbiAgaWYgKGUua2V5ID09PSBcIkVudGVyXCIgJiYgdCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgJiYga2luZE9mKHQpID09PSBcImZpbGxcIikge1xuICAgIGZsdXNoRmlsbHMoKTtcbiAgICBzZW5kKHsgdHlwZTogXCJwcmVzc1wiLCB2YWx1ZTogXCJFbnRlclwiLCBzZWxlY3RvcjogYnVpbGRTZWxlY3RvcnModClbMF0sIGxhYmVsOiBkZXNjcmliZSh0KSB9KTtcbiAgICBvdmVybGF5LnRvYXN0KGDinJMgVGVjbGE6IEVudGVyIGVuICR7ZGVzY3JpYmUodCl9YCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25MZWF2ZSgpIHtcbiAgZmx1c2hGaWxscygpO1xufVxuXG5jb25zdCBvblNjcm9sbCA9ICgpID0+IG92ZXJsYXkuaGlkZSgpO1xuXG5sZXQgc3RvcEhhbmRsZXI6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuY29uc3QgbGlzdGVuZXJzOiBbc3RyaW5nLCBFdmVudExpc3RlbmVyXVtdID0gW1xuICBbXCJtb3VzZW1vdmVcIiwgb25Nb3ZlIGFzIEV2ZW50TGlzdGVuZXJdLFxuICBbXCJwb2ludGVyZG93blwiLCBibG9ja0luUG9pbnRdLFxuICBbXCJtb3VzZWRvd25cIiwgYmxvY2tJblBvaW50XSxcbiAgW1wicG9pbnRlcnVwXCIsIGJsb2NrSW5Qb2ludF0sXG4gIFtcIm1vdXNldXBcIiwgYmxvY2tJblBvaW50XSxcbiAgW1wiY2xpY2tcIiwgb25DbGljayBhcyBFdmVudExpc3RlbmVyXSxcbiAgW1wiaW5wdXRcIiwgb25JbnB1dF0sXG4gIFtcImNoYW5nZVwiLCBvbkNoYW5nZV0sXG4gIFtcImtleWRvd25cIiwgb25LZXkgYXMgRXZlbnRMaXN0ZW5lcl0sXG5dO1xuXG5leHBvcnQgZnVuY3Rpb24gc3RhcnRSZWNvcmRpbmcobTogTW9kZSwgc2luazogKHM6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCwgb25TdG9wOiAoKSA9PiB2b2lkKSB7XG4gIGlmIChtb2RlKSBzdG9wUmVjb3JkaW5nKCk7XG4gIG1vZGUgPSBtO1xuICBzZW5kID0gc2luaztcbiAgc3RvcEhhbmRsZXIgPSBvblN0b3A7XG4gIG92ZXJsYXkub25TdG9wID0gb25TdG9wO1xuICB0cmFja1ZvbGF0aWxlQ2xhc3Nlcyh0cnVlKTtcbiAgZm9yIChjb25zdCBbZXYsIGZuXSBvZiBsaXN0ZW5lcnMpIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2LCBmbiwgdHJ1ZSk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgb25MZWF2ZSk7XG4gIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIG9uU2Nyb2xsLCB0cnVlKTtcbiAgLy8gTGEgcMOtbGRvcmEgc29sbyBlbiBsYSBww6FnaW5hIHByaW5jaXBhbCwgbm8gZW4gY2FkYSBpZnJhbWUuXG4gIGlmICh3aW5kb3cgPT09IHdpbmRvdy50b3ApIG92ZXJsYXkuc2V0UGlsbChtKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0b3BSZWNvcmRpbmcoKSB7XG4gIGZsdXNoRmlsbHMoKTtcbiAgZm9yIChjb25zdCBbZXYsIGZuXSBvZiBsaXN0ZW5lcnMpIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKGV2LCBmbiwgdHJ1ZSk7XG4gIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgb25MZWF2ZSk7XG4gIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIG9uU2Nyb2xsLCB0cnVlKTtcbiAgdHJhY2tWb2xhdGlsZUNsYXNzZXMoZmFsc2UpO1xuICBtb2RlID0gbnVsbDtcbiAgb3ZlcmxheS5oaWRlKCk7XG4gIG92ZXJsYXkuc2V0UGlsbChudWxsKTtcbn1cblxuLyoqIFNlbGVjY2nDs24gZGUgdW4gw7puaWNvIGVsZW1lbnRvIChwYXJhIHJlLWFwdW50YXIgdW4gcGFzbykuIENsaWNrcyBibG9xdWVhZG9zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBpY2tPbmNlKCk6IFByb21pc2U8UmVjb3JkZWRTdGVwIHwgbnVsbD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBjb25zdCBibG9jayA9IChlOiBFdmVudCkgPT4ge1xuICAgICAgaWYgKG92ZXJsYXkub3ducyh0YXJnZXRPZihlKSkpIHJldHVybjtcbiAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gICAgfTtcbiAgICBjb25zdCBkb25lID0gKHI6IFJlY29yZGVkU3RlcCB8IG51bGwpID0+IHtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyLCB0cnVlKTtcbiAgICAgIGZvciAoY29uc3QgZXYgb2YgW1wicG9pbnRlcmRvd25cIiwgXCJtb3VzZWRvd25cIiwgXCJwb2ludGVydXBcIiwgXCJtb3VzZXVwXCJdKSB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihldiwgYmxvY2ssIHRydWUpO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBjbGljaywgdHJ1ZSk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwga2V5LCB0cnVlKTtcbiAgICAgIG92ZXJsYXkuaGlkZSgpO1xuICAgICAgY2FuY2VsUGljayA9ICgpID0+IHt9O1xuICAgICAgaWYgKCFtb2RlKSB0cmFja1ZvbGF0aWxlQ2xhc3NlcyhmYWxzZSk7XG4gICAgICByZXNvbHZlKHIpO1xuICAgIH07XG4gICAgY29uc3QgY2xpY2sgPSAoZTogTW91c2VFdmVudCkgPT4ge1xuICAgICAgYmxvY2soZSk7XG4gICAgICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gICAgICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gICAgICBkb25lKGNhcHR1cmUoYWN0aW9uYWJsZSh0KSkgPz8gbnVsbCk7XG4gICAgfTtcbiAgICBjb25zdCBrZXkgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZG9uZShudWxsKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRyYWNrVm9sYXRpbGVDbGFzc2VzKHRydWUpO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyLCB0cnVlKTtcbiAgICBmb3IgKGNvbnN0IGV2IG9mIFtcInBvaW50ZXJkb3duXCIsIFwibW91c2Vkb3duXCIsIFwicG9pbnRlcnVwXCIsIFwibW91c2V1cFwiXSkgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXYsIGJsb2NrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNsaWNrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwga2V5LCB0cnVlKTtcbiAgICBjYW5jZWxQaWNrID0gKCkgPT4gZG9uZShudWxsKTtcbiAgICBpZiAod2luZG93ID09PSB3aW5kb3cudG9wKSBvdmVybGF5LnRvYXN0KFwiQ2xpY2EgZWwgZWxlbWVudG8gKEVzYyBwYXJhIGNhbmNlbGFyKVwiKTtcbiAgfSk7XG59XG5cbmV4cG9ydCBsZXQgY2FuY2VsUGljazogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuIiwKICAgICIvLyBDb250ZW50IHNjcmlwdDogcHVlbnRlIGVudHJlIGxhIHDDoWdpbmEgeSBsYSBleHRlbnNpw7NuLiBTZSBpbnllY3RhIGVuIHRvZG9zIGxvcyBmcmFtZXMuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCwgVG9CYWNrZ3JvdW5kLCBUb0NvbnRlbnQgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgaGlnaGxpZ2h0LCBydW5TdGVwIH0gZnJvbSBcIi4vcGxheWVyXCI7XG5pbXBvcnQgeyBjYW5jZWxQaWNrLCBwaWNrT25jZSwgc3RhcnRSZWNvcmRpbmcsIHN0b3BSZWNvcmRpbmcgfSBmcm9tIFwiLi9yZWNvcmRlclwiO1xuaW1wb3J0IHsgYnVpbGRTZWxlY3RvcnMsIHJlc29sdmUgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIF9fcmFzdHJvPzogYm9vbGVhbjtcbiAgfVxufVxuXG5mdW5jdGlvbiB0b0JnPFQgPSBhbnk+KG1zZzogVG9CYWNrZ3JvdW5kKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTGEgZXh0ZW5zacOzbiBzZSByZWNhcmfDsyB5IGVzdGUgc2NyaXB0IHF1ZWTDsyBodcOpcmZhbm8uXG4gICAgc3RvcFJlY29yZGluZygpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodW5kZWZpbmVkKTtcbiAgfVxufVxuXG5jb25zdCBzaW5rID0gKHN0ZXA6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RlcFwiLCBzdGVwIH0pO1xuY29uc3Qgb25TdG9wID0gKCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RvcFwiIH0pO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRnJhbWVzOiBoYW5kc2hha2UgcG9yIHBvc3RNZXNzYWdlIChmdW5jaW9uYSB0YW1iacOpbiBjcm9zcy1vcmlnaW4pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBNU0cgPSBcIl9fcmFzdHJvX2ZyYW1lXCI7XG4vKiogdG9rZW4g4oaSIDxpZnJhbWU+IGhpam8gcXVlIHNlIGFudW5jacOzIGNvbiDDqWwuICovXG5jb25zdCBhbm5vdW5jZWQgPSBuZXcgTWFwPHN0cmluZywgRWxlbWVudD4oKTtcblxuZnVuY3Rpb24gZnJhbWVFbGVtZW50Rm9yKHNvdXJjZTogTWVzc2FnZUV2ZW50U291cmNlIHwgbnVsbCk6IEVsZW1lbnQgfCB1bmRlZmluZWQge1xuICBpZiAoIXNvdXJjZSkgcmV0dXJuO1xuICByZXR1cm4gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWUsIGZyYW1lXCIpXS5maW5kKChmKSA9PiAoZiBhcyBIVE1MSUZyYW1lRWxlbWVudCkuY29udGVudFdpbmRvdyA9PT0gc291cmNlKTtcbn1cblxuZnVuY3Rpb24gb25GcmFtZU1lc3NhZ2UoZTogTWVzc2FnZUV2ZW50KSB7XG4gIGNvbnN0IGQgPSBlLmRhdGE7XG4gIGlmICghZCB8fCB0eXBlb2YgZCAhPT0gXCJvYmplY3RcIiB8fCBkW01TR10gPT0gbnVsbCB8fCB0eXBlb2YgZC50b2tlbiAhPT0gXCJzdHJpbmdcIikgcmV0dXJuO1xuICBpZiAoZFtNU0ddID09PSBcImFubm91bmNlXCIpIHtcbiAgICBjb25zdCBlbCA9IGZyYW1lRWxlbWVudEZvcihlLnNvdXJjZSk7XG4gICAgaWYgKGVsKSBhbm5vdW5jZWQuc2V0KGQudG9rZW4sIGVsKTtcbiAgfSBlbHNlIGlmIChkW01TR10gPT09IFwicHJvYmVcIiAmJiBlLnNvdXJjZSA9PT0gd2luZG93LnBhcmVudCAmJiB3aW5kb3cgIT09IHdpbmRvdy50b3ApIHtcbiAgICB2b2lkIHRvQmcoeyBraW5kOiBcImZyYW1lOnByb2JlXCIsIHRva2VuOiBkLnRva2VuIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbGVjdG9yc0ZvckFubm91bmNlZCh0b2tlbjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXSB8IG51bGw+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMCAmJiAhYW5ub3VuY2VkLmhhcyh0b2tlbik7IGkrKykgYXdhaXQgc2xlZXAoNTApO1xuICBjb25zdCBlbCA9IGFubm91bmNlZC5nZXQodG9rZW4pO1xuICBhbm5vdW5jZWQuZGVsZXRlKHRva2VuKTtcbiAgcmV0dXJuIGVsID8gYnVpbGRTZWxlY3RvcnMoZWwpIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVzb2x2ZUZyYW1lKHNlbGVjdG9yczogc3RyaW5nW10sIHRpbWVvdXQ6IG51bWJlcik6IFByb21pc2U8eyB0b2tlbj86IHN0cmluZzsgZXJyb3I/OiBzdHJpbmcgfT4ge1xuICBjb25zdCBlbmQgPSBwZXJmb3JtYW5jZS5ub3coKSArIHRpbWVvdXQ7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgY29uc3QgciA9IHJlc29sdmUoc2VsZWN0b3JzKTtcbiAgICBjb25zdCB3aW4gPSByICYmIChyLmVsIGFzIEhUTUxJRnJhbWVFbGVtZW50KS5jb250ZW50V2luZG93O1xuICAgIGlmICh3aW4pIHtcbiAgICAgIGNvbnN0IHRva2VuID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICAgIHdpbi5wb3N0TWVzc2FnZSh7IFtNU0ddOiBcInByb2JlXCIsIHRva2VuIH0sIFwiKlwiKTtcbiAgICAgIHJldHVybiB7IHRva2VuIH07XG4gICAgfVxuICAgIGlmIChwZXJmb3JtYW5jZS5ub3coKSA+IGVuZCkgcmV0dXJuIHsgZXJyb3I6IGBObyBzZSBlbmNvbnRyw7MgZWwgaWZyYW1lIMKrJHtzZWxlY3RvcnNbMF19wrtgIH07XG4gICAgYXdhaXQgc2xlZXAoMTAwKTtcbiAgfVxufVxuXG5pZiAoIXdpbmRvdy5fX3Jhc3Rybykge1xuICB3aW5kb3cuX19yYXN0cm8gPSB0cnVlO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgb25GcmFtZU1lc3NhZ2UpO1xuXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiBUb0NvbnRlbnQsIF9zZW5kZXIsIHJlcGx5KSA9PiB7XG4gICAgc3dpdGNoIChtc2cua2luZCkge1xuICAgICAgY2FzZSBcInBpbmdcIjpcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvblwiOlxuICAgICAgICBzdGFydFJlY29yZGluZyhtc2cubW9kZSwgc2luaywgb25TdG9wKTtcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvZmZcIjpcbiAgICAgICAgc3RvcFJlY29yZGluZygpO1xuICAgICAgICByZXBseSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICBjYXNlIFwicnVuLXN0ZXBcIjpcbiAgICAgICAgcnVuU3RlcChtc2cuc3RlcCwgbXNnLnNldHRpbmdzKS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIHJlc3B1ZXN0YSBhc8OtbmNyb25hXG4gICAgICBjYXNlIFwiaGlnaGxpZ2h0XCI6XG4gICAgICAgIGhpZ2hsaWdodChbbXNnLnNlbGVjdG9yLCAuLi4obXNnLmZhbGxiYWNrcyA/PyBbXSldKS50aGVuKChmb3VuZCkgPT4gcmVwbHkoeyBvazogZm91bmQgfSkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrXCI6XG4gICAgICAgIC8vIFNlIGRpZnVuZGUgYSB0b2RvcyBsb3MgZnJhbWVzOyByZXNwb25kZSBlbCBmcmFtZSBkb25kZSBjbGlxdWUgZWwgdXN1YXJpbyxcbiAgICAgICAgLy8gdHJhcyBwZWRpciBhbCBiYWNrZ3JvdW5kIHF1ZSBhw7FhZGEgbGEgcnV0YSBkZSBpZnJhbWVzLlxuICAgICAgICBwaWNrT25jZSgpLnRoZW4oYXN5bmMgKHN0ZXApID0+IHJlcGx5KHN0ZXAgPyAoKGF3YWl0IHRvQmc8UmVjb3JkZWRTdGVwPih7IGtpbmQ6IFwiZnJhbWU6bG9jYXRlXCIsIHN0ZXAgfSkpID8/IHN0ZXApIDogbnVsbCkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrOmNhbmNlbFwiOlxuICAgICAgICBjYW5jZWxQaWNrKCk7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTphbm5vdW5jZVwiOlxuICAgICAgICB3aW5kb3cucGFyZW50LnBvc3RNZXNzYWdlKHsgW01TR106IFwiYW5ub3VuY2VcIiwgdG9rZW46IG1zZy50b2tlbiB9LCBcIipcIik7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTpzZWxlY3RvcnNcIjpcbiAgICAgICAgc2VsZWN0b3JzRm9yQW5ub3VuY2VkKG1zZy50b2tlbikudGhlbihyZXBseSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgY2FzZSBcImZyYW1lOnJlc29sdmVcIjpcbiAgICAgICAgcmVzb2x2ZUZyYW1lKG1zZy5zZWxlY3RvcnMsIG1zZy50aW1lb3V0KS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcblxuICAvLyBBbCBjYXJnYXIgdW5hIHDDoWdpbmEgbnVldmEsIMK/c2VndWltb3MgZ3JhYmFuZG8gZW4gZXN0YSBwZXN0YcOxYT9cbiAgdG9CZzx7IG1vZGU/OiBcInJlY29yZFwiIHwgXCJwb2ludFwiIH0+KHsga2luZDogXCJyZWNvcmQ6c3RhdHVzXCIgfSkudGhlbigocikgPT4ge1xuICAgIGlmIChyPy5tb2RlKSBzdGFydFJlY29yZGluZyhyLm1vZGUsIHNpbmssIG9uU3RvcCk7XG4gIH0pO1xufVxuIgogIF0sCiAgIm1hcHBpbmdzIjogIjs7RUFHTyxTQUFTLGNBQWMsQ0FBQyxHQUFvQjtBQUFBLElBQ2pELE9BQ0UsRUFBRSxTQUFTLE1BQ1gsU0FBUyxLQUFLLENBQUMsS0FDZixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLG9CQUFvQixLQUFLLENBQUMsS0FDMUIsa0JBQWtCLEtBQUssQ0FBQyxLQUN4Qix1RkFBdUYsS0FBSyxDQUFDLEtBQzVGLHVCQUF1QixLQUFLLENBQUMsS0FBSyxTQUFTLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQyxLQUM1RCwyQ0FBMkMsS0FBSyxDQUFDO0FBQUE7QUFBQSxFQUk5QyxJQUFNLFFBQVEsQ0FBQyxPQUFlLElBQUksUUFBYyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQzs7O0VDZC9FLElBQU0sT0FBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFDTCxJQUFNLFNBQVMsRUFBRSxPQUFPLFdBQVcsTUFBTSxXQUFXLFFBQVEsV0FBVyxPQUFPLFdBQVcsTUFBTSxXQUFXLEtBQUssVUFBVTtBQUFBO0FBQUEsRUFFaEksTUFBTSxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ1E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDUixTQUFxQixNQUFNO0FBQUEsSUFFbkIsTUFBTSxHQUFHO0FBQUEsTUFDZixJQUFJLEtBQUssTUFBTTtBQUFBLFFBQWE7QUFBQSxNQUM1QixLQUFLLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFBQSxNQUN4QyxLQUFLLEtBQUssS0FBSztBQUFBLE1BQ2YsTUFBTSxPQUFPLEtBQUssS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFBQSxNQUNwRCxLQUFLLFlBQVksVUFBVTtBQUFBO0FBQUE7QUFBQSxNQUczQixLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE9BQU8sS0FBSyxjQUFjLE9BQU87QUFBQSxNQUN0QyxLQUFLLFdBQVcsS0FBSyxjQUFjLE1BQU07QUFBQSxNQUN6QyxLQUFLLFNBQVMsS0FBSyxjQUFjLFNBQVM7QUFBQSxNQUMxQyxLQUFLLGNBQWMsUUFBUSxFQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUFBLFFBQzdELEVBQUUsZ0JBQWdCO0FBQUEsUUFDbEIsS0FBSyxPQUFPO0FBQUEsT0FDYjtBQUFBLE1BQ0QsU0FBUyxnQkFBZ0IsWUFBWSxLQUFLLElBQUk7QUFBQTtBQUFBLElBR2hELElBQUksQ0FBQyxJQUFpQztBQUFBLE1BQ3BDLE9BQU8sQ0FBQyxDQUFDLEtBQUssUUFBUSxjQUFjLFNBQVMsT0FBTyxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQVMsRUFBRTtBQUFBO0FBQUEsSUFHeEYsSUFBSSxDQUFDLElBQWEsTUFBYyxRQUFnQixPQUFPLE9BQU87QUFBQSxNQUM1RCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLE1BQ25DLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTztBQUFBLFFBQzVCLFNBQVM7QUFBQSxRQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU87QUFBQSxRQUFPLEtBQUssR0FBRyxFQUFFLE1BQU07QUFBQSxRQUFPLE9BQU8sR0FBRyxFQUFFLFFBQVE7QUFBQSxRQUFPLFFBQVEsR0FBRyxFQUFFLFNBQVM7QUFBQSxNQUNySCxDQUFDO0FBQUEsTUFDRCxLQUFLLElBQUksTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQ3ZDLEtBQUssSUFBSSxNQUFNLFlBQVksT0FBTyxLQUFLO0FBQUEsTUFDdkMsS0FBSyxJQUFJLGNBQWM7QUFBQSxNQUN2QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUEsTUFDekIsTUFBTSxRQUFRLEVBQUUsTUFBTTtBQUFBLE1BQ3RCLEtBQUssSUFBSSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxPQUFPLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFBQSxNQUMzRSxLQUFLLElBQUksTUFBTSxNQUFNLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxHQUFHLEVBQUUsU0FBUztBQUFBO0FBQUEsSUFHakUsSUFBSSxHQUFHO0FBQUEsTUFDTCxJQUFJLENBQUMsS0FBSztBQUFBLFFBQUs7QUFBQSxNQUNmLEtBQUssSUFBSSxNQUFNLFVBQVU7QUFBQSxNQUN6QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUkzQixLQUFLLENBQUMsSUFBYSxNQUFjLEtBQUssS0FBSyxRQUFnQixPQUFPLEtBQUs7QUFBQSxNQUNyRSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUs7QUFBQSxNQUN6QixXQUFXLE1BQU0sS0FBSyxLQUFLLEdBQUcsRUFBRTtBQUFBO0FBQUEsSUFHbEMsT0FBTyxDQUFDLE1BQWlDO0FBQUEsTUFDdkMsS0FBSyxPQUFPO0FBQUEsTUFDWixJQUFJLENBQUMsTUFBTTtBQUFBLFFBQ1QsS0FBSyxLQUFLLE1BQU0sVUFBVTtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxLQUFLLFlBQVksVUFBVTtBQUFBLE1BQ2hDLEtBQUssU0FBUyxjQUFjLFNBQVMsV0FBVyxvQkFBb0I7QUFBQSxNQUNwRSxLQUFLLEtBQUssTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUc1QixLQUFLLENBQUMsTUFBYyxPQUFnQixPQUFPLE9BQU87QUFBQSxNQUNoRCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxTQUFTLGNBQWMsS0FBSztBQUFBLE1BQ3RDLEVBQUUsWUFBWSxXQUFXLE9BQU8sVUFBVTtBQUFBLE1BQzFDLElBQUk7QUFBQSxRQUFPLEVBQUUsTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQzNDLEVBQUUsY0FBYztBQUFBLE1BQ2hCLEtBQUssT0FBTyxZQUFZLENBQUM7QUFBQSxNQUN6QixXQUFXLE1BQU0sRUFBRSxPQUFPLEdBQUcsSUFBSTtBQUFBLE1BQ2pDLE9BQU8sS0FBSyxPQUFPLFNBQVMsU0FBUztBQUFBLFFBQUcsS0FBSyxPQUFPLGtCQUFtQixPQUFPO0FBQUE7QUFBQSxFQUVsRjtBQUFBLEVBRU8sSUFBTSxVQUFVLElBQUk7OztFQzdHM0IsSUFBTSxhQUFhLENBQUMsZUFBZSxnQkFBZ0IsYUFBYSxXQUFXLFdBQVcsWUFBWSxvQkFBb0I7QUFBQSxFQUV0SCxJQUFNLFlBQ0osd0dBQ0EscUdBQ0E7QUFBQSxFQUVLLElBQU0sVUFBVTtBQUFBLEVBRXZCLElBQU0sT0FBTyxDQUFDLE9BQWtDLEtBQUssSUFBSSxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFBQSxFQUVuRixJQUFNLGdCQUFnQjtBQUFBLEVBSXRCLElBQU0sY0FBYyxJQUFJLElBQUk7QUFBQSxJQUMxQjtBQUFBLElBQVU7QUFBQSxJQUFTO0FBQUEsSUFBVztBQUFBLElBQWdCO0FBQUEsSUFBZTtBQUFBLElBQVM7QUFBQSxJQUFXO0FBQUEsSUFBWTtBQUFBLElBQWE7QUFBQSxJQUMxRztBQUFBLElBQVk7QUFBQSxJQUFXO0FBQUEsSUFBUTtBQUFBLElBQVU7QUFBQSxJQUFZO0FBQUEsSUFBYTtBQUFBLElBQVc7QUFBQSxJQUFZO0FBQUEsSUFBVztBQUFBLElBQVc7QUFBQSxJQUMvRztBQUFBLElBQVM7QUFBQSxJQUFTO0FBQUEsSUFBWTtBQUFBLElBQVM7QUFBQSxJQUFXO0FBQUEsSUFBVztBQUFBLElBQVM7QUFBQSxJQUFZO0FBQUEsSUFBUztBQUFBLElBQVc7QUFBQSxFQUN4RyxDQUFDO0FBQUEsRUFFRCxTQUFTLFlBQVksQ0FBQyxHQUFvQjtBQUFBLElBQ3hDLElBQUksY0FBYyxLQUFLLENBQUM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNsQyxNQUFNLFFBQVEsRUFBRSxNQUFNLDJCQUEyQixFQUFFLE9BQU8sT0FBTztBQUFBLElBQ2pFLE9BQU8sTUFBTSxTQUFTLEtBQUssWUFBWSxJQUFJLE1BQU0sR0FBRyxFQUFFLEVBQUcsWUFBWSxDQUFDO0FBQUE7QUFBQSxFQUt4RSxJQUFNLFdBQVcsSUFBSTtBQUFBLEVBQ3JCLElBQUksZ0JBQXlDO0FBQUEsRUFFN0MsU0FBUyxnQkFBZ0IsQ0FBQyxTQUEyQjtBQUFBLElBQ25ELFdBQVcsS0FBSyxTQUFTO0FBQUEsTUFDdkIsTUFBTSxTQUFTLElBQUksS0FBSyxFQUFFLFlBQVksSUFBSSxNQUFNLEtBQUssRUFBRSxPQUFPLE9BQU8sQ0FBQztBQUFBLE1BQ3RFLE1BQU0sUUFBUyxFQUFFLE9BQW1CO0FBQUEsTUFDcEMsV0FBVyxLQUFLO0FBQUEsUUFBTyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUM7QUFBQSxVQUFHLFNBQVMsSUFBSSxDQUFDO0FBQUEsTUFDekQsV0FBVyxLQUFLO0FBQUEsUUFBUSxJQUFJLENBQUMsTUFBTSxTQUFTLENBQUM7QUFBQSxVQUFHLFNBQVMsSUFBSSxDQUFDO0FBQUEsSUFDaEU7QUFBQTtBQUFBLEVBSUssU0FBUyxvQkFBb0IsQ0FBQyxJQUFhO0FBQUEsSUFDaEQsSUFBSSxNQUFNLENBQUMsZUFBZTtBQUFBLE1BQ3hCLGdCQUFnQixJQUFJLGlCQUFpQixnQkFBZ0I7QUFBQSxNQUNyRCxjQUFjLFFBQVEsU0FBUyxpQkFBaUIsRUFBRSxTQUFTLE1BQU0sWUFBWSxNQUFNLGlCQUFpQixDQUFDLE9BQU8sR0FBRyxtQkFBbUIsS0FBSyxDQUFDO0FBQUEsSUFDMUksRUFBTyxTQUFJLENBQUMsTUFBTSxlQUFlO0FBQUEsTUFDL0IsaUJBQWlCLGNBQWMsWUFBWSxDQUFDO0FBQUEsTUFDNUMsY0FBYyxXQUFXO0FBQUEsTUFDekIsZ0JBQWdCO0FBQUEsSUFDbEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxhQUFhLENBQUMsSUFBdUI7QUFBQSxJQUU1QyxJQUFJO0FBQUEsTUFBZSxpQkFBaUIsY0FBYyxZQUFZLENBQUM7QUFBQSxJQUMvRCxPQUFPLENBQUMsR0FBRyxHQUFHLFNBQVMsRUFBRSxPQUN2QixDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsU0FBUyxHQUFHLEtBQUssRUFBRSxTQUFTLEVBQ3RHO0FBQUE7QUFBQSxFQUdGLElBQU0sSUFBSSxDQUFDLE1BQWMsS0FBSyxVQUFVLENBQUM7QUFBQSxFQUlsQyxTQUFTLFNBQVMsQ0FBQyxJQUFzQjtBQUFBLElBQzlDLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFBYSxPQUFPO0FBQUEsSUFDNUIsSUFBSSxHQUFHLGVBQWUsRUFBRSxXQUFXO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDN0MsTUFBTSxLQUFLLGlCQUFpQixFQUFFO0FBQUEsSUFDOUIsT0FBTyxHQUFHLGVBQWUsWUFBWSxHQUFHLFlBQVk7QUFBQTtBQUFBLEVBSS9DLFNBQVMsTUFBTSxDQUFDLElBQXFCO0FBQUEsSUFDMUMsSUFBSSxjQUFjLG9CQUFvQixDQUFDLFVBQVUsVUFBVSxPQUFPLEVBQUUsU0FBUyxHQUFHLElBQUk7QUFBQSxNQUFHLE9BQU8sS0FBSyxHQUFHLEtBQUs7QUFBQSxJQUMzRyxPQUFPLEtBQU0sR0FBbUIsYUFBYSxHQUFHLFdBQVc7QUFBQTtBQUFBLEVBRzdELFVBQVUsV0FBVyxDQUFDLE9BQXdDLFVBQThCO0FBQUEsSUFDMUYsTUFBTSxTQUFTLFNBQVMsaUJBQWlCLE1BQU0sV0FBVyxZQUFZO0FBQUEsSUFDdEUsSUFBSSxJQUFJLE9BQU8sU0FBUztBQUFBLElBQ3hCLE9BQU8sR0FBRztBQUFBLE1BQ1IsTUFBTTtBQUFBLE1BQ04sTUFBTSxLQUFNLEVBQWM7QUFBQSxNQUMxQixJQUFJO0FBQUEsUUFBSSxPQUFPLFlBQVksRUFBRTtBQUFBLE1BQzdCLElBQUksT0FBTyxTQUFTO0FBQUEsSUFDdEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxNQUFNLENBQUMsTUFBYyxPQUEyQixVQUFxQjtBQUFBLElBQzVFLE1BQU0sU0FBUyxLQUFLLElBQUk7QUFBQSxJQUN4QixNQUFNLFFBQW1CLENBQUM7QUFBQSxJQUMxQixNQUFNLFVBQXFCLENBQUM7QUFBQSxJQUM1QixNQUFNLFFBQVEsT0FBTyxZQUFZO0FBQUEsSUFDakMsV0FBVyxNQUFNLFlBQVksSUFBSSxHQUFHO0FBQUEsTUFDbEMsSUFBSSxHQUFHLFFBQVEsbURBQW1EO0FBQUEsUUFBRztBQUFBLE1BQ3JFLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSTtBQUFBLE1BRWxDLElBQUksRUFBRSxjQUFjLHFCQUFxQixLQUFLLEdBQUcsV0FBVyxFQUFFLFNBQVM7QUFBQSxRQUFPO0FBQUEsTUFDOUUsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQ25CLElBQUksQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUFBLFFBQU87QUFBQSxNQUM1QixJQUFJLE1BQU07QUFBQSxRQUFRLE1BQU0sS0FBSyxFQUFFO0FBQUEsTUFDMUIsU0FBSSxFQUFFLFlBQVksRUFBRSxTQUFTLEtBQUs7QUFBQSxRQUFHLFFBQVEsS0FBSyxFQUFFO0FBQUEsSUFDM0Q7QUFBQSxJQUNBLE1BQU0sT0FBTyxNQUFNLFNBQVMsUUFBUTtBQUFBLElBRXBDLE1BQU0sVUFBVSxLQUFLLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLENBQUMsTUFBTSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDakYsT0FBTyxPQUFPLFFBQVEsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLEVBR2hFLFNBQVMsT0FBTyxDQUFDLE1BQXlCO0FBQUEsSUFDeEMsTUFBTSxTQUFTLEtBQUssSUFBSSxFQUFFLFlBQVk7QUFBQSxJQUN0QyxNQUFNLE1BQWlCLENBQUM7QUFBQSxJQUN4QixXQUFXLFNBQVMsU0FBUyxpQkFBaUIsT0FBTyxHQUFHO0FBQUEsTUFDdEQsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFLFlBQVksRUFBRSxRQUFRLFVBQVUsRUFBRSxNQUFNLFVBQVUsTUFBTTtBQUFBLFFBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTztBQUFBLElBQ25IO0FBQUEsSUFDQSxXQUFXLE1BQU0sU0FBUyxpQkFBaUIsVUFBVSxtQ0FBbUMsR0FBRztBQUFBLE1BQ3pGLElBQUksS0FBSyxHQUFHLGFBQWEsWUFBWSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsUUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQzdFLE1BQU0sS0FBSyxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsTUFDNUMsSUFBSSxJQUFJO0FBQUEsUUFDTixNQUFNLElBQUksR0FDUCxNQUFNLEtBQUssRUFDWCxJQUFJLENBQUMsT0FBTyxTQUFTLGVBQWUsRUFBRSxHQUFHLGFBQWEsRUFBRSxFQUN4RCxLQUFLLEdBQUc7QUFBQSxRQUNYLElBQUksS0FBSyxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxDQUFDLElBQUksUUFBUTtBQUFBLE1BQ2YsV0FBVyxNQUFNLFNBQVMsaUJBQWlCLGVBQWUsR0FBRztBQUFBLFFBQzNELElBQUksS0FBSyxHQUFHLGFBQWEsYUFBYSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ2hGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBLEVBR25CLFNBQVMsT0FBTyxDQUFDLElBQXVCO0FBQUEsSUFDdEMsTUFBTSxNQUFNLFNBQVMsU0FBUyxJQUFJLFVBQVUsTUFBTSxZQUFZLDRCQUE0QixJQUFJO0FBQUEsSUFDOUYsTUFBTSxNQUFpQixDQUFDO0FBQUEsSUFDeEIsU0FBUyxJQUFJLEVBQUcsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0FBQUEsTUFDM0MsTUFBTSxJQUFJLElBQUksYUFBYSxDQUFDO0FBQUEsTUFDNUIsSUFBSSxhQUFhO0FBQUEsUUFBUyxJQUFJLEtBQUssQ0FBQztBQUFBLElBQ3RDO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsTUFBUyxDQUFDLEtBQWU7QUFBQSxJQUNoQyxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDO0FBQUE7QUFBQSxFQUd6QixJQUFNLFFBQVE7QUFBQSxFQUdkLElBQU0sYUFBYSxDQUFDLFFBQWdCLElBQUksV0FBVyxPQUFPLEtBQUssSUFBSSxTQUFTLFFBQVEsT0FBTztBQUFBLEVBR3BGLFNBQVMsVUFBVSxDQUFDLFVBQWtCLE9BQTJCLFVBQXFCO0FBQUEsSUFDM0YsSUFBSTtBQUFBLE1BQ0YsSUFBSSxTQUFTLFdBQVcsT0FBTztBQUFBLFFBQUcsT0FBTyxPQUFPLFFBQVEsU0FBUyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUk7QUFBQSxNQUVoRixNQUFNLElBQUksU0FBUyxRQUFRLEtBQUs7QUFBQSxNQUNoQyxJQUFJLElBQUksR0FBRztBQUFBLFFBQ1QsTUFBTSxTQUFTLFdBQVcsU0FBUyxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUk7QUFBQSxRQUNwRCxPQUFPLE9BQU8sT0FBTyxRQUFRLENBQUMsT0FBTyxXQUFXLFNBQVMsTUFBTSxJQUFJLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQUEsTUFDeEY7QUFBQSxNQUNBLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzVFLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDbkUsSUFBSSxTQUFTLFdBQVcsUUFBUSxHQUFHO0FBQUEsUUFFakMsTUFBTSxJQUFJLFNBQVMsaUJBQWlCLGVBQWUsRUFBRSxPQUFPLFNBQVMsTUFBTSxDQUFDLENBQUM7QUFBQSxRQUM3RSxPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUFBLE1BQ3BCO0FBQUEsTUFDQSxPQUFPLENBQUMsR0FBRyxLQUFLLGlCQUFpQixRQUFRLENBQUM7QUFBQSxNQUMxQyxNQUFNO0FBQUEsTUFDTixPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUEsRUFJWixTQUFTLE9BQU8sQ0FBQyxHQUFtQjtBQUFBLElBQ2xDLE1BQU0sSUFBSSxFQUFFLEtBQUs7QUFBQSxJQUNqQixJQUFLLEVBQUUsV0FBVyxHQUFHLEtBQUssRUFBRSxTQUFTLEdBQUcsS0FBTyxFQUFFLFdBQVcsR0FBRyxLQUFLLEVBQUUsU0FBUyxHQUFHO0FBQUEsTUFBSSxPQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUMxRyxPQUFPO0FBQUE7QUFBQSxFQUlGLFNBQVMsT0FBTyxDQUFDLFdBQStEO0FBQUEsSUFDckYsV0FBVyxPQUFPLFdBQVc7QUFBQSxNQUMzQixNQUFNLFFBQVEsV0FBVyxHQUFHO0FBQUEsTUFDNUIsSUFBSSxNQUFNLFdBQVc7QUFBQSxRQUFHLE9BQU8sRUFBRSxJQUFJLE1BQU0sSUFBSyxVQUFVLElBQUk7QUFBQSxNQUM5RCxNQUFNLE1BQU0sTUFBTSxPQUFPLFNBQVM7QUFBQSxNQUNsQyxJQUFJLElBQUksVUFBVTtBQUFBLFFBQUcsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFLLFVBQVUsSUFBSTtBQUFBLE1BQ3pELElBQUksTUFBTTtBQUFBLFFBQVEsT0FBTyxFQUFFLElBQUksTUFBTSxJQUFLLFVBQVUsSUFBSTtBQUFBLElBQzFEO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUtULFNBQVMsUUFBUSxDQUFDLEtBQWEsSUFBc0I7QUFBQSxJQUNuRCxNQUFNLElBQUksV0FBVyxHQUFHO0FBQUEsSUFDeEIsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLE9BQU87QUFBQTtBQUFBLEVBR3BDLFNBQVMsT0FBTyxDQUFDLElBQXFCO0FBQUEsSUFDcEMsTUFBTSxRQUFrQixDQUFDO0FBQUEsSUFDekIsSUFBSSxNQUFzQjtBQUFBLElBQzFCLE9BQU8sT0FBTyxRQUFRLFNBQVMsaUJBQWlCO0FBQUEsTUFDOUMsTUFBTSxNQUFNLElBQUksUUFBUSxZQUFZO0FBQUEsTUFDcEMsSUFBSSxRQUFRLE1BQU0sSUFBSSxNQUFNLENBQUMsZUFBZSxJQUFJLEVBQUUsR0FBRztBQUFBLFFBQ25ELE1BQU0sUUFBUSxNQUFNLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQztBQUFBLFFBQ3RDLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSztBQUFBLFFBQzFCLElBQUksU0FBUyxHQUFHLEVBQUU7QUFBQSxVQUFHLE9BQU87QUFBQSxRQUM1QixNQUFNLE1BQU07QUFBQSxNQUNkO0FBQUEsTUFDQSxJQUFJLE1BQU07QUFBQSxNQUNWLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQ3pDLElBQUksSUFBSTtBQUFBLFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUFBLE1BRW5FLE1BQU0sYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsTUFDN0MsSUFBSSxTQUFTLFlBQVksRUFBRTtBQUFBLFFBQUcsT0FBTztBQUFBLE1BRXJDLE1BQU0sU0FBeUIsSUFBSTtBQUFBLE1BQ25DLElBQUksUUFBUTtBQUFBLFFBQ1YsTUFBTSxPQUFPLENBQUMsR0FBRyxPQUFPLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFlBQVksSUFBSyxPQUFPO0FBQUEsUUFDMUUsSUFBSSxLQUFLLFNBQVM7QUFBQSxVQUFHLE9BQU8sZ0JBQWdCLEtBQUssUUFBUSxHQUFHLElBQUk7QUFBQSxNQUNsRTtBQUFBLE1BQ0EsTUFBTSxRQUFRLEdBQUc7QUFBQSxNQUNqQixNQUFNLElBQUksTUFBTSxLQUFLLEtBQUs7QUFBQSxNQUMxQixJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQUEsUUFBRyxPQUFPO0FBQUEsTUFDNUIsTUFBTTtBQUFBLElBQ1I7QUFBQSxJQUNBLE9BQU8sTUFBTSxLQUFLLEtBQUs7QUFBQTtBQUFBLEVBSXpCLElBQU0sY0FDSiw0RUFDQTtBQUFBLEVBR0YsU0FBUyxrQkFBa0IsQ0FBQyxLQUF3QjtBQUFBLElBQ2xELE1BQU0sTUFBTSxJQUFJLFFBQVEsWUFBWTtBQUFBLElBQ3BDLE1BQU0sTUFBZ0IsQ0FBQztBQUFBLElBQ3ZCLE1BQU0sT0FBTyxJQUFJLGFBQWEsTUFBTTtBQUFBLElBQ3BDLElBQUk7QUFBQSxNQUFNLElBQUksS0FBSyxTQUFTLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDdEMsV0FBVyxLQUFLLFlBQVk7QUFBQSxNQUMxQixNQUFNLElBQUksSUFBSSxhQUFhLENBQUM7QUFBQSxNQUM1QixJQUFJO0FBQUEsUUFBRyxJQUFJLFFBQVEsSUFBSSxLQUFLLEVBQUUsQ0FBQyxJQUFJO0FBQUEsSUFDckM7QUFBQSxJQUNBLElBQUksSUFBSSxNQUFNLENBQUMsZUFBZSxJQUFJLEVBQUU7QUFBQSxNQUFHLElBQUksUUFBUSxNQUFNLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQztBQUFBLElBQzNFLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLElBQ3pDLElBQUksSUFBSTtBQUFBLE1BQVEsSUFBSSxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksT0FBTyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsQ0FBQztBQUFBLElBQzVFLE9BQU87QUFBQTtBQUFBLEVBUVQsU0FBUyxVQUFVLENBQUMsSUFBYSxNQUF3QjtBQUFBLElBQ3ZELE1BQU0sTUFBZ0IsQ0FBQztBQUFBLElBQ3ZCLElBQUksTUFBTSxHQUFHLGVBQWUsUUFBUSxXQUFXO0FBQUEsSUFDL0MsU0FBUyxJQUFJLEVBQUcsT0FBTyxRQUFRLFNBQVMsUUFBUSxJQUFJLEdBQUcsS0FBSztBQUFBLE1BQzFELFdBQVcsTUFBTSxtQkFBbUIsR0FBRztBQUFBLFFBQUcsSUFBSSxLQUFLLEdBQUcsS0FBSyxhQUFhLE1BQU07QUFBQSxNQUM5RSxNQUFNLElBQUksZUFBZSxRQUFRLFdBQVc7QUFBQSxJQUM5QztBQUFBLElBQ0EsT0FBTztBQUFBO0FBQUEsRUFJRixTQUFTLGNBQWMsQ0FBQyxJQUF1QjtBQUFBLElBQ3BELE1BQU0sTUFBTSxHQUFHLFFBQVEsWUFBWTtBQUFBLElBQ25DLE1BQU0sSUFBYyxDQUFDO0FBQUEsSUFFckIsV0FBVyxLQUFLLFlBQVk7QUFBQSxNQUMxQixNQUFNLElBQUksR0FBRyxhQUFhLENBQUM7QUFBQSxNQUMzQixJQUFJO0FBQUEsUUFBRyxFQUFFLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQyxJQUFJO0FBQUEsSUFDaEM7QUFBQSxJQUNBLElBQUksR0FBRyxNQUFNLENBQUMsZUFBZSxHQUFHLEVBQUU7QUFBQSxNQUFHLEVBQUUsS0FBSyxNQUFNLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUFBLElBRW5FLE1BQU0sT0FBTyxHQUFHLGFBQWEsTUFBTTtBQUFBLElBQ25DLElBQUksTUFBTTtBQUFBLE1BQ1IsSUFBSSxjQUFjLHFCQUFxQixHQUFHLFNBQVMsV0FBVyxHQUFHLFNBQVMsZUFBZSxHQUFHLFNBQVMsR0FBRyxVQUFVLE1BQU07QUFBQSxRQUN0SCxFQUFFLEtBQUssR0FBRyxZQUFZLEVBQUUsSUFBSSxZQUFZLEVBQUUsR0FBRyxLQUFLLElBQUk7QUFBQSxNQUN4RCxFQUFPO0FBQUEsVUFBRSxLQUFLLEdBQUcsWUFBWSxFQUFFLElBQUksSUFBSTtBQUFBLElBQ3pDO0FBQUEsSUFFQSxNQUFNLFlBQVksR0FBRyxRQUFRLE9BQU87QUFBQSxJQUNwQyxJQUFJLFdBQVc7QUFBQSxNQUNiLE1BQU0sTUFBTSxVQUFVLEVBQUU7QUFBQSxNQUN4QixJQUFJLE9BQU8sSUFBSSxVQUFVO0FBQUEsUUFBSSxFQUFFLEtBQUssU0FBUyxLQUFLO0FBQUEsSUFDcEQ7QUFBQSxJQUVBLE1BQU0sT0FBTyxHQUFHLGFBQWEsWUFBWTtBQUFBLElBQ3pDLElBQUk7QUFBQSxNQUFNLEVBQUUsS0FBSyxHQUFHLGtCQUFrQixFQUFFLElBQUksSUFBSTtBQUFBLElBQ2hELE1BQU0sS0FBSyxHQUFHLGFBQWEsYUFBYTtBQUFBLElBQ3hDLElBQUk7QUFBQSxNQUFJLEVBQUUsS0FBSyxHQUFHLG1CQUFtQixFQUFFLEVBQUUsSUFBSTtBQUFBLElBRTdDLElBQUksQ0FBQyxXQUFXO0FBQUEsTUFDZCxNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsTUFDbkIsSUFBSSxLQUFLLEVBQUUsVUFBVSxNQUFNLENBQUMsR0FBRyxjQUFjLE9BQU8sR0FBRztBQUFBLFFBQ3JELElBQUksRUFBRSxVQUFVO0FBQUEsVUFBSSxFQUFFLEtBQUssUUFBUSxHQUFHO0FBQUEsUUFDdEMsRUFBRSxLQUFLLEdBQUcsV0FBVyxJQUFJLENBQUMsQ0FBQztBQUFBLE1BQzdCO0FBQUEsSUFDRjtBQUFBLElBRUEsSUFBSSxjQUFjLG1CQUFtQjtBQUFBLE1BQ25DLE1BQU0sT0FBTyxHQUFHLGFBQWEsTUFBTTtBQUFBLE1BQ25DLElBQUksUUFBUSxLQUFLLFNBQVMsTUFBTSxDQUFDLEtBQUssV0FBVyxhQUFhLEtBQUssU0FBUztBQUFBLFFBQUssRUFBRSxLQUFLLFVBQVUsRUFBRSxJQUFJLElBQUk7QUFBQSxJQUM5RztBQUFBLElBQ0EsSUFBSSxjQUFjLHFCQUFxQixjQUFjLGtCQUFrQjtBQUFBLE1BQ3JFLE1BQU0sTUFBTSxHQUFHLGFBQWEsS0FBSztBQUFBLE1BQ2pDLElBQUksT0FBTyxDQUFDLElBQUksV0FBVyxPQUFPLEtBQUssQ0FBQyxJQUFJLFdBQVcsYUFBYSxHQUFHO0FBQUEsUUFFckUsTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNLEVBQUU7QUFBQSxRQUMvQixFQUFFLEtBQUssU0FBUyxNQUFNLEdBQUcsV0FBVyxFQUFFLEdBQUcsT0FBTyxHQUFHLFlBQVksRUFBRSxJQUFJLElBQUk7QUFBQSxNQUMzRTtBQUFBLElBQ0Y7QUFBQSxJQUNBLE1BQU0sUUFBUSxHQUFHLGFBQWEsT0FBTztBQUFBLElBQ3JDLElBQUk7QUFBQSxNQUFPLEVBQUUsS0FBSyxHQUFHLGFBQWEsRUFBRSxLQUFLLElBQUk7QUFBQSxJQUc3QyxNQUFNLGFBQWEsQ0FBQyxNQUFjO0FBQUEsTUFDaEMsTUFBTSxTQUFTLFdBQVcsQ0FBQztBQUFBLE1BQzNCLE1BQU0sTUFBTSxDQUFDLE1BQWUsTUFBTSxNQUFPLFVBQVUsR0FBRyxTQUFTLENBQUMsS0FBSyxPQUFPLENBQUMsTUFBTSxPQUFPLEVBQUU7QUFBQSxNQUM1RixNQUFNLElBQUksV0FBVyxDQUFDO0FBQUEsTUFDdEIsSUFBSSxFQUFFLFdBQVc7QUFBQSxRQUFHLE9BQU8sSUFBSSxFQUFFLEVBQUc7QUFBQSxNQUdwQyxJQUFJLENBQUM7QUFBQSxRQUFRLE9BQU87QUFBQSxNQUNwQixNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVM7QUFBQSxNQUM5QixPQUFPLElBQUksV0FBVyxLQUFLLElBQUksSUFBSSxFQUFHO0FBQUE7QUFBQSxJQUV4QyxNQUFNLFNBQVMsT0FBTyxDQUFDLEVBQUUsT0FBTyxVQUFVO0FBQUEsSUFDMUMsT0FBTyxLQUFLLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDdkIsT0FBTyxPQUFPLE1BQU0sRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBO0FBQUEsRUFLM0IsU0FBUyxTQUFTLENBQUMsSUFBcUI7QUFBQSxJQUM3QyxJQUFLLEdBQXdCLFFBQVEsUUFBUTtBQUFBLE1BQzNDLE1BQU0sSUFBSSxLQUFNLEdBQXdCLE9BQVEsR0FBSSxTQUFTLEVBQUUsUUFBUSxVQUFVLEVBQUU7QUFBQSxNQUNuRixJQUFJO0FBQUEsUUFBRyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxJQUNBLE1BQU0sT0FBTyxHQUFHLGFBQWEsWUFBWTtBQUFBLElBQ3pDLElBQUk7QUFBQSxNQUFNLE9BQU8sS0FBSyxJQUFJO0FBQUEsSUFDMUIsTUFBTSxLQUFLLEdBQUcsYUFBYSxpQkFBaUI7QUFBQSxJQUM1QyxJQUFJLElBQUk7QUFBQSxNQUNOLE1BQU0sSUFBSSxLQUFLLEdBQUcsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sU0FBUyxlQUFlLEVBQUUsR0FBRyxhQUFhLEVBQUUsRUFBRSxLQUFLLEdBQUcsQ0FBQztBQUFBLE1BQ2xHLElBQUk7QUFBQSxRQUFHLE9BQU87QUFBQSxJQUNoQjtBQUFBLElBQ0EsT0FBTztBQUFBO0FBQUEsRUFJRixTQUFTLFFBQVEsQ0FBQyxJQUFxQjtBQUFBLElBQzVDLElBQUksR0FBRyxRQUFRLE9BQU8sR0FBRztBQUFBLE1BQ3ZCLFFBQ0UsVUFBVSxFQUFFLEtBQ1osR0FBRyxhQUFhLGFBQWEsS0FDN0IsR0FBRyxhQUFhLE1BQU0sS0FDdEIsR0FBRyxNQUNILEdBQUcsYUFBYSxPQUFPLEtBQ3ZCLEdBQUcsUUFBUSxZQUFZLEdBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQUEsSUFDZjtBQUFBLElBQ0EsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ25CLElBQUk7QUFBQSxNQUFHLE9BQU8sRUFBRSxTQUFTLEtBQUssRUFBRSxNQUFNLEdBQUcsRUFBRSxJQUFJLE1BQU07QUFBQSxJQUNyRCxRQUNFLEdBQUcsYUFBYSxZQUFZLEtBQzVCLEdBQUcsYUFBYSxPQUFPLEtBQ3ZCLEdBQUcsY0FBYyxLQUFLLEdBQUcsYUFBYSxLQUFLLEtBQzNDLEdBQUcsYUFBYSxNQUFNLEtBQ3RCLEdBQUcsUUFBUSxZQUFZLEdBQ3ZCLE1BQU0sR0FBRyxFQUFFO0FBQUE7QUFBQSxFQUlSLFNBQVMsVUFBVSxDQUFDLFFBQTBCO0FBQUEsSUFDbkQsTUFBTSxPQUFPLE9BQU8sUUFBUSxPQUFPO0FBQUEsSUFDbkMsSUFBSTtBQUFBLE1BQU0sT0FBTztBQUFBLElBQ2pCLE1BQU0sWUFBWSxPQUFPLFFBQVEsU0FBUztBQUFBLElBQzFDLElBQUkscUJBQXFCLG9CQUFvQixVQUFVO0FBQUEsTUFBUyxPQUFPLFVBQVU7QUFBQSxJQUNqRixPQUFPLGFBQWE7QUFBQTtBQUFBLEVBR3RCLElBQU0sV0FBVyxJQUFJLElBQUk7QUFBQSxJQUN2QjtBQUFBLElBQUk7QUFBQSxJQUFRO0FBQUEsSUFBUztBQUFBLElBQVk7QUFBQSxJQUFVO0FBQUEsSUFBTztBQUFBLElBQU87QUFBQSxJQUN6RDtBQUFBLElBQVE7QUFBQSxJQUFrQjtBQUFBLElBQVM7QUFBQSxJQUFRO0FBQUEsSUFBUTtBQUFBLElBQVM7QUFBQSxFQUM5RCxDQUFDO0FBQUEsRUFJTSxTQUFTLE1BQU0sQ0FBQyxJQUF5QjtBQUFBLElBQzlDLElBQUksY0FBYztBQUFBLE1BQW1CLE9BQU87QUFBQSxJQUM1QyxJQUFJLGNBQWM7QUFBQSxNQUFxQixPQUFPLEdBQUcsV0FBVyxVQUFVO0FBQUEsSUFDdEUsSUFBSSxjQUFjLGtCQUFrQjtBQUFBLE1BQ2xDLElBQUksR0FBRyxTQUFTLGNBQWMsR0FBRyxTQUFTO0FBQUEsUUFBUyxPQUFPO0FBQUEsTUFDMUQsSUFBSSxHQUFHLFNBQVM7QUFBQSxRQUFRLE9BQU87QUFBQSxNQUUvQixJQUFJLFNBQVMsSUFBSSxHQUFHLElBQUk7QUFBQSxRQUFHLE9BQU8sR0FBRyxXQUFXLFVBQVU7QUFBQSxNQUMxRCxPQUFPO0FBQUEsSUFDVDtBQUFBLElBQ0EsSUFBSyxHQUFtQjtBQUFBLE1BQW1CLE9BQU87QUFBQSxJQUNsRCxNQUFNLE9BQU8sR0FBRyxhQUFhLE1BQU07QUFBQSxJQUNuQyxJQUFJLFNBQVMsY0FBYyxTQUFTO0FBQUEsTUFBVSxPQUFPO0FBQUEsSUFDckQsT0FBTztBQUFBO0FBQUEsRUFHRixTQUFTLE9BQU8sQ0FBQyxJQUFxQjtBQUFBLElBQzNDLElBQUksY0FBYyxvQkFBb0IsY0FBYyx1QkFBdUIsY0FBYztBQUFBLE1BQW1CLE9BQU8sR0FBRztBQUFBLElBQ3RILE9BQU8sS0FBTSxHQUFtQixTQUFTO0FBQUE7QUFBQSxFQUdwQyxTQUFTLFNBQVMsQ0FBQyxJQUFzQjtBQUFBLElBQzlDLElBQUksY0FBYztBQUFBLE1BQWtCLE9BQU8sR0FBRztBQUFBLElBQzlDLE9BQU8sR0FBRyxhQUFhLGNBQWMsTUFBTTtBQUFBOzs7RUN4YTdDLElBQU0sWUFBWTtBQUFBLEVBRWxCLElBQU0sWUFBWTtBQUFBLEVBRWxCLElBQU0sVUFBVTtBQUFBLEVBR2hCLElBQU0sVUFBVTtBQUFBLElBQ2Q7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUF1QztBQUFBLElBQ3ZDO0FBQUEsSUFBNkI7QUFBQSxJQUM3QjtBQUFBLElBQXVCO0FBQUEsSUFDdkI7QUFBQSxJQUFjO0FBQUEsSUFDZDtBQUFBLElBQW1CO0FBQUEsSUFDbkI7QUFBQSxJQUFZO0FBQUEsSUFBb0I7QUFBQSxJQUFpQjtBQUFBLElBQVc7QUFBQSxFQUM5RCxFQUFFLEtBQUssSUFBSTtBQUFBLEVBSVgsSUFBSSxVQUFVO0FBQUEsRUFDZCxJQUFJLGFBQWEsWUFBWSxJQUFJO0FBQUEsRUFFakMsU0FBUyxpQkFBaUIsZ0JBQWdCLENBQUMsTUFBTTtBQUFBLElBQy9DLE1BQU0sSUFBSyxFQUFrQjtBQUFBLElBQzdCLElBQUksT0FBTyxNQUFNO0FBQUEsTUFBVTtBQUFBLElBQzNCLFVBQVU7QUFBQSxJQUNWLGFBQWEsWUFBWSxJQUFJO0FBQUEsR0FDOUI7QUFBQSxFQUNELFNBQVMsY0FBYyxJQUFJLE1BQU0sZUFBZSxDQUFDO0FBQUEsRUFJakQsSUFBSSxhQUFhLFlBQVksSUFBSTtBQUFBLEVBQ2pDLElBQUksY0FBdUM7QUFBQSxFQUUzQyxTQUFTLFFBQVEsR0FBRztBQUFBLElBQ2xCLElBQUk7QUFBQSxNQUFhO0FBQUEsSUFDakIsY0FBYyxJQUFJLGlCQUFpQixDQUFDLFlBQVk7QUFBQSxNQUM5QyxJQUFJLFFBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBRSxFQUFFLE9BQW1CLFVBQVUsZ0JBQWdCLENBQUM7QUFBQSxRQUFHLGFBQWEsWUFBWSxJQUFJO0FBQUEsS0FDM0c7QUFBQSxJQUNELFlBQVksUUFBUSxTQUFTLGlCQUFpQixFQUFFLFNBQVMsTUFBTSxXQUFXLE1BQU0sWUFBWSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUE7QUFBQSxFQUl6SCxTQUFTLGNBQWMsQ0FBQyxPQUF3QjtBQUFBLElBQzlDLE1BQU0sSUFBSSxPQUFPLEtBQUs7QUFBQSxJQUN0QixJQUFJLENBQUM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNmLElBQUk7QUFBQSxNQUNGLFNBQVMsY0FBYyxDQUFDO0FBQUEsTUFDeEIsT0FBTyxHQUFHLFlBQVk7QUFBQSxNQUN0QixNQUFNO0FBQUEsTUFDTixPQUFPO0FBQUE7QUFBQTtBQUFBLEVBSUosU0FBUyxhQUFhLENBQUMsT0FBcUM7QUFBQSxJQUNqRSxXQUFXLE1BQU0sU0FBUyxpQkFBaUIsZUFBZSxLQUFLLENBQUMsR0FBRztBQUFBLE1BQ2pFLElBQUksR0FBRyxRQUFRLGdCQUFnQixLQUFLLENBQUMsVUFBVSxFQUFFO0FBQUEsUUFBRztBQUFBLE1BQ3BELE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLE1BQ25DLElBQUksRUFBRSxRQUFRLEtBQUssRUFBRSxTQUFTO0FBQUEsUUFBRyxPQUFPO0FBQUEsSUFDMUM7QUFBQTtBQUFBLEVBT0YsZUFBc0IsTUFBTSxDQUFDLE9BQWUsYUFBcUM7QUFBQSxJQUMvRSxTQUFTO0FBQUEsSUFDVCxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsSUFDOUIsT0FBTyxNQUFNO0FBQUEsTUFDWCxNQUFNLE1BQU0sWUFBWSxJQUFJO0FBQUEsTUFDNUIsTUFBTSxXQUFXLFlBQVksS0FBSyxNQUFNLGNBQWM7QUFBQSxNQUN0RCxNQUFNLFdBQVcsTUFBTSxjQUFjLGFBQWEsTUFBTSxRQUFRO0FBQUEsTUFDaEUsSUFBSSxZQUFZLFlBQVksQ0FBQyxjQUFjLFdBQVc7QUFBQSxRQUFHO0FBQUEsTUFDekQsSUFBSSxNQUFNLFFBQVE7QUFBQSxRQUFPO0FBQUEsTUFDekIsTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNoQjtBQUFBO0FBQUEsRUFLRixTQUFTLFVBQVUsQ0FBQyxJQUFhLFNBQTJCO0FBQUEsSUFDMUQsSUFBSSxHQUFHLFFBQVEsV0FBVztBQUFBLE1BQUcsT0FBTztBQUFBLElBQ3BDLElBQUksR0FBRyxRQUFRLHdCQUF3QjtBQUFBLE1BQUcsT0FBTztBQUFBLElBRWpELE9BQU8sV0FBVyxpQkFBaUIsRUFBRSxFQUFFLGtCQUFrQjtBQUFBO0FBQUEsRUFHM0QsU0FBUyxRQUFRLENBQUMsSUFBYSxRQUF5QjtBQUFBLElBQ3RELElBQUksTUFBTTtBQUFBLElBQ1YsU0FBUyxJQUFJLEVBQUcsSUFBSSxVQUFVLElBQUksZUFBZTtBQUFBLE1BQUssTUFBTSxJQUFJO0FBQUEsSUFDaEUsT0FBTztBQUFBO0FBQUEsRUFJVCxTQUFTLFNBQVMsQ0FBQyxJQUFhLGFBQXNDO0FBQUEsSUFDcEUsSUFBSSxHQUFHLFlBQVksTUFBTTtBQUFBLE1BQVUsT0FBTztBQUFBLElBQzFDLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLElBQ25DLE1BQU0sSUFBSSxFQUFFLE9BQU8sRUFBRSxRQUFRO0FBQUEsSUFDN0IsTUFBTSxJQUFJLEVBQUUsTUFBTSxFQUFFLFNBQVM7QUFBQSxJQUM3QixJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLElBQUk7QUFBQSxNQUFhLE9BQU87QUFBQSxJQUNoRSxNQUFNLE1BQU0sU0FBUyxpQkFBaUIsR0FBRyxDQUFDO0FBQUEsSUFDMUMsSUFBSSxDQUFDLE9BQU8sR0FBRyxTQUFTLEdBQUcsS0FBSyxJQUFJLFFBQVEsZ0JBQWdCO0FBQUEsTUFBRyxPQUFPO0FBQUEsSUFDdEUsSUFBSyxHQUF3QixVQUFVLENBQUMsR0FBSSxHQUF3QixNQUFPLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLEdBQUcsQ0FBQztBQUFBLE1BQUcsT0FBTztBQUFBLElBRWxILElBQUksQ0FBQyxJQUFJLFFBQVEsZUFBZSxXQUFXLENBQUMsS0FBSyxTQUFTLElBQUksQ0FBQyxFQUFFLFNBQVMsR0FBRztBQUFBLE1BQUcsT0FBTztBQUFBLElBQ3ZGLE9BQU87QUFBQTtBQUFBLEVBR1QsU0FBUyxVQUFVLENBQUMsSUFBcUI7QUFBQSxJQUN2QyxNQUFNLE1BQU0sQ0FBQyxHQUFHLEdBQUcsU0FBUyxFQUFFLE1BQU0sR0FBRyxDQUFDLEVBQUUsS0FBSyxHQUFHO0FBQUEsSUFDbEQsT0FBTyxHQUFHLFFBQVEsWUFBWSxLQUFLLEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSyxPQUFPLE1BQU0sTUFBTSxNQUFNO0FBQUE7QUFBQSxFQU9wRixlQUFzQixlQUFlLENBQUMsSUFBYSxTQUFpQixVQUFtQixhQUE4QztBQUFBLElBQ25JLE1BQU0sUUFBUSxZQUFZLElBQUk7QUFBQSxJQUM5QixJQUFJLFdBQVc7QUFBQSxJQUNmLElBQUksTUFBcUI7QUFBQSxJQUN6QixPQUFPLE1BQU07QUFBQSxNQUNYLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLE1BQ25DLE1BQU0sT0FBTyxHQUFHLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUU7QUFBQSxNQUMzQyxNQUFNLFNBQVMsU0FBUztBQUFBLE1BQ3hCLFdBQVc7QUFBQSxNQUNYLE1BQU0sUUFBUSxXQUFXLFVBQVUsSUFBSSxXQUFXLElBQUk7QUFBQSxNQUN0RCxJQUFJLFdBQVcsSUFBSSxRQUFRO0FBQUEsUUFBRyxNQUFNO0FBQUEsTUFDL0IsU0FBSTtBQUFBLFFBQU8sTUFBTSxtQkFBbUIsV0FBVyxLQUFLO0FBQUEsTUFDcEQsU0FBSSxDQUFDO0FBQUEsUUFBUSxNQUFNO0FBQUEsTUFDbkI7QUFBQSxlQUFPO0FBQUEsTUFDWixJQUFJLFlBQVksSUFBSSxJQUFJLFFBQVE7QUFBQSxRQUFTLE9BQU87QUFBQSxNQUNoRCxNQUFNLE1BQU0sRUFBRTtBQUFBLElBQ2hCO0FBQUE7OztFQ3ZJRixNQUFNLGtCQUFrQixNQUFNO0FBQUEsRUFBQztBQUFBLEVBRy9CLGVBQWUsSUFBSSxDQUFDLE1BQVksU0FBaUIsZ0JBQXFFO0FBQUEsSUFDcEgsTUFBTSxZQUFZLENBQUMsS0FBSyxVQUFVLEdBQUksS0FBSyxhQUFhLENBQUMsQ0FBRSxFQUFFLE9BQU8sT0FBTztBQUFBLElBQzNFLElBQUksQ0FBQyxVQUFVO0FBQUEsTUFBUSxNQUFNLElBQUksVUFBVSwyQkFBMkI7QUFBQSxJQUN0RSxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsSUFDOUIsSUFBSSxjQUFjO0FBQUEsSUFDbEIsT0FBTyxNQUFNO0FBQUEsTUFDWCxNQUFNLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDM0IsSUFBSSxHQUFHO0FBQUEsUUFDTCxJQUFJLFVBQVUsRUFBRSxFQUFFO0FBQUEsVUFBRyxPQUFPO0FBQUEsUUFFNUIsSUFBSSxDQUFDLGdCQUFnQjtBQUFBLFVBQ25CLGdCQUFnQixZQUFZLElBQUk7QUFBQSxVQUNoQyxJQUFJLFlBQVksSUFBSSxJQUFJLGNBQWM7QUFBQSxZQUFNLE9BQU87QUFBQSxRQUNyRDtBQUFBLE1BQ0Y7QUFBQSxNQUNBLElBQUksWUFBWSxJQUFJLElBQUksUUFBUSxTQUFTO0FBQUEsUUFDdkMsSUFBSTtBQUFBLFVBQUcsTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxVQUFVLCtCQUErQjtBQUFBLFFBQ2xHLE1BQU0sSUFBSSxVQUFVLG1CQUFtQixLQUFLLFNBQVMsVUFBVSxRQUFRLFVBQVUsS0FBSztBQUFBLE1BQ3hGO0FBQUEsTUFDQSxNQUFNLE1BQU0sR0FBRztBQUFBLElBQ2pCO0FBQUE7QUFBQSxFQUdGLFNBQVMsTUFBTSxDQUFDLElBQWE7QUFBQSxJQUMzQixNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxJQUNuQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxRQUFRLEdBQUcsR0FBRyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUU7QUFBQTtBQUFBLEVBRzVELGVBQWUsUUFBUSxDQUFDLElBQWE7QUFBQSxJQUNuQyxNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxJQUNuQyxJQUFJLEVBQUUsTUFBTSxLQUFLLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTyxLQUFLLEVBQUUsUUFBUSxZQUFZO0FBQUEsTUFDN0UsR0FBRyxlQUFlLEVBQUUsT0FBTyxVQUFVLFFBQVEsVUFBVSxVQUFVLFVBQTRCLENBQUM7QUFBQSxNQUM5RixNQUFNLE1BQU0sRUFBRTtBQUFBLElBQ2hCO0FBQUE7QUFBQSxFQUdGLFNBQVMsS0FBSyxDQUFDLFFBQWlCLE1BQWMsR0FBVyxHQUFXO0FBQUEsSUFDbEUsTUFBTSxPQUF5QjtBQUFBLE1BQzdCLFNBQVM7QUFBQSxNQUFNLFlBQVk7QUFBQSxNQUFNLFVBQVU7QUFBQSxNQUFNLE1BQU07QUFBQSxNQUN2RCxTQUFTO0FBQUEsTUFBRyxTQUFTO0FBQUEsTUFBRyxTQUFTLElBQUk7QUFBQSxNQUFTLFNBQVMsSUFBSTtBQUFBLE1BQzNELFFBQVE7QUFBQSxNQUFHLFNBQVMsS0FBSyxTQUFTLE1BQU0sSUFBSSxJQUFJO0FBQUEsTUFBRyxXQUFXO0FBQUEsTUFBRyxhQUFhO0FBQUEsTUFBUyxXQUFXO0FBQUEsSUFDcEc7QUFBQSxJQUNBLE1BQU0sT0FBTyxLQUFLLFdBQVcsU0FBUyxJQUFJLGVBQWU7QUFBQSxJQUN6RCxPQUFPLE9BQU8sY0FBYyxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUM7QUFBQTtBQUFBLEVBR2xELGVBQWUsU0FBUyxDQUFDLElBQWE7QUFBQSxJQUNwQyxNQUFNLFNBQVMsRUFBRTtBQUFBLElBQ2pCLFFBQVEsR0FBRyxNQUFNLE9BQU8sRUFBRTtBQUFBLElBRTFCLE1BQU0sTUFBTSxTQUFTLGlCQUFpQixHQUFHLENBQUM7QUFBQSxJQUMxQyxNQUFNLFNBQVMsT0FBTyxHQUFHLFNBQVMsR0FBRyxJQUFJLE1BQU07QUFBQSxJQUMvQyxNQUFNLFFBQVEsZUFBZSxHQUFHLENBQUM7QUFBQSxJQUNqQyxNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUMvQixNQUFNLFFBQVEsZUFBZSxHQUFHLENBQUM7QUFBQSxJQUNqQyxNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUMvQixNQUFNLE9BQU8sTUFBTSxRQUFRLGVBQWUsR0FBRyxDQUFDLEtBQUssTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDbEYsSUFBSSxRQUFRLGNBQWMsZUFBZSxHQUFHLFlBQVk7QUFBQSxNQUFJLEdBQUcsTUFBTSxFQUFFLGVBQWUsS0FBSyxDQUFDO0FBQUEsSUFDNUYsTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDL0IsTUFBTSxRQUFRLFdBQVcsR0FBRyxDQUFDO0FBQUEsSUFFN0IsTUFBTSxRQUFRLFNBQVMsR0FBRyxDQUFDO0FBQUE7QUFBQSxFQUc3QixJQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsUUFBUSxrQkFBa0IsU0FBUyxRQUFRLFFBQVEsU0FBUyxPQUFPLENBQUM7QUFBQSxFQUUvRixTQUFTLFNBQVMsQ0FBQyxJQUE0QyxHQUFXO0FBQUEsSUFHeEUsTUFBTSxRQUFRLGNBQWMsc0JBQXNCLG9CQUFvQixZQUFZLGlCQUFpQjtBQUFBLElBQ25HLE9BQU8seUJBQXlCLE9BQU8sT0FBTyxFQUFHLElBQUssS0FBSyxJQUFJLENBQUM7QUFBQTtBQUFBLEVBR2xFLFNBQVMsU0FBUyxDQUFDLElBQWEsTUFBcUIsWUFBWSxjQUFjO0FBQUEsSUFDN0UsR0FBRyxjQUFjLElBQUksV0FBVyxTQUFTLEVBQUUsU0FBUyxNQUFNLFVBQVUsTUFBTSxNQUFNLFVBQVUsQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUc5RixTQUFTLEdBQUcsQ0FBQyxJQUFhLE1BQXdDLEdBQVc7QUFBQSxJQUMzRSxPQUFPLEdBQUcsY0FDUixJQUFJLGNBQWMsTUFBTSxFQUFFLEtBQUssR0FBRyxNQUFNLFFBQVEsQ0FBQyxHQUFHLFNBQVMsTUFBTSxZQUFZLE1BQU0sVUFBVSxLQUFLLENBQUMsQ0FDdkc7QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsR0FBbUI7QUFBQSxJQUNsQyxJQUFJLEVBQUUsV0FBVyxHQUFHO0FBQUEsTUFDbEIsSUFBSSxTQUFTLEtBQUssQ0FBQztBQUFBLFFBQUcsT0FBTyxRQUFRLEVBQUUsWUFBWTtBQUFBLE1BQ25ELElBQUksS0FBSyxLQUFLLENBQUM7QUFBQSxRQUFHLE9BQU8sVUFBVTtBQUFBLE1BQ25DLElBQUksTUFBTTtBQUFBLFFBQUssT0FBTztBQUFBLE1BQ3RCLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsU0FBUyxDQUFDLElBQTRDO0FBQUEsSUFDN0QsSUFBSTtBQUFBLE1BQ0YsR0FBRyxPQUFPO0FBQUEsTUFDVixNQUFNO0FBQUE7QUFBQSxFQUtWLGVBQWUsUUFBUSxDQUFDLElBQWEsT0FBZSxHQUFhO0FBQUEsSUFDL0QsTUFBTSxTQUFTLEVBQUU7QUFBQSxJQUNoQixHQUFtQixNQUFNLEVBQUUsZUFBZSxLQUFLLENBQUM7QUFBQSxJQUVqRCxJQUFLLEdBQW1CLG1CQUFtQjtBQUFBLE1BQ3pDLFNBQVMsWUFBWSxXQUFXO0FBQUEsTUFDaEMsSUFBSTtBQUFBLFFBQU8sU0FBUyxZQUFZLGNBQWMsT0FBTyxLQUFLO0FBQUEsTUFDckQ7QUFBQSxpQkFBUyxZQUFZLFFBQVE7QUFBQSxNQUNsQyxJQUFJLE9BQU8sRUFBRSxNQUFNLE1BQU0sUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLLEdBQUc7QUFBQSxRQUNwRCxHQUFHLGNBQWM7QUFBQSxRQUNqQixVQUFVLElBQUksS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUVBLElBQUksRUFBRSxjQUFjLG9CQUFvQixjQUFjO0FBQUEsTUFBc0IsTUFBTSxJQUFJLFVBQVUsNEJBQTRCO0FBQUEsSUFDNUgsSUFBSSxHQUFHO0FBQUEsTUFBVSxNQUFNLElBQUksVUFBVSxJQUFJLEdBQUcsUUFBUSxHQUFHLHdCQUF3QjtBQUFBLElBRS9FLE1BQU0sV0FBVyxFQUFFLGNBQWMsb0JBQW9CLFVBQVUsSUFBSSxHQUFHLElBQUk7QUFBQSxJQUUxRSxJQUFJLENBQUMsWUFBWSxFQUFFLGFBQWEsV0FBVztBQUFBLE1BQ3pDLFVBQVUsRUFBRTtBQUFBLE1BQ1osTUFBTSxLQUFLLGFBQWEsUUFBUSxTQUFTLFlBQVksY0FBYyxPQUFPLEtBQUssSUFBSSxTQUFTLFlBQVksUUFBUTtBQUFBLE1BQ2hILElBQUksQ0FBQyxNQUFNLEdBQUcsVUFBVSxPQUFPO0FBQUEsUUFDN0IsVUFBVSxJQUFJLEtBQUs7QUFBQSxRQUNuQixVQUFVLElBQUksS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRixFQUFPO0FBQUEsTUFFTCxVQUFVLEVBQUU7QUFBQSxNQUNaLElBQUksQ0FBQyxTQUFTLFlBQVksUUFBUSxLQUFLLEdBQUcsVUFBVSxJQUFJO0FBQUEsUUFDdEQsVUFBVSxJQUFJLEVBQUU7QUFBQSxRQUNoQixVQUFVLElBQUksTUFBTSx1QkFBdUI7QUFBQSxNQUM3QztBQUFBLE1BQ0EsV0FBVyxNQUFNLE9BQU87QUFBQSxRQUN0QixNQUFNLFVBQVUsSUFBSSxJQUFJLFdBQVcsRUFBRTtBQUFBLFFBQ3JDLElBQUksSUFBSSxZQUFZLEVBQUU7QUFBQSxRQUN0QixJQUFJLFNBQVM7QUFBQSxVQUNYLE1BQU0sU0FBUyxHQUFHO0FBQUEsVUFDbEIsSUFBSSxDQUFDLFNBQVMsWUFBWSxjQUFjLE9BQU8sRUFBRSxLQUFLLEdBQUcsVUFBVSxRQUFRO0FBQUEsWUFDekUsVUFBVSxJQUFJLFNBQVMsRUFBRTtBQUFBLFlBQ3pCLFVBQVUsSUFBSSxFQUFFO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsUUFDQSxJQUFJLElBQUksU0FBUyxFQUFFO0FBQUEsUUFDbkIsSUFBSSxFQUFFO0FBQUEsVUFBVSxNQUFNLE1BQU0sRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQTtBQUFBLElBRUYsR0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBO0FBQUEsRUFHekQsU0FBUyxZQUFZLENBQUMsSUFBYSxPQUFlLFlBQXFCO0FBQUEsSUFDckUsSUFBSSxFQUFFLGNBQWM7QUFBQSxNQUFvQixNQUFNLElBQUksVUFBVSwrQkFBK0I7QUFBQSxJQUMzRixNQUFNLE9BQU8sQ0FBQyxHQUFHLEdBQUcsT0FBTztBQUFBLElBQzNCLE1BQU0sVUFBVSxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBVSxLQUFLO0FBQUEsSUFDbEQsTUFBTSxTQUFTLGFBQWEsS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssS0FBSyxNQUFNLFVBQVUsSUFBSTtBQUFBLElBRTdFLE1BQU0sT0FDSCxXQUFXLFVBQVUsUUFBUSxLQUFLLEtBQUssTUFBTSxhQUFhLFNBQVMsWUFDcEUsVUFDQSxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUN4QyxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLEVBQUUsWUFBWSxFQUFFLFNBQVMsTUFBTSxZQUFZLENBQUMsQ0FBQztBQUFBLElBQzVFLElBQUksQ0FBQztBQUFBLE1BQUssTUFBTSxJQUFJLFVBQVUsaUNBQWlDLGNBQWMsUUFBUTtBQUFBLElBQ3JGLEdBQUcsTUFBTTtBQUFBLElBQ1QsR0FBRyxRQUFRLElBQUk7QUFBQSxJQUNmLEdBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxJQUN0RCxHQUFHLGNBQWMsSUFBSSxNQUFNLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUd6RCxlQUFlLFVBQVUsQ0FBQyxJQUFhLE1BQWU7QUFBQSxJQUNwRCxJQUFJLFVBQVUsRUFBRSxNQUFNO0FBQUEsTUFBTTtBQUFBLElBQzVCLElBQUksY0FBYyxvQkFBb0IsR0FBRyxTQUFTLFdBQVcsQ0FBQyxNQUFNO0FBQUEsTUFDbEUsTUFBTSxJQUFJLFVBQVUsNkRBQTZEO0FBQUEsSUFDbkY7QUFBQSxJQUNBLElBQUksVUFBVSxFQUFFO0FBQUEsTUFBRyxNQUFNLFVBQVUsRUFBRTtBQUFBLElBQ2hDLFNBQUksY0FBYyxvQkFBb0IsR0FBRyxTQUFTLE1BQU0sVUFBVSxHQUFHLE9BQU8sRUFBRTtBQUFBLE1BQUcsTUFBTSxVQUFVLEdBQUcsT0FBTyxFQUFFO0FBQUEsSUFDN0c7QUFBQSxNQUFDLEdBQW1CLE1BQU07QUFBQSxJQUMvQixJQUFJLFVBQVUsRUFBRSxNQUFNLFFBQVEsY0FBYyxrQkFBa0I7QUFBQSxNQUM1RCxHQUFHLFVBQVU7QUFBQSxNQUNiLEdBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxNQUN0RCxHQUFHLGNBQWMsSUFBSSxNQUFNLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUEsSUFDekQ7QUFBQTtBQUFBLEVBR0YsSUFBTSxZQUFZO0FBQUEsRUFFbEIsZUFBZSxLQUFLLENBQUMsSUFBYSxHQUFXO0FBQUEsSUFDM0MsTUFBTSxPQUFPLElBQUksSUFBSSxXQUFXLENBQUM7QUFBQSxJQUNqQyxJQUFJLE1BQU07QUFBQSxNQUFTLElBQUksSUFBSSxZQUFZLENBQUM7QUFBQSxJQUN4QyxJQUFJLE1BQU07QUFBQSxNQUNSLElBQUksTUFBTSxTQUFTO0FBQUEsUUFDakIsSUFBSSxjQUFjLG9CQUFvQixHQUFHLE1BQU07QUFBQSxVQUU3QyxNQUFNLE1BQU0sR0FBRyxLQUFLLGNBQTJCLHNGQUFzRjtBQUFBLFVBQ3JJLElBQUk7QUFBQSxZQUFLLE1BQU0sVUFBVSxHQUFHO0FBQUEsVUFDdkI7QUFBQSxlQUFHLEtBQUssY0FBYztBQUFBLFFBQzdCLEVBQU8sU0FBSSxjQUFjLHFCQUFxQixjQUFjLG1CQUFtQjtBQUFBLFVBQzVFLEdBQW1CLE1BQU07QUFBQSxRQUM1QjtBQUFBLE1BQ0YsRUFBTyxTQUFJLE1BQU0sT0FBTztBQUFBLFFBQ3RCLE1BQU0sTUFBTSxDQUFDLEdBQUcsU0FBUyxpQkFBOEIsU0FBUyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sVUFBVSxDQUFDLEtBQUssQ0FBRSxFQUF1QixRQUFRO0FBQUEsUUFDbEksTUFBTSxJQUFJLElBQUksUUFBUSxFQUFpQjtBQUFBLFFBQ3ZDLElBQUssS0FBSSxLQUFLLElBQUksU0FBUyxNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQUEsSUFDQSxJQUFJLElBQUksU0FBUyxDQUFDO0FBQUE7QUFBQSxFQUlwQixTQUFTLFdBQVcsQ0FBQyxJQUFzQjtBQUFBLElBQ3pDLElBQUksR0FBRyxRQUFRLFNBQVM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNsQyxNQUFNLE1BQU0sR0FBRyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxJQUFJLGVBQWU7QUFBQSxNQUFtQixPQUFPLENBQUMsQ0FBQyxJQUFJLFFBQVEsSUFBSSxTQUFTO0FBQUEsSUFDeEUsSUFBSSxlQUFlO0FBQUEsTUFBa0IsT0FBTyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsVUFBVSxPQUFPLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSyxPQUFPLEdBQUcsTUFBTTtBQUFBLElBQ3JILE9BQU87QUFBQTtBQUFBLEVBR1QsZUFBc0IsT0FBTyxDQUFDLE1BQVksR0FBa0M7QUFBQSxJQUMxRSxNQUFNLFVBQVUsS0FBSyxXQUFXLEVBQUU7QUFBQSxJQUNsQyxJQUFJLE1BQU07QUFBQSxJQUNWLElBQUk7QUFBQSxNQUNGLElBQUk7QUFBQSxNQUVKLE1BQU0sT0FBTyxDQUFDLENBQUMsV0FBVyxZQUFZLEVBQUUsU0FBUyxLQUFLLElBQUk7QUFBQSxNQUMxRCxJQUFJLEVBQUUsWUFBWTtBQUFBLFFBQU0sTUFBTSxPQUFPLFNBQVMsRUFBRSxjQUFjO0FBQUEsTUFDOUQsTUFBTSxTQUFTLE9BQU8sVUFBVSxTQUFTO0FBQUEsUUFDdkMsTUFBTSxJQUFJLE1BQU0sS0FBSyxNQUFNLFNBQVMsT0FBTztBQUFBLFFBQzNDLE9BQU8sRUFBRTtBQUFBLFFBQ1QsSUFBSSxFQUFFLFlBQVksTUFBTTtBQUFBLFVBQ3RCLElBQUksVUFBVSxFQUFFLEVBQUU7QUFBQSxZQUFHLE1BQU0sU0FBUyxFQUFFLEVBQUU7QUFBQSxVQUN4QyxNQUFNLE1BQU0sTUFBTSxnQkFBZ0IsRUFBRSxJQUFJLFNBQVMsVUFBVSxFQUFFLEVBQUUsR0FBRyxFQUFFLGNBQWM7QUFBQSxVQUNsRixJQUFJO0FBQUEsWUFBSyxNQUFNLElBQUksVUFBVSxJQUFJLEtBQUssU0FBUyxFQUFFLGFBQWEsS0FBSztBQUFBLFFBQ3JFO0FBQUEsUUFDQSxJQUFJLEVBQUU7QUFBQSxVQUFXLFFBQVEsTUFBTSxFQUFFLElBQUksS0FBSyxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxFQUFFLFlBQVksR0FBRyxHQUFHLE9BQU8sR0FBRztBQUFBLFFBQzFHLE9BQU8sRUFBRTtBQUFBO0FBQUEsTUFHWCxRQUFRLEtBQUs7QUFBQSxhQUNOLFNBQVM7QUFBQSxVQUNaLE1BQU0sS0FBSyxNQUFNLE9BQU87QUFBQSxVQUN4QixNQUFNLFlBQVksRUFBRTtBQUFBLFVBQ3BCLE1BQU0sVUFBVSxFQUFFO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsYUFDSyxRQUFRO0FBQUEsVUFFWCxNQUFNLEtBQUssTUFBTSxPQUFPLEtBQUs7QUFBQSxVQUM3QixJQUFJLGNBQWM7QUFBQSxZQUFtQixhQUFhLElBQUksS0FBSyxTQUFTLEVBQUU7QUFBQSxVQUNqRSxTQUFJLE9BQU8sRUFBRSxNQUFNO0FBQUEsWUFBUyxNQUFNLFdBQVcsSUFBSSxDQUFDLENBQUMsSUFBSSxTQUFTLE9BQU8sR0FBRyxFQUFFLFNBQVMsS0FBSyxTQUFTLEVBQUUsQ0FBQztBQUFBLFVBQ3RHO0FBQUEsa0JBQU0sU0FBUyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUM7QUFBQSxVQUMzQztBQUFBLFFBQ0Y7QUFBQSxhQUNLO0FBQUEsVUFDSCxhQUFhLE1BQU0sT0FBTyxLQUFLLEdBQUcsS0FBSyxTQUFTLElBQUksS0FBSyxVQUFVO0FBQUEsVUFDbkU7QUFBQSxhQUNHO0FBQUEsVUFDSCxNQUFNLFdBQVcsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLFVBQVUsT0FBTztBQUFBLFVBQzVEO0FBQUEsYUFDRyxTQUFTO0FBQUEsVUFDWixNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sT0FBTyxLQUFLLElBQUssU0FBUyxpQkFBaUIsU0FBUztBQUFBLFVBQ3JGLE9BQU8sS0FBSyxTQUFTLGFBQWEsV0FBVyxZQUFZLEVBQUU7QUFBQSxVQUMzRCxNQUFNLE1BQU0sSUFBSSxLQUFLLFNBQVMsT0FBTztBQUFBLFVBQ3JDO0FBQUEsUUFDRjtBQUFBLGFBQ0s7QUFBQSxVQUNILE1BQU0sT0FBTztBQUFBLFVBQ2I7QUFBQSxhQUNHLGNBQWM7QUFBQSxVQUNqQixNQUFNLEtBQUssTUFBTSxPQUFPLEtBQUs7QUFBQSxVQUM3QixNQUFNLFFBQVEsS0FBSyxTQUFTLElBQUksS0FBSztBQUFBLFVBRXJDLE1BQU0sUUFBUSxZQUFZLElBQUk7QUFBQSxVQUM5QixJQUFJLE9BQU87QUFBQSxVQUNYLE9BQU8sTUFBTTtBQUFBLFlBQ1gsT0FBTyxjQUFjLG9CQUFvQixjQUFjLHVCQUF1QixjQUFjLG9CQUFvQixRQUFRLEVBQUUsSUFBSSxPQUFPLEVBQUU7QUFBQSxZQUN2SSxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQUEsY0FBRztBQUFBLFlBQ3pCLElBQUksWUFBWSxJQUFJLElBQUksUUFBUTtBQUFBLGNBQVMsTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLGdCQUFnQixLQUFLLE1BQU0sR0FBRyxFQUFFLElBQUk7QUFBQSxZQUNqSCxNQUFNLE1BQU0sR0FBRztBQUFBLFVBQ2pCO0FBQUEsVUFDQTtBQUFBLFFBQ0Y7QUFBQTtBQUFBLFVBRUUsTUFBTSxJQUFJLFVBQVUsaUJBQWlCLEtBQUssa0NBQWtDO0FBQUE7QUFBQSxNQUVoRixPQUFPLEVBQUUsSUFBSSxNQUFNLGNBQWMsTUFBTSxhQUFhLElBQUk7QUFBQSxNQUN4RCxPQUFPLEdBQUc7QUFBQSxNQUNWLE9BQU8sRUFBRSxJQUFJLE9BQU8sT0FBTyxhQUFhLFFBQVEsRUFBRSxVQUFVLE9BQU8sQ0FBQyxFQUFFO0FBQUE7QUFBQTtBQUFBLEVBSTFFLGVBQXNCLFNBQVMsQ0FBQyxXQUF1QztBQUFBLElBQ3JFLE1BQU0sSUFBSSxRQUFRLFNBQVM7QUFBQSxJQUMzQixJQUFJLENBQUM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNmLE1BQU0sU0FBUyxFQUFFLEVBQUU7QUFBQSxJQUNuQixRQUFRLE1BQU0sRUFBRSxJQUFJLEVBQUUsVUFBVSxNQUFNLE9BQU8sS0FBSztBQUFBLElBQ2xELE9BQU87QUFBQTs7O0VDdlNULElBQUksT0FBb0I7QUFBQSxFQUN4QixJQUFJLE9BQWtDLE1BQU07QUFBQSxFQUM1QyxJQUFNLGNBQWMsSUFBSTtBQUFBLEVBRXhCLElBQU0sT0FBbUMsRUFBRSxPQUFPLFNBQVMsTUFBTSxZQUFZLFFBQVEsZUFBZSxPQUFPLFVBQVUsTUFBTSxVQUFVO0FBQUEsRUFHOUgsU0FBUyxPQUFPLENBQUMsSUFBa0M7QUFBQSxJQUN4RCxNQUFNLE9BQU8sT0FBTyxFQUFFO0FBQUEsSUFDdEIsSUFBSSxTQUFTO0FBQUEsTUFBUSxPQUFPO0FBQUEsSUFDNUIsT0FBTyxhQUFhLGFBQWEsZUFBZSxFQUFFO0FBQUEsSUFDbEQsTUFBTSxPQUFPLEVBQUUsVUFBVSxXQUFXLE9BQU8sU0FBUyxFQUFFLEVBQUU7QUFBQSxJQUN4RCxRQUFRO0FBQUEsV0FDRDtBQUFBLFFBQ0gsT0FBTyxLQUFLLE1BQU0sTUFBTSxRQUFRLE9BQU8sUUFBUSxFQUFFLEdBQUcsUUFBUyxHQUF3QixTQUFTLGNBQWMsVUFBVTtBQUFBLFdBQ25ILFVBQVU7QUFBQSxRQUNiLE1BQU0sSUFBSTtBQUFBLFFBQ1YsT0FBTyxLQUFLLE1BQU0sTUFBTSxVQUFVLE9BQU8sRUFBRSxPQUFPLFlBQVksRUFBRSxnQkFBZ0IsSUFBSSxLQUFLLEtBQUssRUFBRTtBQUFBLE1BQ2xHO0FBQUEsV0FDSztBQUFBLFFBQ0gsT0FBTyxLQUFLLE1BQU0sTUFBTSxTQUFTLE9BQU8sT0FBTyxVQUFVLEVBQUUsQ0FBQyxFQUFFO0FBQUE7QUFBQSxRQUU5RCxPQUFPLEtBQUssTUFBTSxNQUFNLFFBQVE7QUFBQTtBQUFBO0FBQUEsRUFJdEMsU0FBUyxJQUFJLENBQUMsSUFBYSxNQUEyQjtBQUFBLElBQ3BELElBQUksQ0FBQztBQUFBLE1BQU07QUFBQSxJQUNYLEtBQUssSUFBSTtBQUFBLElBQ1QsTUFBTSxPQUFPLEtBQUssU0FBUyxTQUFVLEtBQUssU0FBUyxTQUFTLEtBQUssS0FBSyxTQUFTLElBQUksTUFBTSxHQUFHLEVBQUUsT0FBUTtBQUFBLElBQ3RHLFFBQVEsTUFBTSxLQUFLLEtBQUssS0FBSyxTQUF1QixLQUFLLFNBQVMsS0FBSyxTQUFTLE9BQU8sS0FBSyxHQUFHLE9BQU8sT0FBTyxFQUFFLEVBQUU7QUFBQTtBQUFBLEVBR25ILFNBQVMsVUFBVSxHQUFHO0FBQUEsSUFDcEIsWUFBWSxJQUFJLE1BQU0sYUFBYTtBQUFBLE1BQ2pDLGFBQWEsQ0FBQztBQUFBLE1BQ2QsS0FBSyxRQUFRLEVBQUUsQ0FBRTtBQUFBLElBQ25CO0FBQUEsSUFDQSxZQUFZLE1BQU07QUFBQTtBQUFBLEVBR3BCLFNBQVMsWUFBWSxDQUFDLElBQWE7QUFBQSxJQUNqQyxhQUFhLFlBQVksSUFBSSxFQUFFLENBQUM7QUFBQSxJQUNoQyxZQUFZLElBQ1YsSUFDQSxXQUFXLE1BQU07QUFBQSxNQUNmLFlBQVksT0FBTyxFQUFFO0FBQUEsTUFDckIsTUFBTSxJQUFJLFFBQVEsRUFBRTtBQUFBLE1BQ3BCLElBQUk7QUFBQSxRQUFHLEtBQUssQ0FBQztBQUFBLE9BQ1osR0FBRyxDQUNSO0FBQUE7QUFBQSxFQUdGLElBQU0sV0FBVyxDQUFDLE1BQTZCO0FBQUEsSUFDN0MsTUFBTSxJQUFJLEVBQUUsYUFBYSxFQUFFO0FBQUEsSUFDM0IsT0FBTyxhQUFhLFVBQVUsSUFBSTtBQUFBO0FBQUEsRUFLcEMsU0FBUyxNQUFNLENBQUMsR0FBZTtBQUFBLElBQzdCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUMzQixNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsSUFDdkIsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ25CLE1BQU0sT0FBTyxNQUFNLFNBQVMsK0JBQStCLEdBQUcsS0FBSyxRQUFRLFNBQVMsRUFBRTtBQUFBLElBQ3RGLFFBQVEsS0FBSyxJQUFJLE1BQU0sT0FBTyxFQUFFO0FBQUE7QUFBQSxFQUlsQyxTQUFTLFlBQVksQ0FBQyxHQUFVO0FBQUEsSUFDOUIsSUFBSSxTQUFTLFdBQVcsQ0FBQyxFQUFFO0FBQUEsTUFBVztBQUFBLElBQ3RDLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUMzQixJQUFJLE9BQU8sV0FBVyxDQUFDLENBQUMsTUFBTSxTQUFTO0FBQUEsTUFDckMsRUFBRSxlQUFlO0FBQUEsTUFDakIsRUFBRSx5QkFBeUI7QUFBQSxJQUM3QjtBQUFBO0FBQUEsRUFHRixTQUFTLE9BQU8sQ0FBQyxHQUFlO0FBQUEsSUFDOUIsSUFBSSxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDbEIsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxDQUFDO0FBQUEsTUFBRztBQUFBLElBQzNCLGFBQWEsQ0FBQztBQUFBLElBQ2QsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQ3ZCLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixJQUFJLE1BQU07QUFBQSxNQUFRLE9BQU8sUUFBUSxNQUFNLGtEQUFrRCxXQUFXLElBQUk7QUFBQSxJQUN4RyxJQUFJLE1BQU0sV0FBVyxNQUFNO0FBQUEsTUFBVTtBQUFBLElBQ3JDLFdBQVc7QUFBQSxJQUNYLElBQUksTUFBTSxRQUFRO0FBQUEsTUFHaEIsSUFBSSxRQUFRLEVBQUU7QUFBQSxRQUFHLEtBQUssSUFBSSxRQUFRLEVBQUUsQ0FBQztBQUFBLE1BQ3JDO0FBQUEsSUFDRjtBQUFBLElBQ0EsS0FBSyxJQUFJLFFBQVEsRUFBRSxDQUFDO0FBQUE7QUFBQSxFQUd0QixTQUFTLE9BQU8sQ0FBQyxHQUFVO0FBQUEsSUFDekIsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUNSLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixJQUFJLE9BQU8sRUFBRSxNQUFNO0FBQUEsTUFBUSxhQUFhLEVBQUU7QUFBQTtBQUFBLEVBRzVDLFNBQVMsUUFBUSxDQUFDLEdBQVU7QUFBQSxJQUMxQixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQVc7QUFBQSxJQUNsQixNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDO0FBQUEsTUFBRztBQUFBLElBQ1IsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQ3ZCLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixJQUFJLE1BQU0sUUFBUTtBQUFBLE1BQ2hCLGFBQWEsWUFBWSxJQUFJLEVBQUUsQ0FBQztBQUFBLE1BQ2hDLFlBQVksT0FBTyxFQUFFO0FBQUEsTUFDckIsS0FBSyxRQUFRLEVBQUUsQ0FBRTtBQUFBLElBQ25CLEVBQU8sU0FBSSxNQUFNLFlBQVksTUFBTSxTQUFTO0FBQUEsTUFDMUMsV0FBVztBQUFBLE1BQ1gsS0FBSyxJQUFJLFFBQVEsRUFBRSxDQUFDO0FBQUEsSUFDdEI7QUFBQTtBQUFBLEVBR0YsU0FBUyxLQUFLLENBQUMsR0FBa0I7QUFBQSxJQUMvQixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQVc7QUFBQSxJQUNsQixJQUFJLFNBQVMsV0FBVyxFQUFFLFFBQVEsVUFBVTtBQUFBLE1BQzFDLEVBQUUsZUFBZTtBQUFBLE1BQ2pCLFlBQVk7QUFBQSxNQUNaO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQztBQUFBLE1BQUc7QUFBQSxJQUNSLElBQUksRUFBRSxRQUFRLFdBQVcsYUFBYSxvQkFBb0IsT0FBTyxDQUFDLE1BQU0sUUFBUTtBQUFBLE1BQzlFLFdBQVc7QUFBQSxNQUNYLEtBQUssRUFBRSxNQUFNLFNBQVMsT0FBTyxTQUFTLFVBQVUsZUFBZSxDQUFDLEVBQUUsSUFBSSxPQUFPLFNBQVMsQ0FBQyxFQUFFLENBQUM7QUFBQSxNQUMxRixRQUFRLE1BQU0scUJBQXFCLFNBQVMsQ0FBQyxHQUFHO0FBQUEsSUFDbEQ7QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLEdBQUc7QUFBQSxJQUNqQixXQUFXO0FBQUE7QUFBQSxFQUdiLElBQU0sV0FBVyxNQUFNLFFBQVEsS0FBSztBQUFBLEVBRXBDLElBQUksY0FBMEIsTUFBTTtBQUFBLEVBRXBDLElBQU0sWUFBdUM7QUFBQSxJQUMzQyxDQUFDLGFBQWEsTUFBdUI7QUFBQSxJQUNyQyxDQUFDLGVBQWUsWUFBWTtBQUFBLElBQzVCLENBQUMsYUFBYSxZQUFZO0FBQUEsSUFDMUIsQ0FBQyxhQUFhLFlBQVk7QUFBQSxJQUMxQixDQUFDLFdBQVcsWUFBWTtBQUFBLElBQ3hCLENBQUMsU0FBUyxPQUF3QjtBQUFBLElBQ2xDLENBQUMsU0FBUyxPQUFPO0FBQUEsSUFDakIsQ0FBQyxVQUFVLFFBQVE7QUFBQSxJQUNuQixDQUFDLFdBQVcsS0FBc0I7QUFBQSxFQUNwQztBQUFBLEVBRU8sU0FBUyxjQUFjLENBQUMsR0FBUyxNQUFpQyxRQUFvQjtBQUFBLElBQzNGLElBQUk7QUFBQSxNQUFNLGNBQWM7QUFBQSxJQUN4QixPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxjQUFjO0FBQUEsSUFDZCxRQUFRLFNBQVM7QUFBQSxJQUNqQixxQkFBcUIsSUFBSTtBQUFBLElBQ3pCLFlBQVksSUFBSSxPQUFPO0FBQUEsTUFBVyxPQUFPLGlCQUFpQixJQUFJLElBQUksSUFBSTtBQUFBLElBQ3RFLE9BQU8saUJBQWlCLFlBQVksT0FBTztBQUFBLElBQzNDLE9BQU8saUJBQWlCLFVBQVUsVUFBVSxJQUFJO0FBQUEsSUFFaEQsSUFBSSxXQUFXLE9BQU87QUFBQSxNQUFLLFFBQVEsUUFBUSxDQUFDO0FBQUE7QUFBQSxFQUd2QyxTQUFTLGFBQWEsR0FBRztBQUFBLElBQzlCLFdBQVc7QUFBQSxJQUNYLFlBQVksSUFBSSxPQUFPO0FBQUEsTUFBVyxPQUFPLG9CQUFvQixJQUFJLElBQUksSUFBSTtBQUFBLElBQ3pFLE9BQU8sb0JBQW9CLFlBQVksT0FBTztBQUFBLElBQzlDLE9BQU8sb0JBQW9CLFVBQVUsVUFBVSxJQUFJO0FBQUEsSUFDbkQscUJBQXFCLEtBQUs7QUFBQSxJQUMxQixPQUFPO0FBQUEsSUFDUCxRQUFRLEtBQUs7QUFBQSxJQUNiLFFBQVEsUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUlmLFNBQVMsUUFBUSxHQUFpQztBQUFBLElBQ3ZELE9BQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUFBLE1BQzlCLE1BQU0sUUFBUSxDQUFDLE1BQWE7QUFBQSxRQUMxQixJQUFJLFFBQVEsS0FBSyxTQUFTLENBQUMsQ0FBQztBQUFBLFVBQUc7QUFBQSxRQUMvQixFQUFFLGVBQWU7QUFBQSxRQUNqQixFQUFFLHlCQUF5QjtBQUFBO0FBQUEsTUFFN0IsTUFBTSxPQUFPLENBQUMsTUFBMkI7QUFBQSxRQUN2QyxPQUFPLG9CQUFvQixhQUFhLFFBQXlCLElBQUk7QUFBQSxRQUNyRSxXQUFXLE1BQU0sQ0FBQyxlQUFlLGFBQWEsYUFBYSxTQUFTO0FBQUEsVUFBRyxPQUFPLG9CQUFvQixJQUFJLE9BQU8sSUFBSTtBQUFBLFFBQ2pILE9BQU8sb0JBQW9CLFNBQVMsT0FBTyxJQUFJO0FBQUEsUUFDL0MsT0FBTyxvQkFBb0IsV0FBVyxLQUFLLElBQUk7QUFBQSxRQUMvQyxRQUFRLEtBQUs7QUFBQSxRQUNiLGFBQWEsTUFBTTtBQUFBLFFBQ25CLElBQUksQ0FBQztBQUFBLFVBQU0scUJBQXFCLEtBQUs7QUFBQSxRQUNyQyxRQUFRLENBQUM7QUFBQTtBQUFBLE1BRVgsTUFBTSxRQUFRLENBQUMsTUFBa0I7QUFBQSxRQUMvQixNQUFNLENBQUM7QUFBQSxRQUNQLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxRQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLFVBQUc7QUFBQSxRQUMzQixLQUFLLFFBQVEsV0FBVyxDQUFDLENBQUMsS0FBSyxJQUFJO0FBQUE7QUFBQSxNQUVyQyxNQUFNLE1BQU0sQ0FBQyxNQUFxQjtBQUFBLFFBQ2hDLElBQUksRUFBRSxRQUFRLFVBQVU7QUFBQSxVQUN0QixFQUFFLGVBQWU7QUFBQSxVQUNqQixLQUFLLElBQUk7QUFBQSxRQUNYO0FBQUE7QUFBQSxNQUVGLHFCQUFxQixJQUFJO0FBQUEsTUFDekIsT0FBTyxpQkFBaUIsYUFBYSxRQUF5QixJQUFJO0FBQUEsTUFDbEUsV0FBVyxNQUFNLENBQUMsZUFBZSxhQUFhLGFBQWEsU0FBUztBQUFBLFFBQUcsT0FBTyxpQkFBaUIsSUFBSSxPQUFPLElBQUk7QUFBQSxNQUM5RyxPQUFPLGlCQUFpQixTQUFTLE9BQU8sSUFBSTtBQUFBLE1BQzVDLE9BQU8saUJBQWlCLFdBQVcsS0FBSyxJQUFJO0FBQUEsTUFDNUMsYUFBYSxNQUFNLEtBQUssSUFBSTtBQUFBLE1BQzVCLElBQUksV0FBVyxPQUFPO0FBQUEsUUFBSyxRQUFRLE1BQU0sdUNBQXVDO0FBQUEsS0FDakY7QUFBQTtBQUFBLEVBR0ksSUFBSSxhQUF5QixNQUFNOzs7RUNoTzFDLFNBQVMsSUFBYSxDQUFDLEtBQTJDO0FBQUEsSUFDaEUsSUFBSTtBQUFBLE1BQ0YsT0FBTyxPQUFPLFFBQVEsWUFBWSxHQUFHLEVBQUUsTUFBTSxNQUFHO0FBQUEsUUFBRztBQUFBLE9BQVM7QUFBQSxNQUM1RCxNQUFNO0FBQUEsTUFFTixjQUFjO0FBQUEsTUFDZCxPQUFPLFFBQVEsUUFBUSxTQUFTO0FBQUE7QUFBQTtBQUFBLEVBSXBDLElBQU0sT0FBTyxDQUFDLFNBQXVCLEtBQUssS0FBSyxFQUFFLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxFQUM1RSxJQUFNLFNBQVMsTUFBTSxLQUFLLEtBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLEVBSXRELElBQU0sTUFBTTtBQUFBLEVBRVosSUFBTSxZQUFZLElBQUk7QUFBQSxFQUV0QixTQUFTLGVBQWUsQ0FBQyxRQUF3RDtBQUFBLElBQy9FLElBQUksQ0FBQztBQUFBLE1BQVE7QUFBQSxJQUNiLE9BQU8sQ0FBQyxHQUFHLFNBQVMsaUJBQWlCLGVBQWUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFPLEVBQXdCLGtCQUFrQixNQUFNO0FBQUE7QUFBQSxFQUd0SCxTQUFTLGNBQWMsQ0FBQyxHQUFpQjtBQUFBLElBQ3ZDLE1BQU0sSUFBSSxFQUFFO0FBQUEsSUFDWixJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sWUFBWSxFQUFFLFFBQVEsUUFBUSxPQUFPLEVBQUUsVUFBVTtBQUFBLE1BQVU7QUFBQSxJQUNsRixJQUFJLEVBQUUsU0FBUyxZQUFZO0FBQUEsTUFDekIsTUFBTSxLQUFLLGdCQUFnQixFQUFFLE1BQU07QUFBQSxNQUNuQyxJQUFJO0FBQUEsUUFBSSxVQUFVLElBQUksRUFBRSxPQUFPLEVBQUU7QUFBQSxJQUNuQyxFQUFPLFNBQUksRUFBRSxTQUFTLFdBQVcsRUFBRSxXQUFXLE9BQU8sVUFBVSxXQUFXLE9BQU8sS0FBSztBQUFBLE1BQy9FLEtBQUssRUFBRSxNQUFNLGVBQWUsT0FBTyxFQUFFLE1BQU0sQ0FBQztBQUFBLElBQ25EO0FBQUE7QUFBQSxFQUdGLGVBQWUscUJBQXFCLENBQUMsT0FBeUM7QUFBQSxJQUM1RSxTQUFTLElBQUksRUFBRyxJQUFJLE1BQU0sQ0FBQyxVQUFVLElBQUksS0FBSyxHQUFHO0FBQUEsTUFBSyxNQUFNLE1BQU0sRUFBRTtBQUFBLElBQ3BFLE1BQU0sS0FBSyxVQUFVLElBQUksS0FBSztBQUFBLElBQzlCLFVBQVUsT0FBTyxLQUFLO0FBQUEsSUFDdEIsT0FBTyxLQUFLLGVBQWUsRUFBRSxJQUFJO0FBQUE7QUFBQSxFQUduQyxlQUFlLFlBQVksQ0FBQyxXQUFxQixTQUE4RDtBQUFBLElBQzdHLE1BQU0sTUFBTSxZQUFZLElBQUksSUFBSTtBQUFBLElBQ2hDLE9BQU8sTUFBTTtBQUFBLE1BQ1gsTUFBTSxJQUFJLFFBQVEsU0FBUztBQUFBLE1BQzNCLE1BQU0sTUFBTSxLQUFNLEVBQUUsR0FBeUI7QUFBQSxNQUM3QyxJQUFJLEtBQUs7QUFBQSxRQUNQLE1BQU0sUUFBUSxPQUFPLFdBQVc7QUFBQSxRQUNoQyxJQUFJLFlBQVksR0FBRyxNQUFNLFNBQVMsTUFBTSxHQUFHLEdBQUc7QUFBQSxRQUM5QyxPQUFPLEVBQUUsTUFBTTtBQUFBLE1BQ2pCO0FBQUEsTUFDQSxJQUFJLFlBQVksSUFBSSxJQUFJO0FBQUEsUUFBSyxPQUFPLEVBQUUsT0FBTyw2QkFBNkIsVUFBVSxNQUFNO0FBQUEsTUFDMUYsTUFBTSxNQUFNLEdBQUc7QUFBQSxJQUNqQjtBQUFBO0FBQUEsRUFHRixJQUFJLENBQUMsT0FBTyxVQUFVO0FBQUEsSUFDcEIsT0FBTyxXQUFXO0FBQUEsSUFDbEIsT0FBTyxpQkFBaUIsV0FBVyxjQUFjO0FBQUEsSUFFakQsT0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLEtBQWdCLFNBQVMsVUFBVTtBQUFBLE1BQ3ZFLFFBQVEsSUFBSTtBQUFBLGFBQ0w7QUFBQSxVQUNILE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsZUFBZSxJQUFJLE1BQU0sTUFBTSxNQUFNO0FBQUEsVUFDckMsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxjQUFjO0FBQUEsVUFDZCxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFBQSxVQUNsQjtBQUFBLGFBQ0c7QUFBQSxVQUNILFFBQVEsSUFBSSxNQUFNLElBQUksUUFBUSxFQUFFLEtBQUssS0FBSztBQUFBLFVBQzFDLE9BQU87QUFBQSxhQUNKO0FBQUEsVUFDSCxVQUFVLENBQUMsSUFBSSxVQUFVLEdBQUksSUFBSSxhQUFhLENBQUMsQ0FBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLFVBQVUsTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDLENBQUM7QUFBQSxVQUN4RixPQUFPO0FBQUEsYUFDSjtBQUFBLFVBR0gsU0FBUyxFQUFFLEtBQUssT0FBTyxTQUFTLE1BQU0sT0FBUyxNQUFNLEtBQW1CLEVBQUUsTUFBTSxnQkFBZ0IsS0FBSyxDQUFDLEtBQU0sT0FBUSxJQUFJLENBQUM7QUFBQSxVQUN6SCxPQUFPO0FBQUEsYUFDSjtBQUFBLFVBQ0gsV0FBVztBQUFBLFVBQ1gsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxPQUFPLE9BQU8sWUFBWSxHQUFHLE1BQU0sWUFBWSxPQUFPLElBQUksTUFBTSxHQUFHLEdBQUc7QUFBQSxVQUN0RSxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFBQSxVQUNsQjtBQUFBLGFBQ0c7QUFBQSxVQUNILHNCQUFzQixJQUFJLEtBQUssRUFBRSxLQUFLLEtBQUs7QUFBQSxVQUMzQyxPQUFPO0FBQUEsYUFDSjtBQUFBLFVBQ0gsYUFBYSxJQUFJLFdBQVcsSUFBSSxPQUFPLEVBQUUsS0FBSyxLQUFLO0FBQUEsVUFDbkQsT0FBTztBQUFBO0FBQUEsS0FFWjtBQUFBLElBR0QsS0FBb0MsRUFBRSxNQUFNLGdCQUFnQixDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU07QUFBQSxNQUN6RSxJQUFJLEdBQUc7QUFBQSxRQUFNLGVBQWUsRUFBRSxNQUFNLE1BQU0sTUFBTTtBQUFBLEtBQ2pEO0FBQUEsRUFDSDsiLAogICJkZWJ1Z0lkIjogIkNDQjQyMDhGQTVDMUE2RkM2NDc1NkUyMTY0NzU2RTIxIiwKICAibmFtZXMiOiBbXQp9
