(() => {
  // src/shared/util.ts
  function looksGenerated(s) {
    return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  // src/content/overlay.ts
  var CSS2 = `
:host { all: initial; }
.box {
  position: fixed; pointer-events: none; z-index: 2147483646; display: none;
  border: 2px solid var(--c, #7c5cff); background: color-mix(in srgb, var(--c, #7c5cff) 12%, transparent);
  border-radius: 4px; transition: all 60ms ease-out; box-sizing: border-box;
}
.tag {
  position: fixed; pointer-events: none; z-index: 2147483647; display: none;
  font: 600 11px/1.2 ui-sans-serif, system-ui, sans-serif; color: #fff; background: var(--c, #7c5cff);
  padding: 4px 7px; border-radius: 5px; white-space: nowrap; max-width: 360px; overflow: hidden; text-overflow: ellipsis;
  box-shadow: 0 2px 8px rgb(0 0 0 / .25);
}
.pill {
  position: fixed; z-index: 2147483647; left: 50%; bottom: 18px; transform: translateX(-50%);
  display: none; align-items: center; gap: 10px; padding: 7px 8px 7px 14px; border-radius: 999px;
  font: 600 12px/1 ui-sans-serif, system-ui, sans-serif; color: #f4f2ff; background: #1b1830ee;
  box-shadow: 0 6px 24px rgb(0 0 0 / .35); backdrop-filter: blur(6px); user-select: none;
}
.dot { width: 9px; height: 9px; border-radius: 50%; background: #ff4d6d; animation: pulse 1.2s infinite; }
.pill.point .dot { background: #7c5cff; }
@keyframes pulse { 50% { opacity: .35; } }
.pill button {
  all: unset; cursor: pointer; padding: 5px 10px; border-radius: 999px; background: #ffffff1f; color: #fff;
  font: 600 11px/1 ui-sans-serif, system-ui, sans-serif;
}
.pill button:hover { background: #ffffff38; }
.toasts { position: fixed; z-index: 2147483647; right: 16px; bottom: 64px; display: flex; flex-direction: column; gap: 6px; align-items: flex-end; pointer-events: none; }
.toast {
  font: 500 12px/1.3 ui-sans-serif, system-ui, sans-serif; color: #fff; background: #1b1830ee; padding: 7px 11px;
  border-radius: 8px; border-left: 3px solid var(--c, #7c5cff); box-shadow: 0 4px 14px rgb(0 0 0 / .3);
  animation: in .18s ease-out; max-width: 340px;
}
.toast.warn { --c: #ffb020; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } }
`;
  var COLORS = { click: "#7c5cff", fill: "#14b8a6", select: "#0ea5e9", check: "#22c55e", file: "#ffb020", run: "#f97316" };

  class Overlay {
    host;
    box;
    tag;
    pill;
    pillText;
    toasts;
    onStop = () => {};
    ensure() {
      if (this.host?.isConnected)
        return;
      this.host = document.createElement("div");
      this.host.id = "__rastro_host";
      const root = this.host.attachShadow({ mode: "open" });
      root.innerHTML = `<style>${CSS2}</style><div class="box"></div><div class="tag"></div>
      <div class="pill"><span class="dot"></span><span class="txt"></span><button type="button">Terminar</button></div>
      <div class="toasts"></div>`;
      this.box = root.querySelector(".box");
      this.tag = root.querySelector(".tag");
      this.pill = root.querySelector(".pill");
      this.pillText = root.querySelector(".txt");
      this.toasts = root.querySelector(".toasts");
      root.querySelector("button").addEventListener("click", (e) => {
        e.stopPropagation();
        this.onStop();
      });
      document.documentElement.appendChild(this.host);
    }
    owns(el) {
      return !!this.host && el instanceof Node && (el === this.host || this.host.contains(el));
    }
    show(el, text, color = COLORS.click) {
      this.ensure();
      const r = el.getBoundingClientRect();
      Object.assign(this.box.style, {
        display: "block",
        left: `${r.left - 3}px`,
        top: `${r.top - 3}px`,
        width: `${r.width + 6}px`,
        height: `${r.height + 6}px`
      });
      this.box.style.setProperty("--c", color);
      this.tag.style.setProperty("--c", color);
      this.tag.textContent = text;
      this.tag.style.display = "block";
      const above = r.top > 30;
      this.tag.style.left = `${Math.max(4, Math.min(r.left - 3, innerWidth - 370))}px`;
      this.tag.style.top = above ? `${r.top - 27}px` : `${r.bottom + 6}px`;
    }
    hide() {
      if (!this.box)
        return;
      this.box.style.display = "none";
      this.tag.style.display = "none";
    }
    flash(el, text, ms = 700, color = COLORS.run) {
      this.show(el, text, color);
      setTimeout(() => this.hide(), ms);
    }
    setPill(mode) {
      this.ensure();
      if (!mode) {
        this.pill.style.display = "none";
        return;
      }
      this.pill.className = "pill " + mode;
      this.pillText.textContent = mode === "record" ? "Rastro grabando" : "Rastro · modo señalar (Esc para salir)";
      this.pill.style.display = "flex";
    }
    toast(text, color, warn = false) {
      this.ensure();
      const t = document.createElement("div");
      t.className = "toast" + (warn ? " warn" : "");
      if (color)
        t.style.setProperty("--c", color);
      t.textContent = text;
      this.toasts.appendChild(t);
      setTimeout(() => t.remove(), 2200);
      while (this.toasts.children.length > 4)
        this.toasts.firstElementChild.remove();
    }
  }
  var overlay = new Overlay;

  // src/content/selector.ts
  var TEST_ATTRS = ["data-testid", "data-test-id", "data-test", "data-cy", "data-qa", "data-e2e", "data-automation-id"];
  var CLICKABLE = 'button, a[href], [role="button"], [role="link"], [role="menuitem"], [role="tab"], [role="option"], ' + '[role="checkbox"], [role="radio"], [role="switch"], input[type="submit"], input[type="button"], ' + 'input[type="reset"], input[type="image"], summary, label, [onclick]';
  var CONTROL = 'input, textarea, select, [contenteditable]:not([contenteditable="false"])';
  var norm = (s) => (s ?? "").replace(/\s+/g, " ").trim();
  var STATE_CLASSES = /^(is-|has-)?(active|focus(ed)?|hover(ed)?|selected|open(ed)?|disabled|checked|visible|hidden|show|in|ng-.*)$/i;
  function stableClasses(el) {
    return [...el.classList].filter((c) => !looksGenerated(c) && !STATE_CLASSES.test(c) && !c.includes(":") && c.length < 32);
  }
  var q = (v) => JSON.stringify(v);
  function isVisible(el) {
    if (!el.isConnected)
      return false;
    if (el.getClientRects().length === 0)
      return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.opacity !== "0";
  }
  function textOf(el) {
    if (el instanceof HTMLInputElement && ["submit", "button", "reset"].includes(el.type))
      return norm(el.value);
    return norm(el.innerText ?? el.textContent);
  }
  function* allElements(root = document) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    let n = walker.nextNode();
    while (n) {
      yield n;
      const sr = n.shadowRoot;
      if (sr)
        yield* allElements(sr);
      n = walker.nextNode();
    }
  }
  function byText(text) {
    const target = norm(text);
    const exact = [];
    const partial = [];
    const lower = target.toLowerCase();
    for (const el of allElements()) {
      if (el.closest("script, style, noscript, template, #__rastro_host"))
        continue;
      const limit = target.length * 3 + 20;
      if (!(el instanceof HTMLInputElement) && norm(el.textContent).length > limit)
        continue;
      const t = textOf(el);
      if (!t || t.length > limit)
        continue;
      if (t === target)
        exact.push(el);
      else if (t.toLowerCase().includes(lower))
        partial.push(el);
    }
    const pick = exact.length ? exact : partial;
    const deepest = pick.filter((el) => !pick.some((o) => o !== el && el.contains(o)));
    return dedupe(deepest.map((el) => el.closest(CLICKABLE) ?? el));
  }
  function byLabel(text) {
    const target = norm(text).toLowerCase();
    const out = [];
    for (const label of document.querySelectorAll("label")) {
      if (norm(label.innerText).toLowerCase().replace(/\s*\*$/, "") === target && label.control)
        out.push(label.control);
    }
    for (const el of document.querySelectorAll(CONTROL + ", [aria-label], [aria-labelledby]")) {
      if (norm(el.getAttribute("aria-label")).toLowerCase() === target)
        out.push(el);
      const lb = el.getAttribute("aria-labelledby");
      if (lb) {
        const t = lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" ");
        if (norm(t).toLowerCase() === target)
          out.push(el);
      }
    }
    if (!out.length) {
      for (const el of document.querySelectorAll("[placeholder]")) {
        if (norm(el.getAttribute("placeholder")).toLowerCase() === target)
          out.push(el);
      }
    }
    return dedupe(out);
  }
  function byXPath(xp) {
    const res = document.evaluate(xp, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
    const out = [];
    for (let i = 0;i < res.snapshotLength; i++) {
      const n = res.snapshotItem(i);
      if (n instanceof Element)
        out.push(n);
    }
    return out;
  }
  function dedupe(arr) {
    return [...new Set(arr)];
  }
  function resolveAll(selector) {
    try {
      if (selector.startsWith("text="))
        return byText(unquote(selector.slice(5)));
      if (selector.startsWith("label="))
        return byLabel(unquote(selector.slice(6)));
      if (selector.startsWith("xpath="))
        return byXPath(selector.slice(6));
      if (selector.startsWith("frame=")) {
        const f = document.querySelectorAll("iframe, frame")[Number(selector.slice(6))];
        return f ? [f] : [];
      }
      return [...document.querySelectorAll(selector)];
    } catch {
      return [];
    }
  }
  function unquote(s) {
    const t = s.trim();
    if (t.startsWith('"') && t.endsWith('"') || t.startsWith("'") && t.endsWith("'"))
      return t.slice(1, -1);
    return t;
  }
  function resolve(selectors) {
    for (const sel of selectors) {
      const found = resolveAll(sel);
      if (found.length === 1)
        return { el: found[0], selector: sel };
      const vis = found.filter(isVisible);
      if (vis.length >= 1)
        return { el: vis[0], selector: sel };
      if (found.length)
        return { el: found[0], selector: sel };
    }
    return null;
  }
  function isUnique(sel, el) {
    const r = resolveAll(sel);
    return r.length === 1 && r[0] === el;
  }
  function cssPath(el) {
    const parts = [];
    let cur = el;
    while (cur && cur !== document.documentElement) {
      const tag = cur.tagName.toLowerCase();
      if (cur !== el && cur.id && !looksGenerated(cur.id)) {
        parts.unshift("#" + CSS.escape(cur.id));
        const s = parts.join(" > ");
        if (isUnique(s, el))
          return s;
        parts.shift();
      }
      let seg = tag;
      const cls = stableClasses(cur).slice(0, 2);
      if (cls.length)
        seg += "." + cls.map((c) => CSS.escape(c)).join(".");
      const withoutNth = [seg, ...parts].join(" > ");
      if (isUnique(withoutNth, el))
        return withoutNth;
      const parent = cur.parentElement;
      if (parent) {
        const same = [...parent.children].filter((c) => c.tagName === cur.tagName);
        if (same.length > 1)
          seg += `:nth-of-type(${same.indexOf(cur) + 1})`;
      }
      parts.unshift(seg);
      const s = parts.join(" > ");
      if (isUnique(s, el))
        return s;
      cur = parent;
    }
    return parts.join(" > ");
  }
  function buildSelectors(el) {
    const tag = el.tagName.toLowerCase();
    const c = [];
    for (const a of TEST_ATTRS) {
      const v = el.getAttribute(a);
      if (v)
        c.push(`[${a}=${q(v)}]`);
    }
    if (el.id && !looksGenerated(el.id))
      c.push("#" + CSS.escape(el.id));
    const name = el.getAttribute("name");
    if (name) {
      if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.value && el.value !== "on") {
        c.push(`${tag}[name=${q(name)}][value=${q(el.value)}]`);
      } else
        c.push(`${tag}[name=${q(name)}]`);
    }
    const isControl = el.matches(CONTROL);
    if (isControl) {
      const lbl = labelText(el);
      if (lbl && lbl.length <= 60)
        c.push(`label=${lbl}`);
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      c.push(`${tag}[aria-label=${q(aria)}]`);
    const ph = el.getAttribute("placeholder");
    if (ph)
      c.push(`${tag}[placeholder=${q(ph)}]`);
    if (!isControl) {
      const t = textOf(el);
      if (t && t.length <= 50 && !el.querySelector(CONTROL))
        c.push(`text=${t}`);
    }
    if (el instanceof HTMLAnchorElement) {
      const href = el.getAttribute("href");
      if (href && href.length < 80 && !href.startsWith("javascript:") && href !== "#")
        c.push(`a[href=${q(href)}]`);
    }
    if (el instanceof HTMLIFrameElement || el instanceof HTMLFrameElement) {
      const src = el.getAttribute("src");
      if (src && !src.startsWith("data:") && !src.startsWith("javascript:")) {
        const base = src.split(/[?#]/)[0];
        c.push(base === src ? `${tag}[src=${q(src)}]` : `${tag}[src^=${q(base)}]`);
      }
    }
    const title = el.getAttribute("title");
    if (title)
      c.push(`${tag}[title=${q(title)}]`);
    const sameTarget = (s) => {
      const r = resolveAll(s);
      return r.length === 1 && (r[0] === el || s.startsWith("text=") && el.contains(r[0]) && textOf(r[0]) === textOf(el));
    };
    const unique = dedupe(c).filter(sameTarget);
    unique.push(cssPath(el));
    return dedupe(unique).slice(0, 5);
  }
  function labelText(el) {
    if (el.labels?.length) {
      const t = norm(el.labels[0].innerText).replace(/\s*\*$/, "");
      if (t)
        return t;
    }
    const aria = el.getAttribute("aria-label");
    if (aria)
      return norm(aria);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = norm(lb.split(/\s+/).map((id) => document.getElementById(id)?.innerText ?? "").join(" "));
      if (t)
        return t;
    }
    return "";
  }
  function describe(el) {
    if (el.matches(CONTROL)) {
      return (labelText(el) || el.getAttribute("placeholder") || el.getAttribute("name") || el.id || el.getAttribute("title") || el.tagName.toLowerCase()).slice(0, 60);
    }
    const t = textOf(el);
    if (t)
      return t.length > 50 ? t.slice(0, 47) + "…" : t;
    return (el.getAttribute("aria-label") || el.getAttribute("title") || el.querySelector("img")?.getAttribute("alt") || el.getAttribute("name") || el.tagName.toLowerCase()).slice(0, 60);
  }
  function actionable(target) {
    const ctrl = target.closest(CONTROL);
    if (ctrl)
      return ctrl;
    const clickable = target.closest(CLICKABLE);
    if (clickable instanceof HTMLLabelElement && clickable.control)
      return clickable.control;
    return clickable ?? target;
  }
  var TEXTLIKE = new Set([
    "",
    "text",
    "email",
    "password",
    "search",
    "tel",
    "url",
    "number",
    "date",
    "datetime-local",
    "month",
    "week",
    "time",
    "color",
    "range"
  ]);
  function kindOf(el) {
    if (el instanceof HTMLSelectElement)
      return "select";
    if (el instanceof HTMLTextAreaElement)
      return el.readOnly ? "click" : "fill";
    if (el instanceof HTMLInputElement) {
      if (el.type === "checkbox" || el.type === "radio")
        return "check";
      if (el.type === "file")
        return "file";
      if (TEXTLIKE.has(el.type))
        return el.readOnly ? "click" : "fill";
      return "click";
    }
    if (el.isContentEditable)
      return "fill";
    const role = el.getAttribute("role");
    if (role === "checkbox" || role === "switch")
      return "check";
    return "click";
  }
  function valueOf(el) {
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement)
      return el.value;
    return norm(el.innerText);
  }
  function checkedOf(el) {
    if (el instanceof HTMLInputElement)
      return el.checked;
    return el.getAttribute("aria-checked") === "true";
  }

  // src/content/player.ts
  class StepError extends Error {
  }
  async function find(step, timeout, requireVisible) {
    const selectors = [step.selector, ...step.fallbacks ?? []].filter(Boolean);
    if (!selectors.length)
      throw new StepError("El paso no tiene selector");
    const start = performance.now();
    let hiddenSince = 0;
    while (true) {
      const r = resolve(selectors);
      if (r) {
        if (isVisible(r.el))
          return r;
        if (!requireVisible) {
          hiddenSince ||= performance.now();
          if (performance.now() - hiddenSince > 1000)
            return r;
        }
      }
      if (performance.now() - start > timeout) {
        if (r)
          throw new StepError(`El elemento «${step.label ?? selectors[0]}» existe pero no es visible`);
        throw new StepError(`No se encontró «${step.label ?? selectors[0]}» (${selectors[0]})`);
      }
      await sleep(100);
    }
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
  }
  async function scrollTo(el) {
    const r = el.getBoundingClientRect();
    if (r.top < 0 || r.bottom > innerHeight || r.left < 0 || r.right > innerWidth) {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
      await sleep(50);
    }
  }
  function mouse(target, type, x, y) {
    const init = {
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
      clientX: x,
      clientY: y,
      screenX: x + screenX,
      screenY: y + screenY,
      button: 0,
      buttons: type.endsWith("down") ? 1 : 0,
      pointerId: 1,
      pointerType: "mouse",
      isPrimary: true
    };
    const Ctor = type.startsWith("pointer") ? PointerEvent : MouseEvent;
    return target.dispatchEvent(new Ctor(type, init));
  }
  async function realClick(el) {
    await scrollTo(el);
    const { x, y } = center(el);
    const top = document.elementFromPoint(x, y);
    const target = top && el.contains(top) ? top : el;
    mouse(target, "pointerover", x, y);
    mouse(target, "mouseover", x, y);
    mouse(target, "pointermove", x, y);
    mouse(target, "mousemove", x, y);
    const down = mouse(target, "pointerdown", x, y) && mouse(target, "mousedown", x, y);
    if (down && el instanceof HTMLElement && el.tabIndex >= -1)
      el.focus({ preventScroll: true });
    mouse(target, "pointerup", x, y);
    mouse(target, "mouseup", x, y);
    mouse(target, "click", x, y);
  }
  var NO_TYPING = new Set(["date", "datetime-local", "month", "week", "time", "color", "range"]);
  function setNative(el, v) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value").set.call(el, v);
  }
  function fireInput(el, data, inputType = "insertText") {
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, data, inputType }));
  }
  function key(el, type, k) {
    return el.dispatchEvent(new KeyboardEvent(type, { key: k, code: codeFor(k), bubbles: true, cancelable: true, composed: true }));
  }
  function codeFor(k) {
    if (k.length === 1) {
      if (/[a-z]/i.test(k))
        return "Key" + k.toUpperCase();
      if (/\d/.test(k))
        return "Digit" + k;
      if (k === " ")
        return "Space";
      return "";
    }
    return k;
  }
  function selectAll(el) {
    try {
      el.select();
    } catch {}
  }
  async function typeInto(el, value, s) {
    await scrollTo(el);
    el.focus({ preventScroll: true });
    if (el.isContentEditable) {
      document.execCommand("selectAll");
      if (value)
        document.execCommand("insertText", false, value);
      else
        document.execCommand("delete");
      if (textOf(el) !== value.replace(/\s+/g, " ").trim()) {
        el.textContent = value;
        fireInput(el, value);
      }
      return;
    }
    if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement))
      throw new StepError("El elemento no es editable");
    if (el.disabled)
      throw new StepError(`«${el.name || el.id}» está deshabilitado`);
    const typeable = !(el instanceof HTMLInputElement && NO_TYPING.has(el.type));
    if (!typeable || s.typeMode === "instant") {
      selectAll(el);
      const ok = typeable && (value ? document.execCommand("insertText", false, value) : document.execCommand("delete"));
      if (!ok || el.value !== value) {
        setNative(el, value);
        fireInput(el, value);
      }
    } else {
      selectAll(el);
      if (!document.execCommand("delete") || el.value !== "") {
        setNative(el, "");
        fireInput(el, null, "deleteContentBackward");
      }
      for (const ch of value) {
        const allowed = key(el, "keydown", ch);
        key(el, "keypress", ch);
        if (allowed) {
          const before = el.value;
          if (!document.execCommand("insertText", false, ch) || el.value === before) {
            setNative(el, before + ch);
            fireInput(el, ch);
          }
        }
        key(el, "keyup", ch);
        if (s.keyDelay)
          await sleep(s.keyDelay);
      }
    }
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function selectOption(el, value, optionText) {
    if (!(el instanceof HTMLSelectElement))
      throw new StepError("El elemento no es un <select>");
    const opts = [...el.options];
    const opt = opts.find((o) => o.value === value) ?? (optionText ? opts.find((o) => o.text.trim() === optionText) : undefined) ?? opts.find((o) => o.text.trim() === value) ?? opts.find((o) => o.text.trim().toLowerCase().includes(value.toLowerCase()));
    if (!opt)
      throw new StepError(`El select no tiene la opción «${optionText ?? value}»`);
    el.focus();
    el.value = opt.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  async function setChecked(el, want) {
    if (checkedOf(el) === want)
      return;
    if (el instanceof HTMLInputElement && el.type === "radio" && !want) {
      throw new StepError("Un radio no se puede desmarcar; marca otra opción del grupo");
    }
    if (isVisible(el))
      await realClick(el);
    else if (el instanceof HTMLInputElement && el.labels?.[0] && isVisible(el.labels[0]))
      await realClick(el.labels[0]);
    else
      el.click();
    if (checkedOf(el) !== want && el instanceof HTMLInputElement) {
      el.checked = want;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
  }
  var FOCUSABLE = 'a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"]), [contenteditable]:not([contenteditable="false"])';
  async function press(el, k) {
    const down = key(el, "keydown", k);
    if (k === "Enter")
      key(el, "keypress", k);
    if (down) {
      if (k === "Enter") {
        if (el instanceof HTMLInputElement && el.form) {
          const btn = el.form.querySelector('button[type="submit"], button:not([type]), input[type="submit"], input[type="image"]');
          if (btn)
            await realClick(btn);
          else
            el.form.requestSubmit();
        } else if (el instanceof HTMLButtonElement || el instanceof HTMLAnchorElement) {
          el.click();
        }
      } else if (k === "Tab") {
        const all = [...document.querySelectorAll(FOCUSABLE)].filter((e) => isVisible(e) && !e.disabled);
        const i = all.indexOf(el);
        all[(i + 1) % all.length]?.focus();
      }
    }
    key(el, "keyup", k);
  }
  function mayNavigate(el) {
    if (el.closest("a[href]"))
      return true;
    const btn = el.closest("button, input");
    if (btn instanceof HTMLButtonElement)
      return !!btn.form && btn.type === "submit";
    if (btn instanceof HTMLInputElement)
      return !!btn.form && (["submit", "image"].includes(btn.type) || kindOf(btn) === "fill");
    return false;
  }
  async function runStep(step, s) {
    const timeout = step.timeout ?? s.timeout;
    let nav = false;
    try {
      let used;
      const target = async (visible = true) => {
        const r = await find(step, timeout, visible);
        used = r.selector;
        if (s.highlight)
          overlay.flash(r.el, step.label ?? step.type, Math.max(400, s.stepDelay + 200), COLORS.run);
        return r.el;
      };
      switch (step.type) {
        case "click": {
          const el = await target();
          nav = mayNavigate(el);
          await realClick(el);
          break;
        }
        case "fill": {
          const el = await target(false);
          if (el instanceof HTMLSelectElement)
            selectOption(el, step.value ?? "");
          else if (kindOf(el) === "check")
            await setChecked(el, !["", "false", "off", "0"].includes(step.value ?? ""));
          else
            await typeInto(el, step.value ?? "", s);
          break;
        }
        case "select":
          selectOption(await target(false), step.value ?? "", step.optionText);
          break;
        case "check":
          await setChecked(await target(false), step.value !== "false");
          break;
        case "press": {
          const el = step.selector ? await target(false) : document.activeElement ?? document.body;
          nav = (step.value || "Enter") === "Enter" && mayNavigate(el);
          await press(el, step.value || "Enter");
          break;
        }
        case "waitFor":
          await target();
          break;
        case "assertText": {
          const el = await target(false);
          const want = (step.value ?? "").trim();
          const start = performance.now();
          let have = "";
          while (true) {
            have = el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement ? valueOf(el) : textOf(el);
            if (have.includes(want))
              break;
            if (performance.now() - start > timeout)
              throw new StepError(`Se esperaba «${want}» y hay «${have.slice(0, 80)}»`);
            await sleep(150);
          }
          break;
        }
        default:
          throw new StepError(`Tipo de paso «${step.type}» no se ejecuta en la página`);
      }
      return { ok: true, usedSelector: used, mayNavigate: nav };
    } catch (e) {
      return { ok: false, error: e instanceof Error ? e.message : String(e) };
    }
  }
  async function highlight(selectors) {
    const r = resolve(selectors);
    if (!r)
      return false;
    await scrollTo(r.el);
    overlay.flash(r.el, r.selector, 1500, COLORS.click);
    return true;
  }

  // src/content/recorder.ts
  var mode = null;
  var send = () => {};
  var pendingFill = new Map;
  var VERB = { click: "Click", fill: "Escribir", select: "Seleccionar", check: "Marcar", file: "Fichero" };
  function capture(el) {
    const kind = kindOf(el);
    if (kind === "file")
      return null;
    const [selector, ...fallbacks] = buildSelectors(el);
    const base = { selector, fallbacks, label: describe(el) };
    switch (kind) {
      case "fill":
        return { ...base, type: "fill", value: valueOf(el), secret: el.type === "password" || undefined };
      case "select": {
        const s = el;
        return { ...base, type: "select", value: s.value, optionText: s.selectedOptions[0]?.text.trim() };
      }
      case "check":
        return { ...base, type: "check", value: String(checkedOf(el)) };
      default:
        return { ...base, type: "click" };
    }
  }
  function emit(el, step) {
    if (!step)
      return;
    send(step);
    const what = step.type === "fill" ? step.secret ? "••••" : `«${(step.value ?? "").slice(0, 30)}»` : "";
    overlay.toast(`✓ ${VERB[step.type] ?? step.type}: ${step.label} ${what}`.trim(), COLORS[kindOf(el)]);
  }
  function flushFills() {
    for (const [el, t] of pendingFill) {
      clearTimeout(t);
      send(capture(el));
    }
    pendingFill.clear();
  }
  function scheduleFill(el) {
    clearTimeout(pendingFill.get(el));
    pendingFill.set(el, setTimeout(() => {
      pendingFill.delete(el);
      const s = capture(el);
      if (s)
        send(s);
    }, 350));
  }
  var targetOf = (e) => {
    const t = e.composedPath()[0];
    return t instanceof Element ? t : null;
  };
  function onMove(e) {
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    const el = actionable(t);
    const k = kindOf(el);
    const hint = k === "file" ? "Fichero (no automatizable)" : `${VERB[k]} · ${describe(el)}`;
    overlay.show(el, hint, COLORS[k]);
  }
  function blockInPoint(e) {
    if (mode !== "point" || !e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    if (kindOf(actionable(t)) === "click") {
      e.preventDefault();
      e.stopImmediatePropagation();
    }
  }
  function onClick(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t || overlay.owns(t))
      return;
    blockInPoint(e);
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "file")
      return overlay.toast("Los inputs de fichero no se pueden automatizar", undefined, true);
    if (k === "check" || k === "select")
      return;
    flushFills();
    if (k === "fill") {
      if (valueOf(el))
        emit(el, capture(el));
      return;
    }
    emit(el, capture(el));
  }
  function onInput(e) {
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    if (kindOf(el) === "fill")
      scheduleFill(el);
  }
  function onChange(e) {
    if (!e.isTrusted)
      return;
    const t = targetOf(e);
    if (!t)
      return;
    const el = actionable(t);
    const k = kindOf(el);
    if (k === "fill") {
      clearTimeout(pendingFill.get(el));
      pendingFill.delete(el);
      send(capture(el));
    } else if (k === "select" || k === "check") {
      flushFills();
      emit(el, capture(el));
    }
  }
  function onKey(e) {
    if (!e.isTrusted)
      return;
    if (mode === "point" && e.key === "Escape") {
      e.preventDefault();
      stopHandler();
      return;
    }
    const t = targetOf(e);
    if (!t)
      return;
    if (e.key === "Enter" && t instanceof HTMLInputElement && kindOf(t) === "fill") {
      flushFills();
      send({ type: "press", value: "Enter", selector: buildSelectors(t)[0], label: describe(t) });
      overlay.toast(`✓ Tecla: Enter en ${describe(t)}`);
    }
  }
  function onLeave() {
    flushFills();
  }
  var onScroll = () => overlay.hide();
  var stopHandler = () => {};
  var listeners = [
    ["mousemove", onMove],
    ["pointerdown", blockInPoint],
    ["mousedown", blockInPoint],
    ["pointerup", blockInPoint],
    ["mouseup", blockInPoint],
    ["click", onClick],
    ["input", onInput],
    ["change", onChange],
    ["keydown", onKey]
  ];
  function startRecording(m, sink, onStop) {
    if (mode)
      stopRecording();
    mode = m;
    send = sink;
    stopHandler = onStop;
    overlay.onStop = onStop;
    for (const [ev, fn] of listeners)
      window.addEventListener(ev, fn, true);
    window.addEventListener("pagehide", onLeave);
    window.addEventListener("scroll", onScroll, true);
    if (window === window.top)
      overlay.setPill(m);
  }
  function stopRecording() {
    flushFills();
    for (const [ev, fn] of listeners)
      window.removeEventListener(ev, fn, true);
    window.removeEventListener("pagehide", onLeave);
    window.removeEventListener("scroll", onScroll, true);
    mode = null;
    overlay.hide();
    overlay.setPill(null);
  }
  function pickOnce() {
    return new Promise((resolve) => {
      const block = (e) => {
        if (overlay.owns(targetOf(e)))
          return;
        e.preventDefault();
        e.stopImmediatePropagation();
      };
      const done = (r) => {
        window.removeEventListener("mousemove", onMove, true);
        for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
          window.removeEventListener(ev, block, true);
        window.removeEventListener("click", click, true);
        window.removeEventListener("keydown", key, true);
        overlay.hide();
        cancelPick = () => {};
        resolve(r);
      };
      const click = (e) => {
        block(e);
        const t = targetOf(e);
        if (!t || overlay.owns(t))
          return;
        done(capture(actionable(t)) ?? null);
      };
      const key = (e) => {
        if (e.key === "Escape") {
          e.preventDefault();
          done(null);
        }
      };
      window.addEventListener("mousemove", onMove, true);
      for (const ev of ["pointerdown", "mousedown", "pointerup", "mouseup"])
        window.addEventListener(ev, block, true);
      window.addEventListener("click", click, true);
      window.addEventListener("keydown", key, true);
      cancelPick = () => done(null);
      if (window === window.top)
        overlay.toast("Clica el elemento (Esc para cancelar)");
    });
  }
  var cancelPick = () => {};

  // src/content/index.ts
  function toBg(msg) {
    try {
      return chrome.runtime.sendMessage(msg).catch(() => {
        return;
      });
    } catch {
      stopRecording();
      return Promise.resolve(undefined);
    }
  }
  var sink = (step) => void toBg({ kind: "record:step", step });
  var onStop = () => void toBg({ kind: "record:stop" });
  var MSG = "__rastro_frame";
  var announced = new Map;
  function frameElementFor(source) {
    if (!source)
      return;
    return [...document.querySelectorAll("iframe, frame")].find((f) => f.contentWindow === source);
  }
  function onFrameMessage(e) {
    const d = e.data;
    if (!d || typeof d !== "object" || d[MSG] == null || typeof d.token !== "string")
      return;
    if (d[MSG] === "announce") {
      const el = frameElementFor(e.source);
      if (el)
        announced.set(d.token, el);
    } else if (d[MSG] === "probe" && e.source === window.parent && window !== window.top) {
      toBg({ kind: "frame:probe", token: d.token });
    }
  }
  async function selectorsForAnnounced(token) {
    for (let i = 0;i < 20 && !announced.has(token); i++)
      await sleep(50);
    const el = announced.get(token);
    announced.delete(token);
    return el ? buildSelectors(el) : null;
  }
  async function resolveFrame(selectors, timeout) {
    const end = performance.now() + timeout;
    while (true) {
      const r = resolve(selectors);
      const win = r && r.el.contentWindow;
      if (win) {
        const token = crypto.randomUUID();
        win.postMessage({ [MSG]: "probe", token }, "*");
        return { token };
      }
      if (performance.now() > end)
        return { error: `No se encontró el iframe «${selectors[0]}»` };
      await sleep(100);
    }
  }
  if (!window.__rastro) {
    window.__rastro = true;
    window.addEventListener("message", onFrameMessage);
    chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
      switch (msg.kind) {
        case "ping":
          reply({ ok: true });
          return;
        case "record:on":
          startRecording(msg.mode, sink, onStop);
          reply({ ok: true });
          return;
        case "record:off":
          stopRecording();
          reply({ ok: true });
          return;
        case "run-step":
          runStep(msg.step, msg.settings).then(reply);
          return true;
        case "highlight":
          highlight([msg.selector, ...msg.fallbacks ?? []]).then((found) => reply({ ok: found }));
          return true;
        case "pick":
          pickOnce().then(async (step) => reply(step ? await toBg({ kind: "frame:locate", step }) ?? step : null));
          return true;
        case "pick:cancel":
          cancelPick();
          reply({ ok: true });
          return;
        case "frame:announce":
          window.parent.postMessage({ [MSG]: "announce", token: msg.token }, "*");
          reply({ ok: true });
          return;
        case "frame:selectors":
          selectorsForAnnounced(msg.token).then(reply);
          return true;
        case "frame:resolve":
          resolveFrame(msg.selectors, msg.timeout).then(reply);
          return true;
      }
    });
    toBg({ kind: "record:status" }).then((r) => {
      if (r?.mode)
        startRecording(r.mode, sink, onStop);
    });
  }
})();

//# debugId=175AE8CC3C33CD0C64756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC91dGlsLnRzIiwgInNyYy9jb250ZW50L292ZXJsYXkudHMiLCAic3JjL2NvbnRlbnQvc2VsZWN0b3IudHMiLCAic3JjL2NvbnRlbnQvcGxheWVyLnRzIiwgInNyYy9jb250ZW50L3JlY29yZGVyLnRzIiwgInNyYy9jb250ZW50L2luZGV4LnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWwogICAgImV4cG9ydCBjb25zdCB1aWQgPSAoKTogc3RyaW5nID0+IGNyeXB0by5yYW5kb21VVUlEKCkuc2xpY2UoMCwgOCkgKyBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KS5zbGljZSgtNCk7XG5cbi8qKiDCv1BhcmVjZSB1biBpZC9jbGFzZSBhdXRvZ2VuZXJhZG8gKGhhc2hlcywgY29udGFkb3JlcywgaWRzIGRlIFJlYWN0L0VsZW1lbnQgUGx1c+KApik/ICovXG5leHBvcnQgZnVuY3Rpb24gbG9va3NHZW5lcmF0ZWQoczogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgcy5sZW5ndGggPiA0MCB8fFxuICAgIC9cXGR7NCx9Ly50ZXN0KHMpIHx8XG4gICAgL1stXzpdXFxkK1stXzpdXFxkKyQvLnRlc3QocykgfHwgLy8gcHJlZmlqby1hbGVhdG9yaW8tY29udGFkb3I6IGVsLWlkLTc0NC0xNjUsIGlucHV0LTEyLTNcbiAgICAvXlthLWYwLTktXXsxMCx9JC9pLnRlc3QocykgfHxcbiAgICAvXjpyWzAtOWEtel0rOj8kLy50ZXN0KHMpIHx8IC8vIFJlYWN0IHVzZUlkXG4gICAgL14oZW1iZXJ8ZXh0LWdlbnxyZWFjdC18bXVpLXxyYWRpeC18aGVhZGxlc3N1aS18ZG93bnNoaWZ0LXxyYy18ZWwtaWQtfHYtXFxkfGlucHV0LVxcZCkvaS50ZXN0KHMpIHx8XG4gICAgKC9bXy1dW2EtekEtWjAtOV17NSx9JC8udGVzdChzKSAmJiAvXFxkLipcXGQvLnRlc3Qocy5zbGljZSgtNikpKSB8fCAvLyBjc3MtbW9kdWxlczogYnRuX3gzRjlhXG4gICAgL14oY3NzfHNjfGpzeHxlbW90aW9ufHN2ZWx0ZSktW2EtejAtOV0rJC9pLnRlc3QocylcbiAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG5cbi8qKiBWYXJpYWJsZXMgaW50ZWdyYWRhczoge3skdGltZXN0YW1wfX0sIHt7JHV1aWR9fSwge3skcmFuZG9tRW1haWx9fSwge3skcmFuZG9tSW50fX0sIHt7JHRvZGF5fX0gKi9cbmZ1bmN0aW9uIGJ1aWx0aW4obmFtZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgc3dpdGNoIChuYW1lKSB7XG4gICAgY2FzZSBcIiR0aW1lc3RhbXBcIjpcbiAgICAgIHJldHVybiBTdHJpbmcoRGF0ZS5ub3coKSk7XG4gICAgY2FzZSBcIiR1dWlkXCI6XG4gICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjYXNlIFwiJHJhbmRvbUludFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxXzAwMF8wMDApKTtcbiAgICBjYXNlIFwiJHJhbmRvbUVtYWlsXCI6XG4gICAgICByZXR1cm4gYHRlc3QrJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX0ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApfUBleGFtcGxlLmNvbWA7XG4gICAgY2FzZSBcIiR0b2RheVwiOlxuICAgICAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuLyoqIFN1c3RpdHV5ZSB7e3ZhcmlhYmxlfX0gcG9yIHN1IHZhbG9yLiBMYXMgZGVzY29ub2NpZGFzIHNlIGRlamFuIHRhbCBjdWFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlKHRleHQ6IHN0cmluZywgdmFyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0LnJlcGxhY2UoL1xce1xce1xccyooWyRcXHcuLV0rKVxccypcXH1cXH0vZywgKG0sIG5hbWU6IHN0cmluZykgPT4gdmFyc1tuYW1lXSA/PyBidWlsdGluKG5hbWUpID8/IG0pO1xufVxuXG5leHBvcnQgY29uc3QgQlVJTFRJTl9WQVJTID0gW1wiJHRpbWVzdGFtcFwiLCBcIiR1dWlkXCIsIFwiJHJhbmRvbUVtYWlsXCIsIFwiJHJhbmRvbUludFwiLCBcIiR0b2RheVwiXTtcbiIsCiAgICAiLy8gQ2FwYSB2aXN1YWwgZGVudHJvIGRlIGxhIHDDoWdpbmEsIGFpc2xhZGEgZW4gdW4gc2hhZG93IHJvb3QgcGFyYSBubyBoZXJlZGFyIG5pIHJvbXBlciBlc3RpbG9zLlxuXG5jb25zdCBDU1MgPSBgXG46aG9zdCB7IGFsbDogaW5pdGlhbDsgfVxuLmJveCB7XG4gIHBvc2l0aW9uOiBmaXhlZDsgcG9pbnRlci1ldmVudHM6IG5vbmU7IHotaW5kZXg6IDIxNDc0ODM2NDY7IGRpc3BsYXk6IG5vbmU7XG4gIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWMsICM3YzVjZmYpOyBiYWNrZ3JvdW5kOiBjb2xvci1taXgoaW4gc3JnYiwgdmFyKC0tYywgIzdjNWNmZikgMTIlLCB0cmFuc3BhcmVudCk7XG4gIGJvcmRlci1yYWRpdXM6IDRweDsgdHJhbnNpdGlvbjogYWxsIDYwbXMgZWFzZS1vdXQ7IGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG59XG4udGFnIHtcbiAgcG9zaXRpb246IGZpeGVkOyBwb2ludGVyLWV2ZW50czogbm9uZTsgei1pbmRleDogMjE0NzQ4MzY0NzsgZGlzcGxheTogbm9uZTtcbiAgZm9udDogNjAwIDExcHgvMS4yIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjsgY29sb3I6ICNmZmY7IGJhY2tncm91bmQ6IHZhcigtLWMsICM3YzVjZmYpO1xuICBwYWRkaW5nOiA0cHggN3B4OyBib3JkZXItcmFkaXVzOiA1cHg7IHdoaXRlLXNwYWNlOiBub3dyYXA7IG1heC13aWR0aDogMzYwcHg7IG92ZXJmbG93OiBoaWRkZW47IHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xuICBib3gtc2hhZG93OiAwIDJweCA4cHggcmdiKDAgMCAwIC8gLjI1KTtcbn1cbi5waWxsIHtcbiAgcG9zaXRpb246IGZpeGVkOyB6LWluZGV4OiAyMTQ3NDgzNjQ3OyBsZWZ0OiA1MCU7IGJvdHRvbTogMThweDsgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xuICBkaXNwbGF5OiBub25lOyBhbGlnbi1pdGVtczogY2VudGVyOyBnYXA6IDEwcHg7IHBhZGRpbmc6IDdweCA4cHggN3B4IDE0cHg7IGJvcmRlci1yYWRpdXM6IDk5OXB4O1xuICBmb250OiA2MDAgMTJweC8xIHVpLXNhbnMtc2VyaWYsIHN5c3RlbS11aSwgc2Fucy1zZXJpZjsgY29sb3I6ICNmNGYyZmY7IGJhY2tncm91bmQ6ICMxYjE4MzBlZTtcbiAgYm94LXNoYWRvdzogMCA2cHggMjRweCByZ2IoMCAwIDAgLyAuMzUpOyBiYWNrZHJvcC1maWx0ZXI6IGJsdXIoNnB4KTsgdXNlci1zZWxlY3Q6IG5vbmU7XG59XG4uZG90IHsgd2lkdGg6IDlweDsgaGVpZ2h0OiA5cHg7IGJvcmRlci1yYWRpdXM6IDUwJTsgYmFja2dyb3VuZDogI2ZmNGQ2ZDsgYW5pbWF0aW9uOiBwdWxzZSAxLjJzIGluZmluaXRlOyB9XG4ucGlsbC5wb2ludCAuZG90IHsgYmFja2dyb3VuZDogIzdjNWNmZjsgfVxuQGtleWZyYW1lcyBwdWxzZSB7IDUwJSB7IG9wYWNpdHk6IC4zNTsgfSB9XG4ucGlsbCBidXR0b24ge1xuICBhbGw6IHVuc2V0OyBjdXJzb3I6IHBvaW50ZXI7IHBhZGRpbmc6IDVweCAxMHB4OyBib3JkZXItcmFkaXVzOiA5OTlweDsgYmFja2dyb3VuZDogI2ZmZmZmZjFmOyBjb2xvcjogI2ZmZjtcbiAgZm9udDogNjAwIDExcHgvMSB1aS1zYW5zLXNlcmlmLCBzeXN0ZW0tdWksIHNhbnMtc2VyaWY7XG59XG4ucGlsbCBidXR0b246aG92ZXIgeyBiYWNrZ3JvdW5kOiAjZmZmZmZmMzg7IH1cbi50b2FzdHMgeyBwb3NpdGlvbjogZml4ZWQ7IHotaW5kZXg6IDIxNDc0ODM2NDc7IHJpZ2h0OiAxNnB4OyBib3R0b206IDY0cHg7IGRpc3BsYXk6IGZsZXg7IGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47IGdhcDogNnB4OyBhbGlnbi1pdGVtczogZmxleC1lbmQ7IHBvaW50ZXItZXZlbnRzOiBub25lOyB9XG4udG9hc3Qge1xuICBmb250OiA1MDAgMTJweC8xLjMgdWktc2Fucy1zZXJpZiwgc3lzdGVtLXVpLCBzYW5zLXNlcmlmOyBjb2xvcjogI2ZmZjsgYmFja2dyb3VuZDogIzFiMTgzMGVlOyBwYWRkaW5nOiA3cHggMTFweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4OyBib3JkZXItbGVmdDogM3B4IHNvbGlkIHZhcigtLWMsICM3YzVjZmYpOyBib3gtc2hhZG93OiAwIDRweCAxNHB4IHJnYigwIDAgMCAvIC4zKTtcbiAgYW5pbWF0aW9uOiBpbiAuMThzIGVhc2Utb3V0OyBtYXgtd2lkdGg6IDM0MHB4O1xufVxuLnRvYXN0Lndhcm4geyAtLWM6ICNmZmIwMjA7IH1cbkBrZXlmcmFtZXMgaW4geyBmcm9tIHsgb3BhY2l0eTogMDsgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDZweCk7IH0gfVxuYDtcblxuZXhwb3J0IGNvbnN0IENPTE9SUyA9IHsgY2xpY2s6IFwiIzdjNWNmZlwiLCBmaWxsOiBcIiMxNGI4YTZcIiwgc2VsZWN0OiBcIiMwZWE1ZTlcIiwgY2hlY2s6IFwiIzIyYzU1ZVwiLCBmaWxlOiBcIiNmZmIwMjBcIiwgcnVuOiBcIiNmOTczMTZcIiB9IGFzIGNvbnN0O1xuXG5jbGFzcyBPdmVybGF5IHtcbiAgaG9zdCE6IEhUTUxFbGVtZW50O1xuICBwcml2YXRlIGJveCE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHRhZyE6IEhUTUxEaXZFbGVtZW50O1xuICBwcml2YXRlIHBpbGwhOiBIVE1MRGl2RWxlbWVudDtcbiAgcHJpdmF0ZSBwaWxsVGV4dCE6IEhUTUxTcGFuRWxlbWVudDtcbiAgcHJpdmF0ZSB0b2FzdHMhOiBIVE1MRGl2RWxlbWVudDtcbiAgb25TdG9wOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbiAgcHJpdmF0ZSBlbnN1cmUoKSB7XG4gICAgaWYgKHRoaXMuaG9zdD8uaXNDb25uZWN0ZWQpIHJldHVybjtcbiAgICB0aGlzLmhvc3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgIHRoaXMuaG9zdC5pZCA9IFwiX19yYXN0cm9faG9zdFwiO1xuICAgIGNvbnN0IHJvb3QgPSB0aGlzLmhvc3QuYXR0YWNoU2hhZG93KHsgbW9kZTogXCJvcGVuXCIgfSk7XG4gICAgcm9vdC5pbm5lckhUTUwgPSBgPHN0eWxlPiR7Q1NTfTwvc3R5bGU+PGRpdiBjbGFzcz1cImJveFwiPjwvZGl2PjxkaXYgY2xhc3M9XCJ0YWdcIj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJwaWxsXCI+PHNwYW4gY2xhc3M9XCJkb3RcIj48L3NwYW4+PHNwYW4gY2xhc3M9XCJ0eHRcIj48L3NwYW4+PGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCI+VGVybWluYXI8L2J1dHRvbj48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0b2FzdHNcIj48L2Rpdj5gO1xuICAgIHRoaXMuYm94ID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLmJveFwiKSE7XG4gICAgdGhpcy50YWcgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIudGFnXCIpITtcbiAgICB0aGlzLnBpbGwgPSByb290LnF1ZXJ5U2VsZWN0b3IoXCIucGlsbFwiKSE7XG4gICAgdGhpcy5waWxsVGV4dCA9IHJvb3QucXVlcnlTZWxlY3RvcihcIi50eHRcIikhO1xuICAgIHRoaXMudG9hc3RzID0gcm9vdC5xdWVyeVNlbGVjdG9yKFwiLnRvYXN0c1wiKSE7XG4gICAgcm9vdC5xdWVyeVNlbGVjdG9yKFwiYnV0dG9uXCIpIS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB0aGlzLm9uU3RvcCgpO1xuICAgIH0pO1xuICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hcHBlbmRDaGlsZCh0aGlzLmhvc3QpO1xuICB9XG5cbiAgb3ducyhlbDogRXZlbnRUYXJnZXQgfCBudWxsKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuICEhdGhpcy5ob3N0ICYmIGVsIGluc3RhbmNlb2YgTm9kZSAmJiAoZWwgPT09IHRoaXMuaG9zdCB8fCB0aGlzLmhvc3QuY29udGFpbnMoZWwpKTtcbiAgfVxuXG4gIHNob3coZWw6IEVsZW1lbnQsIHRleHQ6IHN0cmluZywgY29sb3I6IHN0cmluZyA9IENPTE9SUy5jbGljaykge1xuICAgIHRoaXMuZW5zdXJlKCk7XG4gICAgY29uc3QgciA9IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIE9iamVjdC5hc3NpZ24odGhpcy5ib3guc3R5bGUsIHtcbiAgICAgIGRpc3BsYXk6IFwiYmxvY2tcIiwgbGVmdDogYCR7ci5sZWZ0IC0gM31weGAsIHRvcDogYCR7ci50b3AgLSAzfXB4YCwgd2lkdGg6IGAke3Iud2lkdGggKyA2fXB4YCwgaGVpZ2h0OiBgJHtyLmhlaWdodCArIDZ9cHhgLFxuICAgIH0pO1xuICAgIHRoaXMuYm94LnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0aGlzLnRhZy5zdHlsZS5zZXRQcm9wZXJ0eShcIi0tY1wiLCBjb2xvcik7XG4gICAgdGhpcy50YWcudGV4dENvbnRlbnQgPSB0ZXh0O1xuICAgIHRoaXMudGFnLnN0eWxlLmRpc3BsYXkgPSBcImJsb2NrXCI7XG4gICAgY29uc3QgYWJvdmUgPSByLnRvcCA+IDMwO1xuICAgIHRoaXMudGFnLnN0eWxlLmxlZnQgPSBgJHtNYXRoLm1heCg0LCBNYXRoLm1pbihyLmxlZnQgLSAzLCBpbm5lcldpZHRoIC0gMzcwKSl9cHhgO1xuICAgIHRoaXMudGFnLnN0eWxlLnRvcCA9IGFib3ZlID8gYCR7ci50b3AgLSAyN31weGAgOiBgJHtyLmJvdHRvbSArIDZ9cHhgO1xuICB9XG5cbiAgaGlkZSgpIHtcbiAgICBpZiAoIXRoaXMuYm94KSByZXR1cm47XG4gICAgdGhpcy5ib3guc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIHRoaXMudGFnLnN0eWxlLmRpc3BsYXkgPSBcIm5vbmVcIjtcbiAgfVxuXG4gIC8qKiBSZXNhbHRhIGJyZXZlbWVudGUgKHJlcHJvZHVjY2nDs24gLyBcInZlciBlbGVtZW50b1wiKS4gKi9cbiAgZmxhc2goZWw6IEVsZW1lbnQsIHRleHQ6IHN0cmluZywgbXMgPSA3MDAsIGNvbG9yOiBzdHJpbmcgPSBDT0xPUlMucnVuKSB7XG4gICAgdGhpcy5zaG93KGVsLCB0ZXh0LCBjb2xvcik7XG4gICAgc2V0VGltZW91dCgoKSA9PiB0aGlzLmhpZGUoKSwgbXMpO1xuICB9XG5cbiAgc2V0UGlsbChtb2RlOiBcInJlY29yZFwiIHwgXCJwb2ludFwiIHwgbnVsbCkge1xuICAgIHRoaXMuZW5zdXJlKCk7XG4gICAgaWYgKCFtb2RlKSB7XG4gICAgICB0aGlzLnBpbGwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnBpbGwuY2xhc3NOYW1lID0gXCJwaWxsIFwiICsgbW9kZTtcbiAgICB0aGlzLnBpbGxUZXh0LnRleHRDb250ZW50ID0gbW9kZSA9PT0gXCJyZWNvcmRcIiA/IFwiUmFzdHJvIGdyYWJhbmRvXCIgOiBcIlJhc3RybyDCtyBtb2RvIHNlw7FhbGFyIChFc2MgcGFyYSBzYWxpcilcIjtcbiAgICB0aGlzLnBpbGwuc3R5bGUuZGlzcGxheSA9IFwiZmxleFwiO1xuICB9XG5cbiAgdG9hc3QodGV4dDogc3RyaW5nLCBjb2xvcj86IHN0cmluZywgd2FybiA9IGZhbHNlKSB7XG4gICAgdGhpcy5lbnN1cmUoKTtcbiAgICBjb25zdCB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICB0LmNsYXNzTmFtZSA9IFwidG9hc3RcIiArICh3YXJuID8gXCIgd2FyblwiIDogXCJcIik7XG4gICAgaWYgKGNvbG9yKSB0LnN0eWxlLnNldFByb3BlcnR5KFwiLS1jXCIsIGNvbG9yKTtcbiAgICB0LnRleHRDb250ZW50ID0gdGV4dDtcbiAgICB0aGlzLnRvYXN0cy5hcHBlbmRDaGlsZCh0KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHQucmVtb3ZlKCksIDIyMDApO1xuICAgIHdoaWxlICh0aGlzLnRvYXN0cy5jaGlsZHJlbi5sZW5ndGggPiA0KSB0aGlzLnRvYXN0cy5maXJzdEVsZW1lbnRDaGlsZCEucmVtb3ZlKCk7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IG92ZXJsYXkgPSBuZXcgT3ZlcmxheSgpO1xuIiwKICAgICIvLyBNb3RvciBkZSBzZWxlY3RvcmVzIHByb3Bpby5cbi8vXG4vLyBTaW50YXhpcyBzb3BvcnRhZGE6XG4vLyAgIGNzcyAgICAgICAgICAgIOKGkiBjdWFscXVpZXIgc2VsZWN0b3IgQ1NTIChwb3IgZGVmZWN0bylcbi8vICAgZnJhbWU9MiAgICAgICAg4oaSIGVsIHRlcmNlciA8aWZyYW1lPiBkZWwgZG9jdW1lbnRvIChwYXJhIHJ1dGFzIGRlIGZyYW1lcyBpbXBvcnRhZGFzKVxuLy8gICB0ZXh0PUVudmlhciAgICDihpIgZWxlbWVudG8gY3V5byB0ZXh0byB2aXNpYmxlIGVzIGV4YWN0YW1lbnRlIMKrRW52aWFywrsgKG8sIHNpIG5vIGhheSwgcXVlIGxvIGNvbnRpZW5lKVxuLy8gICBsYWJlbD1FbWFpbCAgICDihpIgY29udHJvbCBkZSBmb3JtdWxhcmlvIGFzb2NpYWRvIGEgbGEgZXRpcXVldGEvYXJpYS1sYWJlbCDCq0VtYWlswrtcbi8vICAgeHBhdGg9Ly9kaXZbMV0g4oaSIFhQYXRoXG4vL1xuLy8gQWwgZ2VuZXJhciwgc2UgcHJvZHVjZW4gdmFyaW9zIGNhbmRpZGF0b3Mgb3JkZW5hZG9zIHBvciByb2J1c3Rlei4gRWwgcmVwcm9kdWN0b3Jcbi8vIHBydWViYSBlbCBwcmluY2lwYWwgeSwgc2kgZmFsbGEsIGxvcyBhbHRlcm5hdGl2b3MuXG5cbmltcG9ydCB7IGxvb2tzR2VuZXJhdGVkIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5cbmNvbnN0IFRFU1RfQVRUUlMgPSBbXCJkYXRhLXRlc3RpZFwiLCBcImRhdGEtdGVzdC1pZFwiLCBcImRhdGEtdGVzdFwiLCBcImRhdGEtY3lcIiwgXCJkYXRhLXFhXCIsIFwiZGF0YS1lMmVcIiwgXCJkYXRhLWF1dG9tYXRpb24taWRcIl07XG5cbmNvbnN0IENMSUNLQUJMRSA9XG4gICdidXR0b24sIGFbaHJlZl0sIFtyb2xlPVwiYnV0dG9uXCJdLCBbcm9sZT1cImxpbmtcIl0sIFtyb2xlPVwibWVudWl0ZW1cIl0sIFtyb2xlPVwidGFiXCJdLCBbcm9sZT1cIm9wdGlvblwiXSwgJyArXG4gICdbcm9sZT1cImNoZWNrYm94XCJdLCBbcm9sZT1cInJhZGlvXCJdLCBbcm9sZT1cInN3aXRjaFwiXSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgaW5wdXRbdHlwZT1cImJ1dHRvblwiXSwgJyArXG4gICdpbnB1dFt0eXBlPVwicmVzZXRcIl0sIGlucHV0W3R5cGU9XCJpbWFnZVwiXSwgc3VtbWFyeSwgbGFiZWwsIFtvbmNsaWNrXSc7XG5cbmV4cG9ydCBjb25zdCBDT05UUk9MID0gJ2lucHV0LCB0ZXh0YXJlYSwgc2VsZWN0LCBbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT1cImZhbHNlXCJdKSc7XG5cbmNvbnN0IG5vcm0gPSAoczogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZCkgPT4gKHMgPz8gXCJcIikucmVwbGFjZSgvXFxzKy9nLCBcIiBcIikudHJpbSgpO1xuXG5jb25zdCBTVEFURV9DTEFTU0VTID0gL14oaXMtfGhhcy0pPyhhY3RpdmV8Zm9jdXMoZWQpP3xob3ZlcihlZCk/fHNlbGVjdGVkfG9wZW4oZWQpP3xkaXNhYmxlZHxjaGVja2VkfHZpc2libGV8aGlkZGVufHNob3d8aW58bmctLiopJC9pO1xuXG5mdW5jdGlvbiBzdGFibGVDbGFzc2VzKGVsOiBFbGVtZW50KTogc3RyaW5nW10ge1xuICByZXR1cm4gWy4uLmVsLmNsYXNzTGlzdF0uZmlsdGVyKChjKSA9PiAhbG9va3NHZW5lcmF0ZWQoYykgJiYgIVNUQVRFX0NMQVNTRVMudGVzdChjKSAmJiAhYy5pbmNsdWRlcyhcIjpcIikgJiYgYy5sZW5ndGggPCAzMik7XG59XG5cbmNvbnN0IHEgPSAodjogc3RyaW5nKSA9PiBKU09OLnN0cmluZ2lmeSh2KTsgLy8gY29taWxsYXMgKyBlc2NhcGVzIHbDoWxpZG9zIGVuIENTU1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUmVzb2x1Y2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBpc1Zpc2libGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKCFlbC5pc0Nvbm5lY3RlZCkgcmV0dXJuIGZhbHNlO1xuICBpZiAoZWwuZ2V0Q2xpZW50UmVjdHMoKS5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3QgPSBnZXRDb21wdXRlZFN0eWxlKGVsKTtcbiAgcmV0dXJuIHN0LnZpc2liaWxpdHkgIT09IFwiaGlkZGVuXCIgJiYgc3Qub3BhY2l0eSAhPT0gXCIwXCI7XG59XG5cbi8qKiBUZXh0byDCq3Zpc2libGXCuyBkZSB1biBlbGVtZW50bywgY29tbyBsbyB2ZXLDrWEgZWwgdXN1YXJpby4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0ZXh0T2YoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIFtcInN1Ym1pdFwiLCBcImJ1dHRvblwiLCBcInJlc2V0XCJdLmluY2x1ZGVzKGVsLnR5cGUpKSByZXR1cm4gbm9ybShlbC52YWx1ZSk7XG4gIHJldHVybiBub3JtKChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0ID8/IGVsLnRleHRDb250ZW50KTtcbn1cblxuZnVuY3Rpb24qIGFsbEVsZW1lbnRzKHJvb3Q6IERvY3VtZW50IHwgU2hhZG93Um9vdCA9IGRvY3VtZW50KTogR2VuZXJhdG9yPEVsZW1lbnQ+IHtcbiAgY29uc3Qgd2Fsa2VyID0gZG9jdW1lbnQuY3JlYXRlVHJlZVdhbGtlcihyb290LCBOb2RlRmlsdGVyLlNIT1dfRUxFTUVOVCk7XG4gIGxldCBuID0gd2Fsa2VyLm5leHROb2RlKCk7XG4gIHdoaWxlIChuKSB7XG4gICAgeWllbGQgbiBhcyBFbGVtZW50O1xuICAgIGNvbnN0IHNyID0gKG4gYXMgRWxlbWVudCkuc2hhZG93Um9vdDtcbiAgICBpZiAoc3IpIHlpZWxkKiBhbGxFbGVtZW50cyhzcik7XG4gICAgbiA9IHdhbGtlci5uZXh0Tm9kZSgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGJ5VGV4dCh0ZXh0OiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCB0YXJnZXQgPSBub3JtKHRleHQpO1xuICBjb25zdCBleGFjdDogRWxlbWVudFtdID0gW107XG4gIGNvbnN0IHBhcnRpYWw6IEVsZW1lbnRbXSA9IFtdO1xuICBjb25zdCBsb3dlciA9IHRhcmdldC50b0xvd2VyQ2FzZSgpO1xuICBmb3IgKGNvbnN0IGVsIG9mIGFsbEVsZW1lbnRzKCkpIHtcbiAgICBpZiAoZWwuY2xvc2VzdChcInNjcmlwdCwgc3R5bGUsIG5vc2NyaXB0LCB0ZW1wbGF0ZSwgI19fcmFzdHJvX2hvc3RcIikpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxpbWl0ID0gdGFyZ2V0Lmxlbmd0aCAqIDMgKyAyMDtcbiAgICAvLyB0ZXh0Q29udGVudCBlcyBiYXJhdG87IGlubmVyVGV4dCBmdWVyemEgbGF5b3V0LCBhc8OtIHF1ZSBzb2xvIHBhcmEgY2FuZGlkYXRvcyBjb3J0b3MuXG4gICAgaWYgKCEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSAmJiBub3JtKGVsLnRleHRDb250ZW50KS5sZW5ndGggPiBsaW1pdCkgY29udGludWU7XG4gICAgY29uc3QgdCA9IHRleHRPZihlbCk7XG4gICAgaWYgKCF0IHx8IHQubGVuZ3RoID4gbGltaXQpIGNvbnRpbnVlO1xuICAgIGlmICh0ID09PSB0YXJnZXQpIGV4YWN0LnB1c2goZWwpO1xuICAgIGVsc2UgaWYgKHQudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlcikpIHBhcnRpYWwucHVzaChlbCk7XG4gIH1cbiAgY29uc3QgcGljayA9IGV4YWN0Lmxlbmd0aCA/IGV4YWN0IDogcGFydGlhbDtcbiAgLy8gUXVlZGFyc2UgY29uIGVsIG3DoXMgcHJvZnVuZG8geSBzdWJpciBhIHN1IGFuY2VzdHJvIGNsaWNhYmxlIHNpIGxvIGhheS5cbiAgY29uc3QgZGVlcGVzdCA9IHBpY2suZmlsdGVyKChlbCkgPT4gIXBpY2suc29tZSgobykgPT4gbyAhPT0gZWwgJiYgZWwuY29udGFpbnMobykpKTtcbiAgcmV0dXJuIGRlZHVwZShkZWVwZXN0Lm1hcCgoZWwpID0+IGVsLmNsb3Nlc3QoQ0xJQ0tBQkxFKSA/PyBlbCkpO1xufVxuXG5mdW5jdGlvbiBieUxhYmVsKHRleHQ6IHN0cmluZyk6IEVsZW1lbnRbXSB7XG4gIGNvbnN0IHRhcmdldCA9IG5vcm0odGV4dCkudG9Mb3dlckNhc2UoKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChjb25zdCBsYWJlbCBvZiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwibGFiZWxcIikpIHtcbiAgICBpZiAobm9ybShsYWJlbC5pbm5lclRleHQpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzKlxcKiQvLCBcIlwiKSA9PT0gdGFyZ2V0ICYmIGxhYmVsLmNvbnRyb2wpIG91dC5wdXNoKGxhYmVsLmNvbnRyb2wpO1xuICB9XG4gIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChDT05UUk9MICsgXCIsIFthcmlhLWxhYmVsXSwgW2FyaWEtbGFiZWxsZWRieV1cIikpIHtcbiAgICBpZiAobm9ybShlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICBjb25zdCBsYiA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxsZWRieVwiKTtcbiAgICBpZiAobGIpIHtcbiAgICAgIGNvbnN0IHQgPSBsYlxuICAgICAgICAuc3BsaXQoL1xccysvKVxuICAgICAgICAubWFwKChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpPy5pbm5lclRleHQgPz8gXCJcIilcbiAgICAgICAgLmpvaW4oXCIgXCIpO1xuICAgICAgaWYgKG5vcm0odCkudG9Mb3dlckNhc2UoKSA9PT0gdGFyZ2V0KSBvdXQucHVzaChlbCk7XG4gICAgfVxuICB9XG4gIGlmICghb3V0Lmxlbmd0aCkge1xuICAgIGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChcIltwbGFjZWhvbGRlcl1cIikpIHtcbiAgICAgIGlmIChub3JtKGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpKS50b0xvd2VyQ2FzZSgpID09PSB0YXJnZXQpIG91dC5wdXNoKGVsKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRlZHVwZShvdXQpO1xufVxuXG5mdW5jdGlvbiBieVhQYXRoKHhwOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICBjb25zdCByZXMgPSBkb2N1bWVudC5ldmFsdWF0ZSh4cCwgZG9jdW1lbnQsIG51bGwsIFhQYXRoUmVzdWx0Lk9SREVSRURfTk9ERV9TTkFQU0hPVF9UWVBFLCBudWxsKTtcbiAgY29uc3Qgb3V0OiBFbGVtZW50W10gPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXMuc25hcHNob3RMZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IG4gPSByZXMuc25hcHNob3RJdGVtKGkpO1xuICAgIGlmIChuIGluc3RhbmNlb2YgRWxlbWVudCkgb3V0LnB1c2gobik7XG4gIH1cbiAgcmV0dXJuIG91dDtcbn1cblxuZnVuY3Rpb24gZGVkdXBlPFQ+KGFycjogVFtdKTogVFtdIHtcbiAgcmV0dXJuIFsuLi5uZXcgU2V0KGFycildO1xufVxuXG4vKiogRGV2dWVsdmUgdG9kb3MgbG9zIGVsZW1lbnRvcyBxdWUgY2FzYW4gY29uIHVuIHNlbGVjdG9yIGRlIFJhc3Ryby4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQWxsKHNlbGVjdG9yOiBzdHJpbmcpOiBFbGVtZW50W10ge1xuICB0cnkge1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwidGV4dD1cIikpIHJldHVybiBieVRleHQodW5xdW90ZShzZWxlY3Rvci5zbGljZSg1KSkpO1xuICAgIGlmIChzZWxlY3Rvci5zdGFydHNXaXRoKFwibGFiZWw9XCIpKSByZXR1cm4gYnlMYWJlbCh1bnF1b3RlKHNlbGVjdG9yLnNsaWNlKDYpKSk7XG4gICAgaWYgKHNlbGVjdG9yLnN0YXJ0c1dpdGgoXCJ4cGF0aD1cIikpIHJldHVybiBieVhQYXRoKHNlbGVjdG9yLnNsaWNlKDYpKTtcbiAgICBpZiAoc2VsZWN0b3Iuc3RhcnRzV2l0aChcImZyYW1lPVwiKSkge1xuICAgICAgLy8gTi3DqXNpbW8gaWZyYW1lIGRlbCBkb2N1bWVudG8gKGZvcm1hdG8gZGUgRGV2VG9vbHMgUmVjb3JkZXIpLlxuICAgICAgY29uc3QgZiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWUsIGZyYW1lXCIpW051bWJlcihzZWxlY3Rvci5zbGljZSg2KSldO1xuICAgICAgcmV0dXJuIGYgPyBbZl0gOiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIFsuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKV07XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBbXTtcbiAgfVxufVxuXG5mdW5jdGlvbiB1bnF1b3RlKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IHQgPSBzLnRyaW0oKTtcbiAgaWYgKCh0LnN0YXJ0c1dpdGgoJ1wiJykgJiYgdC5lbmRzV2l0aCgnXCInKSkgfHwgKHQuc3RhcnRzV2l0aChcIidcIikgJiYgdC5lbmRzV2l0aChcIidcIikpKSByZXR1cm4gdC5zbGljZSgxLCAtMSk7XG4gIHJldHVybiB0O1xufVxuXG4vKiogRW5jdWVudHJhIGVsIHByaW1lciBzZWxlY3RvciBxdWUgcmVzdWVsdmUgYSBleGFjdGFtZW50ZSB1biBlbGVtZW50byAobyBhbCBwcmltZXJvIHZpc2libGUpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmUoc2VsZWN0b3JzOiBzdHJpbmdbXSk6IHsgZWw6IEVsZW1lbnQ7IHNlbGVjdG9yOiBzdHJpbmcgfSB8IG51bGwge1xuICBmb3IgKGNvbnN0IHNlbCBvZiBzZWxlY3RvcnMpIHtcbiAgICBjb25zdCBmb3VuZCA9IHJlc29sdmVBbGwoc2VsKTtcbiAgICBpZiAoZm91bmQubGVuZ3RoID09PSAxKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gICAgY29uc3QgdmlzID0gZm91bmQuZmlsdGVyKGlzVmlzaWJsZSk7XG4gICAgaWYgKHZpcy5sZW5ndGggPj0gMSkgcmV0dXJuIHsgZWw6IHZpc1swXSEsIHNlbGVjdG9yOiBzZWwgfTtcbiAgICBpZiAoZm91bmQubGVuZ3RoKSByZXR1cm4geyBlbDogZm91bmRbMF0hLCBzZWxlY3Rvcjogc2VsIH07XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBHZW5lcmFjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZnVuY3Rpb24gaXNVbmlxdWUoc2VsOiBzdHJpbmcsIGVsOiBFbGVtZW50KTogYm9vbGVhbiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlQWxsKHNlbCk7XG4gIHJldHVybiByLmxlbmd0aCA9PT0gMSAmJiByWzBdID09PSBlbDtcbn1cblxuZnVuY3Rpb24gY3NzUGF0aChlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGNvbnN0IHBhcnRzOiBzdHJpbmdbXSA9IFtdO1xuICBsZXQgY3VyOiBFbGVtZW50IHwgbnVsbCA9IGVsO1xuICB3aGlsZSAoY3VyICYmIGN1ciAhPT0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KSB7XG4gICAgY29uc3QgdGFnID0gY3VyLnRhZ05hbWUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoY3VyICE9PSBlbCAmJiBjdXIuaWQgJiYgIWxvb2tzR2VuZXJhdGVkKGN1ci5pZCkpIHtcbiAgICAgIHBhcnRzLnVuc2hpZnQoXCIjXCIgKyBDU1MuZXNjYXBlKGN1ci5pZCkpO1xuICAgICAgY29uc3QgcyA9IHBhcnRzLmpvaW4oXCIgPiBcIik7XG4gICAgICBpZiAoaXNVbmlxdWUocywgZWwpKSByZXR1cm4gcztcbiAgICAgIHBhcnRzLnNoaWZ0KCk7XG4gICAgfVxuICAgIGxldCBzZWcgPSB0YWc7XG4gICAgY29uc3QgY2xzID0gc3RhYmxlQ2xhc3NlcyhjdXIpLnNsaWNlKDAsIDIpO1xuICAgIGlmIChjbHMubGVuZ3RoKSBzZWcgKz0gXCIuXCIgKyBjbHMubWFwKChjKSA9PiBDU1MuZXNjYXBlKGMpKS5qb2luKFwiLlwiKTtcblxuICAgIGNvbnN0IHdpdGhvdXROdGggPSBbc2VnLCAuLi5wYXJ0c10uam9pbihcIiA+IFwiKTtcbiAgICBpZiAoaXNVbmlxdWUod2l0aG91dE50aCwgZWwpKSByZXR1cm4gd2l0aG91dE50aDtcblxuICAgIGNvbnN0IHBhcmVudDogRWxlbWVudCB8IG51bGwgPSBjdXIucGFyZW50RWxlbWVudDtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICBjb25zdCBzYW1lID0gWy4uLnBhcmVudC5jaGlsZHJlbl0uZmlsdGVyKChjKSA9PiBjLnRhZ05hbWUgPT09IGN1ciEudGFnTmFtZSk7XG4gICAgICBpZiAoc2FtZS5sZW5ndGggPiAxKSBzZWcgKz0gYDpudGgtb2YtdHlwZSgke3NhbWUuaW5kZXhPZihjdXIpICsgMX0pYDtcbiAgICB9XG4gICAgcGFydHMudW5zaGlmdChzZWcpO1xuICAgIGNvbnN0IHMgPSBwYXJ0cy5qb2luKFwiID4gXCIpO1xuICAgIGlmIChpc1VuaXF1ZShzLCBlbCkpIHJldHVybiBzO1xuICAgIGN1ciA9IHBhcmVudDtcbiAgfVxuICByZXR1cm4gcGFydHMuam9pbihcIiA+IFwiKTtcbn1cblxuLyoqIEdlbmVyYSBzZWxlY3RvcmVzIGNhbmRpZGF0b3Mgb3JkZW5hZG9zIGRlIG3DoXMgYSBtZW5vcyByb2J1c3RvLiBUb2RvcyDDum5pY29zLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkU2VsZWN0b3JzKGVsOiBFbGVtZW50KTogc3RyaW5nW10ge1xuICBjb25zdCB0YWcgPSBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGM6IHN0cmluZ1tdID0gW107XG5cbiAgZm9yIChjb25zdCBhIG9mIFRFU1RfQVRUUlMpIHtcbiAgICBjb25zdCB2ID0gZWwuZ2V0QXR0cmlidXRlKGEpO1xuICAgIGlmICh2KSBjLnB1c2goYFske2F9PSR7cSh2KX1dYCk7XG4gIH1cbiAgaWYgKGVsLmlkICYmICFsb29rc0dlbmVyYXRlZChlbC5pZCkpIGMucHVzaChcIiNcIiArIENTUy5lc2NhcGUoZWwuaWQpKTtcblxuICBjb25zdCBuYW1lID0gZWwuZ2V0QXR0cmlidXRlKFwibmFtZVwiKTtcbiAgaWYgKG5hbWUpIHtcbiAgICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIChlbC50eXBlID09PSBcInJhZGlvXCIgfHwgZWwudHlwZSA9PT0gXCJjaGVja2JveFwiKSAmJiBlbC52YWx1ZSAmJiBlbC52YWx1ZSAhPT0gXCJvblwiKSB7XG4gICAgICBjLnB1c2goYCR7dGFnfVtuYW1lPSR7cShuYW1lKX1dW3ZhbHVlPSR7cShlbC52YWx1ZSl9XWApO1xuICAgIH0gZWxzZSBjLnB1c2goYCR7dGFnfVtuYW1lPSR7cShuYW1lKX1dYCk7XG4gIH1cblxuICBjb25zdCBpc0NvbnRyb2wgPSBlbC5tYXRjaGVzKENPTlRST0wpO1xuICBpZiAoaXNDb250cm9sKSB7XG4gICAgY29uc3QgbGJsID0gbGFiZWxUZXh0KGVsKTtcbiAgICBpZiAobGJsICYmIGxibC5sZW5ndGggPD0gNjApIGMucHVzaChgbGFiZWw9JHtsYmx9YCk7XG4gIH1cblxuICBjb25zdCBhcmlhID0gZWwuZ2V0QXR0cmlidXRlKFwiYXJpYS1sYWJlbFwiKTtcbiAgaWYgKGFyaWEpIGMucHVzaChgJHt0YWd9W2FyaWEtbGFiZWw9JHtxKGFyaWEpfV1gKTtcbiAgY29uc3QgcGggPSBlbC5nZXRBdHRyaWJ1dGUoXCJwbGFjZWhvbGRlclwiKTtcbiAgaWYgKHBoKSBjLnB1c2goYCR7dGFnfVtwbGFjZWhvbGRlcj0ke3EocGgpfV1gKTtcblxuICBpZiAoIWlzQ29udHJvbCkge1xuICAgIGNvbnN0IHQgPSB0ZXh0T2YoZWwpO1xuICAgIGlmICh0ICYmIHQubGVuZ3RoIDw9IDUwICYmICFlbC5xdWVyeVNlbGVjdG9yKENPTlRST0wpKSBjLnB1c2goYHRleHQ9JHt0fWApO1xuICB9XG5cbiAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICBjb25zdCBocmVmID0gZWwuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKTtcbiAgICBpZiAoaHJlZiAmJiBocmVmLmxlbmd0aCA8IDgwICYmICFocmVmLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSAmJiBocmVmICE9PSBcIiNcIikgYy5wdXNoKGBhW2hyZWY9JHtxKGhyZWYpfV1gKTtcbiAgfVxuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSUZyYW1lRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxGcmFtZUVsZW1lbnQpIHtcbiAgICBjb25zdCBzcmMgPSBlbC5nZXRBdHRyaWJ1dGUoXCJzcmNcIik7XG4gICAgaWYgKHNyYyAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJkYXRhOlwiKSAmJiAhc3JjLnN0YXJ0c1dpdGgoXCJqYXZhc2NyaXB0OlwiKSkge1xuICAgICAgLy8gU2luIHF1ZXJ5IHN0cmluZzogc3VlbGUgbGxldmFyIHRva2VucyBxdWUgY2FtYmlhbiBlbiBjYWRhIGNhcmdhLlxuICAgICAgY29uc3QgYmFzZSA9IHNyYy5zcGxpdCgvWz8jXS8pWzBdITtcbiAgICAgIGMucHVzaChiYXNlID09PSBzcmMgPyBgJHt0YWd9W3NyYz0ke3Eoc3JjKX1dYCA6IGAke3RhZ31bc3JjXj0ke3EoYmFzZSl9XWApO1xuICAgIH1cbiAgfVxuICBjb25zdCB0aXRsZSA9IGVsLmdldEF0dHJpYnV0ZShcInRpdGxlXCIpO1xuICBpZiAodGl0bGUpIGMucHVzaChgJHt0YWd9W3RpdGxlPSR7cSh0aXRsZSl9XWApO1xuXG4gIC8vIHRleHQ9IGFwdW50YSBhbCBub2RvIG3DoXMgcHJvZnVuZG8gY29uIGVzZSB0ZXh0byAocC4gZWouIGVsIDxzcGFuPiBkZSB1biA8bGk+IGRlIGRlc3BsZWdhYmxlKTogY2xpY2FybG8gZXF1aXZhbGUuXG4gIGNvbnN0IHNhbWVUYXJnZXQgPSAoczogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgciA9IHJlc29sdmVBbGwocyk7XG4gICAgcmV0dXJuIHIubGVuZ3RoID09PSAxICYmIChyWzBdID09PSBlbCB8fCAocy5zdGFydHNXaXRoKFwidGV4dD1cIikgJiYgZWwuY29udGFpbnMoclswXSEpICYmIHRleHRPZihyWzBdISkgPT09IHRleHRPZihlbCkpKTtcbiAgfTtcbiAgY29uc3QgdW5pcXVlID0gZGVkdXBlKGMpLmZpbHRlcihzYW1lVGFyZ2V0KTtcbiAgdW5pcXVlLnB1c2goY3NzUGF0aChlbCkpO1xuICByZXR1cm4gZGVkdXBlKHVuaXF1ZSkuc2xpY2UoMCwgNSk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBEZXNjcmlwY2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBsYWJlbFRleHQoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscz8ubGVuZ3RoKSB7XG4gICAgY29uc3QgdCA9IG5vcm0oKGVsIGFzIEhUTUxJbnB1dEVsZW1lbnQpLmxhYmVscyFbMF0hLmlubmVyVGV4dCkucmVwbGFjZSgvXFxzKlxcKiQvLCBcIlwiKTtcbiAgICBpZiAodCkgcmV0dXJuIHQ7XG4gIH1cbiAgY29uc3QgYXJpYSA9IGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIik7XG4gIGlmIChhcmlhKSByZXR1cm4gbm9ybShhcmlhKTtcbiAgY29uc3QgbGIgPSBlbC5nZXRBdHRyaWJ1dGUoXCJhcmlhLWxhYmVsbGVkYnlcIik7XG4gIGlmIChsYikge1xuICAgIGNvbnN0IHQgPSBub3JtKGxiLnNwbGl0KC9cXHMrLykubWFwKChpZCkgPT4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaWQpPy5pbm5lclRleHQgPz8gXCJcIikuam9pbihcIiBcIikpO1xuICAgIGlmICh0KSByZXR1cm4gdDtcbiAgfVxuICByZXR1cm4gXCJcIjtcbn1cblxuLyoqIE5vbWJyZSBsZWdpYmxlIHBhcmEgbW9zdHJhciBlbiBsYSBsaXN0YSBkZSBwYXNvcy4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZShlbDogRWxlbWVudCk6IHN0cmluZyB7XG4gIGlmIChlbC5tYXRjaGVzKENPTlRST0wpKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIGxhYmVsVGV4dChlbCkgfHxcbiAgICAgIGVsLmdldEF0dHJpYnV0ZShcInBsYWNlaG9sZGVyXCIpIHx8XG4gICAgICBlbC5nZXRBdHRyaWJ1dGUoXCJuYW1lXCIpIHx8XG4gICAgICBlbC5pZCB8fFxuICAgICAgZWwuZ2V0QXR0cmlidXRlKFwidGl0bGVcIikgfHxcbiAgICAgIGVsLnRhZ05hbWUudG9Mb3dlckNhc2UoKVxuICAgICkuc2xpY2UoMCwgNjApO1xuICB9XG4gIGNvbnN0IHQgPSB0ZXh0T2YoZWwpO1xuICBpZiAodCkgcmV0dXJuIHQubGVuZ3RoID4gNTAgPyB0LnNsaWNlKDAsIDQ3KSArIFwi4oCmXCIgOiB0O1xuICByZXR1cm4gKFxuICAgIGVsLmdldEF0dHJpYnV0ZShcImFyaWEtbGFiZWxcIikgfHxcbiAgICBlbC5nZXRBdHRyaWJ1dGUoXCJ0aXRsZVwiKSB8fFxuICAgIGVsLnF1ZXJ5U2VsZWN0b3IoXCJpbWdcIik/LmdldEF0dHJpYnV0ZShcImFsdFwiKSB8fFxuICAgIGVsLmdldEF0dHJpYnV0ZShcIm5hbWVcIikgfHxcbiAgICBlbC50YWdOYW1lLnRvTG93ZXJDYXNlKClcbiAgKS5zbGljZSgwLCA2MCk7XG59XG5cbi8qKiBFbGVtZW50byBzb2JyZSBlbCBxdWUgYWN0w7phIGVsIHVzdWFyaW86IGVsIGNvbnRyb2wgbyBlbCBhbmNlc3RybyBjbGljYWJsZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhY3Rpb25hYmxlKHRhcmdldDogRWxlbWVudCk6IEVsZW1lbnQge1xuICBjb25zdCBjdHJsID0gdGFyZ2V0LmNsb3Nlc3QoQ09OVFJPTCk7XG4gIGlmIChjdHJsKSByZXR1cm4gY3RybDtcbiAgY29uc3QgY2xpY2thYmxlID0gdGFyZ2V0LmNsb3Nlc3QoQ0xJQ0tBQkxFKTtcbiAgaWYgKGNsaWNrYWJsZSBpbnN0YW5jZW9mIEhUTUxMYWJlbEVsZW1lbnQgJiYgY2xpY2thYmxlLmNvbnRyb2wpIHJldHVybiBjbGlja2FibGUuY29udHJvbDtcbiAgcmV0dXJuIGNsaWNrYWJsZSA/PyB0YXJnZXQ7XG59XG5cbmNvbnN0IFRFWFRMSUtFID0gbmV3IFNldChbXG4gIFwiXCIsIFwidGV4dFwiLCBcImVtYWlsXCIsIFwicGFzc3dvcmRcIiwgXCJzZWFyY2hcIiwgXCJ0ZWxcIiwgXCJ1cmxcIiwgXCJudW1iZXJcIixcbiAgXCJkYXRlXCIsIFwiZGF0ZXRpbWUtbG9jYWxcIiwgXCJtb250aFwiLCBcIndlZWtcIiwgXCJ0aW1lXCIsIFwiY29sb3JcIiwgXCJyYW5nZVwiLFxuXSk7XG5cbmV4cG9ydCB0eXBlIEFjdGlvbktpbmQgPSBcImNsaWNrXCIgfCBcImZpbGxcIiB8IFwic2VsZWN0XCIgfCBcImNoZWNrXCIgfCBcImZpbGVcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGtpbmRPZihlbDogRWxlbWVudCk6IEFjdGlvbktpbmQge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MU2VsZWN0RWxlbWVudCkgcmV0dXJuIFwic2VsZWN0XCI7XG4gIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxUZXh0QXJlYUVsZW1lbnQpIHJldHVybiBlbC5yZWFkT25seSA/IFwiY2xpY2tcIiA6IFwiZmlsbFwiO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSB7XG4gICAgaWYgKGVsLnR5cGUgPT09IFwiY2hlY2tib3hcIiB8fCBlbC50eXBlID09PSBcInJhZGlvXCIpIHJldHVybiBcImNoZWNrXCI7XG4gICAgaWYgKGVsLnR5cGUgPT09IFwiZmlsZVwiKSByZXR1cm4gXCJmaWxlXCI7XG4gICAgLy8gUmVhZG9ubHkgPSBzZWxlY3RzL2RhdGVwaWNrZXJzIGRlIGxpYnJlcsOtYXMgKEVsZW1lbnQgUGx1cywgVnVldGlmeeKApik6IGFicmVuIHVuIGRlc3BsZWdhYmxlLCBubyBzZSBlc2NyaWJlLlxuICAgIGlmIChURVhUTElLRS5oYXMoZWwudHlwZSkpIHJldHVybiBlbC5yZWFkT25seSA/IFwiY2xpY2tcIiA6IFwiZmlsbFwiO1xuICAgIHJldHVybiBcImNsaWNrXCI7XG4gIH1cbiAgaWYgKChlbCBhcyBIVE1MRWxlbWVudCkuaXNDb250ZW50RWRpdGFibGUpIHJldHVybiBcImZpbGxcIjtcbiAgY29uc3Qgcm9sZSA9IGVsLmdldEF0dHJpYnV0ZShcInJvbGVcIik7XG4gIGlmIChyb2xlID09PSBcImNoZWNrYm94XCIgfHwgcm9sZSA9PT0gXCJzd2l0Y2hcIikgcmV0dXJuIFwiY2hlY2tcIjtcbiAgcmV0dXJuIFwiY2xpY2tcIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHZhbHVlT2YoZWw6IEVsZW1lbnQpOiBzdHJpbmcge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSByZXR1cm4gZWwudmFsdWU7XG4gIHJldHVybiBub3JtKChlbCBhcyBIVE1MRWxlbWVudCkuaW5uZXJUZXh0KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNoZWNrZWRPZihlbDogRWxlbWVudCk6IGJvb2xlYW4ge1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSByZXR1cm4gZWwuY2hlY2tlZDtcbiAgcmV0dXJuIGVsLmdldEF0dHJpYnV0ZShcImFyaWEtY2hlY2tlZFwiKSA9PT0gXCJ0cnVlXCI7XG59XG4iLAogICAgIi8vIFJlcHJvZHVjdG9yOiBlamVjdXRhIHVuIHBhc28gc29icmUgbGEgcMOhZ2luYSBzaW11bGFuZG8gYSB1biB1c3VhcmlvIHJlYWxcbi8vIChzZWN1ZW5jaWEgY29tcGxldGEgZGUgZXZlbnRvcyBkZSBwdW50ZXJvL3RlY2xhZG8sIGNvbXBhdGlibGUgY29uIFJlYWN0L1Z1ZS9Bbmd1bGFyKS5cblxuaW1wb3J0IHR5cGUgeyBTdGVwUmVzdWx0IH0gZnJvbSBcIi4uL3NoYXJlZC9tZXNzYWdlc1wiO1xuaW1wb3J0IHR5cGUgeyBTZXR0aW5ncywgU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5pbXBvcnQgeyBDT0xPUlMsIG92ZXJsYXkgfSBmcm9tIFwiLi9vdmVybGF5XCI7XG5pbXBvcnQgeyBjaGVja2VkT2YsIGlzVmlzaWJsZSwga2luZE9mLCByZXNvbHZlLCB0ZXh0T2YsIHZhbHVlT2YgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG5jbGFzcyBTdGVwRXJyb3IgZXh0ZW5kcyBFcnJvciB7fVxuXG4vKiogRXNwZXJhIGEgcXVlIGVsIGVsZW1lbnRvIGV4aXN0YSAoeSBwcmVmZXJpYmxlbWVudGUgc2VhIHZpc2libGUpLiAqL1xuYXN5bmMgZnVuY3Rpb24gZmluZChzdGVwOiBTdGVwLCB0aW1lb3V0OiBudW1iZXIsIHJlcXVpcmVWaXNpYmxlOiBib29sZWFuKTogUHJvbWlzZTx7IGVsOiBFbGVtZW50OyBzZWxlY3Rvcjogc3RyaW5nIH0+IHtcbiAgY29uc3Qgc2VsZWN0b3JzID0gW3N0ZXAuc2VsZWN0b3IsIC4uLihzdGVwLmZhbGxiYWNrcyA/PyBbXSldLmZpbHRlcihCb29sZWFuKSBhcyBzdHJpbmdbXTtcbiAgaWYgKCFzZWxlY3RvcnMubGVuZ3RoKSB0aHJvdyBuZXcgU3RlcEVycm9yKFwiRWwgcGFzbyBubyB0aWVuZSBzZWxlY3RvclwiKTtcbiAgY29uc3Qgc3RhcnQgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgbGV0IGhpZGRlblNpbmNlID0gMDtcbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCByID0gcmVzb2x2ZShzZWxlY3RvcnMpO1xuICAgIGlmIChyKSB7XG4gICAgICBpZiAoaXNWaXNpYmxlKHIuZWwpKSByZXR1cm4gcjtcbiAgICAgIC8vIENvbnRyb2xlcyBvY3VsdG9zIChjaGVja2JveCBjdXN0b20sIGlucHV0cyBjb24gbGFiZWwgZXN0aWxpemFkb+KApik6IHNlIGFjZXB0YW4gdHJhcyAxcy5cbiAgICAgIGlmICghcmVxdWlyZVZpc2libGUpIHtcbiAgICAgICAgaGlkZGVuU2luY2UgfHw9IHBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBoaWRkZW5TaW5jZSA+IDEwMDApIHJldHVybiByO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHtcbiAgICAgIGlmIChyKSB0aHJvdyBuZXcgU3RlcEVycm9yKGBFbCBlbGVtZW50byDCqyR7c3RlcC5sYWJlbCA/PyBzZWxlY3RvcnNbMF19wrsgZXhpc3RlIHBlcm8gbm8gZXMgdmlzaWJsZWApO1xuICAgICAgdGhyb3cgbmV3IFN0ZXBFcnJvcihgTm8gc2UgZW5jb250csOzIMKrJHtzdGVwLmxhYmVsID8/IHNlbGVjdG9yc1swXX3CuyAoJHtzZWxlY3RvcnNbMF19KWApO1xuICAgIH1cbiAgICBhd2FpdCBzbGVlcCgxMDApO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNlbnRlcihlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIHJldHVybiB7IHg6IHIubGVmdCArIHIud2lkdGggLyAyLCB5OiByLnRvcCArIHIuaGVpZ2h0IC8gMiB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBzY3JvbGxUbyhlbDogRWxlbWVudCkge1xuICBjb25zdCByID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGlmIChyLnRvcCA8IDAgfHwgci5ib3R0b20gPiBpbm5lckhlaWdodCB8fCByLmxlZnQgPCAwIHx8IHIucmlnaHQgPiBpbm5lcldpZHRoKSB7XG4gICAgZWwuc2Nyb2xsSW50b1ZpZXcoeyBibG9jazogXCJjZW50ZXJcIiwgaW5saW5lOiBcImNlbnRlclwiLCBiZWhhdmlvcjogXCJpbnN0YW50XCIgYXMgU2Nyb2xsQmVoYXZpb3IgfSk7XG4gICAgYXdhaXQgc2xlZXAoNTApO1xuICB9XG59XG5cbmZ1bmN0aW9uIG1vdXNlKHRhcmdldDogRWxlbWVudCwgdHlwZTogc3RyaW5nLCB4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICBjb25zdCBpbml0OiBQb2ludGVyRXZlbnRJbml0ID0ge1xuICAgIGJ1YmJsZXM6IHRydWUsIGNhbmNlbGFibGU6IHRydWUsIGNvbXBvc2VkOiB0cnVlLCB2aWV3OiB3aW5kb3csXG4gICAgY2xpZW50WDogeCwgY2xpZW50WTogeSwgc2NyZWVuWDogeCArIHNjcmVlblgsIHNjcmVlblk6IHkgKyBzY3JlZW5ZLFxuICAgIGJ1dHRvbjogMCwgYnV0dG9uczogdHlwZS5lbmRzV2l0aChcImRvd25cIikgPyAxIDogMCwgcG9pbnRlcklkOiAxLCBwb2ludGVyVHlwZTogXCJtb3VzZVwiLCBpc1ByaW1hcnk6IHRydWUsXG4gIH07XG4gIGNvbnN0IEN0b3IgPSB0eXBlLnN0YXJ0c1dpdGgoXCJwb2ludGVyXCIpID8gUG9pbnRlckV2ZW50IDogTW91c2VFdmVudDtcbiAgcmV0dXJuIHRhcmdldC5kaXNwYXRjaEV2ZW50KG5ldyBDdG9yKHR5cGUsIGluaXQpKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVhbENsaWNrKGVsOiBFbGVtZW50KSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgY29uc3QgeyB4LCB5IH0gPSBjZW50ZXIoZWwpO1xuICAvLyBTaSBoYXkgYWxnbyBlbmNpbWEgcGVybyBlcyB1biBoaWpvIChpY29ubyBkZW50cm8gZGVsIGJvdMOzbiksIGRpc3BhcmFtb3Mgc29icmUgw6lsIGNvbW8gaGFyw61hIGVsIG5hdmVnYWRvci5cbiAgY29uc3QgdG9wID0gZG9jdW1lbnQuZWxlbWVudEZyb21Qb2ludCh4LCB5KTtcbiAgY29uc3QgdGFyZ2V0ID0gdG9wICYmIGVsLmNvbnRhaW5zKHRvcCkgPyB0b3AgOiBlbDtcbiAgbW91c2UodGFyZ2V0LCBcInBvaW50ZXJvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2VvdmVyXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcm1vdmVcIiwgeCwgeSk7XG4gIG1vdXNlKHRhcmdldCwgXCJtb3VzZW1vdmVcIiwgeCwgeSk7XG4gIGNvbnN0IGRvd24gPSBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcmRvd25cIiwgeCwgeSkgJiYgbW91c2UodGFyZ2V0LCBcIm1vdXNlZG93blwiLCB4LCB5KTtcbiAgaWYgKGRvd24gJiYgZWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCAmJiBlbC50YWJJbmRleCA+PSAtMSkgZWwuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICBtb3VzZSh0YXJnZXQsIFwicG9pbnRlcnVwXCIsIHgsIHkpO1xuICBtb3VzZSh0YXJnZXQsIFwibW91c2V1cFwiLCB4LCB5KTtcbiAgLy8gY2xpY2sgc2ludMOpdGljbzogZWwgbmF2ZWdhZG9yIGVqZWN1dGEgbGEgYWNjacOzbiBwb3IgZGVmZWN0byAoc2VndWlyIGVubGFjZSwgZW52aWFyIGZvcm3igKYpLlxuICBtb3VzZSh0YXJnZXQsIFwiY2xpY2tcIiwgeCwgeSk7XG59XG5cbmNvbnN0IE5PX1RZUElORyA9IG5ldyBTZXQoW1wiZGF0ZVwiLCBcImRhdGV0aW1lLWxvY2FsXCIsIFwibW9udGhcIiwgXCJ3ZWVrXCIsIFwidGltZVwiLCBcImNvbG9yXCIsIFwicmFuZ2VcIl0pO1xuXG5mdW5jdGlvbiBzZXROYXRpdmUoZWw6IEhUTUxJbnB1dEVsZW1lbnQgfCBIVE1MVGV4dEFyZWFFbGVtZW50LCB2OiBzdHJpbmcpIHtcbiAgLy8gRXN0YW1vcyBlbiBlbCDCq2lzb2xhdGVkIHdvcmxkwrsgZGVsIGNvbnRlbnQgc2NyaXB0OiBlc3RlIHNldHRlciBlcyBlbCBuYXRpdm8sXG4gIC8vIGFzw60gcXVlIGVsIHZhbHVlIHRyYWNrZXIgZGUgUmVhY3QgZGV0ZWN0YSBlbCBjYW1iaW8gYWwgcmVjaWJpciBlbCBldmVudG8gaW5wdXQuXG4gIGNvbnN0IHByb3RvID0gZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50ID8gSFRNTFRleHRBcmVhRWxlbWVudC5wcm90b3R5cGUgOiBIVE1MSW5wdXRFbGVtZW50LnByb3RvdHlwZTtcbiAgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm90bywgXCJ2YWx1ZVwiKSEuc2V0IS5jYWxsKGVsLCB2KTtcbn1cblxuZnVuY3Rpb24gZmlyZUlucHV0KGVsOiBFbGVtZW50LCBkYXRhOiBzdHJpbmcgfCBudWxsLCBpbnB1dFR5cGUgPSBcImluc2VydFRleHRcIikge1xuICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBJbnB1dEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSwgZGF0YSwgaW5wdXRUeXBlIH0pKTtcbn1cblxuZnVuY3Rpb24ga2V5KGVsOiBFbGVtZW50LCB0eXBlOiBcImtleWRvd25cIiB8IFwia2V5cHJlc3NcIiB8IFwia2V5dXBcIiwgazogc3RyaW5nKSB7XG4gIHJldHVybiBlbC5kaXNwYXRjaEV2ZW50KFxuICAgIG5ldyBLZXlib2FyZEV2ZW50KHR5cGUsIHsga2V5OiBrLCBjb2RlOiBjb2RlRm9yKGspLCBidWJibGVzOiB0cnVlLCBjYW5jZWxhYmxlOiB0cnVlLCBjb21wb3NlZDogdHJ1ZSB9KSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gY29kZUZvcihrOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoay5sZW5ndGggPT09IDEpIHtcbiAgICBpZiAoL1thLXpdL2kudGVzdChrKSkgcmV0dXJuIFwiS2V5XCIgKyBrLnRvVXBwZXJDYXNlKCk7XG4gICAgaWYgKC9cXGQvLnRlc3QoaykpIHJldHVybiBcIkRpZ2l0XCIgKyBrO1xuICAgIGlmIChrID09PSBcIiBcIikgcmV0dXJuIFwiU3BhY2VcIjtcbiAgICByZXR1cm4gXCJcIjtcbiAgfVxuICByZXR1cm4gaztcbn1cblxuZnVuY3Rpb24gc2VsZWN0QWxsKGVsOiBIVE1MSW5wdXRFbGVtZW50IHwgSFRNTFRleHRBcmVhRWxlbWVudCkge1xuICB0cnkge1xuICAgIGVsLnNlbGVjdCgpO1xuICB9IGNhdGNoIHtcbiAgICAvKiBudW1iZXIvZW1haWwgbm8gc29wb3J0YW4gc2VsZWNjacOzbiBlbiBhbGd1bm9zIG5hdmVnYWRvcmVzICovXG4gIH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gdHlwZUludG8oZWw6IEVsZW1lbnQsIHZhbHVlOiBzdHJpbmcsIHM6IFNldHRpbmdzKSB7XG4gIGF3YWl0IHNjcm9sbFRvKGVsKTtcbiAgKGVsIGFzIEhUTUxFbGVtZW50KS5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG5cbiAgaWYgKChlbCBhcyBIVE1MRWxlbWVudCkuaXNDb250ZW50RWRpdGFibGUpIHtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZChcInNlbGVjdEFsbFwiKTtcbiAgICBpZiAodmFsdWUpIGRvY3VtZW50LmV4ZWNDb21tYW5kKFwiaW5zZXJ0VGV4dFwiLCBmYWxzZSwgdmFsdWUpO1xuICAgIGVsc2UgZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJkZWxldGVcIik7XG4gICAgaWYgKHRleHRPZihlbCkgIT09IHZhbHVlLnJlcGxhY2UoL1xccysvZywgXCIgXCIpLnRyaW0oKSkge1xuICAgICAgZWwudGV4dENvbnRlbnQgPSB2YWx1ZTtcbiAgICAgIGZpcmVJbnB1dChlbCwgdmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cblxuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQgfHwgZWwgaW5zdGFuY2VvZiBIVE1MVGV4dEFyZWFFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIGVkaXRhYmxlXCIpO1xuICBpZiAoZWwuZGlzYWJsZWQpIHRocm93IG5ldyBTdGVwRXJyb3IoYMKrJHtlbC5uYW1lIHx8IGVsLmlkfcK7IGVzdMOhIGRlc2hhYmlsaXRhZG9gKTtcblxuICBjb25zdCB0eXBlYWJsZSA9ICEoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIE5PX1RZUElORy5oYXMoZWwudHlwZSkpO1xuXG4gIGlmICghdHlwZWFibGUgfHwgcy50eXBlTW9kZSA9PT0gXCJpbnN0YW50XCIpIHtcbiAgICBzZWxlY3RBbGwoZWwpO1xuICAgIGNvbnN0IG9rID0gdHlwZWFibGUgJiYgKHZhbHVlID8gZG9jdW1lbnQuZXhlY0NvbW1hbmQoXCJpbnNlcnRUZXh0XCIsIGZhbHNlLCB2YWx1ZSkgOiBkb2N1bWVudC5leGVjQ29tbWFuZChcImRlbGV0ZVwiKSk7XG4gICAgaWYgKCFvayB8fCBlbC52YWx1ZSAhPT0gdmFsdWUpIHtcbiAgICAgIHNldE5hdGl2ZShlbCwgdmFsdWUpO1xuICAgICAgZmlyZUlucHV0KGVsLCB2YWx1ZSk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIENhcsOhY3RlciBhIGNhcsOhY3RlcjogbcOhcyBsZW50bywgcGVybyBkaXNwYXJhIGtleWRvd24va2V5dXAgcGFyYSB2YWxpZGFjaW9uZXMgeSBhdXRvY29tcGxldGFkb3MuXG4gICAgc2VsZWN0QWxsKGVsKTtcbiAgICBpZiAoIWRvY3VtZW50LmV4ZWNDb21tYW5kKFwiZGVsZXRlXCIpIHx8IGVsLnZhbHVlICE9PSBcIlwiKSB7XG4gICAgICBzZXROYXRpdmUoZWwsIFwiXCIpO1xuICAgICAgZmlyZUlucHV0KGVsLCBudWxsLCBcImRlbGV0ZUNvbnRlbnRCYWNrd2FyZFwiKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBjaCBvZiB2YWx1ZSkge1xuICAgICAgY29uc3QgYWxsb3dlZCA9IGtleShlbCwgXCJrZXlkb3duXCIsIGNoKTtcbiAgICAgIGtleShlbCwgXCJrZXlwcmVzc1wiLCBjaCk7XG4gICAgICBpZiAoYWxsb3dlZCkge1xuICAgICAgICBjb25zdCBiZWZvcmUgPSBlbC52YWx1ZTtcbiAgICAgICAgaWYgKCFkb2N1bWVudC5leGVjQ29tbWFuZChcImluc2VydFRleHRcIiwgZmFsc2UsIGNoKSB8fCBlbC52YWx1ZSA9PT0gYmVmb3JlKSB7XG4gICAgICAgICAgc2V0TmF0aXZlKGVsLCBiZWZvcmUgKyBjaCk7XG4gICAgICAgICAgZmlyZUlucHV0KGVsLCBjaCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGtleShlbCwgXCJrZXl1cFwiLCBjaCk7XG4gICAgICBpZiAocy5rZXlEZWxheSkgYXdhaXQgc2xlZXAocy5rZXlEZWxheSk7XG4gICAgfVxuICB9XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiY2hhbmdlXCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG59XG5cbmZ1bmN0aW9uIHNlbGVjdE9wdGlvbihlbDogRWxlbWVudCwgdmFsdWU6IHN0cmluZywgb3B0aW9uVGV4dD86IHN0cmluZykge1xuICBpZiAoIShlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50KSkgdGhyb3cgbmV3IFN0ZXBFcnJvcihcIkVsIGVsZW1lbnRvIG5vIGVzIHVuIDxzZWxlY3Q+XCIpO1xuICBjb25zdCBvcHRzID0gWy4uLmVsLm9wdGlvbnNdO1xuICBjb25zdCBvcHQgPVxuICAgIG9wdHMuZmluZCgobykgPT4gby52YWx1ZSA9PT0gdmFsdWUpID8/XG4gICAgKG9wdGlvblRleHQgPyBvcHRzLmZpbmQoKG8pID0+IG8udGV4dC50cmltKCkgPT09IG9wdGlvblRleHQpIDogdW5kZWZpbmVkKSA/P1xuICAgIG9wdHMuZmluZCgobykgPT4gby50ZXh0LnRyaW0oKSA9PT0gdmFsdWUpID8/XG4gICAgb3B0cy5maW5kKChvKSA9PiBvLnRleHQudHJpbSgpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModmFsdWUudG9Mb3dlckNhc2UoKSkpO1xuICBpZiAoIW9wdCkgdGhyb3cgbmV3IFN0ZXBFcnJvcihgRWwgc2VsZWN0IG5vIHRpZW5lIGxhIG9wY2nDs24gwqske29wdGlvblRleHQgPz8gdmFsdWV9wrtgKTtcbiAgZWwuZm9jdXMoKTtcbiAgZWwudmFsdWUgPSBvcHQudmFsdWU7XG4gIGVsLmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0Q2hlY2tlZChlbDogRWxlbWVudCwgd2FudDogYm9vbGVhbikge1xuICBpZiAoY2hlY2tlZE9mKGVsKSA9PT0gd2FudCkgcmV0dXJuO1xuICBpZiAoZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50ICYmIGVsLnR5cGUgPT09IFwicmFkaW9cIiAmJiAhd2FudCkge1xuICAgIHRocm93IG5ldyBTdGVwRXJyb3IoXCJVbiByYWRpbyBubyBzZSBwdWVkZSBkZXNtYXJjYXI7IG1hcmNhIG90cmEgb3BjacOzbiBkZWwgZ3J1cG9cIik7XG4gIH1cbiAgaWYgKGlzVmlzaWJsZShlbCkpIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gIGVsc2UgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5sYWJlbHM/LlswXSAmJiBpc1Zpc2libGUoZWwubGFiZWxzWzBdKSkgYXdhaXQgcmVhbENsaWNrKGVsLmxhYmVsc1swXSk7XG4gIGVsc2UgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICBpZiAoY2hlY2tlZE9mKGVsKSAhPT0gd2FudCAmJiBlbCBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHtcbiAgICBlbC5jaGVja2VkID0gd2FudDtcbiAgICBlbC5kaXNwYXRjaEV2ZW50KG5ldyBFdmVudChcImlucHV0XCIsIHsgYnViYmxlczogdHJ1ZSB9KSk7XG4gICAgZWwuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJjaGFuZ2VcIiwgeyBidWJibGVzOiB0cnVlIH0pKTtcbiAgfVxufVxuXG5jb25zdCBGT0NVU0FCTEUgPSAnYVtocmVmXSwgYnV0dG9uLCBpbnB1dCwgc2VsZWN0LCB0ZXh0YXJlYSwgW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCBbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT1cImZhbHNlXCJdKSc7XG5cbmFzeW5jIGZ1bmN0aW9uIHByZXNzKGVsOiBFbGVtZW50LCBrOiBzdHJpbmcpIHtcbiAgY29uc3QgZG93biA9IGtleShlbCwgXCJrZXlkb3duXCIsIGspO1xuICBpZiAoayA9PT0gXCJFbnRlclwiKSBrZXkoZWwsIFwia2V5cHJlc3NcIiwgayk7XG4gIGlmIChkb3duKSB7XG4gICAgaWYgKGsgPT09IFwiRW50ZXJcIikge1xuICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBlbC5mb3JtKSB7XG4gICAgICAgIC8vIEVudsOtbyBpbXBsw61jaXRvOiBlbCBuYXZlZ2Fkb3IgY2xpY2EgZWwgYm90w7NuIGRlIHN1Ym1pdCBwb3IgZGVmZWN0by5cbiAgICAgICAgY29uc3QgYnRuID0gZWwuZm9ybS5xdWVyeVNlbGVjdG9yPEhUTUxFbGVtZW50PignYnV0dG9uW3R5cGU9XCJzdWJtaXRcIl0sIGJ1dHRvbjpub3QoW3R5cGVdKSwgaW5wdXRbdHlwZT1cInN1Ym1pdFwiXSwgaW5wdXRbdHlwZT1cImltYWdlXCJdJyk7XG4gICAgICAgIGlmIChidG4pIGF3YWl0IHJlYWxDbGljayhidG4pO1xuICAgICAgICBlbHNlIGVsLmZvcm0ucmVxdWVzdFN1Ym1pdCgpO1xuICAgICAgfSBlbHNlIGlmIChlbCBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTEFuY2hvckVsZW1lbnQpIHtcbiAgICAgICAgKGVsIGFzIEhUTUxFbGVtZW50KS5jbGljaygpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoayA9PT0gXCJUYWJcIikge1xuICAgICAgY29uc3QgYWxsID0gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KEZPQ1VTQUJMRSldLmZpbHRlcigoZSkgPT4gaXNWaXNpYmxlKGUpICYmICEoZSBhcyBIVE1MSW5wdXRFbGVtZW50KS5kaXNhYmxlZCk7XG4gICAgICBjb25zdCBpID0gYWxsLmluZGV4T2YoZWwgYXMgSFRNTEVsZW1lbnQpO1xuICAgICAgYWxsWyhpICsgMSkgJSBhbGwubGVuZ3RoXT8uZm9jdXMoKTtcbiAgICB9XG4gIH1cbiAga2V5KGVsLCBcImtleXVwXCIsIGspO1xufVxuXG4vKiogwr9BY3RpdmFyIGVzdGUgZWxlbWVudG8gcHVlZGUgY2FtYmlhciBkZSBww6FnaW5hPyAqL1xuZnVuY3Rpb24gbWF5TmF2aWdhdGUoZWw6IEVsZW1lbnQpOiBib29sZWFuIHtcbiAgaWYgKGVsLmNsb3Nlc3QoXCJhW2hyZWZdXCIpKSByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgYnRuID0gZWwuY2xvc2VzdChcImJ1dHRvbiwgaW5wdXRcIik7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MQnV0dG9uRWxlbWVudCkgcmV0dXJuICEhYnRuLmZvcm0gJiYgYnRuLnR5cGUgPT09IFwic3VibWl0XCI7XG4gIGlmIChidG4gaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSByZXR1cm4gISFidG4uZm9ybSAmJiAoW1wic3VibWl0XCIsIFwiaW1hZ2VcIl0uaW5jbHVkZXMoYnRuLnR5cGUpIHx8IGtpbmRPZihidG4pID09PSBcImZpbGxcIik7XG4gIHJldHVybiBmYWxzZTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJ1blN0ZXAoc3RlcDogU3RlcCwgczogU2V0dGluZ3MpOiBQcm9taXNlPFN0ZXBSZXN1bHQ+IHtcbiAgY29uc3QgdGltZW91dCA9IHN0ZXAudGltZW91dCA/PyBzLnRpbWVvdXQ7XG4gIGxldCBuYXYgPSBmYWxzZTtcbiAgdHJ5IHtcbiAgICBsZXQgdXNlZDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgIGNvbnN0IHRhcmdldCA9IGFzeW5jICh2aXNpYmxlID0gdHJ1ZSkgPT4ge1xuICAgICAgY29uc3QgciA9IGF3YWl0IGZpbmQoc3RlcCwgdGltZW91dCwgdmlzaWJsZSk7XG4gICAgICB1c2VkID0gci5zZWxlY3RvcjtcbiAgICAgIGlmIChzLmhpZ2hsaWdodCkgb3ZlcmxheS5mbGFzaChyLmVsLCBzdGVwLmxhYmVsID8/IHN0ZXAudHlwZSwgTWF0aC5tYXgoNDAwLCBzLnN0ZXBEZWxheSArIDIwMCksIENPTE9SUy5ydW4pO1xuICAgICAgcmV0dXJuIHIuZWw7XG4gICAgfTtcblxuICAgIHN3aXRjaCAoc3RlcC50eXBlKSB7XG4gICAgICBjYXNlIFwiY2xpY2tcIjoge1xuICAgICAgICBjb25zdCBlbCA9IGF3YWl0IHRhcmdldCgpO1xuICAgICAgICBuYXYgPSBtYXlOYXZpZ2F0ZShlbCk7XG4gICAgICAgIGF3YWl0IHJlYWxDbGljayhlbCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBcImZpbGxcIjoge1xuICAgICAgICAvLyBUb2xlcmFudGU6IHVuIMKrZmlsbMK7IHNvYnJlIHVuIHNlbGVjdCBvIGNoZWNrYm94IChwLiBlai4gaW1wb3J0YWRvIGRlIERldlRvb2xzKSBoYWNlIGxvIGzDs2dpY28uXG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgaWYgKGVsIGluc3RhbmNlb2YgSFRNTFNlbGVjdEVsZW1lbnQpIHNlbGVjdE9wdGlvbihlbCwgc3RlcC52YWx1ZSA/PyBcIlwiKTtcbiAgICAgICAgZWxzZSBpZiAoa2luZE9mKGVsKSA9PT0gXCJjaGVja1wiKSBhd2FpdCBzZXRDaGVja2VkKGVsLCAhW1wiXCIsIFwiZmFsc2VcIiwgXCJvZmZcIiwgXCIwXCJdLmluY2x1ZGVzKHN0ZXAudmFsdWUgPz8gXCJcIikpO1xuICAgICAgICBlbHNlIGF3YWl0IHR5cGVJbnRvKGVsLCBzdGVwLnZhbHVlID8/IFwiXCIsIHMpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgXCJzZWxlY3RcIjpcbiAgICAgICAgc2VsZWN0T3B0aW9uKGF3YWl0IHRhcmdldChmYWxzZSksIHN0ZXAudmFsdWUgPz8gXCJcIiwgc3RlcC5vcHRpb25UZXh0KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiY2hlY2tcIjpcbiAgICAgICAgYXdhaXQgc2V0Q2hlY2tlZChhd2FpdCB0YXJnZXQoZmFsc2UpLCBzdGVwLnZhbHVlICE9PSBcImZhbHNlXCIpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJwcmVzc1wiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gc3RlcC5zZWxlY3RvciA/IGF3YWl0IHRhcmdldChmYWxzZSkgOiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA/PyBkb2N1bWVudC5ib2R5KTtcbiAgICAgICAgbmF2ID0gKHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKSA9PT0gXCJFbnRlclwiICYmIG1heU5hdmlnYXRlKGVsKTtcbiAgICAgICAgYXdhaXQgcHJlc3MoZWwsIHN0ZXAudmFsdWUgfHwgXCJFbnRlclwiKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwid2FpdEZvclwiOlxuICAgICAgICBhd2FpdCB0YXJnZXQoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYXNzZXJ0VGV4dFwiOiB7XG4gICAgICAgIGNvbnN0IGVsID0gYXdhaXQgdGFyZ2V0KGZhbHNlKTtcbiAgICAgICAgY29uc3Qgd2FudCA9IChzdGVwLnZhbHVlID8/IFwiXCIpLnRyaW0oKTtcbiAgICAgICAgLy8gUmVpbnRlbnRhIGhhc3RhIGVsIHRpbWVvdXQ6IGVsIHRleHRvIHB1ZWRlIHRhcmRhciBlbiBhcGFyZWNlciAocmVzcHVlc3RhIGRlbCBzZXJ2aWRvcikuXG4gICAgICAgIGNvbnN0IHN0YXJ0ID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIGxldCBoYXZlID0gXCJcIjtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICBoYXZlID0gZWwgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50IHx8IGVsIGluc3RhbmNlb2YgSFRNTFRleHRBcmVhRWxlbWVudCB8fCBlbCBpbnN0YW5jZW9mIEhUTUxTZWxlY3RFbGVtZW50ID8gdmFsdWVPZihlbCkgOiB0ZXh0T2YoZWwpO1xuICAgICAgICAgIGlmIChoYXZlLmluY2x1ZGVzKHdhbnQpKSBicmVhaztcbiAgICAgICAgICBpZiAocGVyZm9ybWFuY2Uubm93KCkgLSBzdGFydCA+IHRpbWVvdXQpIHRocm93IG5ldyBTdGVwRXJyb3IoYFNlIGVzcGVyYWJhIMKrJHt3YW50fcK7IHkgaGF5IMKrJHtoYXZlLnNsaWNlKDAsIDgwKX3Cu2ApO1xuICAgICAgICAgIGF3YWl0IHNsZWVwKDE1MCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgU3RlcEVycm9yKGBUaXBvIGRlIHBhc28gwqske3N0ZXAudHlwZX3CuyBubyBzZSBlamVjdXRhIGVuIGxhIHDDoWdpbmFgKTtcbiAgICB9XG4gICAgcmV0dXJuIHsgb2s6IHRydWUsIHVzZWRTZWxlY3RvcjogdXNlZCwgbWF5TmF2aWdhdGU6IG5hdiB9O1xuICB9IGNhdGNoIChlKSB7XG4gICAgcmV0dXJuIHsgb2s6IGZhbHNlLCBlcnJvcjogZSBpbnN0YW5jZW9mIEVycm9yID8gZS5tZXNzYWdlIDogU3RyaW5nKGUpIH07XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhpZ2hsaWdodChzZWxlY3RvcnM6IHN0cmluZ1tdKTogUHJvbWlzZTxib29sZWFuPiB7XG4gIGNvbnN0IHIgPSByZXNvbHZlKHNlbGVjdG9ycyk7XG4gIGlmICghcikgcmV0dXJuIGZhbHNlO1xuICBhd2FpdCBzY3JvbGxUbyhyLmVsKTtcbiAgb3ZlcmxheS5mbGFzaChyLmVsLCByLnNlbGVjdG9yLCAxNTAwLCBDT0xPUlMuY2xpY2spO1xuICByZXR1cm4gdHJ1ZTtcbn1cbiIsCiAgICAiLy8gR3JhYmFkb3IuIERvcyBtb2Rvczpcbi8vICAgcmVjb3JkIOKGkiBsYXMgaW50ZXJhY2Npb25lcyBvY3VycmVuIGRlIHZlcmRhZCB5IHNlIHZhbiBhbm90YW5kby5cbi8vICAgcG9pbnQgIOKGkiDCq3Nlw7FhbGFywrs6IGxvcyBjbGlja3MgZW4gYm90b25lcy9lbmxhY2VzIE5PIHNlIGVqZWN1dGFuLCBzb2xvIHNlIGFub3Rhbi5cbi8vICAgICAgICAgICAgSW5wdXRzLCBzZWxlY3RzIHkgY2hlY2tib3hlcyBmdW5jaW9uYW4gbm9ybWFsLCBhc8OtIHF1ZSBzZSBncmFiYSBzdSBlc3RhZG8uXG4vL1xuLy8gUmVnbGEgY2xhdmU6IGNsaWNhciB1biBpbnB1dCBubyBnZW5lcmEgdW4gwqtjbGlja8K7OyBnZW5lcmEgdW4gwqtmaWxswrsgY29uIHN1IGNvbnRlbmlkbyxcbi8vIHF1ZSBzZSB2YSBhY3R1YWxpemFuZG8gbWllbnRyYXMgZXNjcmliZXMgKGVsIGJhY2tncm91bmQgZnVzaW9uYSBwYXNvcyBkZWwgbWlzbW8gY2FtcG8pLlxuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvbWVzc2FnZXNcIjtcbmltcG9ydCB7IENPTE9SUywgb3ZlcmxheSB9IGZyb20gXCIuL292ZXJsYXlcIjtcbmltcG9ydCB7IGFjdGlvbmFibGUsIGJ1aWxkU2VsZWN0b3JzLCBjaGVja2VkT2YsIGRlc2NyaWJlLCBraW5kT2YsIHZhbHVlT2YsIHR5cGUgQWN0aW9uS2luZCB9IGZyb20gXCIuL3NlbGVjdG9yXCI7XG5cbnR5cGUgTW9kZSA9IFwicmVjb3JkXCIgfCBcInBvaW50XCI7XG5cbmxldCBtb2RlOiBNb2RlIHwgbnVsbCA9IG51bGw7XG5sZXQgc2VuZDogKHM6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuY29uc3QgcGVuZGluZ0ZpbGwgPSBuZXcgTWFwPEVsZW1lbnQsIFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+PigpO1xuXG5jb25zdCBWRVJCOiBSZWNvcmQ8QWN0aW9uS2luZCwgc3RyaW5nPiA9IHsgY2xpY2s6IFwiQ2xpY2tcIiwgZmlsbDogXCJFc2NyaWJpclwiLCBzZWxlY3Q6IFwiU2VsZWNjaW9uYXJcIiwgY2hlY2s6IFwiTWFyY2FyXCIsIGZpbGU6IFwiRmljaGVyb1wiIH07XG5cbi8qKiBDb252aWVydGUgdW4gZWxlbWVudG8gZW4gZWwgcGFzbyBxdWUgbGUgY29ycmVzcG9uZGUsIGNvbiBzdSBlc3RhZG8gYWN0dWFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhcHR1cmUoZWw6IEVsZW1lbnQpOiBSZWNvcmRlZFN0ZXAgfCBudWxsIHtcbiAgY29uc3Qga2luZCA9IGtpbmRPZihlbCk7XG4gIGlmIChraW5kID09PSBcImZpbGVcIikgcmV0dXJuIG51bGw7XG4gIGNvbnN0IFtzZWxlY3RvciwgLi4uZmFsbGJhY2tzXSA9IGJ1aWxkU2VsZWN0b3JzKGVsKTtcbiAgY29uc3QgYmFzZSA9IHsgc2VsZWN0b3IsIGZhbGxiYWNrcywgbGFiZWw6IGRlc2NyaWJlKGVsKSB9O1xuICBzd2l0Y2ggKGtpbmQpIHtcbiAgICBjYXNlIFwiZmlsbFwiOlxuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgdHlwZTogXCJmaWxsXCIsIHZhbHVlOiB2YWx1ZU9mKGVsKSwgc2VjcmV0OiAoZWwgYXMgSFRNTElucHV0RWxlbWVudCkudHlwZSA9PT0gXCJwYXNzd29yZFwiIHx8IHVuZGVmaW5lZCB9O1xuICAgIGNhc2UgXCJzZWxlY3RcIjoge1xuICAgICAgY29uc3QgcyA9IGVsIGFzIEhUTUxTZWxlY3RFbGVtZW50O1xuICAgICAgcmV0dXJuIHsgLi4uYmFzZSwgdHlwZTogXCJzZWxlY3RcIiwgdmFsdWU6IHMudmFsdWUsIG9wdGlvblRleHQ6IHMuc2VsZWN0ZWRPcHRpb25zWzBdPy50ZXh0LnRyaW0oKSB9O1xuICAgIH1cbiAgICBjYXNlIFwiY2hlY2tcIjpcbiAgICAgIHJldHVybiB7IC4uLmJhc2UsIHR5cGU6IFwiY2hlY2tcIiwgdmFsdWU6IFN0cmluZyhjaGVja2VkT2YoZWwpKSB9O1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4geyAuLi5iYXNlLCB0eXBlOiBcImNsaWNrXCIgfTtcbiAgfVxufVxuXG5mdW5jdGlvbiBlbWl0KGVsOiBFbGVtZW50LCBzdGVwOiBSZWNvcmRlZFN0ZXAgfCBudWxsKSB7XG4gIGlmICghc3RlcCkgcmV0dXJuO1xuICBzZW5kKHN0ZXApO1xuICBjb25zdCB3aGF0ID0gc3RlcC50eXBlID09PSBcImZpbGxcIiA/IChzdGVwLnNlY3JldCA/IFwi4oCi4oCi4oCi4oCiXCIgOiBgwqskeyhzdGVwLnZhbHVlID8/IFwiXCIpLnNsaWNlKDAsIDMwKX3Cu2ApIDogXCJcIjtcbiAgb3ZlcmxheS50b2FzdChg4pyTICR7VkVSQltzdGVwLnR5cGUgYXMgQWN0aW9uS2luZF0gPz8gc3RlcC50eXBlfTogJHtzdGVwLmxhYmVsfSAke3doYXR9YC50cmltKCksIENPTE9SU1traW5kT2YoZWwpXSk7XG59XG5cbmZ1bmN0aW9uIGZsdXNoRmlsbHMoKSB7XG4gIGZvciAoY29uc3QgW2VsLCB0XSBvZiBwZW5kaW5nRmlsbCkge1xuICAgIGNsZWFyVGltZW91dCh0KTtcbiAgICBzZW5kKGNhcHR1cmUoZWwpISk7XG4gIH1cbiAgcGVuZGluZ0ZpbGwuY2xlYXIoKTtcbn1cblxuZnVuY3Rpb24gc2NoZWR1bGVGaWxsKGVsOiBFbGVtZW50KSB7XG4gIGNsZWFyVGltZW91dChwZW5kaW5nRmlsbC5nZXQoZWwpKTtcbiAgcGVuZGluZ0ZpbGwuc2V0KFxuICAgIGVsLFxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgcGVuZGluZ0ZpbGwuZGVsZXRlKGVsKTtcbiAgICAgIGNvbnN0IHMgPSBjYXB0dXJlKGVsKTtcbiAgICAgIGlmIChzKSBzZW5kKHMpO1xuICAgIH0sIDM1MCksXG4gICk7XG59XG5cbmNvbnN0IHRhcmdldE9mID0gKGU6IEV2ZW50KTogRWxlbWVudCB8IG51bGwgPT4ge1xuICBjb25zdCB0ID0gZS5jb21wb3NlZFBhdGgoKVswXTtcbiAgcmV0dXJuIHQgaW5zdGFuY2VvZiBFbGVtZW50ID8gdCA6IG51bGw7XG59O1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgTGlzdGVuZXJzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5mdW5jdGlvbiBvbk1vdmUoZTogTW91c2VFdmVudCkge1xuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCB8fCBvdmVybGF5Lm93bnModCkpIHJldHVybjtcbiAgY29uc3QgZWwgPSBhY3Rpb25hYmxlKHQpO1xuICBjb25zdCBrID0ga2luZE9mKGVsKTtcbiAgY29uc3QgaGludCA9IGsgPT09IFwiZmlsZVwiID8gXCJGaWNoZXJvIChubyBhdXRvbWF0aXphYmxlKVwiIDogYCR7VkVSQltrXX0gwrcgJHtkZXNjcmliZShlbCl9YDtcbiAgb3ZlcmxheS5zaG93KGVsLCBoaW50LCBDT0xPUlNba10pO1xufVxuXG4vKiogRW4gbW9kbyBzZcOxYWxhciwgYmxvcXVlYSBib3RvbmVzL2VubGFjZXMgcGFyYSBxdWUgbm8gaGFnYW4gbmFkYSAoZWwgcmVzdG8gZnVuY2lvbmEgbm9ybWFsKS4gKi9cbmZ1bmN0aW9uIGJsb2NrSW5Qb2ludChlOiBFdmVudCkge1xuICBpZiAobW9kZSAhPT0gXCJwb2ludFwiIHx8ICFlLmlzVHJ1c3RlZCkgcmV0dXJuO1xuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCB8fCBvdmVybGF5Lm93bnModCkpIHJldHVybjtcbiAgaWYgKGtpbmRPZihhY3Rpb25hYmxlKHQpKSA9PT0gXCJjbGlja1wiKSB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gb25DbGljayhlOiBNb3VzZUV2ZW50KSB7XG4gIGlmICghZS5pc1RydXN0ZWQpIHJldHVybjtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gIGJsb2NrSW5Qb2ludChlKTtcbiAgY29uc3QgZWwgPSBhY3Rpb25hYmxlKHQpO1xuICBjb25zdCBrID0ga2luZE9mKGVsKTtcbiAgaWYgKGsgPT09IFwiZmlsZVwiKSByZXR1cm4gb3ZlcmxheS50b2FzdChcIkxvcyBpbnB1dHMgZGUgZmljaGVybyBubyBzZSBwdWVkZW4gYXV0b21hdGl6YXJcIiwgdW5kZWZpbmVkLCB0cnVlKTtcbiAgaWYgKGsgPT09IFwiY2hlY2tcIiB8fCBrID09PSBcInNlbGVjdFwiKSByZXR1cm47IC8vIHNlIGdyYWJhbiBlbiBcImNoYW5nZVwiIGNvbiBlbCBlc3RhZG8gZmluYWxcbiAgZmx1c2hGaWxscygpO1xuICBpZiAoayA9PT0gXCJmaWxsXCIpIHtcbiAgICAvLyBDbGljYXIgdW4gaW5wdXQgY29uIGNvbnRlbmlkbyA9IHJlbGxlbmFybG8gY29uIGVzZSBjb250ZW5pZG8uXG4gICAgLy8gU2kgZXN0w6EgdmFjw61vLCBlbCBwYXNvIHNlIGNyZWEgZW4gY3VhbnRvIGVzY3JpYmFzLlxuICAgIGlmICh2YWx1ZU9mKGVsKSkgZW1pdChlbCwgY2FwdHVyZShlbCkpO1xuICAgIHJldHVybjtcbiAgfVxuICBlbWl0KGVsLCBjYXB0dXJlKGVsKSk7XG59XG5cbmZ1bmN0aW9uIG9uSW5wdXQoZTogRXZlbnQpIHtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQpIHJldHVybjtcbiAgY29uc3QgZWwgPSBhY3Rpb25hYmxlKHQpO1xuICBpZiAoa2luZE9mKGVsKSA9PT0gXCJmaWxsXCIpIHNjaGVkdWxlRmlsbChlbCk7XG59XG5cbmZ1bmN0aW9uIG9uQ2hhbmdlKGU6IEV2ZW50KSB7XG4gIGlmICghZS5pc1RydXN0ZWQpIHJldHVybjtcbiAgY29uc3QgdCA9IHRhcmdldE9mKGUpO1xuICBpZiAoIXQpIHJldHVybjtcbiAgY29uc3QgZWwgPSBhY3Rpb25hYmxlKHQpO1xuICBjb25zdCBrID0ga2luZE9mKGVsKTtcbiAgaWYgKGsgPT09IFwiZmlsbFwiKSB7XG4gICAgY2xlYXJUaW1lb3V0KHBlbmRpbmdGaWxsLmdldChlbCkpO1xuICAgIHBlbmRpbmdGaWxsLmRlbGV0ZShlbCk7XG4gICAgc2VuZChjYXB0dXJlKGVsKSEpO1xuICB9IGVsc2UgaWYgKGsgPT09IFwic2VsZWN0XCIgfHwgayA9PT0gXCJjaGVja1wiKSB7XG4gICAgZmx1c2hGaWxscygpO1xuICAgIGVtaXQoZWwsIGNhcHR1cmUoZWwpKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBvbktleShlOiBLZXlib2FyZEV2ZW50KSB7XG4gIGlmICghZS5pc1RydXN0ZWQpIHJldHVybjtcbiAgaWYgKG1vZGUgPT09IFwicG9pbnRcIiAmJiBlLmtleSA9PT0gXCJFc2NhcGVcIikge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBzdG9wSGFuZGxlcigpO1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gIGlmICghdCkgcmV0dXJuO1xuICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIiAmJiB0IGluc3RhbmNlb2YgSFRNTElucHV0RWxlbWVudCAmJiBraW5kT2YodCkgPT09IFwiZmlsbFwiKSB7XG4gICAgZmx1c2hGaWxscygpO1xuICAgIHNlbmQoeyB0eXBlOiBcInByZXNzXCIsIHZhbHVlOiBcIkVudGVyXCIsIHNlbGVjdG9yOiBidWlsZFNlbGVjdG9ycyh0KVswXSwgbGFiZWw6IGRlc2NyaWJlKHQpIH0pO1xuICAgIG92ZXJsYXkudG9hc3QoYOKckyBUZWNsYTogRW50ZXIgZW4gJHtkZXNjcmliZSh0KX1gKTtcbiAgfVxufVxuXG5mdW5jdGlvbiBvbkxlYXZlKCkge1xuICBmbHVzaEZpbGxzKCk7XG59XG5cbmNvbnN0IG9uU2Nyb2xsID0gKCkgPT4gb3ZlcmxheS5oaWRlKCk7XG5cbmxldCBzdG9wSGFuZGxlcjogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuXG5jb25zdCBsaXN0ZW5lcnM6IFtzdHJpbmcsIEV2ZW50TGlzdGVuZXJdW10gPSBbXG4gIFtcIm1vdXNlbW92ZVwiLCBvbk1vdmUgYXMgRXZlbnRMaXN0ZW5lcl0sXG4gIFtcInBvaW50ZXJkb3duXCIsIGJsb2NrSW5Qb2ludF0sXG4gIFtcIm1vdXNlZG93blwiLCBibG9ja0luUG9pbnRdLFxuICBbXCJwb2ludGVydXBcIiwgYmxvY2tJblBvaW50XSxcbiAgW1wibW91c2V1cFwiLCBibG9ja0luUG9pbnRdLFxuICBbXCJjbGlja1wiLCBvbkNsaWNrIGFzIEV2ZW50TGlzdGVuZXJdLFxuICBbXCJpbnB1dFwiLCBvbklucHV0XSxcbiAgW1wiY2hhbmdlXCIsIG9uQ2hhbmdlXSxcbiAgW1wia2V5ZG93blwiLCBvbktleSBhcyBFdmVudExpc3RlbmVyXSxcbl07XG5cbmV4cG9ydCBmdW5jdGlvbiBzdGFydFJlY29yZGluZyhtOiBNb2RlLCBzaW5rOiAoczogUmVjb3JkZWRTdGVwKSA9PiB2b2lkLCBvblN0b3A6ICgpID0+IHZvaWQpIHtcbiAgaWYgKG1vZGUpIHN0b3BSZWNvcmRpbmcoKTtcbiAgbW9kZSA9IG07XG4gIHNlbmQgPSBzaW5rO1xuICBzdG9wSGFuZGxlciA9IG9uU3RvcDtcbiAgb3ZlcmxheS5vblN0b3AgPSBvblN0b3A7XG4gIGZvciAoY29uc3QgW2V2LCBmbl0gb2YgbGlzdGVuZXJzKSB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihldiwgZm4sIHRydWUpO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIG9uTGVhdmUpO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBvblNjcm9sbCwgdHJ1ZSk7XG4gIC8vIExhIHDDrWxkb3JhIHNvbG8gZW4gbGEgcMOhZ2luYSBwcmluY2lwYWwsIG5vIGVuIGNhZGEgaWZyYW1lLlxuICBpZiAod2luZG93ID09PSB3aW5kb3cudG9wKSBvdmVybGF5LnNldFBpbGwobSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdG9wUmVjb3JkaW5nKCkge1xuICBmbHVzaEZpbGxzKCk7XG4gIGZvciAoY29uc3QgW2V2LCBmbl0gb2YgbGlzdGVuZXJzKSB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihldiwgZm4sIHRydWUpO1xuICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsIG9uTGVhdmUpO1xuICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCBvblNjcm9sbCwgdHJ1ZSk7XG4gIG1vZGUgPSBudWxsO1xuICBvdmVybGF5LmhpZGUoKTtcbiAgb3ZlcmxheS5zZXRQaWxsKG51bGwpO1xufVxuXG4vKiogU2VsZWNjacOzbiBkZSB1biDDum5pY28gZWxlbWVudG8gKHBhcmEgcmUtYXB1bnRhciB1biBwYXNvKS4gQ2xpY2tzIGJsb3F1ZWFkb3MuICovXG5leHBvcnQgZnVuY3Rpb24gcGlja09uY2UoKTogUHJvbWlzZTxSZWNvcmRlZFN0ZXAgfCBudWxsPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIGNvbnN0IGJsb2NrID0gKGU6IEV2ZW50KSA9PiB7XG4gICAgICBpZiAob3ZlcmxheS5vd25zKHRhcmdldE9mKGUpKSkgcmV0dXJuO1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTtcbiAgICB9O1xuICAgIGNvbnN0IGRvbmUgPSAocjogUmVjb3JkZWRTdGVwIHwgbnVsbCkgPT4ge1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW1vdmVcIiwgb25Nb3ZlIGFzIEV2ZW50TGlzdGVuZXIsIHRydWUpO1xuICAgICAgZm9yIChjb25zdCBldiBvZiBbXCJwb2ludGVyZG93blwiLCBcIm1vdXNlZG93blwiLCBcInBvaW50ZXJ1cFwiLCBcIm1vdXNldXBcIl0pIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKGV2LCBibG9jaywgdHJ1ZSk7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNsaWNrLCB0cnVlKTtcbiAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBrZXksIHRydWUpO1xuICAgICAgb3ZlcmxheS5oaWRlKCk7XG4gICAgICBjYW5jZWxQaWNrID0gKCkgPT4ge307XG4gICAgICByZXNvbHZlKHIpO1xuICAgIH07XG4gICAgY29uc3QgY2xpY2sgPSAoZTogTW91c2VFdmVudCkgPT4ge1xuICAgICAgYmxvY2soZSk7XG4gICAgICBjb25zdCB0ID0gdGFyZ2V0T2YoZSk7XG4gICAgICBpZiAoIXQgfHwgb3ZlcmxheS5vd25zKHQpKSByZXR1cm47XG4gICAgICBkb25lKGNhcHR1cmUoYWN0aW9uYWJsZSh0KSkgPz8gbnVsbCk7XG4gICAgfTtcbiAgICBjb25zdCBrZXkgPSAoZTogS2V5Ym9hcmRFdmVudCkgPT4ge1xuICAgICAgaWYgKGUua2V5ID09PSBcIkVzY2FwZVwiKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZG9uZShudWxsKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2Vtb3ZlXCIsIG9uTW92ZSBhcyBFdmVudExpc3RlbmVyLCB0cnVlKTtcbiAgICBmb3IgKGNvbnN0IGV2IG9mIFtcInBvaW50ZXJkb3duXCIsIFwibW91c2Vkb3duXCIsIFwicG9pbnRlcnVwXCIsIFwibW91c2V1cFwiXSkgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoZXYsIGJsb2NrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImNsaWNrXCIsIGNsaWNrLCB0cnVlKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwga2V5LCB0cnVlKTtcbiAgICBjYW5jZWxQaWNrID0gKCkgPT4gZG9uZShudWxsKTtcbiAgICBpZiAod2luZG93ID09PSB3aW5kb3cudG9wKSBvdmVybGF5LnRvYXN0KFwiQ2xpY2EgZWwgZWxlbWVudG8gKEVzYyBwYXJhIGNhbmNlbGFyKVwiKTtcbiAgfSk7XG59XG5cbmV4cG9ydCBsZXQgY2FuY2VsUGljazogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuIiwKICAgICIvLyBDb250ZW50IHNjcmlwdDogcHVlbnRlIGVudHJlIGxhIHDDoWdpbmEgeSBsYSBleHRlbnNpw7NuLiBTZSBpbnllY3RhIGVuIHRvZG9zIGxvcyBmcmFtZXMuXG5pbXBvcnQgdHlwZSB7IFJlY29yZGVkU3RlcCwgVG9CYWNrZ3JvdW5kLCBUb0NvbnRlbnQgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgaGlnaGxpZ2h0LCBydW5TdGVwIH0gZnJvbSBcIi4vcGxheWVyXCI7XG5pbXBvcnQgeyBjYW5jZWxQaWNrLCBwaWNrT25jZSwgc3RhcnRSZWNvcmRpbmcsIHN0b3BSZWNvcmRpbmcgfSBmcm9tIFwiLi9yZWNvcmRlclwiO1xuaW1wb3J0IHsgYnVpbGRTZWxlY3RvcnMsIHJlc29sdmUgfSBmcm9tIFwiLi9zZWxlY3RvclwiO1xuXG5kZWNsYXJlIGdsb2JhbCB7XG4gIGludGVyZmFjZSBXaW5kb3cge1xuICAgIF9fcmFzdHJvPzogYm9vbGVhbjtcbiAgfVxufVxuXG5mdW5jdGlvbiB0b0JnPFQgPSBhbnk+KG1zZzogVG9CYWNrZ3JvdW5kKTogUHJvbWlzZTxUIHwgdW5kZWZpbmVkPiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZykuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgfSBjYXRjaCB7XG4gICAgLy8gTGEgZXh0ZW5zacOzbiBzZSByZWNhcmfDsyB5IGVzdGUgc2NyaXB0IHF1ZWTDsyBodcOpcmZhbm8uXG4gICAgc3RvcFJlY29yZGluZygpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodW5kZWZpbmVkKTtcbiAgfVxufVxuXG5jb25zdCBzaW5rID0gKHN0ZXA6IFJlY29yZGVkU3RlcCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RlcFwiLCBzdGVwIH0pO1xuY29uc3Qgb25TdG9wID0gKCkgPT4gdm9pZCB0b0JnKHsga2luZDogXCJyZWNvcmQ6c3RvcFwiIH0pO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRnJhbWVzOiBoYW5kc2hha2UgcG9yIHBvc3RNZXNzYWdlIChmdW5jaW9uYSB0YW1iacOpbiBjcm9zcy1vcmlnaW4pIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBNU0cgPSBcIl9fcmFzdHJvX2ZyYW1lXCI7XG4vKiogdG9rZW4g4oaSIDxpZnJhbWU+IGhpam8gcXVlIHNlIGFudW5jacOzIGNvbiDDqWwuICovXG5jb25zdCBhbm5vdW5jZWQgPSBuZXcgTWFwPHN0cmluZywgRWxlbWVudD4oKTtcblxuZnVuY3Rpb24gZnJhbWVFbGVtZW50Rm9yKHNvdXJjZTogTWVzc2FnZUV2ZW50U291cmNlIHwgbnVsbCk6IEVsZW1lbnQgfCB1bmRlZmluZWQge1xuICBpZiAoIXNvdXJjZSkgcmV0dXJuO1xuICByZXR1cm4gWy4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoXCJpZnJhbWUsIGZyYW1lXCIpXS5maW5kKChmKSA9PiAoZiBhcyBIVE1MSUZyYW1lRWxlbWVudCkuY29udGVudFdpbmRvdyA9PT0gc291cmNlKTtcbn1cblxuZnVuY3Rpb24gb25GcmFtZU1lc3NhZ2UoZTogTWVzc2FnZUV2ZW50KSB7XG4gIGNvbnN0IGQgPSBlLmRhdGE7XG4gIGlmICghZCB8fCB0eXBlb2YgZCAhPT0gXCJvYmplY3RcIiB8fCBkW01TR10gPT0gbnVsbCB8fCB0eXBlb2YgZC50b2tlbiAhPT0gXCJzdHJpbmdcIikgcmV0dXJuO1xuICBpZiAoZFtNU0ddID09PSBcImFubm91bmNlXCIpIHtcbiAgICBjb25zdCBlbCA9IGZyYW1lRWxlbWVudEZvcihlLnNvdXJjZSk7XG4gICAgaWYgKGVsKSBhbm5vdW5jZWQuc2V0KGQudG9rZW4sIGVsKTtcbiAgfSBlbHNlIGlmIChkW01TR10gPT09IFwicHJvYmVcIiAmJiBlLnNvdXJjZSA9PT0gd2luZG93LnBhcmVudCAmJiB3aW5kb3cgIT09IHdpbmRvdy50b3ApIHtcbiAgICB2b2lkIHRvQmcoeyBraW5kOiBcImZyYW1lOnByb2JlXCIsIHRva2VuOiBkLnRva2VuIH0pO1xuICB9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNlbGVjdG9yc0ZvckFubm91bmNlZCh0b2tlbjogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmdbXSB8IG51bGw+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMCAmJiAhYW5ub3VuY2VkLmhhcyh0b2tlbik7IGkrKykgYXdhaXQgc2xlZXAoNTApO1xuICBjb25zdCBlbCA9IGFubm91bmNlZC5nZXQodG9rZW4pO1xuICBhbm5vdW5jZWQuZGVsZXRlKHRva2VuKTtcbiAgcmV0dXJuIGVsID8gYnVpbGRTZWxlY3RvcnMoZWwpIDogbnVsbDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVzb2x2ZUZyYW1lKHNlbGVjdG9yczogc3RyaW5nW10sIHRpbWVvdXQ6IG51bWJlcik6IFByb21pc2U8eyB0b2tlbj86IHN0cmluZzsgZXJyb3I/OiBzdHJpbmcgfT4ge1xuICBjb25zdCBlbmQgPSBwZXJmb3JtYW5jZS5ub3coKSArIHRpbWVvdXQ7XG4gIHdoaWxlICh0cnVlKSB7XG4gICAgY29uc3QgciA9IHJlc29sdmUoc2VsZWN0b3JzKTtcbiAgICBjb25zdCB3aW4gPSByICYmIChyLmVsIGFzIEhUTUxJRnJhbWVFbGVtZW50KS5jb250ZW50V2luZG93O1xuICAgIGlmICh3aW4pIHtcbiAgICAgIGNvbnN0IHRva2VuID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICAgIHdpbi5wb3N0TWVzc2FnZSh7IFtNU0ddOiBcInByb2JlXCIsIHRva2VuIH0sIFwiKlwiKTtcbiAgICAgIHJldHVybiB7IHRva2VuIH07XG4gICAgfVxuICAgIGlmIChwZXJmb3JtYW5jZS5ub3coKSA+IGVuZCkgcmV0dXJuIHsgZXJyb3I6IGBObyBzZSBlbmNvbnRyw7MgZWwgaWZyYW1lIMKrJHtzZWxlY3RvcnNbMF19wrtgIH07XG4gICAgYXdhaXQgc2xlZXAoMTAwKTtcbiAgfVxufVxuXG5pZiAoIXdpbmRvdy5fX3Jhc3Rybykge1xuICB3aW5kb3cuX19yYXN0cm8gPSB0cnVlO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgb25GcmFtZU1lc3NhZ2UpO1xuXG4gIGNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobXNnOiBUb0NvbnRlbnQsIF9zZW5kZXIsIHJlcGx5KSA9PiB7XG4gICAgc3dpdGNoIChtc2cua2luZCkge1xuICAgICAgY2FzZSBcInBpbmdcIjpcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvblwiOlxuICAgICAgICBzdGFydFJlY29yZGluZyhtc2cubW9kZSwgc2luaywgb25TdG9wKTtcbiAgICAgICAgcmVwbHkoeyBvazogdHJ1ZSB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY2FzZSBcInJlY29yZDpvZmZcIjpcbiAgICAgICAgc3RvcFJlY29yZGluZygpO1xuICAgICAgICByZXBseSh7IG9rOiB0cnVlIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICBjYXNlIFwicnVuLXN0ZXBcIjpcbiAgICAgICAgcnVuU3RlcChtc2cuc3RlcCwgbXNnLnNldHRpbmdzKS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIHJlc3B1ZXN0YSBhc8OtbmNyb25hXG4gICAgICBjYXNlIFwiaGlnaGxpZ2h0XCI6XG4gICAgICAgIGhpZ2hsaWdodChbbXNnLnNlbGVjdG9yLCAuLi4obXNnLmZhbGxiYWNrcyA/PyBbXSldKS50aGVuKChmb3VuZCkgPT4gcmVwbHkoeyBvazogZm91bmQgfSkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrXCI6XG4gICAgICAgIC8vIFNlIGRpZnVuZGUgYSB0b2RvcyBsb3MgZnJhbWVzOyByZXNwb25kZSBlbCBmcmFtZSBkb25kZSBjbGlxdWUgZWwgdXN1YXJpbyxcbiAgICAgICAgLy8gdHJhcyBwZWRpciBhbCBiYWNrZ3JvdW5kIHF1ZSBhw7FhZGEgbGEgcnV0YSBkZSBpZnJhbWVzLlxuICAgICAgICBwaWNrT25jZSgpLnRoZW4oYXN5bmMgKHN0ZXApID0+IHJlcGx5KHN0ZXAgPyAoKGF3YWl0IHRvQmc8UmVjb3JkZWRTdGVwPih7IGtpbmQ6IFwiZnJhbWU6bG9jYXRlXCIsIHN0ZXAgfSkpID8/IHN0ZXApIDogbnVsbCkpO1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIGNhc2UgXCJwaWNrOmNhbmNlbFwiOlxuICAgICAgICBjYW5jZWxQaWNrKCk7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTphbm5vdW5jZVwiOlxuICAgICAgICB3aW5kb3cucGFyZW50LnBvc3RNZXNzYWdlKHsgW01TR106IFwiYW5ub3VuY2VcIiwgdG9rZW46IG1zZy50b2tlbiB9LCBcIipcIik7XG4gICAgICAgIHJlcGx5KHsgb2s6IHRydWUgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIGNhc2UgXCJmcmFtZTpzZWxlY3RvcnNcIjpcbiAgICAgICAgc2VsZWN0b3JzRm9yQW5ub3VuY2VkKG1zZy50b2tlbikudGhlbihyZXBseSk7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgY2FzZSBcImZyYW1lOnJlc29sdmVcIjpcbiAgICAgICAgcmVzb2x2ZUZyYW1lKG1zZy5zZWxlY3RvcnMsIG1zZy50aW1lb3V0KS50aGVuKHJlcGx5KTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICB9KTtcblxuICAvLyBBbCBjYXJnYXIgdW5hIHDDoWdpbmEgbnVldmEsIMK/c2VndWltb3MgZ3JhYmFuZG8gZW4gZXN0YSBwZXN0YcOxYT9cbiAgdG9CZzx7IG1vZGU/OiBcInJlY29yZFwiIHwgXCJwb2ludFwiIH0+KHsga2luZDogXCJyZWNvcmQ6c3RhdHVzXCIgfSkudGhlbigocikgPT4ge1xuICAgIGlmIChyPy5tb2RlKSBzdGFydFJlY29yZGluZyhyLm1vZGUsIHNpbmssIG9uU3RvcCk7XG4gIH0pO1xufVxuIgogIF0sCiAgIm1hcHBpbmdzIjogIjs7RUFHTyxTQUFTLGNBQWMsQ0FBQyxHQUFvQjtBQUFBLElBQ2pELE9BQ0UsRUFBRSxTQUFTLE1BQ1gsU0FBUyxLQUFLLENBQUMsS0FDZixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLG9CQUFvQixLQUFLLENBQUMsS0FDMUIsa0JBQWtCLEtBQUssQ0FBQyxLQUN4Qix1RkFBdUYsS0FBSyxDQUFDLEtBQzVGLHVCQUF1QixLQUFLLENBQUMsS0FBSyxTQUFTLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQyxLQUM1RCwyQ0FBMkMsS0FBSyxDQUFDO0FBQUE7QUFBQSxFQUk5QyxJQUFNLFFBQVEsQ0FBQyxPQUFlLElBQUksUUFBYyxDQUFDLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQzs7O0VDZC9FLElBQU0sT0FBTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXFDTCxJQUFNLFNBQVMsRUFBRSxPQUFPLFdBQVcsTUFBTSxXQUFXLFFBQVEsV0FBVyxPQUFPLFdBQVcsTUFBTSxXQUFXLEtBQUssVUFBVTtBQUFBO0FBQUEsRUFFaEksTUFBTSxRQUFRO0FBQUEsSUFDWjtBQUFBLElBQ1E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDUixTQUFxQixNQUFNO0FBQUEsSUFFbkIsTUFBTSxHQUFHO0FBQUEsTUFDZixJQUFJLEtBQUssTUFBTTtBQUFBLFFBQWE7QUFBQSxNQUM1QixLQUFLLE9BQU8sU0FBUyxjQUFjLEtBQUs7QUFBQSxNQUN4QyxLQUFLLEtBQUssS0FBSztBQUFBLE1BQ2YsTUFBTSxPQUFPLEtBQUssS0FBSyxhQUFhLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFBQSxNQUNwRCxLQUFLLFlBQVksVUFBVTtBQUFBO0FBQUE7QUFBQSxNQUczQixLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE1BQU0sS0FBSyxjQUFjLE1BQU07QUFBQSxNQUNwQyxLQUFLLE9BQU8sS0FBSyxjQUFjLE9BQU87QUFBQSxNQUN0QyxLQUFLLFdBQVcsS0FBSyxjQUFjLE1BQU07QUFBQSxNQUN6QyxLQUFLLFNBQVMsS0FBSyxjQUFjLFNBQVM7QUFBQSxNQUMxQyxLQUFLLGNBQWMsUUFBUSxFQUFHLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUFBLFFBQzdELEVBQUUsZ0JBQWdCO0FBQUEsUUFDbEIsS0FBSyxPQUFPO0FBQUEsT0FDYjtBQUFBLE1BQ0QsU0FBUyxnQkFBZ0IsWUFBWSxLQUFLLElBQUk7QUFBQTtBQUFBLElBR2hELElBQUksQ0FBQyxJQUFpQztBQUFBLE1BQ3BDLE9BQU8sQ0FBQyxDQUFDLEtBQUssUUFBUSxjQUFjLFNBQVMsT0FBTyxLQUFLLFFBQVEsS0FBSyxLQUFLLFNBQVMsRUFBRTtBQUFBO0FBQUEsSUFHeEYsSUFBSSxDQUFDLElBQWEsTUFBYyxRQUFnQixPQUFPLE9BQU87QUFBQSxNQUM1RCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxHQUFHLHNCQUFzQjtBQUFBLE1BQ25DLE9BQU8sT0FBTyxLQUFLLElBQUksT0FBTztBQUFBLFFBQzVCLFNBQVM7QUFBQSxRQUFTLE1BQU0sR0FBRyxFQUFFLE9BQU87QUFBQSxRQUFPLEtBQUssR0FBRyxFQUFFLE1BQU07QUFBQSxRQUFPLE9BQU8sR0FBRyxFQUFFLFFBQVE7QUFBQSxRQUFPLFFBQVEsR0FBRyxFQUFFLFNBQVM7QUFBQSxNQUNySCxDQUFDO0FBQUEsTUFDRCxLQUFLLElBQUksTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQ3ZDLEtBQUssSUFBSSxNQUFNLFlBQVksT0FBTyxLQUFLO0FBQUEsTUFDdkMsS0FBSyxJQUFJLGNBQWM7QUFBQSxNQUN2QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUEsTUFDekIsTUFBTSxRQUFRLEVBQUUsTUFBTTtBQUFBLE1BQ3RCLEtBQUssSUFBSSxNQUFNLE9BQU8sR0FBRyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksRUFBRSxPQUFPLEdBQUcsYUFBYSxHQUFHLENBQUM7QUFBQSxNQUMzRSxLQUFLLElBQUksTUFBTSxNQUFNLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxHQUFHLEVBQUUsU0FBUztBQUFBO0FBQUEsSUFHakUsSUFBSSxHQUFHO0FBQUEsTUFDTCxJQUFJLENBQUMsS0FBSztBQUFBLFFBQUs7QUFBQSxNQUNmLEtBQUssSUFBSSxNQUFNLFVBQVU7QUFBQSxNQUN6QixLQUFLLElBQUksTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUkzQixLQUFLLENBQUMsSUFBYSxNQUFjLEtBQUssS0FBSyxRQUFnQixPQUFPLEtBQUs7QUFBQSxNQUNyRSxLQUFLLEtBQUssSUFBSSxNQUFNLEtBQUs7QUFBQSxNQUN6QixXQUFXLE1BQU0sS0FBSyxLQUFLLEdBQUcsRUFBRTtBQUFBO0FBQUEsSUFHbEMsT0FBTyxDQUFDLE1BQWlDO0FBQUEsTUFDdkMsS0FBSyxPQUFPO0FBQUEsTUFDWixJQUFJLENBQUMsTUFBTTtBQUFBLFFBQ1QsS0FBSyxLQUFLLE1BQU0sVUFBVTtBQUFBLFFBQzFCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsS0FBSyxLQUFLLFlBQVksVUFBVTtBQUFBLE1BQ2hDLEtBQUssU0FBUyxjQUFjLFNBQVMsV0FBVyxvQkFBb0I7QUFBQSxNQUNwRSxLQUFLLEtBQUssTUFBTSxVQUFVO0FBQUE7QUFBQSxJQUc1QixLQUFLLENBQUMsTUFBYyxPQUFnQixPQUFPLE9BQU87QUFBQSxNQUNoRCxLQUFLLE9BQU87QUFBQSxNQUNaLE1BQU0sSUFBSSxTQUFTLGNBQWMsS0FBSztBQUFBLE1BQ3RDLEVBQUUsWUFBWSxXQUFXLE9BQU8sVUFBVTtBQUFBLE1BQzFDLElBQUk7QUFBQSxRQUFPLEVBQUUsTUFBTSxZQUFZLE9BQU8sS0FBSztBQUFBLE1BQzNDLEVBQUUsY0FBYztBQUFBLE1BQ2hCLEtBQUssT0FBTyxZQUFZLENBQUM7QUFBQSxNQUN6QixXQUFXLE1BQU0sRUFBRSxPQUFPLEdBQUcsSUFBSTtBQUFBLE1BQ2pDLE9BQU8sS0FBSyxPQUFPLFNBQVMsU0FBUztBQUFBLFFBQUcsS0FBSyxPQUFPLGtCQUFtQixPQUFPO0FBQUE7QUFBQSxFQUVsRjtBQUFBLEVBRU8sSUFBTSxVQUFVLElBQUk7OztFQzlHM0IsSUFBTSxhQUFhLENBQUMsZUFBZSxnQkFBZ0IsYUFBYSxXQUFXLFdBQVcsWUFBWSxvQkFBb0I7QUFBQSxFQUV0SCxJQUFNLFlBQ0osd0dBQ0EscUdBQ0E7QUFBQSxFQUVLLElBQU0sVUFBVTtBQUFBLEVBRXZCLElBQU0sT0FBTyxDQUFDLE9BQWtDLEtBQUssSUFBSSxRQUFRLFFBQVEsR0FBRyxFQUFFLEtBQUs7QUFBQSxFQUVuRixJQUFNLGdCQUFnQjtBQUFBLEVBRXRCLFNBQVMsYUFBYSxDQUFDLElBQXVCO0FBQUEsSUFDNUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxTQUFTLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLGNBQWMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLFNBQVMsR0FBRyxLQUFLLEVBQUUsU0FBUyxFQUFFO0FBQUE7QUFBQSxFQUcxSCxJQUFNLElBQUksQ0FBQyxNQUFjLEtBQUssVUFBVSxDQUFDO0FBQUEsRUFJbEMsU0FBUyxTQUFTLENBQUMsSUFBc0I7QUFBQSxJQUM5QyxJQUFJLENBQUMsR0FBRztBQUFBLE1BQWEsT0FBTztBQUFBLElBQzVCLElBQUksR0FBRyxlQUFlLEVBQUUsV0FBVztBQUFBLE1BQUcsT0FBTztBQUFBLElBQzdDLE1BQU0sS0FBSyxpQkFBaUIsRUFBRTtBQUFBLElBQzlCLE9BQU8sR0FBRyxlQUFlLFlBQVksR0FBRyxZQUFZO0FBQUE7QUFBQSxFQUkvQyxTQUFTLE1BQU0sQ0FBQyxJQUFxQjtBQUFBLElBQzFDLElBQUksY0FBYyxvQkFBb0IsQ0FBQyxVQUFVLFVBQVUsT0FBTyxFQUFFLFNBQVMsR0FBRyxJQUFJO0FBQUEsTUFBRyxPQUFPLEtBQUssR0FBRyxLQUFLO0FBQUEsSUFDM0csT0FBTyxLQUFNLEdBQW1CLGFBQWEsR0FBRyxXQUFXO0FBQUE7QUFBQSxFQUc3RCxVQUFVLFdBQVcsQ0FBQyxPQUE4QixVQUE4QjtBQUFBLElBQ2hGLE1BQU0sU0FBUyxTQUFTLGlCQUFpQixNQUFNLFdBQVcsWUFBWTtBQUFBLElBQ3RFLElBQUksSUFBSSxPQUFPLFNBQVM7QUFBQSxJQUN4QixPQUFPLEdBQUc7QUFBQSxNQUNSLE1BQU07QUFBQSxNQUNOLE1BQU0sS0FBTSxFQUFjO0FBQUEsTUFDMUIsSUFBSTtBQUFBLFFBQUksT0FBTyxZQUFZLEVBQUU7QUFBQSxNQUM3QixJQUFJLE9BQU8sU0FBUztBQUFBLElBQ3RCO0FBQUE7QUFBQSxFQUdGLFNBQVMsTUFBTSxDQUFDLE1BQXlCO0FBQUEsSUFDdkMsTUFBTSxTQUFTLEtBQUssSUFBSTtBQUFBLElBQ3hCLE1BQU0sUUFBbUIsQ0FBQztBQUFBLElBQzFCLE1BQU0sVUFBcUIsQ0FBQztBQUFBLElBQzVCLE1BQU0sUUFBUSxPQUFPLFlBQVk7QUFBQSxJQUNqQyxXQUFXLE1BQU0sWUFBWSxHQUFHO0FBQUEsTUFDOUIsSUFBSSxHQUFHLFFBQVEsbURBQW1EO0FBQUEsUUFBRztBQUFBLE1BQ3JFLE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSTtBQUFBLE1BRWxDLElBQUksRUFBRSxjQUFjLHFCQUFxQixLQUFLLEdBQUcsV0FBVyxFQUFFLFNBQVM7QUFBQSxRQUFPO0FBQUEsTUFDOUUsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLE1BQ25CLElBQUksQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUFBLFFBQU87QUFBQSxNQUM1QixJQUFJLE1BQU07QUFBQSxRQUFRLE1BQU0sS0FBSyxFQUFFO0FBQUEsTUFDMUIsU0FBSSxFQUFFLFlBQVksRUFBRSxTQUFTLEtBQUs7QUFBQSxRQUFHLFFBQVEsS0FBSyxFQUFFO0FBQUEsSUFDM0Q7QUFBQSxJQUNBLE1BQU0sT0FBTyxNQUFNLFNBQVMsUUFBUTtBQUFBLElBRXBDLE1BQU0sVUFBVSxLQUFLLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLENBQUMsTUFBTSxNQUFNLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQUEsSUFDakYsT0FBTyxPQUFPLFFBQVEsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLFNBQVMsS0FBSyxFQUFFLENBQUM7QUFBQTtBQUFBLEVBR2hFLFNBQVMsT0FBTyxDQUFDLE1BQXlCO0FBQUEsSUFDeEMsTUFBTSxTQUFTLEtBQUssSUFBSSxFQUFFLFlBQVk7QUFBQSxJQUN0QyxNQUFNLE1BQWlCLENBQUM7QUFBQSxJQUN4QixXQUFXLFNBQVMsU0FBUyxpQkFBaUIsT0FBTyxHQUFHO0FBQUEsTUFDdEQsSUFBSSxLQUFLLE1BQU0sU0FBUyxFQUFFLFlBQVksRUFBRSxRQUFRLFVBQVUsRUFBRSxNQUFNLFVBQVUsTUFBTTtBQUFBLFFBQVMsSUFBSSxLQUFLLE1BQU0sT0FBTztBQUFBLElBQ25IO0FBQUEsSUFDQSxXQUFXLE1BQU0sU0FBUyxpQkFBaUIsVUFBVSxtQ0FBbUMsR0FBRztBQUFBLE1BQ3pGLElBQUksS0FBSyxHQUFHLGFBQWEsWUFBWSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsUUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQzdFLE1BQU0sS0FBSyxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsTUFDNUMsSUFBSSxJQUFJO0FBQUEsUUFDTixNQUFNLElBQUksR0FDUCxNQUFNLEtBQUssRUFDWCxJQUFJLENBQUMsT0FBTyxTQUFTLGVBQWUsRUFBRSxHQUFHLGFBQWEsRUFBRSxFQUN4RCxLQUFLLEdBQUc7QUFBQSxRQUNYLElBQUksS0FBSyxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ25EO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxDQUFDLElBQUksUUFBUTtBQUFBLE1BQ2YsV0FBVyxNQUFNLFNBQVMsaUJBQWlCLGVBQWUsR0FBRztBQUFBLFFBQzNELElBQUksS0FBSyxHQUFHLGFBQWEsYUFBYSxDQUFDLEVBQUUsWUFBWSxNQUFNO0FBQUEsVUFBUSxJQUFJLEtBQUssRUFBRTtBQUFBLE1BQ2hGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLEdBQUc7QUFBQTtBQUFBLEVBR25CLFNBQVMsT0FBTyxDQUFDLElBQXVCO0FBQUEsSUFDdEMsTUFBTSxNQUFNLFNBQVMsU0FBUyxJQUFJLFVBQVUsTUFBTSxZQUFZLDRCQUE0QixJQUFJO0FBQUEsSUFDOUYsTUFBTSxNQUFpQixDQUFDO0FBQUEsSUFDeEIsU0FBUyxJQUFJLEVBQUcsSUFBSSxJQUFJLGdCQUFnQixLQUFLO0FBQUEsTUFDM0MsTUFBTSxJQUFJLElBQUksYUFBYSxDQUFDO0FBQUEsTUFDNUIsSUFBSSxhQUFhO0FBQUEsUUFBUyxJQUFJLEtBQUssQ0FBQztBQUFBLElBQ3RDO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsTUFBUyxDQUFDLEtBQWU7QUFBQSxJQUNoQyxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksR0FBRyxDQUFDO0FBQUE7QUFBQSxFQUlsQixTQUFTLFVBQVUsQ0FBQyxVQUE2QjtBQUFBLElBQ3RELElBQUk7QUFBQSxNQUNGLElBQUksU0FBUyxXQUFXLE9BQU87QUFBQSxRQUFHLE9BQU8sT0FBTyxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzFFLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxRQUFRLFNBQVMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUFBLE1BQzVFLElBQUksU0FBUyxXQUFXLFFBQVE7QUFBQSxRQUFHLE9BQU8sUUFBUSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0FBQUEsTUFDbkUsSUFBSSxTQUFTLFdBQVcsUUFBUSxHQUFHO0FBQUEsUUFFakMsTUFBTSxJQUFJLFNBQVMsaUJBQWlCLGVBQWUsRUFBRSxPQUFPLFNBQVMsTUFBTSxDQUFDLENBQUM7QUFBQSxRQUM3RSxPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUFBLE1BQ3BCO0FBQUEsTUFDQSxPQUFPLENBQUMsR0FBRyxTQUFTLGlCQUFpQixRQUFRLENBQUM7QUFBQSxNQUM5QyxNQUFNO0FBQUEsTUFDTixPQUFPLENBQUM7QUFBQTtBQUFBO0FBQUEsRUFJWixTQUFTLE9BQU8sQ0FBQyxHQUFtQjtBQUFBLElBQ2xDLE1BQU0sSUFBSSxFQUFFLEtBQUs7QUFBQSxJQUNqQixJQUFLLEVBQUUsV0FBVyxHQUFHLEtBQUssRUFBRSxTQUFTLEdBQUcsS0FBTyxFQUFFLFdBQVcsR0FBRyxLQUFLLEVBQUUsU0FBUyxHQUFHO0FBQUEsTUFBSSxPQUFPLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQSxJQUMxRyxPQUFPO0FBQUE7QUFBQSxFQUlGLFNBQVMsT0FBTyxDQUFDLFdBQStEO0FBQUEsSUFDckYsV0FBVyxPQUFPLFdBQVc7QUFBQSxNQUMzQixNQUFNLFFBQVEsV0FBVyxHQUFHO0FBQUEsTUFDNUIsSUFBSSxNQUFNLFdBQVc7QUFBQSxRQUFHLE9BQU8sRUFBRSxJQUFJLE1BQU0sSUFBSyxVQUFVLElBQUk7QUFBQSxNQUM5RCxNQUFNLE1BQU0sTUFBTSxPQUFPLFNBQVM7QUFBQSxNQUNsQyxJQUFJLElBQUksVUFBVTtBQUFBLFFBQUcsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFLLFVBQVUsSUFBSTtBQUFBLE1BQ3pELElBQUksTUFBTTtBQUFBLFFBQVEsT0FBTyxFQUFFLElBQUksTUFBTSxJQUFLLFVBQVUsSUFBSTtBQUFBLElBQzFEO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUtULFNBQVMsUUFBUSxDQUFDLEtBQWEsSUFBc0I7QUFBQSxJQUNuRCxNQUFNLElBQUksV0FBVyxHQUFHO0FBQUEsSUFDeEIsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLE9BQU87QUFBQTtBQUFBLEVBR3BDLFNBQVMsT0FBTyxDQUFDLElBQXFCO0FBQUEsSUFDcEMsTUFBTSxRQUFrQixDQUFDO0FBQUEsSUFDekIsSUFBSSxNQUFzQjtBQUFBLElBQzFCLE9BQU8sT0FBTyxRQUFRLFNBQVMsaUJBQWlCO0FBQUEsTUFDOUMsTUFBTSxNQUFNLElBQUksUUFBUSxZQUFZO0FBQUEsTUFDcEMsSUFBSSxRQUFRLE1BQU0sSUFBSSxNQUFNLENBQUMsZUFBZSxJQUFJLEVBQUUsR0FBRztBQUFBLFFBQ25ELE1BQU0sUUFBUSxNQUFNLElBQUksT0FBTyxJQUFJLEVBQUUsQ0FBQztBQUFBLFFBQ3RDLE1BQU0sSUFBSSxNQUFNLEtBQUssS0FBSztBQUFBLFFBQzFCLElBQUksU0FBUyxHQUFHLEVBQUU7QUFBQSxVQUFHLE9BQU87QUFBQSxRQUM1QixNQUFNLE1BQU07QUFBQSxNQUNkO0FBQUEsTUFDQSxJQUFJLE1BQU07QUFBQSxNQUNWLE1BQU0sTUFBTSxjQUFjLEdBQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQztBQUFBLE1BQ3pDLElBQUksSUFBSTtBQUFBLFFBQVEsT0FBTyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRztBQUFBLE1BRW5FLE1BQU0sYUFBYSxDQUFDLEtBQUssR0FBRyxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsTUFDN0MsSUFBSSxTQUFTLFlBQVksRUFBRTtBQUFBLFFBQUcsT0FBTztBQUFBLE1BRXJDLE1BQU0sU0FBeUIsSUFBSTtBQUFBLE1BQ25DLElBQUksUUFBUTtBQUFBLFFBQ1YsTUFBTSxPQUFPLENBQUMsR0FBRyxPQUFPLFFBQVEsRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLFlBQVksSUFBSyxPQUFPO0FBQUEsUUFDMUUsSUFBSSxLQUFLLFNBQVM7QUFBQSxVQUFHLE9BQU8sZ0JBQWdCLEtBQUssUUFBUSxHQUFHLElBQUk7QUFBQSxNQUNsRTtBQUFBLE1BQ0EsTUFBTSxRQUFRLEdBQUc7QUFBQSxNQUNqQixNQUFNLElBQUksTUFBTSxLQUFLLEtBQUs7QUFBQSxNQUMxQixJQUFJLFNBQVMsR0FBRyxFQUFFO0FBQUEsUUFBRyxPQUFPO0FBQUEsTUFDNUIsTUFBTTtBQUFBLElBQ1I7QUFBQSxJQUNBLE9BQU8sTUFBTSxLQUFLLEtBQUs7QUFBQTtBQUFBLEVBSWxCLFNBQVMsY0FBYyxDQUFDLElBQXVCO0FBQUEsSUFDcEQsTUFBTSxNQUFNLEdBQUcsUUFBUSxZQUFZO0FBQUEsSUFDbkMsTUFBTSxJQUFjLENBQUM7QUFBQSxJQUVyQixXQUFXLEtBQUssWUFBWTtBQUFBLE1BQzFCLE1BQU0sSUFBSSxHQUFHLGFBQWEsQ0FBQztBQUFBLE1BQzNCLElBQUk7QUFBQSxRQUFHLEVBQUUsS0FBSyxJQUFJLEtBQUssRUFBRSxDQUFDLElBQUk7QUFBQSxJQUNoQztBQUFBLElBQ0EsSUFBSSxHQUFHLE1BQU0sQ0FBQyxlQUFlLEdBQUcsRUFBRTtBQUFBLE1BQUcsRUFBRSxLQUFLLE1BQU0sSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO0FBQUEsSUFFbkUsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsSUFDbkMsSUFBSSxNQUFNO0FBQUEsTUFDUixJQUFJLGNBQWMscUJBQXFCLEdBQUcsU0FBUyxXQUFXLEdBQUcsU0FBUyxlQUFlLEdBQUcsU0FBUyxHQUFHLFVBQVUsTUFBTTtBQUFBLFFBQ3RILEVBQUUsS0FBSyxHQUFHLFlBQVksRUFBRSxJQUFJLFlBQVksRUFBRSxHQUFHLEtBQUssSUFBSTtBQUFBLE1BQ3hELEVBQU87QUFBQSxVQUFFLEtBQUssR0FBRyxZQUFZLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDekM7QUFBQSxJQUVBLE1BQU0sWUFBWSxHQUFHLFFBQVEsT0FBTztBQUFBLElBQ3BDLElBQUksV0FBVztBQUFBLE1BQ2IsTUFBTSxNQUFNLFVBQVUsRUFBRTtBQUFBLE1BQ3hCLElBQUksT0FBTyxJQUFJLFVBQVU7QUFBQSxRQUFJLEVBQUUsS0FBSyxTQUFTLEtBQUs7QUFBQSxJQUNwRDtBQUFBLElBRUEsTUFBTSxPQUFPLEdBQUcsYUFBYSxZQUFZO0FBQUEsSUFDekMsSUFBSTtBQUFBLE1BQU0sRUFBRSxLQUFLLEdBQUcsa0JBQWtCLEVBQUUsSUFBSSxJQUFJO0FBQUEsSUFDaEQsTUFBTSxLQUFLLEdBQUcsYUFBYSxhQUFhO0FBQUEsSUFDeEMsSUFBSTtBQUFBLE1BQUksRUFBRSxLQUFLLEdBQUcsbUJBQW1CLEVBQUUsRUFBRSxJQUFJO0FBQUEsSUFFN0MsSUFBSSxDQUFDLFdBQVc7QUFBQSxNQUNkLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxNQUNuQixJQUFJLEtBQUssRUFBRSxVQUFVLE1BQU0sQ0FBQyxHQUFHLGNBQWMsT0FBTztBQUFBLFFBQUcsRUFBRSxLQUFLLFFBQVEsR0FBRztBQUFBLElBQzNFO0FBQUEsSUFFQSxJQUFJLGNBQWMsbUJBQW1CO0FBQUEsTUFDbkMsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsTUFDbkMsSUFBSSxRQUFRLEtBQUssU0FBUyxNQUFNLENBQUMsS0FBSyxXQUFXLGFBQWEsS0FBSyxTQUFTO0FBQUEsUUFBSyxFQUFFLEtBQUssVUFBVSxFQUFFLElBQUksSUFBSTtBQUFBLElBQzlHO0FBQUEsSUFDQSxJQUFJLGNBQWMscUJBQXFCLGNBQWMsa0JBQWtCO0FBQUEsTUFDckUsTUFBTSxNQUFNLEdBQUcsYUFBYSxLQUFLO0FBQUEsTUFDakMsSUFBSSxPQUFPLENBQUMsSUFBSSxXQUFXLE9BQU8sS0FBSyxDQUFDLElBQUksV0FBVyxhQUFhLEdBQUc7QUFBQSxRQUVyRSxNQUFNLE9BQU8sSUFBSSxNQUFNLE1BQU0sRUFBRTtBQUFBLFFBQy9CLEVBQUUsS0FBSyxTQUFTLE1BQU0sR0FBRyxXQUFXLEVBQUUsR0FBRyxPQUFPLEdBQUcsWUFBWSxFQUFFLElBQUksSUFBSTtBQUFBLE1BQzNFO0FBQUEsSUFDRjtBQUFBLElBQ0EsTUFBTSxRQUFRLEdBQUcsYUFBYSxPQUFPO0FBQUEsSUFDckMsSUFBSTtBQUFBLE1BQU8sRUFBRSxLQUFLLEdBQUcsYUFBYSxFQUFFLEtBQUssSUFBSTtBQUFBLElBRzdDLE1BQU0sYUFBYSxDQUFDLE1BQWM7QUFBQSxNQUNoQyxNQUFNLElBQUksV0FBVyxDQUFDO0FBQUEsTUFDdEIsT0FBTyxFQUFFLFdBQVcsTUFBTSxFQUFFLE9BQU8sTUFBTyxFQUFFLFdBQVcsT0FBTyxLQUFLLEdBQUcsU0FBUyxFQUFFLEVBQUcsS0FBSyxPQUFPLEVBQUUsRUFBRyxNQUFNLE9BQU8sRUFBRTtBQUFBO0FBQUEsSUFFdEgsTUFBTSxTQUFTLE9BQU8sQ0FBQyxFQUFFLE9BQU8sVUFBVTtBQUFBLElBQzFDLE9BQU8sS0FBSyxRQUFRLEVBQUUsQ0FBQztBQUFBLElBQ3ZCLE9BQU8sT0FBTyxNQUFNLEVBQUUsTUFBTSxHQUFHLENBQUM7QUFBQTtBQUFBLEVBSzNCLFNBQVMsU0FBUyxDQUFDLElBQXFCO0FBQUEsSUFDN0MsSUFBSyxHQUF3QixRQUFRLFFBQVE7QUFBQSxNQUMzQyxNQUFNLElBQUksS0FBTSxHQUF3QixPQUFRLEdBQUksU0FBUyxFQUFFLFFBQVEsVUFBVSxFQUFFO0FBQUEsTUFDbkYsSUFBSTtBQUFBLFFBQUcsT0FBTztBQUFBLElBQ2hCO0FBQUEsSUFDQSxNQUFNLE9BQU8sR0FBRyxhQUFhLFlBQVk7QUFBQSxJQUN6QyxJQUFJO0FBQUEsTUFBTSxPQUFPLEtBQUssSUFBSTtBQUFBLElBQzFCLE1BQU0sS0FBSyxHQUFHLGFBQWEsaUJBQWlCO0FBQUEsSUFDNUMsSUFBSSxJQUFJO0FBQUEsTUFDTixNQUFNLElBQUksS0FBSyxHQUFHLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQyxPQUFPLFNBQVMsZUFBZSxFQUFFLEdBQUcsYUFBYSxFQUFFLEVBQUUsS0FBSyxHQUFHLENBQUM7QUFBQSxNQUNsRyxJQUFJO0FBQUEsUUFBRyxPQUFPO0FBQUEsSUFDaEI7QUFBQSxJQUNBLE9BQU87QUFBQTtBQUFBLEVBSUYsU0FBUyxRQUFRLENBQUMsSUFBcUI7QUFBQSxJQUM1QyxJQUFJLEdBQUcsUUFBUSxPQUFPLEdBQUc7QUFBQSxNQUN2QixRQUNFLFVBQVUsRUFBRSxLQUNaLEdBQUcsYUFBYSxhQUFhLEtBQzdCLEdBQUcsYUFBYSxNQUFNLEtBQ3RCLEdBQUcsTUFDSCxHQUFHLGFBQWEsT0FBTyxLQUN2QixHQUFHLFFBQVEsWUFBWSxHQUN2QixNQUFNLEdBQUcsRUFBRTtBQUFBLElBQ2Y7QUFBQSxJQUNBLE1BQU0sSUFBSSxPQUFPLEVBQUU7QUFBQSxJQUNuQixJQUFJO0FBQUEsTUFBRyxPQUFPLEVBQUUsU0FBUyxLQUFLLEVBQUUsTUFBTSxHQUFHLEVBQUUsSUFBSSxNQUFNO0FBQUEsSUFDckQsUUFDRSxHQUFHLGFBQWEsWUFBWSxLQUM1QixHQUFHLGFBQWEsT0FBTyxLQUN2QixHQUFHLGNBQWMsS0FBSyxHQUFHLGFBQWEsS0FBSyxLQUMzQyxHQUFHLGFBQWEsTUFBTSxLQUN0QixHQUFHLFFBQVEsWUFBWSxHQUN2QixNQUFNLEdBQUcsRUFBRTtBQUFBO0FBQUEsRUFJUixTQUFTLFVBQVUsQ0FBQyxRQUEwQjtBQUFBLElBQ25ELE1BQU0sT0FBTyxPQUFPLFFBQVEsT0FBTztBQUFBLElBQ25DLElBQUk7QUFBQSxNQUFNLE9BQU87QUFBQSxJQUNqQixNQUFNLFlBQVksT0FBTyxRQUFRLFNBQVM7QUFBQSxJQUMxQyxJQUFJLHFCQUFxQixvQkFBb0IsVUFBVTtBQUFBLE1BQVMsT0FBTyxVQUFVO0FBQUEsSUFDakYsT0FBTyxhQUFhO0FBQUE7QUFBQSxFQUd0QixJQUFNLFdBQVcsSUFBSSxJQUFJO0FBQUEsSUFDdkI7QUFBQSxJQUFJO0FBQUEsSUFBUTtBQUFBLElBQVM7QUFBQSxJQUFZO0FBQUEsSUFBVTtBQUFBLElBQU87QUFBQSxJQUFPO0FBQUEsSUFDekQ7QUFBQSxJQUFRO0FBQUEsSUFBa0I7QUFBQSxJQUFTO0FBQUEsSUFBUTtBQUFBLElBQVE7QUFBQSxJQUFTO0FBQUEsRUFDOUQsQ0FBQztBQUFBLEVBSU0sU0FBUyxNQUFNLENBQUMsSUFBeUI7QUFBQSxJQUM5QyxJQUFJLGNBQWM7QUFBQSxNQUFtQixPQUFPO0FBQUEsSUFDNUMsSUFBSSxjQUFjO0FBQUEsTUFBcUIsT0FBTyxHQUFHLFdBQVcsVUFBVTtBQUFBLElBQ3RFLElBQUksY0FBYyxrQkFBa0I7QUFBQSxNQUNsQyxJQUFJLEdBQUcsU0FBUyxjQUFjLEdBQUcsU0FBUztBQUFBLFFBQVMsT0FBTztBQUFBLE1BQzFELElBQUksR0FBRyxTQUFTO0FBQUEsUUFBUSxPQUFPO0FBQUEsTUFFL0IsSUFBSSxTQUFTLElBQUksR0FBRyxJQUFJO0FBQUEsUUFBRyxPQUFPLEdBQUcsV0FBVyxVQUFVO0FBQUEsTUFDMUQsT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUssR0FBbUI7QUFBQSxNQUFtQixPQUFPO0FBQUEsSUFDbEQsTUFBTSxPQUFPLEdBQUcsYUFBYSxNQUFNO0FBQUEsSUFDbkMsSUFBSSxTQUFTLGNBQWMsU0FBUztBQUFBLE1BQVUsT0FBTztBQUFBLElBQ3JELE9BQU87QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsSUFBcUI7QUFBQSxJQUMzQyxJQUFJLGNBQWMsb0JBQW9CLGNBQWMsdUJBQXVCLGNBQWM7QUFBQSxNQUFtQixPQUFPLEdBQUc7QUFBQSxJQUN0SCxPQUFPLEtBQU0sR0FBbUIsU0FBUztBQUFBO0FBQUEsRUFHcEMsU0FBUyxTQUFTLENBQUMsSUFBc0I7QUFBQSxJQUM5QyxJQUFJLGNBQWM7QUFBQSxNQUFrQixPQUFPLEdBQUc7QUFBQSxJQUM5QyxPQUFPLEdBQUcsYUFBYSxjQUFjLE1BQU07QUFBQTs7O0VDalU3QyxNQUFNLGtCQUFrQixNQUFNO0FBQUEsRUFBQztBQUFBLEVBRy9CLGVBQWUsSUFBSSxDQUFDLE1BQVksU0FBaUIsZ0JBQXFFO0FBQUEsSUFDcEgsTUFBTSxZQUFZLENBQUMsS0FBSyxVQUFVLEdBQUksS0FBSyxhQUFhLENBQUMsQ0FBRSxFQUFFLE9BQU8sT0FBTztBQUFBLElBQzNFLElBQUksQ0FBQyxVQUFVO0FBQUEsTUFBUSxNQUFNLElBQUksVUFBVSwyQkFBMkI7QUFBQSxJQUN0RSxNQUFNLFFBQVEsWUFBWSxJQUFJO0FBQUEsSUFDOUIsSUFBSSxjQUFjO0FBQUEsSUFDbEIsT0FBTyxNQUFNO0FBQUEsTUFDWCxNQUFNLElBQUksUUFBUSxTQUFTO0FBQUEsTUFDM0IsSUFBSSxHQUFHO0FBQUEsUUFDTCxJQUFJLFVBQVUsRUFBRSxFQUFFO0FBQUEsVUFBRyxPQUFPO0FBQUEsUUFFNUIsSUFBSSxDQUFDLGdCQUFnQjtBQUFBLFVBQ25CLGdCQUFnQixZQUFZLElBQUk7QUFBQSxVQUNoQyxJQUFJLFlBQVksSUFBSSxJQUFJLGNBQWM7QUFBQSxZQUFNLE9BQU87QUFBQSxRQUNyRDtBQUFBLE1BQ0Y7QUFBQSxNQUNBLElBQUksWUFBWSxJQUFJLElBQUksUUFBUSxTQUFTO0FBQUEsUUFDdkMsSUFBSTtBQUFBLFVBQUcsTUFBTSxJQUFJLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxVQUFVLCtCQUErQjtBQUFBLFFBQ2xHLE1BQU0sSUFBSSxVQUFVLG1CQUFtQixLQUFLLFNBQVMsVUFBVSxRQUFRLFVBQVUsS0FBSztBQUFBLE1BQ3hGO0FBQUEsTUFDQSxNQUFNLE1BQU0sR0FBRztBQUFBLElBQ2pCO0FBQUE7QUFBQSxFQUdGLFNBQVMsTUFBTSxDQUFDLElBQWE7QUFBQSxJQUMzQixNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxJQUNuQyxPQUFPLEVBQUUsR0FBRyxFQUFFLE9BQU8sRUFBRSxRQUFRLEdBQUcsR0FBRyxFQUFFLE1BQU0sRUFBRSxTQUFTLEVBQUU7QUFBQTtBQUFBLEVBRzVELGVBQWUsUUFBUSxDQUFDLElBQWE7QUFBQSxJQUNuQyxNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxJQUNuQyxJQUFJLEVBQUUsTUFBTSxLQUFLLEVBQUUsU0FBUyxlQUFlLEVBQUUsT0FBTyxLQUFLLEVBQUUsUUFBUSxZQUFZO0FBQUEsTUFDN0UsR0FBRyxlQUFlLEVBQUUsT0FBTyxVQUFVLFFBQVEsVUFBVSxVQUFVLFVBQTRCLENBQUM7QUFBQSxNQUM5RixNQUFNLE1BQU0sRUFBRTtBQUFBLElBQ2hCO0FBQUE7QUFBQSxFQUdGLFNBQVMsS0FBSyxDQUFDLFFBQWlCLE1BQWMsR0FBVyxHQUFXO0FBQUEsSUFDbEUsTUFBTSxPQUF5QjtBQUFBLE1BQzdCLFNBQVM7QUFBQSxNQUFNLFlBQVk7QUFBQSxNQUFNLFVBQVU7QUFBQSxNQUFNLE1BQU07QUFBQSxNQUN2RCxTQUFTO0FBQUEsTUFBRyxTQUFTO0FBQUEsTUFBRyxTQUFTLElBQUk7QUFBQSxNQUFTLFNBQVMsSUFBSTtBQUFBLE1BQzNELFFBQVE7QUFBQSxNQUFHLFNBQVMsS0FBSyxTQUFTLE1BQU0sSUFBSSxJQUFJO0FBQUEsTUFBRyxXQUFXO0FBQUEsTUFBRyxhQUFhO0FBQUEsTUFBUyxXQUFXO0FBQUEsSUFDcEc7QUFBQSxJQUNBLE1BQU0sT0FBTyxLQUFLLFdBQVcsU0FBUyxJQUFJLGVBQWU7QUFBQSxJQUN6RCxPQUFPLE9BQU8sY0FBYyxJQUFJLEtBQUssTUFBTSxJQUFJLENBQUM7QUFBQTtBQUFBLEVBR2xELGVBQWUsU0FBUyxDQUFDLElBQWE7QUFBQSxJQUNwQyxNQUFNLFNBQVMsRUFBRTtBQUFBLElBQ2pCLFFBQVEsR0FBRyxNQUFNLE9BQU8sRUFBRTtBQUFBLElBRTFCLE1BQU0sTUFBTSxTQUFTLGlCQUFpQixHQUFHLENBQUM7QUFBQSxJQUMxQyxNQUFNLFNBQVMsT0FBTyxHQUFHLFNBQVMsR0FBRyxJQUFJLE1BQU07QUFBQSxJQUMvQyxNQUFNLFFBQVEsZUFBZSxHQUFHLENBQUM7QUFBQSxJQUNqQyxNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUMvQixNQUFNLFFBQVEsZUFBZSxHQUFHLENBQUM7QUFBQSxJQUNqQyxNQUFNLFFBQVEsYUFBYSxHQUFHLENBQUM7QUFBQSxJQUMvQixNQUFNLE9BQU8sTUFBTSxRQUFRLGVBQWUsR0FBRyxDQUFDLEtBQUssTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDbEYsSUFBSSxRQUFRLGNBQWMsZUFBZSxHQUFHLFlBQVk7QUFBQSxNQUFJLEdBQUcsTUFBTSxFQUFFLGVBQWUsS0FBSyxDQUFDO0FBQUEsSUFDNUYsTUFBTSxRQUFRLGFBQWEsR0FBRyxDQUFDO0FBQUEsSUFDL0IsTUFBTSxRQUFRLFdBQVcsR0FBRyxDQUFDO0FBQUEsSUFFN0IsTUFBTSxRQUFRLFNBQVMsR0FBRyxDQUFDO0FBQUE7QUFBQSxFQUc3QixJQUFNLFlBQVksSUFBSSxJQUFJLENBQUMsUUFBUSxrQkFBa0IsU0FBUyxRQUFRLFFBQVEsU0FBUyxPQUFPLENBQUM7QUFBQSxFQUUvRixTQUFTLFNBQVMsQ0FBQyxJQUE0QyxHQUFXO0FBQUEsSUFHeEUsTUFBTSxRQUFRLGNBQWMsc0JBQXNCLG9CQUFvQixZQUFZLGlCQUFpQjtBQUFBLElBQ25HLE9BQU8seUJBQXlCLE9BQU8sT0FBTyxFQUFHLElBQUssS0FBSyxJQUFJLENBQUM7QUFBQTtBQUFBLEVBR2xFLFNBQVMsU0FBUyxDQUFDLElBQWEsTUFBcUIsWUFBWSxjQUFjO0FBQUEsSUFDN0UsR0FBRyxjQUFjLElBQUksV0FBVyxTQUFTLEVBQUUsU0FBUyxNQUFNLFVBQVUsTUFBTSxNQUFNLFVBQVUsQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUc5RixTQUFTLEdBQUcsQ0FBQyxJQUFhLE1BQXdDLEdBQVc7QUFBQSxJQUMzRSxPQUFPLEdBQUcsY0FDUixJQUFJLGNBQWMsTUFBTSxFQUFFLEtBQUssR0FBRyxNQUFNLFFBQVEsQ0FBQyxHQUFHLFNBQVMsTUFBTSxZQUFZLE1BQU0sVUFBVSxLQUFLLENBQUMsQ0FDdkc7QUFBQTtBQUFBLEVBR0YsU0FBUyxPQUFPLENBQUMsR0FBbUI7QUFBQSxJQUNsQyxJQUFJLEVBQUUsV0FBVyxHQUFHO0FBQUEsTUFDbEIsSUFBSSxTQUFTLEtBQUssQ0FBQztBQUFBLFFBQUcsT0FBTyxRQUFRLEVBQUUsWUFBWTtBQUFBLE1BQ25ELElBQUksS0FBSyxLQUFLLENBQUM7QUFBQSxRQUFHLE9BQU8sVUFBVTtBQUFBLE1BQ25DLElBQUksTUFBTTtBQUFBLFFBQUssT0FBTztBQUFBLE1BQ3RCLE9BQU87QUFBQSxJQUNUO0FBQUEsSUFDQSxPQUFPO0FBQUE7QUFBQSxFQUdULFNBQVMsU0FBUyxDQUFDLElBQTRDO0FBQUEsSUFDN0QsSUFBSTtBQUFBLE1BQ0YsR0FBRyxPQUFPO0FBQUEsTUFDVixNQUFNO0FBQUE7QUFBQSxFQUtWLGVBQWUsUUFBUSxDQUFDLElBQWEsT0FBZSxHQUFhO0FBQUEsSUFDL0QsTUFBTSxTQUFTLEVBQUU7QUFBQSxJQUNoQixHQUFtQixNQUFNLEVBQUUsZUFBZSxLQUFLLENBQUM7QUFBQSxJQUVqRCxJQUFLLEdBQW1CLG1CQUFtQjtBQUFBLE1BQ3pDLFNBQVMsWUFBWSxXQUFXO0FBQUEsTUFDaEMsSUFBSTtBQUFBLFFBQU8sU0FBUyxZQUFZLGNBQWMsT0FBTyxLQUFLO0FBQUEsTUFDckQ7QUFBQSxpQkFBUyxZQUFZLFFBQVE7QUFBQSxNQUNsQyxJQUFJLE9BQU8sRUFBRSxNQUFNLE1BQU0sUUFBUSxRQUFRLEdBQUcsRUFBRSxLQUFLLEdBQUc7QUFBQSxRQUNwRCxHQUFHLGNBQWM7QUFBQSxRQUNqQixVQUFVLElBQUksS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUVBLElBQUksRUFBRSxjQUFjLG9CQUFvQixjQUFjO0FBQUEsTUFBc0IsTUFBTSxJQUFJLFVBQVUsNEJBQTRCO0FBQUEsSUFDNUgsSUFBSSxHQUFHO0FBQUEsTUFBVSxNQUFNLElBQUksVUFBVSxJQUFJLEdBQUcsUUFBUSxHQUFHLHdCQUF3QjtBQUFBLElBRS9FLE1BQU0sV0FBVyxFQUFFLGNBQWMsb0JBQW9CLFVBQVUsSUFBSSxHQUFHLElBQUk7QUFBQSxJQUUxRSxJQUFJLENBQUMsWUFBWSxFQUFFLGFBQWEsV0FBVztBQUFBLE1BQ3pDLFVBQVUsRUFBRTtBQUFBLE1BQ1osTUFBTSxLQUFLLGFBQWEsUUFBUSxTQUFTLFlBQVksY0FBYyxPQUFPLEtBQUssSUFBSSxTQUFTLFlBQVksUUFBUTtBQUFBLE1BQ2hILElBQUksQ0FBQyxNQUFNLEdBQUcsVUFBVSxPQUFPO0FBQUEsUUFDN0IsVUFBVSxJQUFJLEtBQUs7QUFBQSxRQUNuQixVQUFVLElBQUksS0FBSztBQUFBLE1BQ3JCO0FBQUEsSUFDRixFQUFPO0FBQUEsTUFFTCxVQUFVLEVBQUU7QUFBQSxNQUNaLElBQUksQ0FBQyxTQUFTLFlBQVksUUFBUSxLQUFLLEdBQUcsVUFBVSxJQUFJO0FBQUEsUUFDdEQsVUFBVSxJQUFJLEVBQUU7QUFBQSxRQUNoQixVQUFVLElBQUksTUFBTSx1QkFBdUI7QUFBQSxNQUM3QztBQUFBLE1BQ0EsV0FBVyxNQUFNLE9BQU87QUFBQSxRQUN0QixNQUFNLFVBQVUsSUFBSSxJQUFJLFdBQVcsRUFBRTtBQUFBLFFBQ3JDLElBQUksSUFBSSxZQUFZLEVBQUU7QUFBQSxRQUN0QixJQUFJLFNBQVM7QUFBQSxVQUNYLE1BQU0sU0FBUyxHQUFHO0FBQUEsVUFDbEIsSUFBSSxDQUFDLFNBQVMsWUFBWSxjQUFjLE9BQU8sRUFBRSxLQUFLLEdBQUcsVUFBVSxRQUFRO0FBQUEsWUFDekUsVUFBVSxJQUFJLFNBQVMsRUFBRTtBQUFBLFlBQ3pCLFVBQVUsSUFBSSxFQUFFO0FBQUEsVUFDbEI7QUFBQSxRQUNGO0FBQUEsUUFDQSxJQUFJLElBQUksU0FBUyxFQUFFO0FBQUEsUUFDbkIsSUFBSSxFQUFFO0FBQUEsVUFBVSxNQUFNLE1BQU0sRUFBRSxRQUFRO0FBQUEsTUFDeEM7QUFBQTtBQUFBLElBRUYsR0FBRyxjQUFjLElBQUksTUFBTSxVQUFVLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBO0FBQUEsRUFHekQsU0FBUyxZQUFZLENBQUMsSUFBYSxPQUFlLFlBQXFCO0FBQUEsSUFDckUsSUFBSSxFQUFFLGNBQWM7QUFBQSxNQUFvQixNQUFNLElBQUksVUFBVSwrQkFBK0I7QUFBQSxJQUMzRixNQUFNLE9BQU8sQ0FBQyxHQUFHLEdBQUcsT0FBTztBQUFBLElBQzNCLE1BQU0sTUFDSixLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBVSxLQUFLLE1BQ2pDLGFBQWEsS0FBSyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssS0FBSyxNQUFNLFVBQVUsSUFBSSxjQUMvRCxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUN4QyxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxLQUFLLEVBQUUsWUFBWSxFQUFFLFNBQVMsTUFBTSxZQUFZLENBQUMsQ0FBQztBQUFBLElBQzVFLElBQUksQ0FBQztBQUFBLE1BQUssTUFBTSxJQUFJLFVBQVUsaUNBQWlDLGNBQWMsUUFBUTtBQUFBLElBQ3JGLEdBQUcsTUFBTTtBQUFBLElBQ1QsR0FBRyxRQUFRLElBQUk7QUFBQSxJQUNmLEdBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxJQUN0RCxHQUFHLGNBQWMsSUFBSSxNQUFNLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUd6RCxlQUFlLFVBQVUsQ0FBQyxJQUFhLE1BQWU7QUFBQSxJQUNwRCxJQUFJLFVBQVUsRUFBRSxNQUFNO0FBQUEsTUFBTTtBQUFBLElBQzVCLElBQUksY0FBYyxvQkFBb0IsR0FBRyxTQUFTLFdBQVcsQ0FBQyxNQUFNO0FBQUEsTUFDbEUsTUFBTSxJQUFJLFVBQVUsNkRBQTZEO0FBQUEsSUFDbkY7QUFBQSxJQUNBLElBQUksVUFBVSxFQUFFO0FBQUEsTUFBRyxNQUFNLFVBQVUsRUFBRTtBQUFBLElBQ2hDLFNBQUksY0FBYyxvQkFBb0IsR0FBRyxTQUFTLE1BQU0sVUFBVSxHQUFHLE9BQU8sRUFBRTtBQUFBLE1BQUcsTUFBTSxVQUFVLEdBQUcsT0FBTyxFQUFFO0FBQUEsSUFDN0c7QUFBQSxNQUFDLEdBQW1CLE1BQU07QUFBQSxJQUMvQixJQUFJLFVBQVUsRUFBRSxNQUFNLFFBQVEsY0FBYyxrQkFBa0I7QUFBQSxNQUM1RCxHQUFHLFVBQVU7QUFBQSxNQUNiLEdBQUcsY0FBYyxJQUFJLE1BQU0sU0FBUyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUM7QUFBQSxNQUN0RCxHQUFHLGNBQWMsSUFBSSxNQUFNLFVBQVUsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0FBQUEsSUFDekQ7QUFBQTtBQUFBLEVBR0YsSUFBTSxZQUFZO0FBQUEsRUFFbEIsZUFBZSxLQUFLLENBQUMsSUFBYSxHQUFXO0FBQUEsSUFDM0MsTUFBTSxPQUFPLElBQUksSUFBSSxXQUFXLENBQUM7QUFBQSxJQUNqQyxJQUFJLE1BQU07QUFBQSxNQUFTLElBQUksSUFBSSxZQUFZLENBQUM7QUFBQSxJQUN4QyxJQUFJLE1BQU07QUFBQSxNQUNSLElBQUksTUFBTSxTQUFTO0FBQUEsUUFDakIsSUFBSSxjQUFjLG9CQUFvQixHQUFHLE1BQU07QUFBQSxVQUU3QyxNQUFNLE1BQU0sR0FBRyxLQUFLLGNBQTJCLHNGQUFzRjtBQUFBLFVBQ3JJLElBQUk7QUFBQSxZQUFLLE1BQU0sVUFBVSxHQUFHO0FBQUEsVUFDdkI7QUFBQSxlQUFHLEtBQUssY0FBYztBQUFBLFFBQzdCLEVBQU8sU0FBSSxjQUFjLHFCQUFxQixjQUFjLG1CQUFtQjtBQUFBLFVBQzVFLEdBQW1CLE1BQU07QUFBQSxRQUM1QjtBQUFBLE1BQ0YsRUFBTyxTQUFJLE1BQU0sT0FBTztBQUFBLFFBQ3RCLE1BQU0sTUFBTSxDQUFDLEdBQUcsU0FBUyxpQkFBOEIsU0FBUyxDQUFDLEVBQUUsT0FBTyxDQUFDLE1BQU0sVUFBVSxDQUFDLEtBQUssQ0FBRSxFQUF1QixRQUFRO0FBQUEsUUFDbEksTUFBTSxJQUFJLElBQUksUUFBUSxFQUFpQjtBQUFBLFFBQ3ZDLElBQUssS0FBSSxLQUFLLElBQUksU0FBUyxNQUFNO0FBQUEsTUFDbkM7QUFBQSxJQUNGO0FBQUEsSUFDQSxJQUFJLElBQUksU0FBUyxDQUFDO0FBQUE7QUFBQSxFQUlwQixTQUFTLFdBQVcsQ0FBQyxJQUFzQjtBQUFBLElBQ3pDLElBQUksR0FBRyxRQUFRLFNBQVM7QUFBQSxNQUFHLE9BQU87QUFBQSxJQUNsQyxNQUFNLE1BQU0sR0FBRyxRQUFRLGVBQWU7QUFBQSxJQUN0QyxJQUFJLGVBQWU7QUFBQSxNQUFtQixPQUFPLENBQUMsQ0FBQyxJQUFJLFFBQVEsSUFBSSxTQUFTO0FBQUEsSUFDeEUsSUFBSSxlQUFlO0FBQUEsTUFBa0IsT0FBTyxDQUFDLENBQUMsSUFBSSxTQUFTLENBQUMsVUFBVSxPQUFPLEVBQUUsU0FBUyxJQUFJLElBQUksS0FBSyxPQUFPLEdBQUcsTUFBTTtBQUFBLElBQ3JILE9BQU87QUFBQTtBQUFBLEVBR1QsZUFBc0IsT0FBTyxDQUFDLE1BQVksR0FBa0M7QUFBQSxJQUMxRSxNQUFNLFVBQVUsS0FBSyxXQUFXLEVBQUU7QUFBQSxJQUNsQyxJQUFJLE1BQU07QUFBQSxJQUNWLElBQUk7QUFBQSxNQUNGLElBQUk7QUFBQSxNQUNKLE1BQU0sU0FBUyxPQUFPLFVBQVUsU0FBUztBQUFBLFFBQ3ZDLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTSxTQUFTLE9BQU87QUFBQSxRQUMzQyxPQUFPLEVBQUU7QUFBQSxRQUNULElBQUksRUFBRTtBQUFBLFVBQVcsUUFBUSxNQUFNLEVBQUUsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLLEVBQUUsWUFBWSxHQUFHLEdBQUcsT0FBTyxHQUFHO0FBQUEsUUFDMUcsT0FBTyxFQUFFO0FBQUE7QUFBQSxNQUdYLFFBQVEsS0FBSztBQUFBLGFBQ04sU0FBUztBQUFBLFVBQ1osTUFBTSxLQUFLLE1BQU0sT0FBTztBQUFBLFVBQ3hCLE1BQU0sWUFBWSxFQUFFO0FBQUEsVUFDcEIsTUFBTSxVQUFVLEVBQUU7QUFBQSxVQUNsQjtBQUFBLFFBQ0Y7QUFBQSxhQUNLLFFBQVE7QUFBQSxVQUVYLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSztBQUFBLFVBQzdCLElBQUksY0FBYztBQUFBLFlBQW1CLGFBQWEsSUFBSSxLQUFLLFNBQVMsRUFBRTtBQUFBLFVBQ2pFLFNBQUksT0FBTyxFQUFFLE1BQU07QUFBQSxZQUFTLE1BQU0sV0FBVyxJQUFJLENBQUMsQ0FBQyxJQUFJLFNBQVMsT0FBTyxHQUFHLEVBQUUsU0FBUyxLQUFLLFNBQVMsRUFBRSxDQUFDO0FBQUEsVUFDdEc7QUFBQSxrQkFBTSxTQUFTLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQztBQUFBLFVBQzNDO0FBQUEsUUFDRjtBQUFBLGFBQ0s7QUFBQSxVQUNILGFBQWEsTUFBTSxPQUFPLEtBQUssR0FBRyxLQUFLLFNBQVMsSUFBSSxLQUFLLFVBQVU7QUFBQSxVQUNuRTtBQUFBLGFBQ0c7QUFBQSxVQUNILE1BQU0sV0FBVyxNQUFNLE9BQU8sS0FBSyxHQUFHLEtBQUssVUFBVSxPQUFPO0FBQUEsVUFDNUQ7QUFBQSxhQUNHLFNBQVM7QUFBQSxVQUNaLE1BQU0sS0FBSyxLQUFLLFdBQVcsTUFBTSxPQUFPLEtBQUssSUFBSyxTQUFTLGlCQUFpQixTQUFTO0FBQUEsVUFDckYsT0FBTyxLQUFLLFNBQVMsYUFBYSxXQUFXLFlBQVksRUFBRTtBQUFBLFVBQzNELE1BQU0sTUFBTSxJQUFJLEtBQUssU0FBUyxPQUFPO0FBQUEsVUFDckM7QUFBQSxRQUNGO0FBQUEsYUFDSztBQUFBLFVBQ0gsTUFBTSxPQUFPO0FBQUEsVUFDYjtBQUFBLGFBQ0csY0FBYztBQUFBLFVBQ2pCLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSztBQUFBLFVBQzdCLE1BQU0sUUFBUSxLQUFLLFNBQVMsSUFBSSxLQUFLO0FBQUEsVUFFckMsTUFBTSxRQUFRLFlBQVksSUFBSTtBQUFBLFVBQzlCLElBQUksT0FBTztBQUFBLFVBQ1gsT0FBTyxNQUFNO0FBQUEsWUFDWCxPQUFPLGNBQWMsb0JBQW9CLGNBQWMsdUJBQXVCLGNBQWMsb0JBQW9CLFFBQVEsRUFBRSxJQUFJLE9BQU8sRUFBRTtBQUFBLFlBQ3ZJLElBQUksS0FBSyxTQUFTLElBQUk7QUFBQSxjQUFHO0FBQUEsWUFDekIsSUFBSSxZQUFZLElBQUksSUFBSSxRQUFRO0FBQUEsY0FBUyxNQUFNLElBQUksVUFBVSxnQkFBZ0IsZ0JBQWdCLEtBQUssTUFBTSxHQUFHLEVBQUUsSUFBSTtBQUFBLFlBQ2pILE1BQU0sTUFBTSxHQUFHO0FBQUEsVUFDakI7QUFBQSxVQUNBO0FBQUEsUUFDRjtBQUFBO0FBQUEsVUFFRSxNQUFNLElBQUksVUFBVSxpQkFBaUIsS0FBSyxrQ0FBa0M7QUFBQTtBQUFBLE1BRWhGLE9BQU8sRUFBRSxJQUFJLE1BQU0sY0FBYyxNQUFNLGFBQWEsSUFBSTtBQUFBLE1BQ3hELE9BQU8sR0FBRztBQUFBLE1BQ1YsT0FBTyxFQUFFLElBQUksT0FBTyxPQUFPLGFBQWEsUUFBUSxFQUFFLFVBQVUsT0FBTyxDQUFDLEVBQUU7QUFBQTtBQUFBO0FBQUEsRUFJMUUsZUFBc0IsU0FBUyxDQUFDLFdBQXVDO0FBQUEsSUFDckUsTUFBTSxJQUFJLFFBQVEsU0FBUztBQUFBLElBQzNCLElBQUksQ0FBQztBQUFBLE1BQUcsT0FBTztBQUFBLElBQ2YsTUFBTSxTQUFTLEVBQUUsRUFBRTtBQUFBLElBQ25CLFFBQVEsTUFBTSxFQUFFLElBQUksRUFBRSxVQUFVLE1BQU0sT0FBTyxLQUFLO0FBQUEsSUFDbEQsT0FBTztBQUFBOzs7RUMzUlQsSUFBSSxPQUFvQjtBQUFBLEVBQ3hCLElBQUksT0FBa0MsTUFBTTtBQUFBLEVBQzVDLElBQU0sY0FBYyxJQUFJO0FBQUEsRUFFeEIsSUFBTSxPQUFtQyxFQUFFLE9BQU8sU0FBUyxNQUFNLFlBQVksUUFBUSxlQUFlLE9BQU8sVUFBVSxNQUFNLFVBQVU7QUFBQSxFQUc5SCxTQUFTLE9BQU8sQ0FBQyxJQUFrQztBQUFBLElBQ3hELE1BQU0sT0FBTyxPQUFPLEVBQUU7QUFBQSxJQUN0QixJQUFJLFNBQVM7QUFBQSxNQUFRLE9BQU87QUFBQSxJQUM1QixPQUFPLGFBQWEsYUFBYSxlQUFlLEVBQUU7QUFBQSxJQUNsRCxNQUFNLE9BQU8sRUFBRSxVQUFVLFdBQVcsT0FBTyxTQUFTLEVBQUUsRUFBRTtBQUFBLElBQ3hELFFBQVE7QUFBQSxXQUNEO0FBQUEsUUFDSCxPQUFPLEtBQUssTUFBTSxNQUFNLFFBQVEsT0FBTyxRQUFRLEVBQUUsR0FBRyxRQUFTLEdBQXdCLFNBQVMsY0FBYyxVQUFVO0FBQUEsV0FDbkgsVUFBVTtBQUFBLFFBQ2IsTUFBTSxJQUFJO0FBQUEsUUFDVixPQUFPLEtBQUssTUFBTSxNQUFNLFVBQVUsT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLGdCQUFnQixJQUFJLEtBQUssS0FBSyxFQUFFO0FBQUEsTUFDbEc7QUFBQSxXQUNLO0FBQUEsUUFDSCxPQUFPLEtBQUssTUFBTSxNQUFNLFNBQVMsT0FBTyxPQUFPLFVBQVUsRUFBRSxDQUFDLEVBQUU7QUFBQTtBQUFBLFFBRTlELE9BQU8sS0FBSyxNQUFNLE1BQU0sUUFBUTtBQUFBO0FBQUE7QUFBQSxFQUl0QyxTQUFTLElBQUksQ0FBQyxJQUFhLE1BQTJCO0FBQUEsSUFDcEQsSUFBSSxDQUFDO0FBQUEsTUFBTTtBQUFBLElBQ1gsS0FBSyxJQUFJO0FBQUEsSUFDVCxNQUFNLE9BQU8sS0FBSyxTQUFTLFNBQVUsS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLLFNBQVMsSUFBSSxNQUFNLEdBQUcsRUFBRSxPQUFRO0FBQUEsSUFDdEcsUUFBUSxNQUFNLEtBQUssS0FBSyxLQUFLLFNBQXVCLEtBQUssU0FBUyxLQUFLLFNBQVMsT0FBTyxLQUFLLEdBQUcsT0FBTyxPQUFPLEVBQUUsRUFBRTtBQUFBO0FBQUEsRUFHbkgsU0FBUyxVQUFVLEdBQUc7QUFBQSxJQUNwQixZQUFZLElBQUksTUFBTSxhQUFhO0FBQUEsTUFDakMsYUFBYSxDQUFDO0FBQUEsTUFDZCxLQUFLLFFBQVEsRUFBRSxDQUFFO0FBQUEsSUFDbkI7QUFBQSxJQUNBLFlBQVksTUFBTTtBQUFBO0FBQUEsRUFHcEIsU0FBUyxZQUFZLENBQUMsSUFBYTtBQUFBLElBQ2pDLGFBQWEsWUFBWSxJQUFJLEVBQUUsQ0FBQztBQUFBLElBQ2hDLFlBQVksSUFDVixJQUNBLFdBQVcsTUFBTTtBQUFBLE1BQ2YsWUFBWSxPQUFPLEVBQUU7QUFBQSxNQUNyQixNQUFNLElBQUksUUFBUSxFQUFFO0FBQUEsTUFDcEIsSUFBSTtBQUFBLFFBQUcsS0FBSyxDQUFDO0FBQUEsT0FDWixHQUFHLENBQ1I7QUFBQTtBQUFBLEVBR0YsSUFBTSxXQUFXLENBQUMsTUFBNkI7QUFBQSxJQUM3QyxNQUFNLElBQUksRUFBRSxhQUFhLEVBQUU7QUFBQSxJQUMzQixPQUFPLGFBQWEsVUFBVSxJQUFJO0FBQUE7QUFBQSxFQUtwQyxTQUFTLE1BQU0sQ0FBQyxHQUFlO0FBQUEsSUFDN0IsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxDQUFDO0FBQUEsTUFBRztBQUFBLElBQzNCLE1BQU0sS0FBSyxXQUFXLENBQUM7QUFBQSxJQUN2QixNQUFNLElBQUksT0FBTyxFQUFFO0FBQUEsSUFDbkIsTUFBTSxPQUFPLE1BQU0sU0FBUywrQkFBK0IsR0FBRyxLQUFLLFFBQVEsU0FBUyxFQUFFO0FBQUEsSUFDdEYsUUFBUSxLQUFLLElBQUksTUFBTSxPQUFPLEVBQUU7QUFBQTtBQUFBLEVBSWxDLFNBQVMsWUFBWSxDQUFDLEdBQVU7QUFBQSxJQUM5QixJQUFJLFNBQVMsV0FBVyxDQUFDLEVBQUU7QUFBQSxNQUFXO0FBQUEsSUFDdEMsTUFBTSxJQUFJLFNBQVMsQ0FBQztBQUFBLElBQ3BCLElBQUksQ0FBQyxLQUFLLFFBQVEsS0FBSyxDQUFDO0FBQUEsTUFBRztBQUFBLElBQzNCLElBQUksT0FBTyxXQUFXLENBQUMsQ0FBQyxNQUFNLFNBQVM7QUFBQSxNQUNyQyxFQUFFLGVBQWU7QUFBQSxNQUNqQixFQUFFLHlCQUF5QjtBQUFBLElBQzdCO0FBQUE7QUFBQSxFQUdGLFNBQVMsT0FBTyxDQUFDLEdBQWU7QUFBQSxJQUM5QixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQVc7QUFBQSxJQUNsQixNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDLEtBQUssUUFBUSxLQUFLLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDM0IsYUFBYSxDQUFDO0FBQUEsSUFDZCxNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsSUFDdkIsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ25CLElBQUksTUFBTTtBQUFBLE1BQVEsT0FBTyxRQUFRLE1BQU0sa0RBQWtELFdBQVcsSUFBSTtBQUFBLElBQ3hHLElBQUksTUFBTSxXQUFXLE1BQU07QUFBQSxNQUFVO0FBQUEsSUFDckMsV0FBVztBQUFBLElBQ1gsSUFBSSxNQUFNLFFBQVE7QUFBQSxNQUdoQixJQUFJLFFBQVEsRUFBRTtBQUFBLFFBQUcsS0FBSyxJQUFJLFFBQVEsRUFBRSxDQUFDO0FBQUEsTUFDckM7QUFBQSxJQUNGO0FBQUEsSUFDQSxLQUFLLElBQUksUUFBUSxFQUFFLENBQUM7QUFBQTtBQUFBLEVBR3RCLFNBQVMsT0FBTyxDQUFDLEdBQVU7QUFBQSxJQUN6QixNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDO0FBQUEsTUFBRztBQUFBLElBQ1IsTUFBTSxLQUFLLFdBQVcsQ0FBQztBQUFBLElBQ3ZCLElBQUksT0FBTyxFQUFFLE1BQU07QUFBQSxNQUFRLGFBQWEsRUFBRTtBQUFBO0FBQUEsRUFHNUMsU0FBUyxRQUFRLENBQUMsR0FBVTtBQUFBLElBQzFCLElBQUksQ0FBQyxFQUFFO0FBQUEsTUFBVztBQUFBLElBQ2xCLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxJQUNwQixJQUFJLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDUixNQUFNLEtBQUssV0FBVyxDQUFDO0FBQUEsSUFDdkIsTUFBTSxJQUFJLE9BQU8sRUFBRTtBQUFBLElBQ25CLElBQUksTUFBTSxRQUFRO0FBQUEsTUFDaEIsYUFBYSxZQUFZLElBQUksRUFBRSxDQUFDO0FBQUEsTUFDaEMsWUFBWSxPQUFPLEVBQUU7QUFBQSxNQUNyQixLQUFLLFFBQVEsRUFBRSxDQUFFO0FBQUEsSUFDbkIsRUFBTyxTQUFJLE1BQU0sWUFBWSxNQUFNLFNBQVM7QUFBQSxNQUMxQyxXQUFXO0FBQUEsTUFDWCxLQUFLLElBQUksUUFBUSxFQUFFLENBQUM7QUFBQSxJQUN0QjtBQUFBO0FBQUEsRUFHRixTQUFTLEtBQUssQ0FBQyxHQUFrQjtBQUFBLElBQy9CLElBQUksQ0FBQyxFQUFFO0FBQUEsTUFBVztBQUFBLElBQ2xCLElBQUksU0FBUyxXQUFXLEVBQUUsUUFBUSxVQUFVO0FBQUEsTUFDMUMsRUFBRSxlQUFlO0FBQUEsTUFDakIsWUFBWTtBQUFBLE1BQ1o7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLElBQUksU0FBUyxDQUFDO0FBQUEsSUFDcEIsSUFBSSxDQUFDO0FBQUEsTUFBRztBQUFBLElBQ1IsSUFBSSxFQUFFLFFBQVEsV0FBVyxhQUFhLG9CQUFvQixPQUFPLENBQUMsTUFBTSxRQUFRO0FBQUEsTUFDOUUsV0FBVztBQUFBLE1BQ1gsS0FBSyxFQUFFLE1BQU0sU0FBUyxPQUFPLFNBQVMsVUFBVSxlQUFlLENBQUMsRUFBRSxJQUFJLE9BQU8sU0FBUyxDQUFDLEVBQUUsQ0FBQztBQUFBLE1BQzFGLFFBQVEsTUFBTSxxQkFBcUIsU0FBUyxDQUFDLEdBQUc7QUFBQSxJQUNsRDtBQUFBO0FBQUEsRUFHRixTQUFTLE9BQU8sR0FBRztBQUFBLElBQ2pCLFdBQVc7QUFBQTtBQUFBLEVBR2IsSUFBTSxXQUFXLE1BQU0sUUFBUSxLQUFLO0FBQUEsRUFFcEMsSUFBSSxjQUEwQixNQUFNO0FBQUEsRUFFcEMsSUFBTSxZQUF1QztBQUFBLElBQzNDLENBQUMsYUFBYSxNQUF1QjtBQUFBLElBQ3JDLENBQUMsZUFBZSxZQUFZO0FBQUEsSUFDNUIsQ0FBQyxhQUFhLFlBQVk7QUFBQSxJQUMxQixDQUFDLGFBQWEsWUFBWTtBQUFBLElBQzFCLENBQUMsV0FBVyxZQUFZO0FBQUEsSUFDeEIsQ0FBQyxTQUFTLE9BQXdCO0FBQUEsSUFDbEMsQ0FBQyxTQUFTLE9BQU87QUFBQSxJQUNqQixDQUFDLFVBQVUsUUFBUTtBQUFBLElBQ25CLENBQUMsV0FBVyxLQUFzQjtBQUFBLEVBQ3BDO0FBQUEsRUFFTyxTQUFTLGNBQWMsQ0FBQyxHQUFTLE1BQWlDLFFBQW9CO0FBQUEsSUFDM0YsSUFBSTtBQUFBLE1BQU0sY0FBYztBQUFBLElBQ3hCLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLGNBQWM7QUFBQSxJQUNkLFFBQVEsU0FBUztBQUFBLElBQ2pCLFlBQVksSUFBSSxPQUFPO0FBQUEsTUFBVyxPQUFPLGlCQUFpQixJQUFJLElBQUksSUFBSTtBQUFBLElBQ3RFLE9BQU8saUJBQWlCLFlBQVksT0FBTztBQUFBLElBQzNDLE9BQU8saUJBQWlCLFVBQVUsVUFBVSxJQUFJO0FBQUEsSUFFaEQsSUFBSSxXQUFXLE9BQU87QUFBQSxNQUFLLFFBQVEsUUFBUSxDQUFDO0FBQUE7QUFBQSxFQUd2QyxTQUFTLGFBQWEsR0FBRztBQUFBLElBQzlCLFdBQVc7QUFBQSxJQUNYLFlBQVksSUFBSSxPQUFPO0FBQUEsTUFBVyxPQUFPLG9CQUFvQixJQUFJLElBQUksSUFBSTtBQUFBLElBQ3pFLE9BQU8sb0JBQW9CLFlBQVksT0FBTztBQUFBLElBQzlDLE9BQU8sb0JBQW9CLFVBQVUsVUFBVSxJQUFJO0FBQUEsSUFDbkQsT0FBTztBQUFBLElBQ1AsUUFBUSxLQUFLO0FBQUEsSUFDYixRQUFRLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFJZixTQUFTLFFBQVEsR0FBaUM7QUFBQSxJQUN2RCxPQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFBQSxNQUM5QixNQUFNLFFBQVEsQ0FBQyxNQUFhO0FBQUEsUUFDMUIsSUFBSSxRQUFRLEtBQUssU0FBUyxDQUFDLENBQUM7QUFBQSxVQUFHO0FBQUEsUUFDL0IsRUFBRSxlQUFlO0FBQUEsUUFDakIsRUFBRSx5QkFBeUI7QUFBQTtBQUFBLE1BRTdCLE1BQU0sT0FBTyxDQUFDLE1BQTJCO0FBQUEsUUFDdkMsT0FBTyxvQkFBb0IsYUFBYSxRQUF5QixJQUFJO0FBQUEsUUFDckUsV0FBVyxNQUFNLENBQUMsZUFBZSxhQUFhLGFBQWEsU0FBUztBQUFBLFVBQUcsT0FBTyxvQkFBb0IsSUFBSSxPQUFPLElBQUk7QUFBQSxRQUNqSCxPQUFPLG9CQUFvQixTQUFTLE9BQU8sSUFBSTtBQUFBLFFBQy9DLE9BQU8sb0JBQW9CLFdBQVcsS0FBSyxJQUFJO0FBQUEsUUFDL0MsUUFBUSxLQUFLO0FBQUEsUUFDYixhQUFhLE1BQU07QUFBQSxRQUNuQixRQUFRLENBQUM7QUFBQTtBQUFBLE1BRVgsTUFBTSxRQUFRLENBQUMsTUFBa0I7QUFBQSxRQUMvQixNQUFNLENBQUM7QUFBQSxRQUNQLE1BQU0sSUFBSSxTQUFTLENBQUM7QUFBQSxRQUNwQixJQUFJLENBQUMsS0FBSyxRQUFRLEtBQUssQ0FBQztBQUFBLFVBQUc7QUFBQSxRQUMzQixLQUFLLFFBQVEsV0FBVyxDQUFDLENBQUMsS0FBSyxJQUFJO0FBQUE7QUFBQSxNQUVyQyxNQUFNLE1BQU0sQ0FBQyxNQUFxQjtBQUFBLFFBQ2hDLElBQUksRUFBRSxRQUFRLFVBQVU7QUFBQSxVQUN0QixFQUFFLGVBQWU7QUFBQSxVQUNqQixLQUFLLElBQUk7QUFBQSxRQUNYO0FBQUE7QUFBQSxNQUVGLE9BQU8saUJBQWlCLGFBQWEsUUFBeUIsSUFBSTtBQUFBLE1BQ2xFLFdBQVcsTUFBTSxDQUFDLGVBQWUsYUFBYSxhQUFhLFNBQVM7QUFBQSxRQUFHLE9BQU8saUJBQWlCLElBQUksT0FBTyxJQUFJO0FBQUEsTUFDOUcsT0FBTyxpQkFBaUIsU0FBUyxPQUFPLElBQUk7QUFBQSxNQUM1QyxPQUFPLGlCQUFpQixXQUFXLEtBQUssSUFBSTtBQUFBLE1BQzVDLGFBQWEsTUFBTSxLQUFLLElBQUk7QUFBQSxNQUM1QixJQUFJLFdBQVcsT0FBTztBQUFBLFFBQUssUUFBUSxNQUFNLHVDQUF1QztBQUFBLEtBQ2pGO0FBQUE7QUFBQSxFQUdJLElBQUksYUFBeUIsTUFBTTs7O0VDNU4xQyxTQUFTLElBQWEsQ0FBQyxLQUEyQztBQUFBLElBQ2hFLElBQUk7QUFBQSxNQUNGLE9BQU8sT0FBTyxRQUFRLFlBQVksR0FBRyxFQUFFLE1BQU0sTUFBRztBQUFBLFFBQUc7QUFBQSxPQUFTO0FBQUEsTUFDNUQsTUFBTTtBQUFBLE1BRU4sY0FBYztBQUFBLE1BQ2QsT0FBTyxRQUFRLFFBQVEsU0FBUztBQUFBO0FBQUE7QUFBQSxFQUlwQyxJQUFNLE9BQU8sQ0FBQyxTQUF1QixLQUFLLEtBQUssRUFBRSxNQUFNLGVBQWUsS0FBSyxDQUFDO0FBQUEsRUFDNUUsSUFBTSxTQUFTLE1BQU0sS0FBSyxLQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxFQUl0RCxJQUFNLE1BQU07QUFBQSxFQUVaLElBQU0sWUFBWSxJQUFJO0FBQUEsRUFFdEIsU0FBUyxlQUFlLENBQUMsUUFBd0Q7QUFBQSxJQUMvRSxJQUFJLENBQUM7QUFBQSxNQUFRO0FBQUEsSUFDYixPQUFPLENBQUMsR0FBRyxTQUFTLGlCQUFpQixlQUFlLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBTyxFQUF3QixrQkFBa0IsTUFBTTtBQUFBO0FBQUEsRUFHdEgsU0FBUyxjQUFjLENBQUMsR0FBaUI7QUFBQSxJQUN2QyxNQUFNLElBQUksRUFBRTtBQUFBLElBQ1osSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFlBQVksRUFBRSxRQUFRLFFBQVEsT0FBTyxFQUFFLFVBQVU7QUFBQSxNQUFVO0FBQUEsSUFDbEYsSUFBSSxFQUFFLFNBQVMsWUFBWTtBQUFBLE1BQ3pCLE1BQU0sS0FBSyxnQkFBZ0IsRUFBRSxNQUFNO0FBQUEsTUFDbkMsSUFBSTtBQUFBLFFBQUksVUFBVSxJQUFJLEVBQUUsT0FBTyxFQUFFO0FBQUEsSUFDbkMsRUFBTyxTQUFJLEVBQUUsU0FBUyxXQUFXLEVBQUUsV0FBVyxPQUFPLFVBQVUsV0FBVyxPQUFPLEtBQUs7QUFBQSxNQUMvRSxLQUFLLEVBQUUsTUFBTSxlQUFlLE9BQU8sRUFBRSxNQUFNLENBQUM7QUFBQSxJQUNuRDtBQUFBO0FBQUEsRUFHRixlQUFlLHFCQUFxQixDQUFDLE9BQXlDO0FBQUEsSUFDNUUsU0FBUyxJQUFJLEVBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxJQUFJLEtBQUssR0FBRztBQUFBLE1BQUssTUFBTSxNQUFNLEVBQUU7QUFBQSxJQUNwRSxNQUFNLEtBQUssVUFBVSxJQUFJLEtBQUs7QUFBQSxJQUM5QixVQUFVLE9BQU8sS0FBSztBQUFBLElBQ3RCLE9BQU8sS0FBSyxlQUFlLEVBQUUsSUFBSTtBQUFBO0FBQUEsRUFHbkMsZUFBZSxZQUFZLENBQUMsV0FBcUIsU0FBOEQ7QUFBQSxJQUM3RyxNQUFNLE1BQU0sWUFBWSxJQUFJLElBQUk7QUFBQSxJQUNoQyxPQUFPLE1BQU07QUFBQSxNQUNYLE1BQU0sSUFBSSxRQUFRLFNBQVM7QUFBQSxNQUMzQixNQUFNLE1BQU0sS0FBTSxFQUFFLEdBQXlCO0FBQUEsTUFDN0MsSUFBSSxLQUFLO0FBQUEsUUFDUCxNQUFNLFFBQVEsT0FBTyxXQUFXO0FBQUEsUUFDaEMsSUFBSSxZQUFZLEdBQUcsTUFBTSxTQUFTLE1BQU0sR0FBRyxHQUFHO0FBQUEsUUFDOUMsT0FBTyxFQUFFLE1BQU07QUFBQSxNQUNqQjtBQUFBLE1BQ0EsSUFBSSxZQUFZLElBQUksSUFBSTtBQUFBLFFBQUssT0FBTyxFQUFFLE9BQU8sNkJBQTZCLFVBQVUsTUFBTTtBQUFBLE1BQzFGLE1BQU0sTUFBTSxHQUFHO0FBQUEsSUFDakI7QUFBQTtBQUFBLEVBR0YsSUFBSSxDQUFDLE9BQU8sVUFBVTtBQUFBLElBQ3BCLE9BQU8sV0FBVztBQUFBLElBQ2xCLE9BQU8saUJBQWlCLFdBQVcsY0FBYztBQUFBLElBRWpELE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxLQUFnQixTQUFTLFVBQVU7QUFBQSxNQUN2RSxRQUFRLElBQUk7QUFBQSxhQUNMO0FBQUEsVUFDSCxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUM7QUFBQSxVQUNsQjtBQUFBLGFBQ0c7QUFBQSxVQUNILGVBQWUsSUFBSSxNQUFNLE1BQU0sTUFBTTtBQUFBLFVBQ3JDLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsY0FBYztBQUFBLFVBQ2QsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxRQUFRLElBQUksTUFBTSxJQUFJLFFBQVEsRUFBRSxLQUFLLEtBQUs7QUFBQSxVQUMxQyxPQUFPO0FBQUEsYUFDSjtBQUFBLFVBQ0gsVUFBVSxDQUFDLElBQUksVUFBVSxHQUFJLElBQUksYUFBYSxDQUFDLENBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxVQUFVLE1BQU0sRUFBRSxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsVUFDeEYsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUdILFNBQVMsRUFBRSxLQUFLLE9BQU8sU0FBUyxNQUFNLE9BQVMsTUFBTSxLQUFtQixFQUFFLE1BQU0sZ0JBQWdCLEtBQUssQ0FBQyxLQUFNLE9BQVEsSUFBSSxDQUFDO0FBQUEsVUFDekgsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILFdBQVc7QUFBQSxVQUNYLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQztBQUFBLFVBQ2xCO0FBQUEsYUFDRztBQUFBLFVBQ0gsT0FBTyxPQUFPLFlBQVksR0FBRyxNQUFNLFlBQVksT0FBTyxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBQUEsVUFDdEUsTUFBTSxFQUFFLElBQUksS0FBSyxDQUFDO0FBQUEsVUFDbEI7QUFBQSxhQUNHO0FBQUEsVUFDSCxzQkFBc0IsSUFBSSxLQUFLLEVBQUUsS0FBSyxLQUFLO0FBQUEsVUFDM0MsT0FBTztBQUFBLGFBQ0o7QUFBQSxVQUNILGFBQWEsSUFBSSxXQUFXLElBQUksT0FBTyxFQUFFLEtBQUssS0FBSztBQUFBLFVBQ25ELE9BQU87QUFBQTtBQUFBLEtBRVo7QUFBQSxJQUdELEtBQW9DLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxFQUFFLEtBQUssQ0FBQyxNQUFNO0FBQUEsTUFDekUsSUFBSSxHQUFHO0FBQUEsUUFBTSxlQUFlLEVBQUUsTUFBTSxNQUFNLE1BQU07QUFBQSxLQUNqRDtBQUFBLEVBQ0g7IiwKICAiZGVidWdJZCI6ICIxNzVBRThDQzNDMzNDRDBDNjQ3NTZFMjE2NDc1NkUyMSIsCiAgIm5hbWVzIjogW10KfQ==
