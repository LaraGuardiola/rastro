(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  function __accessProp(key) {
    return this[key];
  }
  var __toCommonJS = (from) => {
    var entry = (__moduleCache ??= new WeakMap).get(from), desc;
    if (entry)
      return entry;
    entry = __defProp({}, "__esModule", { value: true });
    if (from && typeof from === "object" || typeof from === "function") {
      for (var key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(entry, key))
          __defProp(entry, key, {
            get: __accessProp.bind(from, key),
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
          });
    }
    __moduleCache.set(from, entry);
    return entry;
  };
  var __moduleCache;

  // src/content/hook.ts
  var exports_hook = {};
  var EVT = "__rastro_net";
  var STALE = 1e4;
  if (!window.__rastroNet) {
    window.__rastroNet = true;
    const inflight = new Set;
    let seq = 0;
    const publish = () => document.dispatchEvent(new CustomEvent(EVT, { detail: inflight.size }));
    const end = (id) => {
      if (inflight.delete(id))
        publish();
    };
    const begin = () => {
      const id = ++seq;
      inflight.add(id);
      setTimeout(() => end(id), STALE);
      publish();
      return id;
    };
    const origFetch = window.fetch;
    window.fetch = function(...args) {
      const id = begin();
      try {
        const p = origFetch.apply(this, args);
        p.then(() => end(id), () => end(id));
        return p;
      } catch (e) {
        end(id);
        throw e;
      }
    };
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function(...args) {
      const id = begin();
      this.addEventListener("loadend", () => end(id), { once: true });
      try {
        return origSend.apply(this, args);
      } catch (e) {
        end(id);
        throw e;
      }
    };
    document.addEventListener(EVT + "?", publish);
  }
})();

//# debugId=B3145F0598B15E0364756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL2NvbnRlbnQvaG9vay50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsKICAgICIvLyBDb3JyZSBlbiBlbCDCq21haW4gd29ybGTCuyBkZSBsYSBww6FnaW5hIChubyBlbiBlbCBtdW5kbyBhaXNsYWRvIGRlbCBjb250ZW50IHNjcmlwdCkgcGFyYSBwb2RlclxuLy8gdmVyIHN1cyBmZXRjaC9YSFIuIFB1YmxpY2EgY3XDoW50YXMgcGV0aWNpb25lcyBoYXkgZW4gdnVlbG8gY29uIHVuIGV2ZW50byBlbiBkb2N1bWVudDtcbi8vIGVsIGNvbnRlbnQgc2NyaXB0ICh3YWl0LnRzKSBsbyBlc2N1Y2hhLiBTb2xvIHNlIGVudsOtYW4gbsO6bWVyb3M6IGNydXphbiBiaWVuIGVudHJlIG11bmRvcy5cblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICBfX3Jhc3Ryb05ldD86IGJvb2xlYW47XG4gIH1cbn1cblxuY29uc3QgRVZUID0gXCJfX3Jhc3Ryb19uZXRcIjtcbi8vIExvbmctcG9sbGluZywgc3RyZWFtcywgcGV0aWNpb25lcyBjb2xnYWRhc+KApjogcGFzYWRvIGVzdGUgdGllbXBvIHVuYSBwZXRpY2nDs24gZGVqYSBkZSBjb250YXIuXG5jb25zdCBTVEFMRSA9IDEwMDAwO1xuXG5pZiAoIXdpbmRvdy5fX3Jhc3Ryb05ldCkge1xuICB3aW5kb3cuX19yYXN0cm9OZXQgPSB0cnVlO1xuICBjb25zdCBpbmZsaWdodCA9IG5ldyBTZXQ8bnVtYmVyPigpO1xuICBsZXQgc2VxID0gMDtcblxuICBjb25zdCBwdWJsaXNoID0gKCkgPT4gZG9jdW1lbnQuZGlzcGF0Y2hFdmVudChuZXcgQ3VzdG9tRXZlbnQoRVZULCB7IGRldGFpbDogaW5mbGlnaHQuc2l6ZSB9KSk7XG4gIGNvbnN0IGVuZCA9IChpZDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGluZmxpZ2h0LmRlbGV0ZShpZCkpIHB1Ymxpc2goKTtcbiAgfTtcbiAgY29uc3QgYmVnaW4gPSAoKSA9PiB7XG4gICAgY29uc3QgaWQgPSArK3NlcTtcbiAgICBpbmZsaWdodC5hZGQoaWQpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gZW5kKGlkKSwgU1RBTEUpO1xuICAgIHB1Ymxpc2goKTtcbiAgICByZXR1cm4gaWQ7XG4gIH07XG5cbiAgY29uc3Qgb3JpZ0ZldGNoID0gd2luZG93LmZldGNoO1xuICB3aW5kb3cuZmV0Y2ggPSBmdW5jdGlvbiAodGhpczogdW5rbm93biwgLi4uYXJnczogUGFyYW1ldGVyczx0eXBlb2YgZmV0Y2g+KSB7XG4gICAgY29uc3QgaWQgPSBiZWdpbigpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwID0gb3JpZ0ZldGNoLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgICAgcC50aGVuKFxuICAgICAgICAoKSA9PiBlbmQoaWQpLFxuICAgICAgICAoKSA9PiBlbmQoaWQpLFxuICAgICAgKTtcbiAgICAgIHJldHVybiBwO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGVuZChpZCk7XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfSBhcyB0eXBlb2YgZmV0Y2g7XG5cbiAgY29uc3Qgb3JpZ1NlbmQgPSBYTUxIdHRwUmVxdWVzdC5wcm90b3R5cGUuc2VuZDtcbiAgWE1MSHR0cFJlcXVlc3QucHJvdG90eXBlLnNlbmQgPSBmdW5jdGlvbiAodGhpczogWE1MSHR0cFJlcXVlc3QsIC4uLmFyZ3M6IFBhcmFtZXRlcnM8WE1MSHR0cFJlcXVlc3RbXCJzZW5kXCJdPikge1xuICAgIGNvbnN0IGlkID0gYmVnaW4oKTtcbiAgICB0aGlzLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkZW5kXCIsICgpID0+IGVuZChpZCksIHsgb25jZTogdHJ1ZSB9KTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG9yaWdTZW5kLmFwcGx5KHRoaXMsIGFyZ3MpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGVuZChpZCk7XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgfTtcblxuICAvLyBFbCBjb250ZW50IHNjcmlwdCBwdWVkZSBsbGVnYXIgdGFyZGUgKGRvY3VtZW50X2lkbGUpOiBwcmVndW50YSBlbCBlc3RhZG8gYWN0dWFsLlxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKEVWVCArIFwiP1wiLCBwdWJsaXNoKTtcbn1cblxuZXhwb3J0IHt9O1xuIgogIF0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQVVBLElBQU0sTUFBTTtBQUFBLEVBRVosSUFBTSxRQUFRO0FBQUEsRUFFZCxJQUFJLENBQUMsT0FBTyxhQUFhO0FBQUEsSUFDdkIsT0FBTyxjQUFjO0FBQUEsSUFDckIsTUFBTSxXQUFXLElBQUk7QUFBQSxJQUNyQixJQUFJLE1BQU07QUFBQSxJQUVWLE1BQU0sVUFBVSxNQUFNLFNBQVMsY0FBYyxJQUFJLFlBQVksS0FBSyxFQUFFLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQztBQUFBLElBQzVGLE1BQU0sTUFBTSxDQUFDLE9BQWU7QUFBQSxNQUMxQixJQUFJLFNBQVMsT0FBTyxFQUFFO0FBQUEsUUFBRyxRQUFRO0FBQUE7QUFBQSxJQUVuQyxNQUFNLFFBQVEsTUFBTTtBQUFBLE1BQ2xCLE1BQU0sS0FBSyxFQUFFO0FBQUEsTUFDYixTQUFTLElBQUksRUFBRTtBQUFBLE1BQ2YsV0FBVyxNQUFNLElBQUksRUFBRSxHQUFHLEtBQUs7QUFBQSxNQUMvQixRQUFRO0FBQUEsTUFDUixPQUFPO0FBQUE7QUFBQSxJQUdULE1BQU0sWUFBWSxPQUFPO0FBQUEsSUFDekIsT0FBTyxRQUFRLFFBQVMsSUFBbUIsTUFBZ0M7QUFBQSxNQUN6RSxNQUFNLEtBQUssTUFBTTtBQUFBLE1BQ2pCLElBQUk7QUFBQSxRQUNGLE1BQU0sSUFBSSxVQUFVLE1BQU0sTUFBTSxJQUFJO0FBQUEsUUFDcEMsRUFBRSxLQUNBLE1BQU0sSUFBSSxFQUFFLEdBQ1osTUFBTSxJQUFJLEVBQUUsQ0FDZDtBQUFBLFFBQ0EsT0FBTztBQUFBLFFBQ1AsT0FBTyxHQUFHO0FBQUEsUUFDVixJQUFJLEVBQUU7QUFBQSxRQUNOLE1BQU07QUFBQTtBQUFBO0FBQUEsSUFJVixNQUFNLFdBQVcsZUFBZSxVQUFVO0FBQUEsSUFDMUMsZUFBZSxVQUFVLE9BQU8sUUFBUyxJQUEwQixNQUEwQztBQUFBLE1BQzNHLE1BQU0sS0FBSyxNQUFNO0FBQUEsTUFDakIsS0FBSyxpQkFBaUIsV0FBVyxNQUFNLElBQUksRUFBRSxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFBQSxNQUM5RCxJQUFJO0FBQUEsUUFDRixPQUFPLFNBQVMsTUFBTSxNQUFNLElBQUk7QUFBQSxRQUNoQyxPQUFPLEdBQUc7QUFBQSxRQUNWLElBQUksRUFBRTtBQUFBLFFBQ04sTUFBTTtBQUFBO0FBQUE7QUFBQSxJQUtWLFNBQVMsaUJBQWlCLE1BQU0sS0FBSyxPQUFPO0FBQUEsRUFDOUM7IiwKICAiZGVidWdJZCI6ICJCMzE0NUYwNTk4QjE1RTAzNjQ3NTZFMjE2NDc1NkUyMSIsCiAgIm5hbWVzIjogW10KfQ==
