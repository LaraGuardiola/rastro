// src/shared/types.ts
var DEFAULT_SETTINGS = {
  timeout: 8000,
  stepDelay: 250,
  typeMode: "instant",
  keyDelay: 25,
  highlight: true,
  autoWait: true,
  loaderSelector: ""
};
var STEP_META = {
  navigate: { label: "Ir a", icon: "↗", needsTarget: false, valueHint: "https://…" },
  click: { label: "Click", icon: "◉", needsTarget: true },
  fill: { label: "Escribir", icon: "⌨", needsTarget: true, valueHint: "texto o {{variable}}" },
  select: { label: "Seleccionar", icon: "☰", needsTarget: true, valueHint: "value de la opción" },
  check: { label: "Marcar", icon: "☑", needsTarget: true, valueHint: "true / false" },
  press: { label: "Tecla", icon: "⏎", needsTarget: false, valueHint: "Enter, Tab, Escape…" },
  wait: { label: "Esperar", icon: "⏱", needsTarget: false, valueHint: "milisegundos" },
  waitFor: { label: "Esperar a", icon: "⌛", needsTarget: true },
  assertText: { label: "Comprobar", icon: "✓", needsTarget: true, valueHint: "texto esperado" }
};

// src/shared/util.ts
var uid = () => crypto.randomUUID().slice(0, 8) + Date.now().toString(36).slice(-4);
function looksGenerated(s) {
  return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function builtin(name) {
  switch (name) {
    case "$timestamp":
      return String(Date.now());
    case "$uuid":
      return crypto.randomUUID();
    case "$randomInt":
      return String(Math.floor(Math.random() * 1e6));
    case "$randomEmail":
      return `test+${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}@example.com`;
    case "$today":
      return new Date().toISOString().slice(0, 10);
  }
  return;
}
function interpolate(text, vars) {
  return text.replace(/\{\{\s*([$\w.-]+)\s*\}\}/g, (m, name) => vars[name] ?? builtin(name) ?? m);
}
var BUILTIN_VARS = ["$timestamp", "$uuid", "$randomEmail", "$randomInt", "$today"];

// src/shared/store.ts
var FLOW_PREFIX = "flow:";
var SETTINGS_KEY = "settings";
var RECORDING_KEY = "recording";
async function listFlows() {
  const all = await chrome.storage.local.get(null);
  return Object.entries(all).filter(([k]) => k.startsWith(FLOW_PREFIX)).map(([, v]) => v).sort((a, b) => b.updatedAt - a.updatedAt);
}
async function saveFlow(flow, touch = true) {
  if (touch)
    flow.updatedAt = Date.now();
  await chrome.storage.local.set({ [FLOW_PREFIX + flow.id]: flow });
  return flow;
}
async function deleteFlows(ids) {
  await chrome.storage.local.remove(ids.map((id) => FLOW_PREFIX + id));
}
function newFlow(partial = {}) {
  const now = Date.now();
  return {
    id: uid(),
    name: "Nuevo flujo",
    tags: [],
    variables: {},
    steps: [],
    createdAt: now,
    updatedAt: now,
    ...partial
  };
}
function newStep(partial) {
  return { id: uid(), enabled: true, ...partial };
}
async function getSettings() {
  const s = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  return { ...DEFAULT_SETTINGS, ...s ?? {} };
}
async function saveSettings(s) {
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
}
async function getRecording() {
  return (await chrome.storage.session.get(RECORDING_KEY))[RECORDING_KEY];
}
var isFlowKey = (k) => k.startsWith(FLOW_PREFIX);
var RECORDING_STORAGE_KEY = RECORDING_KEY;

// src/shared/devtools.ts
function isDevToolsRecording(data) {
  if (!data || typeof data !== "object" || !Array.isArray(data.steps))
    return false;
  const steps = data.steps;
  return "title" in data && steps.some((s) => s && (s.type === "setViewport" || Array.isArray(s.selectors) || s.type === "navigate" && ("url" in s)));
}
function mapSelectors(raw, isInput) {
  const stable = [];
  const named = [];
  const positional = [];
  const xpath = [];
  let name;
  for (const entry of raw ?? []) {
    const parts = Array.isArray(entry) ? entry : [entry];
    if (parts.length !== 1)
      continue;
    const s = parts[0];
    if (hasGeneratedId(s))
      continue;
    if (s.startsWith("aria/")) {
      const n = s.slice(5).replace(/\[role="[^"]*"\]$/, "");
      name ??= n.replace(/\s*\*$/, "");
      if (isInput)
        named.push(`label=${n.replace(/\s*\*$/, "")}`);
      else
        named.push(`text=${n}`, `[aria-label=${JSON.stringify(n)}]`);
    } else if (s.startsWith("text/")) {
      name ??= s.slice(5);
      named.push(`text=${s.slice(5)}`);
    } else if (s.startsWith("xpath/"))
      xpath.push(`xpath=${s.slice(6)}`);
    else {
      const css = s.startsWith("pierce/") ? s.slice(7) : s;
      (/^#[\w-]+$|^[\w-]*\[[^\]]+\]$/.test(css) ? stable : positional).push(css);
    }
  }
  return { selectors: [...new Set([...stable, ...named, ...positional, ...xpath])].slice(0, 6), name };
}
function hasGeneratedId(sel) {
  const ids = [...sel.matchAll(/#((?:\\.|[\w-])+)/g), ...sel.matchAll(/@id=["']([^"']+)["']/g), ...sel.matchAll(/\[id=["']?([^"'\]]+)/g)];
  return ids.some((m) => looksGenerated(m[1].replace(/\\/g, "")));
}
function mapFrame(frame) {
  return frame?.length ? frame.map((i) => ({ selector: `frame=${i}` })) : undefined;
}
function fromDevTools(rec) {
  const steps = [];
  const skipped = [];
  for (const s of rec.steps) {
    if (s.target && s.target !== "main") {
      skipped.push(`${s.type} (en otra ventana)`);
      continue;
    }
    const isInput = s.type === "change";
    const mapped = mapSelectors(s.selectors, isInput);
    const [selector, ...fallbacks] = mapped.selectors;
    const target = { selector, fallbacks, frame: mapFrame(s.frame), timeout: s.timeout };
    const label = mapped.name ?? selector;
    switch (s.type) {
      case "setViewport":
      case "keyUp":
        break;
      case "navigate":
        steps.push(newStep({ type: "navigate", value: s.url }));
        break;
      case "click":
      case "doubleClick":
        if (!selector)
          skipped.push(s.type + " sin selector usable");
        else
          steps.push(newStep({ type: "click", ...target, label, note: s.type === "doubleClick" ? "doble click en DevTools" : undefined }));
        break;
      case "change": {
        if (!selector) {
          skipped.push("change sin selector usable");
          break;
        }
        const prev = steps.at(-1);
        if (prev?.type === "click" && prev.selector === selector && JSON.stringify(prev.frame) === JSON.stringify(target.frame))
          steps.pop();
        steps.push(newStep({ type: "fill", ...target, label, value: s.value ?? "" }));
        break;
      }
      case "keyDown":
        steps.push(newStep({ type: "press", value: s.key ?? "Enter" }));
        break;
      case "waitForElement":
        if (selector)
          steps.push(newStep({ type: "waitFor", ...target, label }));
        break;
      default:
        skipped.push(s.type);
    }
  }
  const flow = newFlow({ name: rec.title || "Grabación de DevTools", tags: ["devtools"], steps });
  return { flow, skipped };
}
function toDTSelector(sel) {
  if (sel.startsWith("text="))
    return `text/${sel.slice(5)}`;
  const i = sel.indexOf(" >> ");
  if (i > 0)
    return toDTSelector(sel.slice(i + 4));
  if (sel.startsWith("label="))
    return `aria/${sel.slice(6)}`;
  if (sel.startsWith("xpath="))
    return `xpath/${sel.slice(6)}`;
  return sel;
}
function toDevTools(flow) {
  const steps = [
    { type: "setViewport", width: 1280, height: 800, deviceScaleFactor: 1, isMobile: false, hasTouch: false, isLandscape: false }
  ];
  let warnings = 0;
  for (const s of flow.steps) {
    if (!s.enabled)
      continue;
    if (s.frame?.length)
      warnings++;
    const selectors = [s.selector, ...s.fallbacks ?? []].filter(Boolean).map((x) => [toDTSelector(x)]);
    const base = { target: "main", selectors, ...s.timeout ? { timeout: s.timeout } : {} };
    switch (s.type) {
      case "navigate":
        steps.push({ type: "navigate", url: s.value ?? "" });
        break;
      case "click":
      case "check":
        steps.push({ type: "click", ...base, offsetX: 1, offsetY: 1 });
        break;
      case "fill":
      case "select":
        steps.push({ type: "change", ...base, value: s.value ?? "" });
        break;
      case "press":
        steps.push({ type: "keyDown", target: "main", key: s.value || "Enter" }, { type: "keyUp", target: "main", key: s.value || "Enter" });
        break;
      case "waitFor":
        steps.push({ type: "waitForElement", ...base });
        break;
      case "assertText":
        steps.push({
          type: "waitForExpression",
          target: "main",
          expression: `(() => { const e = document.querySelector(${JSON.stringify(s.selector ?? "")}); return !!e && (e.value ?? e.innerText).includes(${JSON.stringify(s.value ?? "")}); })()`
        });
        break;
      case "wait":
        steps.push({ type: "waitForExpression", target: "main", expression: `new Promise((r) => setTimeout(() => r(true), ${Number(s.value) || 1000}))` });
        break;
    }
  }
  return { json: { title: flow.name, steps }, warnings };
}

// src/shared/exporters.ts
function toExportFile(flows) {
  return { format: "rastro", version: 1, exportedAt: new Date().toISOString(), flows: flows.map((f) => ({ ...f, lastRun: undefined })) };
}
var STEP_TYPES = ["navigate", "click", "fill", "select", "check", "press", "wait", "waitFor", "assertText"];
function parseImport(text) {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error("El fichero no es JSON válido");
  }
  if (isDevToolsRecording(data)) {
    const { flow, skipped } = fromDevTools(data);
    return { flows: [flow], source: "devtools", skipped };
  }
  return { flows: parseRastro(data), source: "rastro", skipped: [] };
}
function parseRastro(data) {
  const raw = Array.isArray(data) ? data : data && typeof data === "object" && ("flows" in data) && Array.isArray(data.flows) ? data.flows : data && typeof data === "object" && ("steps" in data) ? [data] : [];
  if (!raw.length)
    throw new Error("No se encontraron flujos en el fichero");
  return raw.map((r, i) => {
    const f = r;
    if (!Array.isArray(f.steps))
      throw new Error(`El flujo #${i + 1} no tiene pasos`);
    const steps = f.steps.map((s, j) => {
      if (!s || !STEP_TYPES.includes(s.type))
        throw new Error(`Paso ${j + 1} de «${f.name ?? i + 1}»: tipo desconocido`);
      return { ...s, id: typeof s.id === "string" ? s.id : uid(), enabled: s.enabled !== false };
    });
    return newFlow({
      id: typeof f.id === "string" ? f.id : uid(),
      name: String(f.name ?? `Importado ${i + 1}`),
      description: f.description,
      folder: f.folder,
      tags: Array.isArray(f.tags) ? f.tags.map(String) : [],
      variables: f.variables && typeof f.variables === "object" ? f.variables : {},
      steps,
      createdAt: typeof f.createdAt === "number" ? f.createdAt : Date.now()
    });
  });
}
function ppSelector(sel) {
  if (sel.startsWith("text="))
    return `::-p-text(${JSON.stringify(sel.slice(5))})`;
  const i = sel.indexOf(" >> ");
  if (i > 0)
    return `${ppSelector(sel.slice(0, i))} ${ppSelector(sel.slice(i + 4))}`;
  if (sel.startsWith("label="))
    return `::-p-aria(${JSON.stringify(sel.slice(6))})`;
  if (sel.startsWith("xpath="))
    return `::-p-xpath(${sel.slice(6)})`;
  return sel;
}
var js = (s) => JSON.stringify(s);
function jsValue(v) {
  if (!/\{\{/.test(v))
    return js(v);
  return "v(" + js(v) + ")";
}
function locator(step, ctx = "page") {
  const sels = [step.selector, ...step.fallbacks ?? []].map(ppSelector);
  if (sels.length === 1)
    return `${ctx}.locator(${js(sels[0])})`;
  return `Locator.race([${sels.map((x) => `${ctx}.locator(${js(x)})`).join(", ")}])`;
}
function frameExpr(step) {
  if (!step.frame?.length)
    return;
  const path = step.frame.map((f) => [f.selector, ...f.fallbacks ?? []].map(ppSelector));
  return `await frameOf(${JSON.stringify(path)})`;
}
function toPuppeteer(flow) {
  const out = [];
  out.push(`// ${flow.name} — exportado desde Rastro el ${new Date().toLocaleString()}`);
  out.push(`// Requiere: npm i puppeteer   ·   Ejecutar: node ${slug(flow.name)}.mjs  (o bun)`);
  out.push(`import puppeteer, { Locator } from "puppeteer";`);
  out.push("");
  out.push(`const T = 8000;`);
  out.push(`const vars = ${JSON.stringify(flow.variables ?? {}, null, 2)};`);
  out.push(`const builtins = {`);
  out.push(`  $timestamp: String(Date.now()),`);
  out.push(`  $uuid: crypto.randomUUID(),`);
  out.push(`  $randomInt: String(Math.floor(Math.random() * 1e6)),`);
  out.push(`  $randomEmail: \`test+\${Date.now().toString(36)}@example.com\`,`);
  out.push(`  $today: new Date().toISOString().slice(0, 10),`);
  out.push(`};`);
  out.push(`const v = (s) => s.replace(/\\{\\{\\s*([$\\w.-]+)\\s*\\}\\}/g, (m, k) => vars[k] != null ? v(vars[k]) : builtins[k] ?? m);`);
  out.push("");
  if (flow.steps.some((st) => st.frame?.length)) {
    out.push(`/** Baja por la ruta de iframes: en cada nivel, el primer selector que aparezca. */`);
    out.push(`async function frameOf(path) {`);
    out.push(`  let f = page.mainFrame();`);
    out.push(`  for (const sels of path) {`);
    out.push(`    const el = await Locator.race(sels.map((s) => f.locator(s))).waitHandle();`);
    out.push(`    f = await el.contentFrame();`);
    out.push(`  }`);
    out.push(`  return f;`);
    out.push(`}`);
    out.push("");
  }
  out.push(`const browser = await puppeteer.launch({ headless: process.env.HEADLESS !== "0" ? "new" : false });`);
  out.push(`const page = await browser.newPage();`);
  out.push(`page.setDefaultTimeout(T);`);
  out.push(`try {`);
  flow.steps.forEach((s, i) => {
    const comment = `  // ${i + 1}. ${s.type}${s.label ? ` · ${s.label}` : ""}`;
    if (!s.enabled) {
      out.push(comment + " (desactivado)");
      return;
    }
    out.push(comment);
    const val = s.value ?? "";
    const fr = frameExpr(s);
    const ctx = fr ? "f" : "page";
    const loc = () => locator(s, ctx);
    if (fr && s.type !== "navigate" && s.type !== "wait")
      out.push(`  {`, `  const f = ${fr};`);
    switch (s.type) {
      case "navigate":
        out.push(`  await page.goto(${jsValue(val)}, { waitUntil: "networkidle2" });`);
        break;
      case "click":
        out.push(`  await Promise.all([`);
        out.push(`    page.waitForNavigation({ timeout: 1500 }).catch(() => {}),`);
        out.push(`    ${loc()}.click(),`);
        out.push(`  ]);`);
        break;
      case "fill":
        out.push(`  await ${loc()}.fill(${jsValue(val)});`);
        break;
      case "select":
        out.push(`  await ${ctx}.select(${js(ppSelector(s.selector))}, ${jsValue(val)});`);
        break;
      case "check":
        out.push(`  {`);
        out.push(`    const el = await ${loc()}.waitHandle();`);
        out.push(`    if ((await el.evaluate((e) => e.checked ?? e.getAttribute("aria-checked") === "true")) !== ${val !== "false"}) await el.click();`);
        out.push(`  }`);
        break;
      case "press":
        if (s.selector)
          out.push(`  await ${loc()}.click();`);
        out.push(`  await Promise.all([`);
        out.push(`    page.waitForNavigation({ timeout: 1500 }).catch(() => {}),`);
        out.push(`    page.keyboard.press(${js(val || "Enter")}),`);
        out.push(`  ]);`);
        break;
      case "wait":
        out.push(`  await new Promise((r) => setTimeout(r, ${Number(val) || 1000}));`);
        break;
      case "waitFor":
        out.push(`  await ${loc()}.wait();`);
        break;
      case "assertText":
        out.push(`  {`);
        out.push(`    const el = await ${loc()}.waitHandle();`);
        out.push(`    const txt = await el.evaluate((e) => e.value ?? e.innerText);`);
        out.push(`    if (!txt.includes(${jsValue(val)})) throw new Error(\`Paso ${i + 1}: se esperaba ${val.replace(/[`$\\]/g, "")} y hay \${txt}\`);`);
        out.push(`  }`);
        break;
    }
    if (fr && s.type !== "navigate" && s.type !== "wait")
      out.push(`  }`);
  });
  out.push(`  console.log("✓ ${flow.name.replace(/"/g, "'")}: OK");`);
  out.push(`} catch (e) {`);
  out.push(`  console.error("✗", e.message);`);
  out.push(`  await page.screenshot({ path: "rastro-error.png" });`);
  out.push(`  process.exitCode = 1;`);
  out.push(`} finally {`);
  out.push(`  await browser.close();`);
  out.push(`}`);
  return out.join(`
`) + `
`;
}
var slug = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "flujo";

// src/panel/runner.ts
var PORT_CLOSED = /message port closed|Receiving end does not exist|back\/forward cache|context invalidated/i;
var pinnedTab = Number(new URLSearchParams(location.search).get("tab")) || undefined;
async function activeTab() {
  if (pinnedTab)
    return chrome.tabs.get(pinnedTab);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id)
    throw new Error("No hay pestaña activa");
  return tab;
}
async function waitForLoad(tabId, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === "complete")
      return;
    await sleep(120);
  }
  throw new Error("La página tardó demasiado en cargar");
}
function watchNavigations(tabId, frameId = 0) {
  let started = false;
  let pending = 0;
  const mine = (d) => d.tabId === tabId && (d.frameId === 0 || d.frameId === frameId);
  const onStart = (d) => {
    if (mine(d))
      started = true, pending++;
  };
  const onEnd = (d) => {
    if (mine(d))
      pending = Math.max(0, pending - 1);
  };
  const nav = chrome.webNavigation;
  nav.onBeforeNavigate.addListener(onStart);
  nav.onCompleted.addListener(onEnd);
  nav.onErrorOccurred.addListener(onEnd);
  return {
    async started(within) {
      const end = Date.now() + within;
      while (!started && Date.now() < end)
        await sleep(50);
      return started;
    },
    async settled(timeout = 30000) {
      const end = Date.now() + timeout;
      while (pending > 0) {
        if (Date.now() > end)
          throw new Error("La página tardó demasiado en cargar");
        await sleep(80);
      }
      await waitForLoad(tabId, timeout);
    },
    dispose() {
      nav.onBeforeNavigate.removeListener(onStart);
      nav.onCompleted.removeListener(onEnd);
      nav.onErrorOccurred.removeListener(onEnd);
    }
  };
}
async function ensureContent(tabId, frameId = 0) {
  for (let i = 0;i < 20; i++) {
    try {
      const r = await chrome.tabs.sendMessage(tabId, { kind: "ping" }, { frameId });
      if (r?.ok)
        return;
    } catch {}
    if (i === 3) {
      try {
        await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["hook.js"], world: "MAIN" }).catch(() => {});
        await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["content.js"] });
      } catch (e) {
        throw new Error("No se puede actuar en esta página (" + e.message + ")");
      }
    }
    await sleep(150);
  }
  throw new Error(frameId ? "El iframe no responde" : "El content script no responde en la pestaña");
}
async function sendToTab(tabId, msg, frameId = 0) {
  await ensureContent(tabId, frameId);
  return chrome.tabs.sendMessage(tabId, msg, { frameId });
}
async function frameIdFor(tabId, frame, timeout) {
  let fid = 0;
  for (const [i, ref] of (frame ?? []).entries()) {
    const end = Date.now() + timeout;
    let next;
    while (next == null) {
      const r = await sendToTab(tabId, { kind: "frame:resolve", selectors: [ref.selector, ...ref.fallbacks ?? []], timeout: Math.max(0, end - Date.now()) }, fid);
      if (!r?.token)
        throw new Error(`${r?.error ?? "No se encontró el iframe"} (nivel ${i + 1})`);
      for (let k = 0;k < 8 && next == null; k++) {
        await sleep(60);
        next = (await chrome.runtime.sendMessage({ kind: "frame:probed", token: r.token }))?.frameId;
      }
      if (next == null && Date.now() > end)
        throw new Error(`El iframe «${ref.selector}» no responde (nivel ${i + 1})`);
    }
    fid = next;
  }
  return fid;
}
function runVariables(flow) {
  const base = {};
  for (const b of BUILTIN_VARS)
    base[b] = interpolate(`{{${b}}}`, {});
  const vars = { ...base };
  for (const [k, v] of Object.entries(flow.variables ?? {}))
    vars[k] = interpolate(v, base);
  return vars;
}
function resolveStep(step, vars) {
  return { ...step, value: step.value != null ? interpolate(step.value, vars) : undefined };
}

class Runner {
  stopped = false;
  running = false;
  stop() {
    this.stopped = true;
  }
  async run(flow, settings, hooks, from = 0, only) {
    this.stopped = false;
    this.running = true;
    const t0 = Date.now();
    const vars = runVariables(flow);
    const steps = flow.steps;
    const end = only != null ? only + 1 : steps.length;
    for (let i = 0;i < steps.length; i++)
      if (i >= from && i < end)
        hooks.onStatus(steps[i].id, "pending");
    try {
      const tab = await activeTab();
      const tabId = tab.id;
      for (let i = from;i < end; i++) {
        if (this.stopped)
          throw new Error("Detenido por el usuario");
        const step = steps[i];
        if (!step.enabled) {
          hooks.onStatus(step.id, "skipped");
          continue;
        }
        hooks.onStatus(step.id, "running");
        try {
          await this.exec(tabId, resolveStep(step, vars), settings);
          hooks.onStatus(step.id, "ok");
        } catch (e) {
          const msg = e.message;
          hooks.onStatus(step.id, "error", msg);
          return { at: t0, ok: false, ms: Date.now() - t0, failedStepId: step.id, error: msg };
        }
        if (i < end - 1 && settings.stepDelay)
          await sleep(settings.stepDelay);
      }
      return { at: t0, ok: true, ms: Date.now() - t0 };
    } catch (e) {
      return { at: t0, ok: false, ms: Date.now() - t0, error: e.message };
    } finally {
      this.running = false;
    }
  }
  async exec(tabId, step, settings) {
    switch (step.type) {
      case "navigate": {
        if (!step.value)
          throw new Error("Falta la URL");
        const navs = watchNavigations(tabId);
        try {
          await chrome.tabs.update(tabId, { url: step.value });
          await navs.started(3000);
          await navs.settled();
        } finally {
          navs.dispose();
        }
        return;
      }
      case "wait":
        await sleep(Number(step.value) || 1000);
        return;
    }
    const acts = step.type === "click" || step.type === "press";
    const timeout = step.timeout ?? settings.timeout;
    let res;
    let fid = await frameIdFor(tabId, step.frame, timeout);
    const navs = watchNavigations(tabId, fid);
    try {
      for (let attempt = 0;; attempt++) {
        try {
          res = await sendToTab(tabId, { kind: "run-step", step, settings }, fid);
        } catch (e) {
          if (!PORT_CLOSED.test(e.message))
            throw e;
          await navs.settled();
          if (acts)
            return;
          if (attempt >= 2)
            throw new Error("La página no paró de navegar durante el paso");
          fid = await frameIdFor(tabId, step.frame, timeout);
          continue;
        }
        if (!res)
          throw new Error("Sin respuesta de la página");
        if (!res.ok)
          throw new Error(res.error);
        break;
      }
      if (acts && await navs.started(res.mayNavigate ? 1500 : 150))
        await navs.settled();
    } finally {
      navs.dispose();
    }
  }
}

// src/panel/ui.ts
function h(tag, props, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props ?? {})) {
    if (v == null || v === false)
      continue;
    if (k.startsWith("on") && typeof v === "function")
      el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "class")
      el.className = String(v);
    else if (k === "value" || k === "checked" || k === "selected" || k === "indeterminate")
      el[k] = v;
    else if (v === true)
      el.setAttribute(k, "");
    else
      el.setAttribute(k, String(v));
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children) {
    if (c == null || c === false)
      continue;
    if (Array.isArray(c))
      append(el, c);
    else
      el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}
function morph(root, next) {
  const active = document.activeElement;
  const key = active?.dataset?.k;
  const sel = key && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
  const scrollers = [...root.querySelectorAll("[data-scroll]")].map((e) => [e.dataset.scroll, e.scrollTop]);
  root.replaceChildren(next);
  for (const [k, top] of scrollers) {
    const e = root.querySelector(`[data-scroll="${k}"]`);
    if (e)
      e.scrollTop = top;
  }
  if (key) {
    const el = root.querySelector(`[data-k="${CSS.escape(key)}"]`);
    if (el) {
      el.focus({ preventScroll: true });
      if (sel) {
        try {
          el.setSelectionRange(sel[0], sel[1]);
        } catch {}
      }
    }
  }
}
function ask(o) {
  return new Promise((resolve) => {
    const listId = "dl-" + Math.random().toString(36).slice(2);
    const input = o.input != null ? h("input", { class: "input", value: o.input, placeholder: o.placeholder, list: o.options ? listId : null }) : null;
    const dlg = h("dialog", { class: "dialog" }, h("form", { method: "dialog" }, h("h3", null, o.title), o.message && h("p", { class: "muted" }, o.message), input, o.options && h("datalist", { id: listId }, o.options.map((x) => h("option", { value: x }))), h("div", { class: "row end" }, h("button", { class: "btn ghost", value: "__cancel", type: "submit" }, "Cancelar"), o.extra && h("button", { class: "btn", value: "__extra", type: "submit" }, o.extra.label), h("button", { class: "btn " + (o.danger ? "danger" : "primary"), value: "__ok", type: "submit" }, o.ok ?? "Aceptar"))));
    dlg.addEventListener("close", () => {
      const rv = dlg.returnValue;
      dlg.remove();
      if (rv === "__ok")
        resolve(input ? input.value : "ok");
      else if (rv === "__extra")
        resolve(o.extra.value);
      else
        resolve(null);
    });
    document.body.appendChild(dlg);
    dlg.showModal();
    if (input) {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          dlg.close("__ok");
        }
      });
      input.focus();
      input.select();
    }
  });
}
var toastTimer;
function toast(text, kind = "info") {
  let el = document.getElementById("toast");
  if (!el) {
    el = h("div", { id: "toast" });
    document.body.appendChild(el);
  }
  el.textContent = text;
  el.className = "show " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = "", kind === "error" ? 5000 : 2500);
}
function download(filename, content, mime = "application/json") {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = h("a", { href: url, download: filename });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function pickFile(accept = ".json,application/json") {
  return new Promise((resolve) => {
    const input = h("input", { type: "file", accept });
    input.addEventListener("change", () => resolve(input.files?.[0] ?? null));
    input.addEventListener("cancel", () => resolve(null));
    input.click();
  });
}
function timeAgo(ts) {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 45)
    return "ahora";
  const m = Math.round(s / 60);
  if (m < 60)
    return `hace ${m} min`;
  const hr = Math.round(m / 60);
  if (hr < 24)
    return `hace ${hr} h`;
  const d = Math.round(hr / 24);
  if (d < 30)
    return `hace ${d} d`;
  return new Date(ts).toLocaleDateString();
}
function hostOf(url) {
  if (!url)
    return "";
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}
function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

// src/panel/state.ts
var state = {
  view: "library",
  flows: [],
  currentId: undefined,
  settings: { ...DEFAULT_SETTINGS },
  recording: undefined,
  expanded: new Set,
  selected: new Set,
  filter: { q: "", folder: "", tags: new Set, sort: "updated" },
  collapsedFolders: new Set,
  run: undefined,
  picking: undefined,
  dragId: undefined
};
var renderFn = () => {};
var setRender = (fn) => renderFn = fn;
var render = () => renderFn();
var runner = new Runner;
var current = () => state.flows.find((f) => f.id === state.currentId);
var pendingSaves = new Map;
function saveSoon(flow) {
  let fn = pendingSaves.get(flow.id);
  if (!fn) {
    fn = debounce(() => {
      const f = state.flows.find((x) => x.id === flow.id);
      if (f)
        saveFlow(f);
    }, 300);
    pendingSaves.set(flow.id, fn);
  }
  fn();
}
async function saveNow(flow) {
  await saveFlow(flow);
  render();
}
async function reload() {
  state.flows = await listFlows();
  render();
}
async function createFlow() {
  const name = await ask({ title: "Nuevo flujo", input: "", placeholder: "p. ej. Alta de cliente", ok: "Crear" });
  if (name == null)
    return;
  const folder = state.filter.folder && state.filter.folder !== "__none" ? state.filter.folder : undefined;
  const flow = newFlow({ name: name.trim() || "Nuevo flujo", folder });
  await saveFlow(flow);
  if (!state.flows.some((f) => f.id === flow.id))
    state.flows.unshift(flow);
  openFlow(flow.id);
}
function openFlow(id) {
  state.currentId = id;
  state.view = "editor";
  state.expanded.clear();
  if (state.run?.flowId !== id)
    state.run = undefined;
  render();
  document.querySelector("[data-scroll]")?.scrollTo(0, 0);
}
async function duplicateFlow(flow) {
  const copy = structuredClone(flow);
  copy.id = uid();
  copy.name = flow.name + " (copia)";
  copy.createdAt = Date.now();
  copy.lastRun = undefined;
  copy.steps.forEach((s) => s.id = uid());
  await saveFlow(copy);
  await reload();
  toast("Flujo duplicado", "ok");
}
async function removeFlows(ids) {
  const names = state.flows.filter((f) => ids.includes(f.id)).map((f) => f.name);
  const ok = await ask({
    title: ids.length === 1 ? `¿Borrar «${names[0]}»?` : `¿Borrar ${ids.length} flujos?`,
    message: "No se puede deshacer. Exporta antes si quieres conservarlos.",
    ok: "Borrar",
    danger: true
  });
  if (!ok)
    return;
  await deleteFlows(ids);
  ids.forEach((id) => state.selected.delete(id));
  if (state.currentId && ids.includes(state.currentId))
    state.view = "library";
  await reload();
}
function allFolders() {
  return [...new Set(state.flows.map((f) => f.folder).filter(Boolean))].sort((a, b) => a.localeCompare(b));
}
function allTags() {
  return [...new Set(state.flows.flatMap((f) => f.tags))].sort((a, b) => a.localeCompare(b));
}
function filteredFlows() {
  const { q, folder, tags, sort } = state.filter;
  const tokens = q.toLowerCase().split(/\s+/).filter(Boolean);
  const list = state.flows.filter((f) => {
    if (folder === "__none" ? f.folder : folder && f.folder !== folder)
      return false;
    for (const t of tags)
      if (!f.tags.includes(t))
        return false;
    if (!tokens.length)
      return true;
    const hay = [f.name, f.description, f.folder, ...f.tags.map((t) => "#" + t), ...f.steps.map((s) => `${s.label ?? ""} ${s.type === "navigate" ? s.value : ""}`)].join(" ").toLowerCase();
    return tokens.every((t) => hay.includes(t));
  });
  if (sort === "name")
    list.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === "lastRun")
    list.sort((a, b) => (b.lastRun?.at ?? 0) - (a.lastRun?.at ?? 0));
  else
    list.sort((a, b) => b.updatedAt - a.updatedAt);
  return list;
}
async function bulkMove(ids) {
  const folder = await ask({ title: "Mover a carpeta", input: "", placeholder: "Nombre de carpeta (vacío = sin carpeta)", options: allFolders(), ok: "Mover" });
  if (folder == null)
    return;
  for (const f of state.flows.filter((x) => ids.includes(x.id))) {
    f.folder = folder.trim() || undefined;
    await saveFlow(f);
  }
  await reload();
}
async function bulkTag(ids) {
  const tag = await ask({ title: "Añadir etiqueta", input: "", placeholder: "etiqueta", options: allTags(), ok: "Añadir" });
  const t = tag?.trim().replace(/^#/, "");
  if (!t)
    return;
  for (const f of state.flows.filter((x) => ids.includes(x.id))) {
    if (!f.tags.includes(t))
      f.tags.push(t);
    await saveFlow(f);
  }
  await reload();
}
var stamp = () => new Date().toISOString().slice(0, 10);
function exportFlows(flows) {
  if (!flows.length)
    return toast("No hay flujos que exportar", "error");
  const name = flows.length === 1 ? `rastro-${slug(flows[0].name)}-${stamp()}.json` : `rastro-${flows.length}-flujos-${stamp()}.json`;
  download(name, JSON.stringify(toExportFile(flows), null, 2));
  toast(`${flows.length} flujo(s) exportado(s)`, "ok");
}
function exportPuppeteer(flow) {
  download(`${slug(flow.name)}.mjs`, toPuppeteer(flow), "text/javascript");
  toast("Script de Puppeteer descargado", "ok");
}
async function importText(text) {
  let flows;
  let result;
  try {
    result = parseImport(text);
    flows = result.flows;
  } catch (e) {
    return toast(e.message, "error");
  }
  const existing = new Set(state.flows.map((f) => f.id));
  const clashes = flows.filter((f) => existing.has(f.id));
  let mode = "copy";
  if (clashes.length) {
    const r = await ask({
      title: `${clashes.length} flujo(s) ya existen`,
      message: clashes.map((f) => f.name).join(", "),
      ok: "Sobrescribir",
      extra: { label: "Importar como copia", value: "copy" }
    });
    if (r == null)
      return;
    mode = r === "copy" ? "copy" : "overwrite";
  }
  for (const f of flows) {
    if (existing.has(f.id) && mode === "copy") {
      f.id = uid();
      f.name += " (importado)";
    }
    await saveFlow(f);
  }
  await reload();
  if (result.source === "devtools") {
    const n = result.skipped.length;
    toast(`Grabación de DevTools importada${n ? ` (${n} paso(s) sin equivalente: ${[...new Set(result.skipped)].join(", ")})` : ""}`, n ? "info" : "ok");
    openFlow(flows[0].id);
  } else
    toast(`${flows.length} flujo(s) importado(s)`, "ok");
}
function exportDevTools(flow) {
  const { json, warnings } = toDevTools(flow);
  download(`${slug(flow.name)}.recorder.json`, JSON.stringify(json, null, 2));
  toast(warnings ? `Exportado. ${warnings} paso(s) en iframes van sin ruta de frame: revísalos en DevTools` : "Exportado: impórtalo en DevTools › Recorder", warnings ? "info" : "ok");
}
function addStep(flow, type, after) {
  const step = newStep({ type, value: type === "press" ? "Enter" : type === "wait" ? "1000" : type === "check" ? "true" : undefined });
  const i = after ? flow.steps.findIndex((s) => s.id === after) : -1;
  if (i >= 0)
    flow.steps.splice(i + 1, 0, step);
  else
    flow.steps.push(step);
  state.expanded.add(step.id);
  saveNow(flow);
  return step;
}
function moveStep(flow, id, beforeId) {
  const from = flow.steps.findIndex((s) => s.id === id);
  if (from < 0)
    return;
  const [s] = flow.steps.splice(from, 1);
  const to = beforeId ? flow.steps.findIndex((x) => x.id === beforeId) : flow.steps.length;
  flow.steps.splice(to < 0 ? flow.steps.length : to, 0, s);
  saveNow(flow);
}
function duplicateStep(flow, step) {
  const i = flow.steps.indexOf(step);
  const copy = { ...structuredClone(step), id: uid() };
  flow.steps.splice(i + 1, 0, copy);
  saveNow(flow);
}
function deleteStep(flow, step) {
  flow.steps = flow.steps.filter((s) => s !== step);
  state.expanded.delete(step.id);
  saveNow(flow);
}
async function pickFor(flow, step) {
  try {
    const tab = await activeTab();
    state.picking = step.id;
    render();
    await sendToTab(tab.id, { kind: "ping" });
    const r = await chrome.tabs.sendMessage(tab.id, { kind: "pick" });
    chrome.tabs.sendMessage(tab.id, { kind: "pick:cancel" }).catch(() => {});
    if (r) {
      step.selector = r.selector;
      step.fallbacks = r.fallbacks;
      step.label = r.label;
      step.frame = r.frame;
      if (step.type === "click" && r.type !== "click") {
        Object.assign(step, { type: r.type, value: r.value, optionText: r.optionText, secret: r.secret });
      }
      await saveNow(flow);
      toast("Elemento actualizado", "ok");
    }
  } catch (e) {
    toast(e.message, "error");
  } finally {
    state.picking = undefined;
    render();
  }
}
async function cancelPick() {
  try {
    const tab = await activeTab();
    await chrome.tabs.sendMessage(tab.id, { kind: "pick:cancel" });
  } catch {}
  state.picking = undefined;
  render();
}
async function highlightStep(step) {
  if (!step.selector)
    return;
  try {
    const tab = await activeTab();
    const fid = await frameIdFor(tab.id, step.frame, 3000);
    const r = await sendToTab(tab.id, { kind: "highlight", selector: step.selector, fallbacks: step.fallbacks }, fid);
    if (!r?.ok)
      toast("No se encuentra en esta página", "error");
  } catch (e) {
    toast(e.message, "error");
  }
}
var bg = (msg) => chrome.runtime.sendMessage(msg);
async function startRecording(flow, mode) {
  try {
    const tab = await activeTab();
    if (!tab.url || !/^(https?|file):/.test(tab.url)) {
      return toast("Abre una página web en la pestaña activa para grabar", "error");
    }
    const r = await bg({ kind: "record:start", flowId: flow.id, tabId: tab.id, mode });
    if (!r.ok)
      toast(r.error ?? "No se pudo empezar a grabar", "error");
  } catch (e) {
    toast(e.message, "error");
  }
}
var stopRecording = () => bg({ kind: "record:stop" });
var pauseRecording = (paused) => bg({ kind: "record:pause", paused });
async function play(flow, from = 0, only) {
  if (runner.running)
    return;
  if (state.recording)
    await stopRecording();
  state.run = { flowId: flow.id, status: {}, info: {} };
  render();
  const summary = await runner.run(flow, state.settings, {
    onStatus(id, status, info) {
      if (!state.run)
        return;
      state.run.status[id] = status;
      if (info)
        state.run.info[id] = info;
      render();
      if (status === "running")
        document.querySelector(`[data-step="${id}"]`)?.scrollIntoView({ block: "nearest" });
    }
  }, from, only);
  if (only == null) {
    flow.lastRun = summary;
    await saveFlow(flow, false);
  }
  render();
  if (summary.ok)
    toast(`✓ Completado en ${(summary.ms / 1000).toFixed(1)}s`, "ok");
  else
    toast(`✗ ${summary.error}`, "error");
}
function stopPlay() {
  runner.stop();
}

// src/panel/views/editor.ts
var TYPES = Object.keys(STEP_META);
function editorView(flow) {
  const rec = state.recording?.flowId === flow.id ? state.recording : undefined;
  const otherRec = state.recording && !rec;
  const running = runner.running;
  const run = state.run?.flowId === flow.id ? state.run : undefined;
  const set = (k, v) => {
    flow[k] = v;
    saveSoon(flow);
  };
  return h("div", { class: "view" }, h("header", { class: "top" }, h("button", { class: "btn ghost sm", onclick: () => (state.view = "library", render()) }, "← Flujos"), h("div", { class: "row" }, h("button", { class: "icon", title: "Exportar JSON", onclick: () => exportFlows([flow]) }, "⇩"), h("button", { class: "icon", title: "Exportar a Puppeteer", onclick: () => exportPuppeteer(flow) }, "JS"), h("button", { class: "icon", title: "Exportar a DevTools Recorder", onclick: () => exportDevTools(flow) }, "DT"), h("button", { class: "icon", title: "Duplicar", onclick: () => duplicateFlow(flow) }, "⧉"), h("button", { class: "icon danger", title: "Borrar flujo", onclick: () => removeFlows([flow.id]) }, "\uD83D\uDDD1"))), h("main", { class: "scroll", "data-scroll": "editor" }, h("input", {
    class: "title-input",
    value: flow.name,
    "data-k": "flow-name",
    placeholder: "Nombre del flujo",
    oninput: (e) => set("name", e.target.value)
  }), h("div", { class: "meta-grid" }, h("label", null, h("span", null, "Carpeta"), h("input", {
    class: "input sm",
    list: "folders",
    value: flow.folder ?? "",
    placeholder: "—",
    "data-k": "flow-folder",
    oninput: (e) => set("folder", e.target.value.trim() || undefined)
  }), h("datalist", { id: "folders" }, allFolders().map((f) => h("option", { value: f })))), h("label", null, h("span", null, "Etiquetas"), tagEditor(flow))), h("textarea", {
    class: "input desc",
    rows: 1,
    placeholder: "Descripción / notas (opcional)",
    "data-k": "flow-desc",
    value: flow.description ?? "",
    oninput: (e) => set("description", e.target.value || undefined)
  }), h("div", { class: "actions" }, rec ? [
    h("button", { class: "btn rec on", onclick: () => stopRecording() }, "■ Terminar"),
    h("button", { class: "btn", onclick: () => pauseRecording(!rec.paused) }, rec.paused ? "▶ Reanudar" : "❚❚ Pausar")
  ] : [
    h("button", { class: "btn rec", disabled: running || otherRec, title: "Usa la página normalmente; todo lo que hagas se graba", onclick: () => startRecording(flow, "record") }, "● Grabar"),
    h("button", {
      class: "btn",
      disabled: running || otherRec,
      title: "Clica elementos para añadirlos sin que los botones hagan nada",
      onclick: () => startRecording(flow, "point")
    }, "◎ Señalar")
  ], running ? h("button", { class: "btn danger", onclick: stopPlay }, "■ Parar") : h("button", { class: "btn primary", disabled: !flow.steps.length || !!rec, onclick: () => play(flow) }, "▶ Reproducir")), rec && h("div", { class: "banner " + (rec.paused ? "paused" : rec.mode) }, rec.paused ? "Grabación en pausa." : rec.mode === "record" ? "Grabando en la pestaña activa. Botones → click, inputs → escribir su contenido." : "Modo señalar: clica elementos de la página. Los botones no se ejecutan. Esc para salir."), otherRec && h("div", { class: "banner paused" }, "Se está grabando otro flujo."), state.picking && h("div", { class: "banner point" }, "Clica un elemento en la página… ", h("button", { class: "btn sm", onclick: cancelPick }, "Cancelar")), !running && flow.lastRun && runSummary(flow), variablesEditor(flow), h("ol", {
    class: "steps",
    ondragover: (e) => e.preventDefault(),
    ondrop: (e) => {
      e.preventDefault();
      if (state.dragId)
        moveStep(flow, state.dragId, null);
    }
  }, flow.steps.map((s, i) => stepRow(flow, s, i, run))), flow.steps.length === 0 && !rec && h("p", { class: "empty muted" }, "Sin pasos todavía. Pulsa ", h("b", null, "Grabar"), " o añade pasos a mano."), addStepMenu(flow)));
}
function runSummary(flow) {
  const r = flow.lastRun;
  const idx = r.failedStepId ? flow.steps.findIndex((s) => s.id === r.failedStepId) + 1 : 0;
  return h("div", { class: "summary " + (r.ok ? "ok" : "err") }, r.ok ? `✓ OK en ${(r.ms / 1000).toFixed(1)}s` : `✗ Falló${idx ? ` en el paso ${idx}` : ""}: ${r.error}`, h("span", { class: "muted" }, " · " + timeAgo(r.at)));
}
function tagEditor(flow) {
  return h("div", { class: "tag-editor" }, flow.tags.map((t) => h("span", { class: "chip" }, "#" + t, h("button", {
    class: "x",
    title: "Quitar",
    onclick: () => {
      flow.tags = flow.tags.filter((x) => x !== t);
      saveNow(flow);
    }
  }, "×"))), h("input", {
    class: "tag-input",
    placeholder: flow.tags.length ? "+" : "añadir…",
    list: "all-tags",
    "data-k": "tag-input",
    onkeydown: (e) => {
      const input = e.target;
      if ((e.key === "Enter" || e.key === ",") && input.value.trim()) {
        e.preventDefault();
        const t = input.value.trim().replace(/^#/, "").replace(/,$/, "");
        if (t && !flow.tags.includes(t))
          flow.tags.push(t);
        input.value = "";
        saveNow(flow);
      } else if (e.key === "Backspace" && !input.value && flow.tags.length) {
        flow.tags.pop();
        saveNow(flow);
      }
    }
  }), h("datalist", { id: "all-tags" }, allTags().map((t) => h("option", { value: t }))));
}
var varsOpen;
function variablesEditor(flow) {
  const entries = Object.entries(flow.variables ?? {});
  const write = (pairs) => {
    flow.variables = Object.fromEntries(pairs.filter(([k]) => k.trim()));
  };
  return h("details", {
    class: "vars",
    open: varsOpen ?? entries.length > 0,
    ontoggle: (e) => varsOpen = e.target.open
  }, h("summary", null, "Variables", entries.length > 0 && h("span", { class: "count" }, String(entries.length))), h("p", { class: "muted small" }, "Usa ", h("code", null, "{{nombre}}"), " en cualquier valor. Integradas: ", BUILTIN_VARS.map((b, i) => [i ? ", " : "", h("code", null, `{{${b}}}`)])), entries.map(([k, v], i) => h("div", { class: "var-row" }, h("input", {
    class: "input sm mono",
    value: k,
    placeholder: "nombre",
    "data-k": `var-k-${i}`,
    onchange: (e) => {
      const pairs = Object.entries(flow.variables);
      pairs[i] = [e.target.value.trim(), v];
      write(pairs);
      saveNow(flow);
    }
  }), h("input", {
    class: "input sm",
    value: v,
    placeholder: "valor",
    "data-k": `var-v-${i}`,
    oninput: (e) => {
      flow.variables[k] = e.target.value;
      saveSoon(flow);
    }
  }), h("button", {
    class: "icon",
    title: "Quitar",
    onclick: () => {
      delete flow.variables[k];
      saveNow(flow);
    }
  }, "×"))), h("button", {
    class: "btn sm ghost",
    onclick: () => {
      let n = 1;
      while (`var${n}` in flow.variables)
        n++;
      flow.variables[`var${n}`] = "";
      saveNow(flow);
    }
  }, "+ Variable"));
}
function summaryValue(s) {
  if (s.value == null || s.value === "")
    return "";
  if (s.secret)
    return "••••••";
  if (s.type === "check")
    return s.value === "false" ? "desmarcar" : "marcar";
  if (s.type === "select")
    return s.optionText || s.value;
  if (s.type === "wait")
    return `${s.value} ms`;
  return s.value;
}
function stepRow(flow, s, i, run) {
  const meta = STEP_META[s.type];
  const open = state.expanded.has(s.id);
  const status = run?.status[s.id];
  const info = run?.info[s.id];
  const title = s.type === "navigate" ? s.label || s.value || "URL" : s.type === "press" ? s.value || "Enter" : s.type === "wait" ? "" : s.label || s.selector || "sin elemento";
  const val = s.type === "navigate" || s.type === "press" ? "" : summaryValue(s);
  const toggle = () => {
    open ? state.expanded.delete(s.id) : state.expanded.add(s.id);
    render();
  };
  const li = h("li", {
    class: `step t-${s.type}${open ? " open" : ""}${s.enabled ? "" : " disabled"}${status ? " st-" + status : ""}${state.dragId === s.id ? " dragging" : ""}`,
    "data-step": s.id,
    ondragstart: (e) => {
      state.dragId = s.id;
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", s.id);
    },
    ondragend: () => {
      state.dragId = undefined;
      li.draggable = false;
      render();
    },
    ondragover: (e) => {
      if (!state.dragId || state.dragId === s.id)
        return;
      e.preventDefault();
      const r = li.getBoundingClientRect();
      li.classList.toggle("drop-before", e.clientY < r.top + r.height / 2);
      li.classList.toggle("drop-after", e.clientY >= r.top + r.height / 2);
    },
    ondragleave: () => li.classList.remove("drop-before", "drop-after"),
    ondrop: (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!state.dragId || state.dragId === s.id)
        return;
      const after = li.classList.contains("drop-after");
      const next = after ? flow.steps[i + 1]?.id ?? null : s.id;
      moveStep(flow, state.dragId, next === state.dragId ? s.id : next);
    }
  }, h("div", { class: "step-h" }, h("span", {
    class: "grip",
    title: "Arrastrar para reordenar",
    onmousedown: () => li.draggable = true,
    onmouseup: () => li.draggable = false
  }, "⋮⋮"), h("span", { class: "num" }, String(i + 1)), h("span", { class: "badge", title: meta.label }, meta.icon), h("button", { class: "step-title", onclick: toggle }, h("b", null, meta.label), title && h("span", { class: "lbl" }, title), !!s.frame?.length && h("span", { class: "frame-tag", title: "Dentro de iframe: " + s.frame.map((f) => f.selector).join(" » ") }, s.frame.length > 1 ? `iframe ×${s.frame.length}` : "iframe"), val && h("span", { class: "val" }, val)), h("span", { class: "status", title: info ?? status ?? "" }, statusIcon(status))), status === "error" && info && h("div", { class: "step-err" }, info), open && stepDetails(flow, s, i));
  return li;
}
function statusIcon(st) {
  switch (st) {
    case "running":
      return h("span", { class: "spin" });
    case "ok":
      return "✓";
    case "error":
      return "✗";
    case "skipped":
      return "–";
    default:
      return "";
  }
}
function stepDetails(flow, s, i) {
  const meta = STEP_META[s.type];
  const save = () => saveSoon(flow);
  const field = (label, ...control) => h("label", { class: "field" }, h("span", null, label), ...control);
  const targetable = meta.needsTarget || s.type === "press";
  return h("div", { class: "step-body" }, field("Tipo", h("select", {
    class: "input sm",
    onchange: (e) => {
      s.type = e.target.value;
      saveNow(flow);
    }
  }, TYPES.map((t) => h("option", { value: t, selected: t === s.type }, `${STEP_META[t].icon}  ${STEP_META[t].label}`)))), targetable && field(s.type === "press" ? "Elemento (opcional)" : "Elemento", h("div", { class: "row tight" }, h("input", {
    class: "input sm mono grow",
    value: s.selector ?? "",
    placeholder: "css, text=…, label=…, xpath=…, A >> B",
    "data-k": `sel-${s.id}`,
    oninput: (e) => {
      s.selector = e.target.value || undefined;
      save();
    }
  }), h("button", { class: "icon", title: "Apuntar en la página", disabled: !!state.picking, onclick: () => pickFor(flow, s) }, "\uD83C\uDFAF"), h("button", { class: "icon", title: "Resaltar en la página", disabled: !s.selector, onclick: () => highlightStep(s) }, "\uD83D\uDC41"))), targetable && frameField(flow, s, field), targetable && !!s.fallbacks?.length && h("details", { class: "fallbacks" }, h("summary", null, `${s.fallbacks.length} selector(es) alternativo(s)`), h("textarea", {
    class: "input sm mono",
    rows: Math.min(5, s.fallbacks.length),
    "data-k": `fb-${s.id}`,
    value: s.fallbacks.join(`
`),
    oninput: (e) => {
      s.fallbacks = e.target.value.split(`
`).map((x) => x.trim()).filter(Boolean);
      save();
    }
  })), targetable && field("Nombre", h("input", {
    class: "input sm",
    value: s.label ?? "",
    placeholder: "Descripción legible",
    "data-k": `lbl-${s.id}`,
    oninput: (e) => {
      s.label = e.target.value || undefined;
      save();
    }
  })), s.type !== "click" && s.type !== "waitFor" && valueField(flow, s, field), h("div", { class: "row two" }, s.type !== "navigate" && s.type !== "wait" && field("Timeout (ms)", h("input", {
    class: "input sm",
    type: "number",
    min: 0,
    step: 500,
    placeholder: String(state.settings.timeout),
    value: s.timeout ?? "",
    "data-k": `to-${s.id}`,
    oninput: (e) => {
      const v = e.target.valueAsNumber;
      s.timeout = Number.isFinite(v) ? v : undefined;
      save();
    }
  })), field("Nota", h("input", {
    class: "input sm",
    value: s.note ?? "",
    "data-k": `note-${s.id}`,
    oninput: (e) => {
      s.note = e.target.value || undefined;
      save();
    }
  }))), h("div", { class: "row step-foot" }, h("label", { class: "toggle" }, h("input", {
    type: "checkbox",
    checked: s.enabled,
    onchange: (e) => {
      s.enabled = e.target.checked;
      saveNow(flow);
    }
  }), "Activo"), h("span", { class: "grow" }), h("button", { class: "btn sm ghost", title: "Ejecutar solo este paso", disabled: runner.running, onclick: () => play(flow, i, i) }, "▶ Solo este"), h("button", { class: "btn sm ghost", title: "Reproducir desde este paso", disabled: runner.running, onclick: () => play(flow, i) }, "▶ Desde aquí"), h("button", { class: "icon", title: "Duplicar paso", onclick: () => duplicateStep(flow, s) }, "⧉"), h("button", { class: "icon danger", title: "Borrar paso", onclick: () => deleteStep(flow, s) }, "\uD83D\uDDD1")));
}
var FRAME_SEP = " >> ";
function frameField(flow, s, field) {
  return field("Iframe", h("input", {
    class: "input sm mono",
    value: (s.frame ?? []).map((f) => f.selector).join(FRAME_SEP),
    placeholder: "— página principal —   (iframe#pago >> iframe[name=cvc])",
    "data-k": `frame-${s.id}`,
    oninput: (e) => {
      const parts = e.target.value.split(">>").map((x) => x.trim()).filter(Boolean);
      s.frame = parts.length ? parts.map((sel, i) => s.frame?.[i]?.selector === sel ? s.frame[i] : { selector: sel }) : undefined;
      saveSoon(flow);
    }
  }), !!s.frame?.length && h("small", { class: "muted" }, "Ruta de iframes desde la página principal, separada por >>"));
}
function valueField(flow, s, field) {
  const meta = STEP_META[s.type];
  const onVal = (e) => {
    s.value = e.target.value;
    saveSoon(flow);
  };
  if (s.type === "check") {
    return field("Estado", h("select", {
      class: "input sm",
      onchange: (e) => {
        s.value = e.target.value;
        saveNow(flow);
      }
    }, h("option", { value: "true", selected: s.value !== "false" }, "☑ Marcado"), h("option", { value: "false", selected: s.value === "false" }, "☐ Desmarcado")));
  }
  const labels = { navigate: "URL", fill: "Texto", select: "Opción (value)", press: "Tecla", wait: "Milisegundos", assertText: "Texto esperado" };
  const input = h("input", {
    class: "input sm" + (s.type === "navigate" ? " mono" : ""),
    type: s.secret ? "password" : s.type === "wait" ? "number" : "text",
    value: s.value ?? "",
    placeholder: meta.valueHint ?? "",
    list: s.type === "press" ? "keys" : null,
    "data-k": `val-${s.id}`,
    oninput: onVal
  });
  return field(labels[s.type] ?? "Valor", h("div", { class: "row tight" }, s.type === "fill" ? h("textarea", { class: "input sm grow", rows: 1, value: s.value ?? "", "data-k": `val-${s.id}`, placeholder: meta.valueHint, oninput: onVal, style: s.secret ? "-webkit-text-security: disc" : undefined }) : input, s.type === "fill" && h("button", {
    class: "icon",
    title: s.secret ? "Mostrar (deja de ser secreto)" : "Marcar como secreto",
    onclick: () => {
      s.secret = !s.secret || undefined;
      saveNow(flow);
    }
  }, s.secret ? "\uD83D\uDD12" : "\uD83D\uDD13")), s.type === "select" && !!s.optionText && h("small", { class: "muted" }, `Texto visible: «${s.optionText}»`), s.type === "press" && h("datalist", { id: "keys" }, ["Enter", "Tab", "Escape", "ArrowDown", "ArrowUp", "Backspace", " "].map((k) => h("option", { value: k }))));
}
function addStepMenu(flow) {
  return h("details", { class: "menu add-step" }, h("summary", { class: "btn ghost sm" }, "+ Añadir paso"), h("div", { class: "menu-list" }, TYPES.map((t) => h("button", {
    onclick: (e) => {
      e.target.closest("details").open = false;
      const step = addStep(flow, t);
      setTimeout(() => document.querySelector(`[data-step="${step.id}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" }), 50);
    }
  }, `${STEP_META[t].icon}  ${STEP_META[t].label}`))));
}

// src/panel/views/library.ts
function libraryView() {
  const flows = filteredFlows();
  const folders = allFolders();
  const tags = allTags();
  const sel = [...state.selected].filter((id) => state.flows.some((f) => f.id === id));
  const groups = new Map;
  for (const f of flows) {
    const k = f.folder ?? "";
    if (!groups.has(k))
      groups.set(k, []);
    groups.get(k).push(f);
  }
  const groupKeys = [...groups.keys()].sort((a, b) => a === "" ? 1 : b === "" ? -1 : a.localeCompare(b));
  return h("div", { class: "view" }, h("header", { class: "top" }, h("div", { class: "brand" }, h("span", { class: "logo" }), "Rastro"), h("div", { class: "row" }, h("button", { class: "icon", title: "Importar", onclick: importFile }, "⇪"), h("button", { class: "icon", title: "Exportar todo", onclick: () => exportFlows(state.flows) }, "⇩"), h("button", { class: "icon", title: "Ajustes", onclick: () => (state.view = "settings", render()) }, "⚙"))), h("div", { class: "toolbar" }, h("input", {
    class: "input search",
    type: "search",
    placeholder: "Buscar por nombre, #etiqueta, URL, campo…",
    value: state.filter.q,
    "data-k": "search",
    oninput: (e) => {
      state.filter.q = e.target.value;
      render();
    }
  }), h("button", { class: "btn primary", onclick: createFlow }, "+ Nuevo")), (folders.length > 0 || tags.length > 0) && h("div", { class: "filters" }, h("select", {
    class: "input sm",
    onchange: (e) => {
      state.filter.folder = e.target.value;
      render();
    }
  }, h("option", { value: "", selected: state.filter.folder === "" }, "Todas las carpetas"), h("option", { value: "__none", selected: state.filter.folder === "__none" }, "Sin carpeta"), folders.map((f) => h("option", { value: f, selected: state.filter.folder === f }, "\uD83D\uDCC1 " + f))), h("select", {
    class: "input sm",
    onchange: (e) => {
      state.filter.sort = e.target.value;
      render();
    }
  }, h("option", { value: "updated", selected: state.filter.sort === "updated" }, "Recientes"), h("option", { value: "name", selected: state.filter.sort === "name" }, "Nombre"), h("option", { value: "lastRun", selected: state.filter.sort === "lastRun" }, "Última ejecución")), tags.length > 0 && h("div", { class: "chips" }, tags.map((t) => h("button", {
    class: "chip" + (state.filter.tags.has(t) ? " on" : ""),
    onclick: () => {
      state.filter.tags.has(t) ? state.filter.tags.delete(t) : state.filter.tags.add(t);
      render();
    }
  }, "#" + t)))), sel.length > 0 && h("div", { class: "bulk" }, h("span", null, `${sel.length} seleccionado(s)`), h("button", { class: "btn sm", onclick: () => exportFlows(state.flows.filter((f) => sel.includes(f.id))) }, "Exportar"), h("button", { class: "btn sm", onclick: () => bulkMove(sel) }, "Mover"), h("button", { class: "btn sm", onclick: () => bulkTag(sel) }, "Etiquetar"), h("button", { class: "btn sm danger", onclick: () => removeFlows(sel) }, "Borrar"), h("button", { class: "icon", title: "Quitar selección", onclick: () => (state.selected.clear(), render()) }, "✕")), h("main", { class: "scroll", "data-scroll": "library" }, state.flows.length === 0 ? emptyState() : flows.length === 0 ? h("p", { class: "empty muted" }, "Ningún flujo coincide con el filtro.") : groupKeys.map((k) => folderGroup(k, groups.get(k), groupKeys.length > 1 || k !== ""))));
}
function folderGroup(name, flows, showHeader) {
  const key = name || "__none";
  const collapsed = state.collapsedFolders.has(key);
  return h("section", { class: "group" }, showHeader && h("button", {
    class: "group-h",
    onclick: () => {
      collapsed ? state.collapsedFolders.delete(key) : state.collapsedFolders.add(key);
      render();
    }
  }, h("span", { class: "caret" + (collapsed ? "" : " open") }, "▸"), name ? "\uD83D\uDCC1 " + name : "Sin carpeta", h("span", { class: "count" }, String(flows.length))), !collapsed && flows.map(flowCard));
}
function flowCard(f) {
  const host = hostOf(f.steps.find((s) => s.type === "navigate")?.value);
  const running = runner.running && state.run?.flowId === f.id;
  return h("article", { class: "card" + (state.selected.has(f.id) ? " selected" : "") }, h("input", {
    type: "checkbox",
    class: "check",
    checked: state.selected.has(f.id),
    title: "Seleccionar",
    onchange: (e) => {
      e.target.checked ? state.selected.add(f.id) : state.selected.delete(f.id);
      render();
    }
  }), h("div", { class: "card-body", onclick: () => openFlow(f.id) }, h("div", { class: "card-title" }, f.lastRun && h("span", { class: "dot " + (f.lastRun.ok ? "ok" : "err"), title: lastRunText(f) }), f.name), h("div", { class: "meta" }, `${f.steps.length} paso${f.steps.length === 1 ? "" : "s"}`, host && ` · ${host}`, ` · ${timeAgo(f.updatedAt)}`), f.tags.length > 0 && h("div", { class: "chips" }, f.tags.map((t) => h("span", { class: "chip static" }, "#" + t)))), h("div", { class: "card-actions" }, h("button", { class: "icon play", title: "Reproducir en la pestaña activa", disabled: runner.running, onclick: () => play(f) }, running ? "…" : "▶"), h("details", { class: "menu" }, h("summary", { class: "icon", title: "Más" }, "⋯"), h("div", { class: "menu-list" }, h("button", { onclick: () => duplicateFlow(f) }, "⧉ Duplicar"), h("button", { onclick: () => exportFlows([f]) }, "⇩ Exportar JSON"), h("button", { onclick: () => exportPuppeteer(f) }, "⇩ Exportar a Puppeteer"), h("button", { onclick: () => exportDevTools(f) }, "⇩ Exportar a DevTools Recorder"), h("button", { class: "danger", onclick: () => removeFlows([f.id]) }, "\uD83D\uDDD1 Borrar")))));
}
function lastRunText(f) {
  const r = f.lastRun;
  return r.ok ? `OK ${timeAgo(r.at)} (${(r.ms / 1000).toFixed(1)}s)` : `Falló ${timeAgo(r.at)}: ${r.error}`;
}
function emptyState() {
  return h("div", { class: "empty" }, h("div", { class: "empty-art" }, "◉ → ⌨ → ⏎"), h("h2", null, "Graba tu primer flujo"), h("ol", { class: "muted" }, h("li", null, "Crea un flujo y abre la web que quieras automatizar."), h("li", null, "Pulsa ", h("b", null, "Grabar"), " y usa la página con normalidad: los botones se graban como click y los inputs como «escribir» con su contenido."), h("li", null, "Edita, reordena y dale a ", h("b", null, "Reproducir"), ".")), h("div", { class: "row center" }, h("button", { class: "btn primary", onclick: createFlow }, "+ Nuevo flujo"), h("button", { class: "btn", onclick: importFile }, "Importar")));
}
async function importFile() {
  const file = await pickFile();
  if (file)
    await importText(await file.text());
}

// src/panel/views/settings.ts
function settingsView() {
  const s = state.settings;
  const set = (k, v) => {
    s[k] = v;
    saveSettings(s);
  };
  const num = (k, label, hint) => h("label", { class: "field" }, h("span", null, label), h("input", {
    class: "input sm",
    type: "number",
    min: 0,
    step: k === "keyDelay" ? 5 : 100,
    value: s[k],
    "data-k": "set-" + k,
    oninput: (e) => {
      const v = e.target.valueAsNumber;
      if (Number.isFinite(v) && v >= 0)
        set(k, v);
    }
  }), h("small", { class: "muted" }, hint));
  return h("div", { class: "view" }, h("header", { class: "top" }, h("button", { class: "btn ghost sm", onclick: () => (state.view = "library", render()) }, "← Flujos"), h("b", null, "Ajustes")), h("main", { class: "scroll settings", "data-scroll": "settings" }, h("h3", null, "Reproducción"), num("timeout", "Timeout por paso (ms)", "Cuánto esperar a que aparezca un elemento antes de fallar."), num("stepDelay", "Pausa entre pasos (ms)", "Útil para ver lo que pasa o para webs lentas."), h("label", { class: "field" }, h("span", null, "Forma de escribir"), h("select", {
    class: "input sm",
    onchange: (e) => {
      set("typeMode", e.target.value);
      render();
    }
  }, h("option", { value: "instant", selected: s.typeMode === "instant" }, "De golpe (rápido)"), h("option", { value: "keys", selected: s.typeMode === "keys" }, "Tecla a tecla (realista)")), h("small", { class: "muted" }, "Tecla a tecla dispara keydown/keyup: útil para autocompletados y máscaras.")), s.typeMode === "keys" && num("keyDelay", "Pausa entre teclas (ms)", ""), h("label", { class: "toggle" }, h("input", { type: "checkbox", checked: s.highlight, onchange: (e) => set("highlight", e.target.checked) }), "Resaltar cada elemento antes de actuar"), h("label", { class: "toggle" }, h("input", {
    type: "checkbox",
    checked: s.autoWait,
    onchange: (e) => {
      set("autoWait", e.target.checked);
      render();
    }
  }), "Esperar a que la página termine de cargar antes de cada acción"), h("small", { class: "muted" }, "Antes de actuar espera a que no haya peticiones en curso ni loaders visibles, y a que el elemento esté habilitado y sin nada encima."), s.autoWait && h("label", { class: "field" }, h("span", null, "Selector de loaders propios"), h("input", {
    class: "input sm",
    type: "text",
    placeholder: ".mi-loader, #overlay-cargando",
    value: s.loaderSelector,
    oninput: (e) => {
      const inp = e.target;
      let ok = true;
      try {
        if (inp.value.trim())
          document.querySelector(inp.value);
      } catch {
        ok = false;
      }
      inp.setCustomValidity(ok ? "" : "Selector CSS no válido");
      inp.reportValidity();
      if (ok)
        set("loaderSelector", inp.value);
    }
  }), h("small", { class: "muted" }, "Opcional. Se suma a los loaders de Element Plus, Ant, Vuetify, MUI, Bootstrap… Mientras alguno sea visible, Rastro espera.")), h("div", { class: "row" }, h("button", {
    class: "btn sm ghost",
    onclick: () => {
      state.settings = { ...DEFAULT_SETTINGS };
      saveSettings(state.settings);
      render();
      toast("Ajustes restablecidos", "ok");
    }
  }, "Restablecer")), h("h3", null, "Selectores"), h("p", { class: "muted small" }, "Rastro genera varios selectores por elemento y prueba los alternativos si falla el principal. Orden de preferencia: ", h("code", null, "data-testid"), ", ", h("code", null, "#id"), " estable, ", h("code", null, "name"), ", ", h("code", null, "label=…"), ", ", h("code", null, "aria-label"), ", ", h("code", null, "placeholder"), ", ", h("code", null, "text=…"), " y por último ruta CSS. Ids y clases con pinta de autogeneradas se ignoran. Añadir ", h("code", null, "data-testid"), " a la app es lo que da los flujos más robustos."), h("h3", null, "Datos"), h("p", { class: "muted small" }, `${state.flows.length} flujo(s), ${state.flows.reduce((n, f) => n + f.steps.length, 0)} paso(s). Se guardan en el almacenamiento local de la extensión, en este navegador.`)));
}

// src/panel/main.ts
var app = document.getElementById("app");
var scheduled = false;
setRender(() => {
  if (scheduled)
    return;
  scheduled = true;
  queueMicrotask(() => {
    scheduled = false;
    const flow = current();
    if (state.view === "editor" && !flow)
      state.view = "library";
    const view = state.view === "editor" ? editorView(flow) : state.view === "settings" ? settingsView() : libraryView();
    morph(app, view);
  });
});
async function boot() {
  [state.flows, state.settings, state.recording] = await Promise.all([listFlows(), getSettings(), getRecording()]);
  render();
  chrome.storage.onChanged.addListener((changes, area) => {
    let dirty = false;
    let appended = false;
    if (area === "local") {
      for (const [k, { newValue }] of Object.entries(changes)) {
        if (isFlowKey(k)) {
          const id = k.slice(5);
          const i = state.flows.findIndex((f) => f.id === id);
          if (!newValue) {
            if (i >= 0)
              state.flows.splice(i, 1);
          } else if (i >= 0) {
            appended ||= newValue.steps.length > state.flows[i].steps.length;
            state.flows[i] = newValue;
          } else
            state.flows.unshift(newValue);
          dirty = true;
        } else if (k === "settings") {
          state.settings = { ...state.settings, ...newValue };
        }
      }
    }
    if (area === "session" && RECORDING_STORAGE_KEY in changes) {
      state.recording = changes[RECORDING_STORAGE_KEY].newValue;
      dirty = true;
    }
    if (!dirty)
      return;
    render();
    if (appended && state.recording?.flowId === state.currentId) {
      setTimeout(() => {
        const el = document.querySelector("[data-scroll]");
        el?.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
      }, 30);
    }
  });
}
document.addEventListener("click", (e) => {
  for (const d of document.querySelectorAll("details.menu[open]")) {
    if (!d.contains(e.target))
      d.open = false;
  }
});
document.addEventListener("dragover", (e) => {
  if (e.dataTransfer?.types.includes("Files")) {
    e.preventDefault();
    document.body.classList.add("dropping");
  }
});
document.addEventListener("dragleave", (e) => {
  if (!e.relatedTarget)
    document.body.classList.remove("dropping");
});
document.addEventListener("drop", async (e) => {
  const file = e.dataTransfer?.files?.[0];
  document.body.classList.remove("dropping");
  if (!file)
    return;
  e.preventDefault();
  await importText(await file.text());
});
boot();

//# debugId=DEAD6C8591F16AA664756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC90eXBlcy50cyIsICJzcmMvc2hhcmVkL3V0aWwudHMiLCAic3JjL3NoYXJlZC9zdG9yZS50cyIsICJzcmMvc2hhcmVkL2RldnRvb2xzLnRzIiwgInNyYy9zaGFyZWQvZXhwb3J0ZXJzLnRzIiwgInNyYy9wYW5lbC9ydW5uZXIudHMiLCAic3JjL3BhbmVsL3VpLnRzIiwgInNyYy9wYW5lbC9zdGF0ZS50cyIsICJzcmMvcGFuZWwvdmlld3MvZWRpdG9yLnRzIiwgInNyYy9wYW5lbC92aWV3cy9saWJyYXJ5LnRzIiwgInNyYy9wYW5lbC92aWV3cy9zZXR0aW5ncy50cyIsICJzcmMvcGFuZWwvbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsKICAgICJleHBvcnQgdHlwZSBTdGVwVHlwZSA9XG4gIHwgXCJuYXZpZ2F0ZVwiIC8vIGlyIGEgdW5hIFVSTFxuICB8IFwiY2xpY2tcIiAvLyBjbGljayBlbiBib3TDs24vZW5sYWNlL2N1YWxxdWllciBjb3NhXG4gIHwgXCJmaWxsXCIgLy8gZXNjcmliaXIgZW4gaW5wdXQvdGV4dGFyZWEvY29udGVudGVkaXRhYmxlXG4gIHwgXCJzZWxlY3RcIiAvLyBlbGVnaXIgb3BjacOzbiBkZSB1biA8c2VsZWN0PlxuICB8IFwiY2hlY2tcIiAvLyBtYXJjYXIvZGVzbWFyY2FyIGNoZWNrYm94IG8gcmFkaW9cbiAgfCBcInByZXNzXCIgLy8gcHVsc2FyIHVuYSB0ZWNsYSAoRW50ZXIsIFRhYuKApilcbiAgfCBcIndhaXRcIiAvLyBlc3BlcmFyIE4gbXNcbiAgfCBcIndhaXRGb3JcIiAvLyBlc3BlcmFyIGEgcXVlIGFwYXJlemNhIHVuIGVsZW1lbnRvXG4gIHwgXCJhc3NlcnRUZXh0XCI7IC8vIGNvbXByb2JhciBxdWUgdW4gZWxlbWVudG8gY29udGllbmUgdW4gdGV4dG9cblxuLyoqIFVuIG5pdmVsIGRlIGxhIHJ1dGEgaGFzdGEgdW4gaWZyYW1lOiBzZWxlY3RvcmVzIGRlbCBlbGVtZW50byA8aWZyYW1lPiBlbiBzdSBkb2N1bWVudG8uICovXG5leHBvcnQgaW50ZXJmYWNlIEZyYW1lUmVmIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgZmFsbGJhY2tzPzogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RlcCB7XG4gIGlkOiBzdHJpbmc7XG4gIHR5cGU6IFN0ZXBUeXBlO1xuICAvKiogUnV0YSBkZSBpZnJhbWVzIGRlc2RlIGxhIHDDoWdpbmEgcHJpbmNpcGFsIGhhc3RhIGVsIGRvY3VtZW50byBkZWwgZWxlbWVudG8gKHZhY8OtbyA9IHDDoWdpbmEgcHJpbmNpcGFsKS4gKi9cbiAgZnJhbWU/OiBGcmFtZVJlZltdO1xuICAvKiogU2VsZWN0b3IgcHJpbmNpcGFsIChlZGl0YWJsZSkuIEFkbWl0ZSBDU1MsIGB0ZXh0PeKApmAgeSBgeHBhdGg94oCmYC4gKi9cbiAgc2VsZWN0b3I/OiBzdHJpbmc7XG4gIC8qKiBTZWxlY3RvcmVzIGFsdGVybmF0aXZvcyBxdWUgc2UgcHJ1ZWJhbiBzaSBmYWxsYSBlbCBwcmluY2lwYWwuICovXG4gIGZhbGxiYWNrcz86IHN0cmluZ1tdO1xuICAvKiogRGVzY3JpcGNpw7NuIGxlZ2libGU6IMKrRW1haWzCuywgwqtFbnZpYXLCu+KApiAqL1xuICBsYWJlbD86IHN0cmluZztcbiAgLyoqIFRleHRvIGEgZXNjcmliaXIsIG9wY2nDs24sIFVSTCwgdGVjbGEsIG1zLCB0ZXh0byBlc3BlcmFkbyBvIFwidHJ1ZVwiL1wiZmFsc2VcIiBwYXJhIGNoZWNrLiAqL1xuICB2YWx1ZT86IHN0cmluZztcbiAgLyoqIFBhcmEgPHNlbGVjdD46IHRleHRvIHZpc2libGUgZGUgbGEgb3BjacOzbiAocG9yIHNpIGNhbWJpYSBlbCB2YWx1ZSkuICovXG4gIG9wdGlvblRleHQ/OiBzdHJpbmc7XG4gIC8qKiBFbCB2YWxvciBlcyBzZW5zaWJsZSAocGFzc3dvcmQpOiBzZSBlbm1hc2NhcmEgZW4gbGEgVUkuICovXG4gIHNlY3JldD86IGJvb2xlYW47XG4gIGVuYWJsZWQ6IGJvb2xlYW47XG4gIC8qKiBUaW1lb3V0IHByb3BpbyBlbiBtcyAoc2kgbm8sIGVsIGdsb2JhbCkuICovXG4gIHRpbWVvdXQ/OiBudW1iZXI7XG4gIG5vdGU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmxvdyB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGZvbGRlcj86IHN0cmluZztcbiAgdGFnczogc3RyaW5nW107XG4gIC8qKiBWYXJpYWJsZXMgdXNhYmxlcyBjb21vIHt7bm9tYnJlfX0gZW4gbG9zIHZhbG9yZXMgZGUgbG9zIHBhc29zLiAqL1xuICB2YXJpYWJsZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIHN0ZXBzOiBTdGVwW107XG4gIGNyZWF0ZWRBdDogbnVtYmVyO1xuICB1cGRhdGVkQXQ6IG51bWJlcjtcbiAgbGFzdFJ1bj86IFJ1blN1bW1hcnk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU3VtbWFyeSB7XG4gIGF0OiBudW1iZXI7XG4gIG9rOiBib29sZWFuO1xuICBtczogbnVtYmVyO1xuICBmYWlsZWRTdGVwSWQ/OiBzdHJpbmc7XG4gIGVycm9yPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNldHRpbmdzIHtcbiAgLyoqIFRpZW1wbyBtw6F4aW1vIGVzcGVyYW5kbyBhIHVuIGVsZW1lbnRvLiAqL1xuICB0aW1lb3V0OiBudW1iZXI7XG4gIC8qKiBQYXVzYSBlbnRyZSBwYXNvcyBkdXJhbnRlIGxhIHJlcHJvZHVjY2nDs24uICovXG4gIHN0ZXBEZWxheTogbnVtYmVyO1xuICAvKiogRXNjcmliaXIgY2Fyw6FjdGVyIGEgY2Fyw6FjdGVyIChtw6FzIHJlYWxpc3RhKSBvIGRlIGdvbHBlLiAqL1xuICB0eXBlTW9kZTogXCJpbnN0YW50XCIgfCBcImtleXNcIjtcbiAgLyoqIFBhdXNhIGVudHJlIHRlY2xhcyBlbiBtb2RvIFwia2V5c1wiLiAqL1xuICBrZXlEZWxheTogbnVtYmVyO1xuICAvKiogUmVzYWx0YXIgZWwgZWxlbWVudG8gYW50ZXMgZGUgYWN0dWFyLiAqL1xuICBoaWdobGlnaHQ6IGJvb2xlYW47XG4gIC8qKiBBbnRlcyBkZSBjYWRhIGFjY2nDs24sIGVzcGVyYXIgYSBxdWUgbm8gaGF5YSBwZXRpY2lvbmVzL2xvYWRlcnMgeSBlbCBlbGVtZW50byBlc3TDqSBsaXN0by4gKi9cbiAgYXV0b1dhaXQ6IGJvb2xlYW47XG4gIC8qKiBTZWxlY3RvciBDU1MgZXh0cmEgZGUgbG9zIGxvYWRlcnMgcHJvcGlvcyBkZSBsYSBhcHAgKHNlIHN1bWEgYSBsb3MgZGUgbGlicmVyw61hcyBjb25vY2lkYXMpLiAqL1xuICBsb2FkZXJTZWxlY3Rvcjogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHRpbWVvdXQ6IDgwMDAsXG4gIHN0ZXBEZWxheTogMjUwLFxuICB0eXBlTW9kZTogXCJpbnN0YW50XCIsXG4gIGtleURlbGF5OiAyNSxcbiAgaGlnaGxpZ2h0OiB0cnVlLFxuICBhdXRvV2FpdDogdHJ1ZSxcbiAgbG9hZGVyU2VsZWN0b3I6IFwiXCIsXG59O1xuXG4vKiogRXN0YWRvIGRlIGdyYWJhY2nDs24gKHZpdmUgZW4gc3RvcmFnZS5zZXNzaW9uKS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVjb3JkaW5nU3RhdGUge1xuICBmbG93SWQ6IHN0cmluZztcbiAgdGFiSWQ6IG51bWJlcjtcbiAgLyoqIHJlY29yZDogbGFzIGludGVyYWNjaW9uZXMgb2N1cnJlbiBkZSB2ZXJkYWQuIHBvaW50OiBzb2xvIHNlIHNlw7FhbGFuLCBsb3MgY2xpY2tzIG5vIHNlIGVqZWN1dGFuLiAqL1xuICBtb2RlOiBcInJlY29yZFwiIHwgXCJwb2ludFwiO1xuICBwYXVzZWQ6IGJvb2xlYW47XG59XG5cbi8qKiBGb3JtYXRvIGRlbCBmaWNoZXJvIGRlIGV4cG9ydGFjacOzbi4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRXhwb3J0RmlsZSB7XG4gIGZvcm1hdDogXCJyYXN0cm9cIjtcbiAgdmVyc2lvbjogMTtcbiAgZXhwb3J0ZWRBdDogc3RyaW5nO1xuICBmbG93czogRmxvd1tdO1xufVxuXG5leHBvcnQgY29uc3QgU1RFUF9NRVRBOiBSZWNvcmQ8U3RlcFR5cGUsIHsgbGFiZWw6IHN0cmluZzsgaWNvbjogc3RyaW5nOyBuZWVkc1RhcmdldDogYm9vbGVhbjsgdmFsdWVIaW50Pzogc3RyaW5nIH0+ID0ge1xuICBuYXZpZ2F0ZTogeyBsYWJlbDogXCJJciBhXCIsIGljb246IFwi4oaXXCIsIG5lZWRzVGFyZ2V0OiBmYWxzZSwgdmFsdWVIaW50OiBcImh0dHBzOi8v4oCmXCIgfSxcbiAgY2xpY2s6IHsgbGFiZWw6IFwiQ2xpY2tcIiwgaWNvbjogXCLil4lcIiwgbmVlZHNUYXJnZXQ6IHRydWUgfSxcbiAgZmlsbDogeyBsYWJlbDogXCJFc2NyaWJpclwiLCBpY29uOiBcIuKMqFwiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRleHRvIG8ge3t2YXJpYWJsZX19XCIgfSxcbiAgc2VsZWN0OiB7IGxhYmVsOiBcIlNlbGVjY2lvbmFyXCIsIGljb246IFwi4piwXCIsIG5lZWRzVGFyZ2V0OiB0cnVlLCB2YWx1ZUhpbnQ6IFwidmFsdWUgZGUgbGEgb3BjacOzblwiIH0sXG4gIGNoZWNrOiB7IGxhYmVsOiBcIk1hcmNhclwiLCBpY29uOiBcIuKYkVwiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRydWUgLyBmYWxzZVwiIH0sXG4gIHByZXNzOiB7IGxhYmVsOiBcIlRlY2xhXCIsIGljb246IFwi4o+OXCIsIG5lZWRzVGFyZ2V0OiBmYWxzZSwgdmFsdWVIaW50OiBcIkVudGVyLCBUYWIsIEVzY2FwZeKAplwiIH0sXG4gIHdhaXQ6IHsgbGFiZWw6IFwiRXNwZXJhclwiLCBpY29uOiBcIuKPsVwiLCBuZWVkc1RhcmdldDogZmFsc2UsIHZhbHVlSGludDogXCJtaWxpc2VndW5kb3NcIiB9LFxuICB3YWl0Rm9yOiB7IGxhYmVsOiBcIkVzcGVyYXIgYVwiLCBpY29uOiBcIuKMm1wiLCBuZWVkc1RhcmdldDogdHJ1ZSB9LFxuICBhc3NlcnRUZXh0OiB7IGxhYmVsOiBcIkNvbXByb2JhclwiLCBpY29uOiBcIuKck1wiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRleHRvIGVzcGVyYWRvXCIgfSxcbn07XG4iLAogICAgImV4cG9ydCBjb25zdCB1aWQgPSAoKTogc3RyaW5nID0+IGNyeXB0by5yYW5kb21VVUlEKCkuc2xpY2UoMCwgOCkgKyBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KS5zbGljZSgtNCk7XG5cbi8qKiDCv1BhcmVjZSB1biBpZC9jbGFzZSBhdXRvZ2VuZXJhZG8gKGhhc2hlcywgY29udGFkb3JlcywgaWRzIGRlIFJlYWN0L0VsZW1lbnQgUGx1c+KApik/ICovXG5leHBvcnQgZnVuY3Rpb24gbG9va3NHZW5lcmF0ZWQoczogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgcy5sZW5ndGggPiA0MCB8fFxuICAgIC9cXGR7NCx9Ly50ZXN0KHMpIHx8XG4gICAgL1stXzpdXFxkK1stXzpdXFxkKyQvLnRlc3QocykgfHwgLy8gcHJlZmlqby1hbGVhdG9yaW8tY29udGFkb3I6IGVsLWlkLTc0NC0xNjUsIGlucHV0LTEyLTNcbiAgICAvXlthLWYwLTktXXsxMCx9JC9pLnRlc3QocykgfHxcbiAgICAvXjpyWzAtOWEtel0rOj8kLy50ZXN0KHMpIHx8IC8vIFJlYWN0IHVzZUlkXG4gICAgL14oZW1iZXJ8ZXh0LWdlbnxyZWFjdC18bXVpLXxyYWRpeC18aGVhZGxlc3N1aS18ZG93bnNoaWZ0LXxyYy18ZWwtaWQtfHYtXFxkfGlucHV0LVxcZCkvaS50ZXN0KHMpIHx8XG4gICAgKC9bXy1dW2EtekEtWjAtOV17NSx9JC8udGVzdChzKSAmJiAvXFxkLipcXGQvLnRlc3Qocy5zbGljZSgtNikpKSB8fCAvLyBjc3MtbW9kdWxlczogYnRuX3gzRjlhXG4gICAgL14oY3NzfHNjfGpzeHxlbW90aW9ufHN2ZWx0ZSktW2EtejAtOV0rJC9pLnRlc3QocylcbiAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG5cbi8qKiBWYXJpYWJsZXMgaW50ZWdyYWRhczoge3skdGltZXN0YW1wfX0sIHt7JHV1aWR9fSwge3skcmFuZG9tRW1haWx9fSwge3skcmFuZG9tSW50fX0sIHt7JHRvZGF5fX0gKi9cbmZ1bmN0aW9uIGJ1aWx0aW4obmFtZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgc3dpdGNoIChuYW1lKSB7XG4gICAgY2FzZSBcIiR0aW1lc3RhbXBcIjpcbiAgICAgIHJldHVybiBTdHJpbmcoRGF0ZS5ub3coKSk7XG4gICAgY2FzZSBcIiR1dWlkXCI6XG4gICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjYXNlIFwiJHJhbmRvbUludFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxXzAwMF8wMDApKTtcbiAgICBjYXNlIFwiJHJhbmRvbUVtYWlsXCI6XG4gICAgICByZXR1cm4gYHRlc3QrJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX0ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApfUBleGFtcGxlLmNvbWA7XG4gICAgY2FzZSBcIiR0b2RheVwiOlxuICAgICAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuLyoqIFN1c3RpdHV5ZSB7e3ZhcmlhYmxlfX0gcG9yIHN1IHZhbG9yLiBMYXMgZGVzY29ub2NpZGFzIHNlIGRlamFuIHRhbCBjdWFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlKHRleHQ6IHN0cmluZywgdmFyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0LnJlcGxhY2UoL1xce1xce1xccyooWyRcXHcuLV0rKVxccypcXH1cXH0vZywgKG0sIG5hbWU6IHN0cmluZykgPT4gdmFyc1tuYW1lXSA/PyBidWlsdGluKG5hbWUpID8/IG0pO1xufVxuXG5leHBvcnQgY29uc3QgQlVJTFRJTl9WQVJTID0gW1wiJHRpbWVzdGFtcFwiLCBcIiR1dWlkXCIsIFwiJHJhbmRvbUVtYWlsXCIsIFwiJHJhbmRvbUludFwiLCBcIiR0b2RheVwiXTtcbiIsCiAgICAiLy8gUGVyc2lzdGVuY2lhIGVuIGNocm9tZS5zdG9yYWdlLmxvY2FsLiBDYWRhIGZsdWpvIHZhIGVuIHN1IHByb3BpYSBjbGF2ZSAoZmxvdzo8aWQ+KVxuLy8gcGFyYSBxdWUgbGFzIGVzY3JpdHVyYXMgY29uY3VycmVudGVzIGRlbCBiYWNrZ3JvdW5kIChncmFiYW5kbykgeSBkZWwgcGFuZWwgKGVkaXRhbmRvKVxuLy8gbm8gc2UgcGlzZW4gZW50cmUgZmx1am9zIGRpc3RpbnRvcy5cbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIHR5cGUgRmxvdywgdHlwZSBSZWNvcmRpbmdTdGF0ZSwgdHlwZSBTZXR0aW5ncywgdHlwZSBTdGVwIH0gZnJvbSBcIi4vdHlwZXNcIjtcbmltcG9ydCB7IHVpZCB9IGZyb20gXCIuL3V0aWxcIjtcblxuY29uc3QgRkxPV19QUkVGSVggPSBcImZsb3c6XCI7XG5jb25zdCBTRVRUSU5HU19LRVkgPSBcInNldHRpbmdzXCI7XG5jb25zdCBSRUNPUkRJTkdfS0VZID0gXCJyZWNvcmRpbmdcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxpc3RGbG93cygpOiBQcm9taXNlPEZsb3dbXT4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQobnVsbCk7XG4gIHJldHVybiBPYmplY3QuZW50cmllcyhhbGwpXG4gICAgLmZpbHRlcigoW2tdKSA9PiBrLnN0YXJ0c1dpdGgoRkxPV19QUkVGSVgpKVxuICAgIC5tYXAoKFssIHZdKSA9PiB2IGFzIEZsb3cpXG4gICAgLnNvcnQoKGEsIGIpID0+IGIudXBkYXRlZEF0IC0gYS51cGRhdGVkQXQpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RmxvdyhpZDogc3RyaW5nKTogUHJvbWlzZTxGbG93IHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IGtleSA9IEZMT1dfUFJFRklYICsgaWQ7XG4gIHJldHVybiAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSkpW2tleV0gYXMgRmxvdyB8IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVGbG93KGZsb3c6IEZsb3csIHRvdWNoID0gdHJ1ZSk6IFByb21pc2U8Rmxvdz4ge1xuICBpZiAodG91Y2gpIGZsb3cudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW0ZMT1dfUFJFRklYICsgZmxvdy5pZF06IGZsb3cgfSk7XG4gIHJldHVybiBmbG93O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlRmxvd3MoaWRzOiBzdHJpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoaWRzLm1hcCgoaWQpID0+IEZMT1dfUFJFRklYICsgaWQpKTtcbn1cblxuLyoqIExlZS1tb2RpZmljYS1lc2NyaWJlIHVuIGZsdWpvLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUZsb3coaWQ6IHN0cmluZywgZm46IChmOiBGbG93KSA9PiB2b2lkLCB0b3VjaCA9IHRydWUpOiBQcm9taXNlPEZsb3cgfCB1bmRlZmluZWQ+IHtcbiAgY29uc3QgZmxvdyA9IGF3YWl0IGdldEZsb3coaWQpO1xuICBpZiAoIWZsb3cpIHJldHVybjtcbiAgZm4oZmxvdyk7XG4gIHJldHVybiBzYXZlRmxvdyhmbG93LCB0b3VjaCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdGbG93KHBhcnRpYWw6IFBhcnRpYWw8Rmxvdz4gPSB7fSk6IEZsb3cge1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICByZXR1cm4ge1xuICAgIGlkOiB1aWQoKSxcbiAgICBuYW1lOiBcIk51ZXZvIGZsdWpvXCIsXG4gICAgdGFnczogW10sXG4gICAgdmFyaWFibGVzOiB7fSxcbiAgICBzdGVwczogW10sXG4gICAgY3JlYXRlZEF0OiBub3csXG4gICAgdXBkYXRlZEF0OiBub3csXG4gICAgLi4ucGFydGlhbCxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1N0ZXAocGFydGlhbDogUGFydGlhbDxTdGVwPiAmIFBpY2s8U3RlcCwgXCJ0eXBlXCI+KTogU3RlcCB7XG4gIHJldHVybiB7IGlkOiB1aWQoKSwgZW5hYmxlZDogdHJ1ZSwgLi4ucGFydGlhbCB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBzID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChTRVRUSU5HU19LRVkpKVtTRVRUSU5HU19LRVldO1xuICByZXR1cm4geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi4ocyA/PyB7fSkgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU0VUVElOR1NfS0VZXTogcyB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY29yZGluZygpOiBQcm9taXNlPFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkPiB7XG4gIHJldHVybiAoYXdhaXQgY2hyb21lLnN0b3JhZ2Uuc2Vzc2lvbi5nZXQoUkVDT1JESU5HX0tFWSkpW1JFQ09SRElOR19LRVldIGFzIFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVjb3JkaW5nKHI6IFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyKSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5zZXNzaW9uLnNldCh7IFtSRUNPUkRJTkdfS0VZXTogciB9KTtcbiAgZWxzZSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5zZXNzaW9uLnJlbW92ZShSRUNPUkRJTkdfS0VZKTtcbn1cblxuZXhwb3J0IGNvbnN0IGlzRmxvd0tleSA9IChrOiBzdHJpbmcpID0+IGsuc3RhcnRzV2l0aChGTE9XX1BSRUZJWCk7XG5leHBvcnQgY29uc3QgUkVDT1JESU5HX1NUT1JBR0VfS0VZID0gUkVDT1JESU5HX0tFWTtcbiIsCiAgICAiLy8gQ29udmVyc2nDs24gZGVzZGUvaGFjaWEgZWwgZm9ybWF0byBKU09OIGRlbCBwYW5lbCDCq1JlY29yZGVywrsgZGUgQ2hyb21lIERldlRvb2xzLlxuLy8gRm9ybWF0bzogaHR0cHM6Ly9naXRodWIuY29tL3B1cHBldGVlci9yZXBsYXkgKHRpdGxlICsgc3RlcHNbXSBjb24gc2VsZWN0b3JzOiBzdHJpbmdbXVtdKS5cbmltcG9ydCB7IG5ld0Zsb3csIG5ld1N0ZXAgfSBmcm9tIFwiLi9zdG9yZVwiO1xuaW1wb3J0IHR5cGUgeyBGbG93LCBGcmFtZVJlZiwgU3RlcCB9IGZyb20gXCIuL3R5cGVzXCI7XG5pbXBvcnQgeyBsb29rc0dlbmVyYXRlZCB9IGZyb20gXCIuL3V0aWxcIjtcblxuaW50ZXJmYWNlIERUU3RlcCB7XG4gIHR5cGU6IHN0cmluZztcbiAgdGFyZ2V0Pzogc3RyaW5nO1xuICBmcmFtZT86IG51bWJlcltdO1xuICBzZWxlY3RvcnM/OiAoc3RyaW5nIHwgc3RyaW5nW10pW107XG4gIHVybD86IHN0cmluZztcbiAgdmFsdWU/OiBzdHJpbmc7XG4gIGtleT86IHN0cmluZztcbiAgdGltZW91dD86IG51bWJlcjtcbiAgW2s6IHN0cmluZ106IHVua25vd247XG59XG5cbmludGVyZmFjZSBEVFJlY29yZGluZyB7XG4gIHRpdGxlPzogc3RyaW5nO1xuICB0aW1lb3V0PzogbnVtYmVyO1xuICBzdGVwczogRFRTdGVwW107XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0RldlRvb2xzUmVjb3JkaW5nKGRhdGE6IHVua25vd24pOiBkYXRhIGlzIERUUmVjb3JkaW5nIHtcbiAgaWYgKCFkYXRhIHx8IHR5cGVvZiBkYXRhICE9PSBcIm9iamVjdFwiIHx8ICFBcnJheS5pc0FycmF5KChkYXRhIGFzIERUUmVjb3JkaW5nKS5zdGVwcykpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3RlcHMgPSAoZGF0YSBhcyBEVFJlY29yZGluZykuc3RlcHM7XG4gIHJldHVybiBcInRpdGxlXCIgaW4gZGF0YSAmJiBzdGVwcy5zb21lKChzKSA9PiBzICYmIChzLnR5cGUgPT09IFwic2V0Vmlld3BvcnRcIiB8fCBBcnJheS5pc0FycmF5KHMuc2VsZWN0b3JzKSB8fCBzLnR5cGUgPT09IFwibmF2aWdhdGVcIiAmJiBcInVybFwiIGluIHMpKTtcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIEltcG9ydGFyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIFRyYWR1Y2UgbG9zIHNlbGVjdG9yZXMgZGUgUmVjb3JkZXIgYSBsb3MgZGUgUmFzdHJvLiBDYWRhIGVudHJhZGEgZXMgdW5hIGNhZGVuYVxuICogKHZhcmlhcyBwYXJ0ZXMgPSBhdHJhdmVzYXIgc2hhZG93IHJvb3RzOyBub3MgcXVlZGFtb3MgY29uIGxhcyBkZSB1bmEgc29sYSBwYXJ0ZSkuXG4gKi9cbmZ1bmN0aW9uIG1hcFNlbGVjdG9ycyhyYXc6IChzdHJpbmcgfCBzdHJpbmdbXSlbXSB8IHVuZGVmaW5lZCwgaXNJbnB1dDogYm9vbGVhbik6IHsgc2VsZWN0b3JzOiBzdHJpbmdbXTsgbmFtZT86IHN0cmluZyB9IHtcbiAgY29uc3Qgc3RhYmxlOiBzdHJpbmdbXSA9IFtdOyAvLyAjaWQsIFthdHJpYnV0b11cbiAgY29uc3QgbmFtZWQ6IHN0cmluZ1tdID0gW107IC8vIHRleHQ9IC8gbGFiZWw9XG4gIGNvbnN0IHBvc2l0aW9uYWw6IHN0cmluZ1tdID0gW107IC8vIHJ1dGFzIENTUyBjb24gbnRoLW9mLXR5cGXigKZcbiAgY29uc3QgeHBhdGg6IHN0cmluZ1tdID0gW107XG4gIGxldCBuYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGZvciAoY29uc3QgZW50cnkgb2YgcmF3ID8/IFtdKSB7XG4gICAgY29uc3QgcGFydHMgPSBBcnJheS5pc0FycmF5KGVudHJ5KSA/IGVudHJ5IDogW2VudHJ5XTtcbiAgICBpZiAocGFydHMubGVuZ3RoICE9PSAxKSBjb250aW51ZTtcbiAgICBjb25zdCBzID0gcGFydHNbMF0hO1xuICAgIC8vIFJlY29yZGVyIG5vIHNhYmUgcXXDqSBpZHMgc29uIGFsZWF0b3Jpb3M6ICNlbC1pZC03NDQwLTE2NTggZGVqYXLDrWEgZGUgZXhpc3RpciBlbiBsYSBwcsOzeGltYSBjYXJnYS5cbiAgICBpZiAoaGFzR2VuZXJhdGVkSWQocykpIGNvbnRpbnVlO1xuICAgIGlmIChzLnN0YXJ0c1dpdGgoXCJhcmlhL1wiKSkge1xuICAgICAgY29uc3QgbiA9IHMuc2xpY2UoNSkucmVwbGFjZSgvXFxbcm9sZT1cIlteXCJdKlwiXFxdJC8sIFwiXCIpO1xuICAgICAgbmFtZSA/Pz0gbi5yZXBsYWNlKC9cXHMqXFwqJC8sIFwiXCIpO1xuICAgICAgaWYgKGlzSW5wdXQpIG5hbWVkLnB1c2goYGxhYmVsPSR7bi5yZXBsYWNlKC9cXHMqXFwqJC8sIFwiXCIpfWApO1xuICAgICAgZWxzZSBuYW1lZC5wdXNoKGB0ZXh0PSR7bn1gLCBgW2FyaWEtbGFiZWw9JHtKU09OLnN0cmluZ2lmeShuKX1dYCk7XG4gICAgfSBlbHNlIGlmIChzLnN0YXJ0c1dpdGgoXCJ0ZXh0L1wiKSkge1xuICAgICAgbmFtZSA/Pz0gcy5zbGljZSg1KTtcbiAgICAgIG5hbWVkLnB1c2goYHRleHQ9JHtzLnNsaWNlKDUpfWApO1xuICAgIH0gZWxzZSBpZiAocy5zdGFydHNXaXRoKFwieHBhdGgvXCIpKSB4cGF0aC5wdXNoKGB4cGF0aD0ke3Muc2xpY2UoNil9YCk7XG4gICAgZWxzZSB7XG4gICAgICBjb25zdCBjc3MgPSBzLnN0YXJ0c1dpdGgoXCJwaWVyY2UvXCIpID8gcy5zbGljZSg3KSA6IHM7XG4gICAgICAoL14jW1xcdy1dKyR8XltcXHctXSpcXFtbXlxcXV0rXFxdJC8udGVzdChjc3MpID8gc3RhYmxlIDogcG9zaXRpb25hbCkucHVzaChjc3MpO1xuICAgIH1cbiAgfVxuICByZXR1cm4geyBzZWxlY3RvcnM6IFsuLi5uZXcgU2V0KFsuLi5zdGFibGUsIC4uLm5hbWVkLCAuLi5wb3NpdGlvbmFsLCAuLi54cGF0aF0pXS5zbGljZSgwLCA2KSwgbmFtZSB9O1xufVxuXG5mdW5jdGlvbiBoYXNHZW5lcmF0ZWRJZChzZWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBpZHMgPSBbLi4uc2VsLm1hdGNoQWxsKC8jKCg/OlxcXFwufFtcXHctXSkrKS9nKSwgLi4uc2VsLm1hdGNoQWxsKC9AaWQ9W1wiJ10oW15cIiddKylbXCInXS9nKSwgLi4uc2VsLm1hdGNoQWxsKC9cXFtpZD1bXCInXT8oW15cIidcXF1dKykvZyldO1xuICByZXR1cm4gaWRzLnNvbWUoKG0pID0+IGxvb2tzR2VuZXJhdGVkKG1bMV0hLnJlcGxhY2UoL1xcXFwvZywgXCJcIikpKTtcbn1cblxuZnVuY3Rpb24gbWFwRnJhbWUoZnJhbWU6IG51bWJlcltdIHwgdW5kZWZpbmVkKTogRnJhbWVSZWZbXSB8IHVuZGVmaW5lZCB7XG4gIHJldHVybiBmcmFtZT8ubGVuZ3RoID8gZnJhbWUubWFwKChpKSA9PiAoeyBzZWxlY3RvcjogYGZyYW1lPSR7aX1gIH0pKSA6IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGZyb21EZXZUb29scyhyZWM6IERUUmVjb3JkaW5nKTogeyBmbG93OiBGbG93OyBza2lwcGVkOiBzdHJpbmdbXSB9IHtcbiAgY29uc3Qgc3RlcHM6IFN0ZXBbXSA9IFtdO1xuICBjb25zdCBza2lwcGVkOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHMgb2YgcmVjLnN0ZXBzKSB7XG4gICAgaWYgKHMudGFyZ2V0ICYmIHMudGFyZ2V0ICE9PSBcIm1haW5cIikge1xuICAgICAgc2tpcHBlZC5wdXNoKGAke3MudHlwZX0gKGVuIG90cmEgdmVudGFuYSlgKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBpc0lucHV0ID0gcy50eXBlID09PSBcImNoYW5nZVwiO1xuICAgIGNvbnN0IG1hcHBlZCA9IG1hcFNlbGVjdG9ycyhzLnNlbGVjdG9ycywgaXNJbnB1dCk7XG4gICAgY29uc3QgW3NlbGVjdG9yLCAuLi5mYWxsYmFja3NdID0gbWFwcGVkLnNlbGVjdG9ycztcbiAgICBjb25zdCB0YXJnZXQgPSB7IHNlbGVjdG9yLCBmYWxsYmFja3MsIGZyYW1lOiBtYXBGcmFtZShzLmZyYW1lKSwgdGltZW91dDogcy50aW1lb3V0IH07XG4gICAgY29uc3QgbGFiZWwgPSBtYXBwZWQubmFtZSA/PyBzZWxlY3RvcjtcbiAgICBzd2l0Y2ggKHMudHlwZSkge1xuICAgICAgY2FzZSBcInNldFZpZXdwb3J0XCI6XG4gICAgICBjYXNlIFwia2V5VXBcIjpcbiAgICAgICAgYnJlYWs7IC8vIHNpbiBlcXVpdmFsZW50ZSAvIHJlZHVuZGFudGVcbiAgICAgIGNhc2UgXCJuYXZpZ2F0ZVwiOlxuICAgICAgICBzdGVwcy5wdXNoKG5ld1N0ZXAoeyB0eXBlOiBcIm5hdmlnYXRlXCIsIHZhbHVlOiBzLnVybCB9KSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNsaWNrXCI6XG4gICAgICBjYXNlIFwiZG91YmxlQ2xpY2tcIjpcbiAgICAgICAgaWYgKCFzZWxlY3Rvcikgc2tpcHBlZC5wdXNoKHMudHlwZSArIFwiIHNpbiBzZWxlY3RvciB1c2FibGVcIik7XG4gICAgICAgIGVsc2Ugc3RlcHMucHVzaChuZXdTdGVwKHsgdHlwZTogXCJjbGlja1wiLCAuLi50YXJnZXQsIGxhYmVsLCBub3RlOiBzLnR5cGUgPT09IFwiZG91YmxlQ2xpY2tcIiA/IFwiZG9ibGUgY2xpY2sgZW4gRGV2VG9vbHNcIiA6IHVuZGVmaW5lZCB9KSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNoYW5nZVwiOiB7XG4gICAgICAgIGlmICghc2VsZWN0b3IpIHtcbiAgICAgICAgICBza2lwcGVkLnB1c2goXCJjaGFuZ2Ugc2luIHNlbGVjdG9yIHVzYWJsZVwiKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICAvLyBSZWNvcmRlciBncmFiYSDCq2NsaWNrIGVuIGVsIGNhbXBvwrsgKyDCq2NoYW5nZcK7OiBlbCBjbGljayBzb2JyYS5cbiAgICAgICAgY29uc3QgcHJldiA9IHN0ZXBzLmF0KC0xKTtcbiAgICAgICAgaWYgKHByZXY/LnR5cGUgPT09IFwiY2xpY2tcIiAmJiBwcmV2LnNlbGVjdG9yID09PSBzZWxlY3RvciAmJiBKU09OLnN0cmluZ2lmeShwcmV2LmZyYW1lKSA9PT0gSlNPTi5zdHJpbmdpZnkodGFyZ2V0LmZyYW1lKSkgc3RlcHMucG9wKCk7XG4gICAgICAgIHN0ZXBzLnB1c2gobmV3U3RlcCh7IHR5cGU6IFwiZmlsbFwiLCAuLi50YXJnZXQsIGxhYmVsLCB2YWx1ZTogcy52YWx1ZSA/PyBcIlwiIH0pKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwia2V5RG93blwiOlxuICAgICAgICBzdGVwcy5wdXNoKG5ld1N0ZXAoeyB0eXBlOiBcInByZXNzXCIsIHZhbHVlOiBzLmtleSA/PyBcIkVudGVyXCIgfSkpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ3YWl0Rm9yRWxlbWVudFwiOlxuICAgICAgICBpZiAoc2VsZWN0b3IpIHN0ZXBzLnB1c2gobmV3U3RlcCh7IHR5cGU6IFwid2FpdEZvclwiLCAuLi50YXJnZXQsIGxhYmVsIH0pKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBza2lwcGVkLnB1c2gocy50eXBlKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgZmxvdyA9IG5ld0Zsb3coeyBuYW1lOiByZWMudGl0bGUgfHwgXCJHcmFiYWNpw7NuIGRlIERldlRvb2xzXCIsIHRhZ3M6IFtcImRldnRvb2xzXCJdLCBzdGVwcyB9KTtcbiAgcmV0dXJuIHsgZmxvdywgc2tpcHBlZCB9O1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRXhwb3J0YXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIHRvRFRTZWxlY3RvcihzZWw6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcInRleHQ9XCIpKSByZXR1cm4gYHRleHQvJHtzZWwuc2xpY2UoNSl9YDtcbiAgLy8gUmVjb3JkZXIgbm8gZW5jYWRlbmEgc2VsZWN0b3Jlczogbm9zIHF1ZWRhbW9zIGNvbiBlbCDDumx0aW1vIGVzbGFiw7NuLlxuICBjb25zdCBpID0gc2VsLmluZGV4T2YoXCIgPj4gXCIpO1xuICBpZiAoaSA+IDApIHJldHVybiB0b0RUU2VsZWN0b3Ioc2VsLnNsaWNlKGkgKyA0KSk7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcImxhYmVsPVwiKSkgcmV0dXJuIGBhcmlhLyR7c2VsLnNsaWNlKDYpfWA7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcInhwYXRoPVwiKSkgcmV0dXJuIGB4cGF0aC8ke3NlbC5zbGljZSg2KX1gO1xuICByZXR1cm4gc2VsO1xufVxuXG4vKiogRXhwb3J0YSBhbCBmb3JtYXRvIGRlIERldlRvb2xzIFJlY29yZGVyLiBMb3MgcGFzb3MgZGVudHJvIGRlIGlmcmFtZXMgcGllcmRlbiBsYSBydXRhIChSZWNvcmRlciB1c2Egw61uZGljZXMpLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHRvRGV2VG9vbHMoZmxvdzogRmxvdyk6IHsganNvbjogRFRSZWNvcmRpbmc7IHdhcm5pbmdzOiBudW1iZXIgfSB7XG4gIGNvbnN0IHN0ZXBzOiBEVFN0ZXBbXSA9IFtcbiAgICB7IHR5cGU6IFwic2V0Vmlld3BvcnRcIiwgd2lkdGg6IDEyODAsIGhlaWdodDogODAwLCBkZXZpY2VTY2FsZUZhY3RvcjogMSwgaXNNb2JpbGU6IGZhbHNlLCBoYXNUb3VjaDogZmFsc2UsIGlzTGFuZHNjYXBlOiBmYWxzZSB9LFxuICBdO1xuICBsZXQgd2FybmluZ3MgPSAwO1xuICBmb3IgKGNvbnN0IHMgb2YgZmxvdy5zdGVwcykge1xuICAgIGlmICghcy5lbmFibGVkKSBjb250aW51ZTtcbiAgICBpZiAocy5mcmFtZT8ubGVuZ3RoKSB3YXJuaW5ncysrO1xuICAgIGNvbnN0IHNlbGVjdG9ycyA9IFtzLnNlbGVjdG9yLCAuLi4ocy5mYWxsYmFja3MgPz8gW10pXS5maWx0ZXIoQm9vbGVhbikubWFwKCh4KSA9PiBbdG9EVFNlbGVjdG9yKHghKV0pO1xuICAgIGNvbnN0IGJhc2UgPSB7IHRhcmdldDogXCJtYWluXCIsIHNlbGVjdG9ycywgLi4uKHMudGltZW91dCA/IHsgdGltZW91dDogcy50aW1lb3V0IH0gOiB7fSkgfTtcbiAgICBzd2l0Y2ggKHMudHlwZSkge1xuICAgICAgY2FzZSBcIm5hdmlnYXRlXCI6XG4gICAgICAgIHN0ZXBzLnB1c2goeyB0eXBlOiBcIm5hdmlnYXRlXCIsIHVybDogcy52YWx1ZSA/PyBcIlwiIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJjbGlja1wiOlxuICAgICAgY2FzZSBcImNoZWNrXCI6XG4gICAgICAgIHN0ZXBzLnB1c2goeyB0eXBlOiBcImNsaWNrXCIsIC4uLmJhc2UsIG9mZnNldFg6IDEsIG9mZnNldFk6IDEgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImZpbGxcIjpcbiAgICAgIGNhc2UgXCJzZWxlY3RcIjpcbiAgICAgICAgc3RlcHMucHVzaCh7IHR5cGU6IFwiY2hhbmdlXCIsIC4uLmJhc2UsIHZhbHVlOiBzLnZhbHVlID8/IFwiXCIgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInByZXNzXCI6XG4gICAgICAgIHN0ZXBzLnB1c2goeyB0eXBlOiBcImtleURvd25cIiwgdGFyZ2V0OiBcIm1haW5cIiwga2V5OiBzLnZhbHVlIHx8IFwiRW50ZXJcIiB9LCB7IHR5cGU6IFwia2V5VXBcIiwgdGFyZ2V0OiBcIm1haW5cIiwga2V5OiBzLnZhbHVlIHx8IFwiRW50ZXJcIiB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwid2FpdEZvclwiOlxuICAgICAgICBzdGVwcy5wdXNoKHsgdHlwZTogXCJ3YWl0Rm9yRWxlbWVudFwiLCAuLi5iYXNlIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJhc3NlcnRUZXh0XCI6XG4gICAgICAgIHN0ZXBzLnB1c2goe1xuICAgICAgICAgIHR5cGU6IFwid2FpdEZvckV4cHJlc3Npb25cIixcbiAgICAgICAgICB0YXJnZXQ6IFwibWFpblwiLFxuICAgICAgICAgIGV4cHJlc3Npb246IGAoKCkgPT4geyBjb25zdCBlID0gZG9jdW1lbnQucXVlcnlTZWxlY3Rvcigke0pTT04uc3RyaW5naWZ5KHMuc2VsZWN0b3IgPz8gXCJcIil9KTsgcmV0dXJuICEhZSAmJiAoZS52YWx1ZSA/PyBlLmlubmVyVGV4dCkuaW5jbHVkZXMoJHtKU09OLnN0cmluZ2lmeShzLnZhbHVlID8/IFwiXCIpfSk7IH0pKClgLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwid2FpdFwiOlxuICAgICAgICBzdGVwcy5wdXNoKHsgdHlwZTogXCJ3YWl0Rm9yRXhwcmVzc2lvblwiLCB0YXJnZXQ6IFwibWFpblwiLCBleHByZXNzaW9uOiBgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQoKCkgPT4gcih0cnVlKSwgJHtOdW1iZXIocy52YWx1ZSkgfHwgMTAwMH0pKWAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICByZXR1cm4geyBqc29uOiB7IHRpdGxlOiBmbG93Lm5hbWUsIHN0ZXBzIH0sIHdhcm5pbmdzIH07XG59XG4iLAogICAgImltcG9ydCB7IGZyb21EZXZUb29scywgaXNEZXZUb29sc1JlY29yZGluZyB9IGZyb20gXCIuL2RldnRvb2xzXCI7XG5pbXBvcnQgeyBuZXdGbG93IH0gZnJvbSBcIi4vc3RvcmVcIjtcbmltcG9ydCB0eXBlIHsgRXhwb3J0RmlsZSwgRmxvdywgU3RlcCwgU3RlcFR5cGUgfSBmcm9tIFwiLi90eXBlc1wiO1xuaW1wb3J0IHsgdWlkIH0gZnJvbSBcIi4vdXRpbFwiO1xuXG5leHBvcnQgZnVuY3Rpb24gdG9FeHBvcnRGaWxlKGZsb3dzOiBGbG93W10pOiBFeHBvcnRGaWxlIHtcbiAgcmV0dXJuIHsgZm9ybWF0OiBcInJhc3Ryb1wiLCB2ZXJzaW9uOiAxLCBleHBvcnRlZEF0OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksIGZsb3dzOiBmbG93cy5tYXAoKGYpID0+ICh7IC4uLmYsIGxhc3RSdW46IHVuZGVmaW5lZCB9KSkgfTtcbn1cblxuY29uc3QgU1RFUF9UWVBFUzogU3RlcFR5cGVbXSA9IFtcIm5hdmlnYXRlXCIsIFwiY2xpY2tcIiwgXCJmaWxsXCIsIFwic2VsZWN0XCIsIFwiY2hlY2tcIiwgXCJwcmVzc1wiLCBcIndhaXRcIiwgXCJ3YWl0Rm9yXCIsIFwiYXNzZXJ0VGV4dFwiXTtcblxuZXhwb3J0IGludGVyZmFjZSBJbXBvcnRSZXN1bHQge1xuICBmbG93czogRmxvd1tdO1xuICBzb3VyY2U6IFwicmFzdHJvXCIgfCBcImRldnRvb2xzXCI7XG4gIC8qKiBQYXNvcyBxdWUgbm8gc2UgcHVkaWVyb24gY29udmVydGlyIChpbXBvcnRhY2nDs24gZGVzZGUgRGV2VG9vbHMpLiAqL1xuICBza2lwcGVkOiBzdHJpbmdbXTtcbn1cblxuLyoqIEFjZXB0YSB1biBFeHBvcnRGaWxlIGRlIFJhc3RybywgdW4gRmxvdyBzdWVsdG8sIHVuIGFycmF5IGRlIEZsb3cgbyB1bmEgZ3JhYmFjacOzbiBkZSBEZXZUb29scyBSZWNvcmRlci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUltcG9ydCh0ZXh0OiBzdHJpbmcpOiBJbXBvcnRSZXN1bHQge1xuICBsZXQgZGF0YTogdW5rbm93bjtcbiAgdHJ5IHtcbiAgICBkYXRhID0gSlNPTi5wYXJzZSh0ZXh0KTtcbiAgfSBjYXRjaCB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRWwgZmljaGVybyBubyBlcyBKU09OIHbDoWxpZG9cIik7XG4gIH1cbiAgaWYgKGlzRGV2VG9vbHNSZWNvcmRpbmcoZGF0YSkpIHtcbiAgICBjb25zdCB7IGZsb3csIHNraXBwZWQgfSA9IGZyb21EZXZUb29scyhkYXRhKTtcbiAgICByZXR1cm4geyBmbG93czogW2Zsb3ddLCBzb3VyY2U6IFwiZGV2dG9vbHNcIiwgc2tpcHBlZCB9O1xuICB9XG4gIHJldHVybiB7IGZsb3dzOiBwYXJzZVJhc3RybyhkYXRhKSwgc291cmNlOiBcInJhc3Ryb1wiLCBza2lwcGVkOiBbXSB9O1xufVxuXG5mdW5jdGlvbiBwYXJzZVJhc3RybyhkYXRhOiB1bmtub3duKTogRmxvd1tdIHtcbiAgY29uc3QgcmF3OiB1bmtub3duW10gPSBBcnJheS5pc0FycmF5KGRhdGEpXG4gICAgPyBkYXRhXG4gICAgOiBkYXRhICYmIHR5cGVvZiBkYXRhID09PSBcIm9iamVjdFwiICYmIFwiZmxvd3NcIiBpbiBkYXRhICYmIEFycmF5LmlzQXJyYXkoKGRhdGEgYXMgRXhwb3J0RmlsZSkuZmxvd3MpXG4gICAgICA/IChkYXRhIGFzIEV4cG9ydEZpbGUpLmZsb3dzXG4gICAgICA6IGRhdGEgJiYgdHlwZW9mIGRhdGEgPT09IFwib2JqZWN0XCIgJiYgXCJzdGVwc1wiIGluIGRhdGFcbiAgICAgICAgPyBbZGF0YV1cbiAgICAgICAgOiBbXTtcbiAgaWYgKCFyYXcubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoXCJObyBzZSBlbmNvbnRyYXJvbiBmbHVqb3MgZW4gZWwgZmljaGVyb1wiKTtcblxuICByZXR1cm4gcmF3Lm1hcCgociwgaSkgPT4ge1xuICAgIGNvbnN0IGYgPSByIGFzIFBhcnRpYWw8Rmxvdz47XG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGYuc3RlcHMpKSB0aHJvdyBuZXcgRXJyb3IoYEVsIGZsdWpvICMke2kgKyAxfSBubyB0aWVuZSBwYXNvc2ApO1xuICAgIGNvbnN0IHN0ZXBzOiBTdGVwW10gPSBmLnN0ZXBzLm1hcCgocywgaikgPT4ge1xuICAgICAgaWYgKCFzIHx8ICFTVEVQX1RZUEVTLmluY2x1ZGVzKHMudHlwZSkpIHRocm93IG5ldyBFcnJvcihgUGFzbyAke2ogKyAxfSBkZSDCqyR7Zi5uYW1lID8/IGkgKyAxfcK7OiB0aXBvIGRlc2Nvbm9jaWRvYCk7XG4gICAgICByZXR1cm4geyAuLi5zLCBpZDogdHlwZW9mIHMuaWQgPT09IFwic3RyaW5nXCIgPyBzLmlkIDogdWlkKCksIGVuYWJsZWQ6IHMuZW5hYmxlZCAhPT0gZmFsc2UgfTtcbiAgICB9KTtcbiAgICByZXR1cm4gbmV3Rmxvdyh7XG4gICAgICBpZDogdHlwZW9mIGYuaWQgPT09IFwic3RyaW5nXCIgPyBmLmlkIDogdWlkKCksXG4gICAgICBuYW1lOiBTdHJpbmcoZi5uYW1lID8/IGBJbXBvcnRhZG8gJHtpICsgMX1gKSxcbiAgICAgIGRlc2NyaXB0aW9uOiBmLmRlc2NyaXB0aW9uLFxuICAgICAgZm9sZGVyOiBmLmZvbGRlcixcbiAgICAgIHRhZ3M6IEFycmF5LmlzQXJyYXkoZi50YWdzKSA/IGYudGFncy5tYXAoU3RyaW5nKSA6IFtdLFxuICAgICAgdmFyaWFibGVzOiBmLnZhcmlhYmxlcyAmJiB0eXBlb2YgZi52YXJpYWJsZXMgPT09IFwib2JqZWN0XCIgPyBmLnZhcmlhYmxlcyA6IHt9LFxuICAgICAgc3RlcHMsXG4gICAgICBjcmVhdGVkQXQ6IHR5cGVvZiBmLmNyZWF0ZWRBdCA9PT0gXCJudW1iZXJcIiA/IGYuY3JlYXRlZEF0IDogRGF0ZS5ub3coKSxcbiAgICB9KTtcbiAgfSk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBQdXBwZXRlZXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKiBUcmFkdWNlIHVuIHNlbGVjdG9yIGRlIFJhc3RybyBhIGxhIHNpbnRheGlzIGRlIFB1cHBldGVlci4gKi9cbmZ1bmN0aW9uIHBwU2VsZWN0b3Ioc2VsOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoc2VsLnN0YXJ0c1dpdGgoXCJ0ZXh0PVwiKSkgcmV0dXJuIGA6Oi1wLXRleHQoJHtKU09OLnN0cmluZ2lmeShzZWwuc2xpY2UoNSkpfSlgO1xuICAvLyDCq0EgPj4gQsK7IOKGkiBjb21iaW5hZG9yIGRlc2NlbmRpZW50ZSAoUHVwcGV0ZWVyIGFkbWl0ZSA6Oi1wLXRleHQgdHJhcyB1biBzZWxlY3RvciBDU1MpLlxuICBjb25zdCBpID0gc2VsLmluZGV4T2YoXCIgPj4gXCIpO1xuICBpZiAoaSA+IDApIHJldHVybiBgJHtwcFNlbGVjdG9yKHNlbC5zbGljZSgwLCBpKSl9ICR7cHBTZWxlY3RvcihzZWwuc2xpY2UoaSArIDQpKX1gO1xuICBpZiAoc2VsLnN0YXJ0c1dpdGgoXCJsYWJlbD1cIikpIHJldHVybiBgOjotcC1hcmlhKCR7SlNPTi5zdHJpbmdpZnkoc2VsLnNsaWNlKDYpKX0pYDtcbiAgaWYgKHNlbC5zdGFydHNXaXRoKFwieHBhdGg9XCIpKSByZXR1cm4gYDo6LXAteHBhdGgoJHtzZWwuc2xpY2UoNil9KWA7XG4gIHJldHVybiBzZWw7XG59XG5cbmNvbnN0IGpzID0gKHM6IHN0cmluZykgPT4gSlNPTi5zdHJpbmdpZnkocyk7XG5cbi8qKiBWYWxvciBjb24ge3t2YXJpYWJsZXN9fSDihpIgZXhwcmVzacOzbiBKUy4gKi9cbmZ1bmN0aW9uIGpzVmFsdWUodjogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCEvXFx7XFx7Ly50ZXN0KHYpKSByZXR1cm4ganModik7XG4gIHJldHVybiBcInYoXCIgKyBqcyh2KSArIFwiKVwiO1xufVxuXG5mdW5jdGlvbiBsb2NhdG9yKHN0ZXA6IFN0ZXAsIGN0eCA9IFwicGFnZVwiKTogc3RyaW5nIHtcbiAgY29uc3Qgc2VscyA9IFtzdGVwLnNlbGVjdG9yISwgLi4uKHN0ZXAuZmFsbGJhY2tzID8/IFtdKV0ubWFwKHBwU2VsZWN0b3IpO1xuICBpZiAoc2Vscy5sZW5ndGggPT09IDEpIHJldHVybiBgJHtjdHh9LmxvY2F0b3IoJHtqcyhzZWxzWzBdISl9KWA7XG4gIHJldHVybiBgTG9jYXRvci5yYWNlKFske3NlbHMubWFwKCh4KSA9PiBgJHtjdHh9LmxvY2F0b3IoJHtqcyh4KX0pYCkuam9pbihcIiwgXCIpfV0pYDtcbn1cblxuLyoqIEV4cHJlc2nDs24gcXVlIHJlc3VlbHZlIGVsIGZyYW1lIGRlbCBwYXNvIChvIGBwYWdlYCkuICovXG5mdW5jdGlvbiBmcmFtZUV4cHIoc3RlcDogU3RlcCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmICghc3RlcC5mcmFtZT8ubGVuZ3RoKSByZXR1cm4gdW5kZWZpbmVkO1xuICBjb25zdCBwYXRoID0gc3RlcC5mcmFtZS5tYXAoKGYpID0+IFtmLnNlbGVjdG9yLCAuLi4oZi5mYWxsYmFja3MgPz8gW10pXS5tYXAocHBTZWxlY3RvcikpO1xuICByZXR1cm4gYGF3YWl0IGZyYW1lT2YoJHtKU09OLnN0cmluZ2lmeShwYXRoKX0pYDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRvUHVwcGV0ZWVyKGZsb3c6IEZsb3cpOiBzdHJpbmcge1xuICBjb25zdCBvdXQ6IHN0cmluZ1tdID0gW107XG4gIG91dC5wdXNoKGAvLyAke2Zsb3cubmFtZX0g4oCUIGV4cG9ydGFkbyBkZXNkZSBSYXN0cm8gZWwgJHtuZXcgRGF0ZSgpLnRvTG9jYWxlU3RyaW5nKCl9YCk7XG4gIG91dC5wdXNoKGAvLyBSZXF1aWVyZTogbnBtIGkgcHVwcGV0ZWVyICAgwrcgICBFamVjdXRhcjogbm9kZSAke3NsdWcoZmxvdy5uYW1lKX0ubWpzICAobyBidW4pYCk7XG4gIG91dC5wdXNoKGBpbXBvcnQgcHVwcGV0ZWVyLCB7IExvY2F0b3IgfSBmcm9tIFwicHVwcGV0ZWVyXCI7YCk7XG4gIG91dC5wdXNoKFwiXCIpO1xuICBvdXQucHVzaChgY29uc3QgVCA9IDgwMDA7YCk7XG4gIG91dC5wdXNoKGBjb25zdCB2YXJzID0gJHtKU09OLnN0cmluZ2lmeShmbG93LnZhcmlhYmxlcyA/PyB7fSwgbnVsbCwgMil9O2ApO1xuICBvdXQucHVzaChgY29uc3QgYnVpbHRpbnMgPSB7YCk7XG4gIG91dC5wdXNoKGAgICR0aW1lc3RhbXA6IFN0cmluZyhEYXRlLm5vdygpKSxgKTtcbiAgb3V0LnB1c2goYCAgJHV1aWQ6IGNyeXB0by5yYW5kb21VVUlEKCksYCk7XG4gIG91dC5wdXNoKGAgICRyYW5kb21JbnQ6IFN0cmluZyhNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxZTYpKSxgKTtcbiAgb3V0LnB1c2goYCAgJHJhbmRvbUVtYWlsOiBcXGB0ZXN0K1xcJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX1AZXhhbXBsZS5jb21cXGAsYCk7XG4gIG91dC5wdXNoKGAgICR0b2RheTogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKSxgKTtcbiAgb3V0LnB1c2goYH07YCk7XG4gIG91dC5wdXNoKGBjb25zdCB2ID0gKHMpID0+IHMucmVwbGFjZSgvXFxcXHtcXFxce1xcXFxzKihbJFxcXFx3Li1dKylcXFxccypcXFxcfVxcXFx9L2csIChtLCBrKSA9PiB2YXJzW2tdICE9IG51bGwgPyB2KHZhcnNba10pIDogYnVpbHRpbnNba10gPz8gbSk7YCk7XG4gIG91dC5wdXNoKFwiXCIpO1xuICBpZiAoZmxvdy5zdGVwcy5zb21lKChzdCkgPT4gc3QuZnJhbWU/Lmxlbmd0aCkpIHtcbiAgICBvdXQucHVzaChgLyoqIEJhamEgcG9yIGxhIHJ1dGEgZGUgaWZyYW1lczogZW4gY2FkYSBuaXZlbCwgZWwgcHJpbWVyIHNlbGVjdG9yIHF1ZSBhcGFyZXpjYS4gKi9gKTtcbiAgICBvdXQucHVzaChgYXN5bmMgZnVuY3Rpb24gZnJhbWVPZihwYXRoKSB7YCk7XG4gICAgb3V0LnB1c2goYCAgbGV0IGYgPSBwYWdlLm1haW5GcmFtZSgpO2ApO1xuICAgIG91dC5wdXNoKGAgIGZvciAoY29uc3Qgc2VscyBvZiBwYXRoKSB7YCk7XG4gICAgb3V0LnB1c2goYCAgICBjb25zdCBlbCA9IGF3YWl0IExvY2F0b3IucmFjZShzZWxzLm1hcCgocykgPT4gZi5sb2NhdG9yKHMpKSkud2FpdEhhbmRsZSgpO2ApO1xuICAgIG91dC5wdXNoKGAgICAgZiA9IGF3YWl0IGVsLmNvbnRlbnRGcmFtZSgpO2ApO1xuICAgIG91dC5wdXNoKGAgIH1gKTtcbiAgICBvdXQucHVzaChgICByZXR1cm4gZjtgKTtcbiAgICBvdXQucHVzaChgfWApO1xuICAgIG91dC5wdXNoKFwiXCIpO1xuICB9XG4gIG91dC5wdXNoKGBjb25zdCBicm93c2VyID0gYXdhaXQgcHVwcGV0ZWVyLmxhdW5jaCh7IGhlYWRsZXNzOiBwcm9jZXNzLmVudi5IRUFETEVTUyAhPT0gXCIwXCIgPyBcIm5ld1wiIDogZmFsc2UgfSk7YCk7XG4gIG91dC5wdXNoKGBjb25zdCBwYWdlID0gYXdhaXQgYnJvd3Nlci5uZXdQYWdlKCk7YCk7XG4gIG91dC5wdXNoKGBwYWdlLnNldERlZmF1bHRUaW1lb3V0KFQpO2ApO1xuICBvdXQucHVzaChgdHJ5IHtgKTtcblxuICBmbG93LnN0ZXBzLmZvckVhY2goKHMsIGkpID0+IHtcbiAgICBjb25zdCBjb21tZW50ID0gYCAgLy8gJHtpICsgMX0uICR7cy50eXBlfSR7cy5sYWJlbCA/IGAgwrcgJHtzLmxhYmVsfWAgOiBcIlwifWA7XG4gICAgaWYgKCFzLmVuYWJsZWQpIHtcbiAgICAgIG91dC5wdXNoKGNvbW1lbnQgKyBcIiAoZGVzYWN0aXZhZG8pXCIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBvdXQucHVzaChjb21tZW50KTtcbiAgICBjb25zdCB2YWwgPSBzLnZhbHVlID8/IFwiXCI7XG4gICAgY29uc3QgZnIgPSBmcmFtZUV4cHIocyk7XG4gICAgY29uc3QgY3R4ID0gZnIgPyBcImZcIiA6IFwicGFnZVwiO1xuICAgIGNvbnN0IGxvYyA9ICgpID0+IGxvY2F0b3IocywgY3R4KTtcbiAgICBpZiAoZnIgJiYgcy50eXBlICE9PSBcIm5hdmlnYXRlXCIgJiYgcy50eXBlICE9PSBcIndhaXRcIikgb3V0LnB1c2goYCAge2AsIGAgIGNvbnN0IGYgPSAke2ZyfTtgKTtcbiAgICBzd2l0Y2ggKHMudHlwZSkge1xuICAgICAgY2FzZSBcIm5hdmlnYXRlXCI6XG4gICAgICAgIG91dC5wdXNoKGAgIGF3YWl0IHBhZ2UuZ290bygke2pzVmFsdWUodmFsKX0sIHsgd2FpdFVudGlsOiBcIm5ldHdvcmtpZGxlMlwiIH0pO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJjbGlja1wiOlxuICAgICAgICBvdXQucHVzaChgICBhd2FpdCBQcm9taXNlLmFsbChbYCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgcGFnZS53YWl0Rm9yTmF2aWdhdGlvbih7IHRpbWVvdXQ6IDE1MDAgfSkuY2F0Y2goKCkgPT4ge30pLGApO1xuICAgICAgICBvdXQucHVzaChgICAgICR7bG9jKCl9LmNsaWNrKCksYCk7XG4gICAgICAgIG91dC5wdXNoKGAgIF0pO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJmaWxsXCI6XG4gICAgICAgIG91dC5wdXNoKGAgIGF3YWl0ICR7bG9jKCl9LmZpbGwoJHtqc1ZhbHVlKHZhbCl9KTtgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwic2VsZWN0XCI6XG4gICAgICAgIG91dC5wdXNoKGAgIGF3YWl0ICR7Y3R4fS5zZWxlY3QoJHtqcyhwcFNlbGVjdG9yKHMuc2VsZWN0b3IhKSl9LCAke2pzVmFsdWUodmFsKX0pO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJjaGVja1wiOlxuICAgICAgICBvdXQucHVzaChgICB7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgY29uc3QgZWwgPSBhd2FpdCAke2xvYygpfS53YWl0SGFuZGxlKCk7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgaWYgKChhd2FpdCBlbC5ldmFsdWF0ZSgoZSkgPT4gZS5jaGVja2VkID8/IGUuZ2V0QXR0cmlidXRlKFwiYXJpYS1jaGVja2VkXCIpID09PSBcInRydWVcIikpICE9PSAke3ZhbCAhPT0gXCJmYWxzZVwifSkgYXdhaXQgZWwuY2xpY2soKTtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgfWApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJwcmVzc1wiOlxuICAgICAgICBpZiAocy5zZWxlY3Rvcikgb3V0LnB1c2goYCAgYXdhaXQgJHtsb2MoKX0uY2xpY2soKTtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgUHJvbWlzZS5hbGwoW2ApO1xuICAgICAgICBvdXQucHVzaChgICAgIHBhZ2Uud2FpdEZvck5hdmlnYXRpb24oeyB0aW1lb3V0OiAxNTAwIH0pLmNhdGNoKCgpID0+IHt9KSxgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBwYWdlLmtleWJvYXJkLnByZXNzKCR7anModmFsIHx8IFwiRW50ZXJcIil9KSxgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgXSk7YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIndhaXRcIjpcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgbmV3IFByb21pc2UoKHIpID0+IHNldFRpbWVvdXQociwgJHtOdW1iZXIodmFsKSB8fCAxMDAwfSkpO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ3YWl0Rm9yXCI6XG4gICAgICAgIG91dC5wdXNoKGAgIGF3YWl0ICR7bG9jKCl9LndhaXQoKTtgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiYXNzZXJ0VGV4dFwiOlxuICAgICAgICBvdXQucHVzaChgICB7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgY29uc3QgZWwgPSBhd2FpdCAke2xvYygpfS53YWl0SGFuZGxlKCk7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgY29uc3QgdHh0ID0gYXdhaXQgZWwuZXZhbHVhdGUoKGUpID0+IGUudmFsdWUgPz8gZS5pbm5lclRleHQpO2ApO1xuICAgICAgICBvdXQucHVzaChgICAgIGlmICghdHh0LmluY2x1ZGVzKCR7anNWYWx1ZSh2YWwpfSkpIHRocm93IG5ldyBFcnJvcihcXGBQYXNvICR7aSArIDF9OiBzZSBlc3BlcmFiYSAke3ZhbC5yZXBsYWNlKC9bYCRcXFxcXS9nLCBcIlwiKX0geSBoYXkgXFwke3R4dH1cXGApO2ApO1xuICAgICAgICBvdXQucHVzaChgICB9YCk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBpZiAoZnIgJiYgcy50eXBlICE9PSBcIm5hdmlnYXRlXCIgJiYgcy50eXBlICE9PSBcIndhaXRcIikgb3V0LnB1c2goYCAgfWApO1xuICB9KTtcblxuICBvdXQucHVzaChgICBjb25zb2xlLmxvZyhcIuKckyAke2Zsb3cubmFtZS5yZXBsYWNlKC9cIi9nLCBcIidcIil9OiBPS1wiKTtgKTtcbiAgb3V0LnB1c2goYH0gY2F0Y2ggKGUpIHtgKTtcbiAgb3V0LnB1c2goYCAgY29uc29sZS5lcnJvcihcIuKcl1wiLCBlLm1lc3NhZ2UpO2ApO1xuICBvdXQucHVzaChgICBhd2FpdCBwYWdlLnNjcmVlbnNob3QoeyBwYXRoOiBcInJhc3Ryby1lcnJvci5wbmdcIiB9KTtgKTtcbiAgb3V0LnB1c2goYCAgcHJvY2Vzcy5leGl0Q29kZSA9IDE7YCk7XG4gIG91dC5wdXNoKGB9IGZpbmFsbHkge2ApO1xuICBvdXQucHVzaChgICBhd2FpdCBicm93c2VyLmNsb3NlKCk7YCk7XG4gIG91dC5wdXNoKGB9YCk7XG4gIHJldHVybiBvdXQuam9pbihcIlxcblwiKSArIFwiXFxuXCI7XG59XG5cbmV4cG9ydCBjb25zdCBzbHVnID0gKHM6IHN0cmluZykgPT5cbiAgc1xuICAgIC5ub3JtYWxpemUoXCJORkRcIilcbiAgICAucmVwbGFjZSgvW8yALc2vXS9nLCBcIlwiKVxuICAgIC50b0xvd2VyQ2FzZSgpXG4gICAgLnJlcGxhY2UoL1teYS16MC05XSsvZywgXCItXCIpXG4gICAgLnJlcGxhY2UoL14tfC0kL2csIFwiXCIpIHx8IFwiZmx1am9cIjtcbiIsCiAgICAiLy8gT3JxdWVzdGFkb3IgZGUgbGEgcmVwcm9kdWNjacOzbi4gVml2ZSBlbiBlbCBzaWRlIHBhbmVsOiBtYW5kYSBjYWRhIHBhc28gYWwgY29udGVudFxuLy8gc2NyaXB0IGRlIGxhIHBlc3Rhw7FhIHkgZ2VzdGlvbmEgbmF2ZWdhY2lvbmVzIGVudHJlIHDDoWdpbmFzIChxdWUgbWF0YW4gYWwgY29udGVudCBzY3JpcHQpLlxuaW1wb3J0IHR5cGUgeyBTdGVwUmVzdWx0LCBUb0NvbnRlbnQgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgdHlwZSB7IEZyYW1lUmVmLCBGbG93LCBSdW5TdW1tYXJ5LCBTZXR0aW5ncywgU3RlcCB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IEJVSUxUSU5fVkFSUywgaW50ZXJwb2xhdGUsIHNsZWVwIH0gZnJvbSBcIi4uL3NoYXJlZC91dGlsXCI7XG5cbmV4cG9ydCB0eXBlIFN0ZXBTdGF0dXMgPSBcInBlbmRpbmdcIiB8IFwicnVubmluZ1wiIHwgXCJva1wiIHwgXCJlcnJvclwiIHwgXCJza2lwcGVkXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuSG9va3Mge1xuICBvblN0YXR1cyhzdGVwSWQ6IHN0cmluZywgc3RhdHVzOiBTdGVwU3RhdHVzLCBpbmZvPzogc3RyaW5nKTogdm9pZDtcbn1cblxuY29uc3QgUE9SVF9DTE9TRUQgPSAvbWVzc2FnZSBwb3J0IGNsb3NlZHxSZWNlaXZpbmcgZW5kIGRvZXMgbm90IGV4aXN0fGJhY2tcXC9mb3J3YXJkIGNhY2hlfGNvbnRleHQgaW52YWxpZGF0ZWQvaTtcblxuLyoqIHBhbmVsLmh0bWw/dGFiPTxpZD4gZmlqYSBlbCBwYW5lbCBhIHVuYSBwZXN0YcOxYSBjb25jcmV0YSAow7p0aWwgYWJpZXJ0byBjb21vIHBlc3Rhw7FhIG8gZW4gdGVzdHMpLiAqL1xuY29uc3QgcGlubmVkVGFiID0gTnVtYmVyKG5ldyBVUkxTZWFyY2hQYXJhbXMobG9jYXRpb24uc2VhcmNoKS5nZXQoXCJ0YWJcIikpIHx8IHVuZGVmaW5lZDtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFjdGl2ZVRhYigpOiBQcm9taXNlPGNocm9tZS50YWJzLlRhYj4ge1xuICBpZiAocGlubmVkVGFiKSByZXR1cm4gY2hyb21lLnRhYnMuZ2V0KHBpbm5lZFRhYik7XG4gIGNvbnN0IFt0YWJdID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoeyBhY3RpdmU6IHRydWUsIGN1cnJlbnRXaW5kb3c6IHRydWUgfSk7XG4gIGlmICghdGFiPy5pZCkgdGhyb3cgbmV3IEVycm9yKFwiTm8gaGF5IHBlc3Rhw7FhIGFjdGl2YVwiKTtcbiAgcmV0dXJuIHRhYjtcbn1cblxuYXN5bmMgZnVuY3Rpb24gd2FpdEZvckxvYWQodGFiSWQ6IG51bWJlciwgdGltZW91dCA9IDMwMDAwKSB7XG4gIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgd2hpbGUgKERhdGUubm93KCkgLSBzdGFydCA8IHRpbWVvdXQpIHtcbiAgICBjb25zdCB0ID0gYXdhaXQgY2hyb21lLnRhYnMuZ2V0KHRhYklkKTtcbiAgICBpZiAodC5zdGF0dXMgPT09IFwiY29tcGxldGVcIikgcmV0dXJuO1xuICAgIGF3YWl0IHNsZWVwKDEyMCk7XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKFwiTGEgcMOhZ2luYSB0YXJkw7MgZGVtYXNpYWRvIGVuIGNhcmdhclwiKTtcbn1cblxuLyoqIE9ic2VydmEgbmF2ZWdhY2lvbmVzIGRlIHDDoWdpbmEgY29tcGxldGEgZW4gbGEgcGVzdGHDsWEgKGluaWNpbyB5IGZpbikuICovXG5mdW5jdGlvbiB3YXRjaE5hdmlnYXRpb25zKHRhYklkOiBudW1iZXIsIGZyYW1lSWQgPSAwKSB7XG4gIGxldCBzdGFydGVkID0gZmFsc2U7XG4gIGxldCBwZW5kaW5nID0gMDtcbiAgY29uc3QgbWluZSA9IChkOiB7IHRhYklkOiBudW1iZXI7IGZyYW1lSWQ6IG51bWJlciB9KSA9PiBkLnRhYklkID09PSB0YWJJZCAmJiAoZC5mcmFtZUlkID09PSAwIHx8IGQuZnJhbWVJZCA9PT0gZnJhbWVJZCk7XG4gIGNvbnN0IG9uU3RhcnQgPSAoZDogY2hyb21lLndlYk5hdmlnYXRpb24uV2ViTmF2aWdhdGlvblBhcmVudGVkQ2FsbGJhY2tEZXRhaWxzKSA9PiB7XG4gICAgaWYgKG1pbmUoZCkpIChzdGFydGVkID0gdHJ1ZSksIHBlbmRpbmcrKztcbiAgfTtcbiAgY29uc3Qgb25FbmQgPSAoZDogeyB0YWJJZDogbnVtYmVyOyBmcmFtZUlkOiBudW1iZXIgfSkgPT4ge1xuICAgIGlmIChtaW5lKGQpKSBwZW5kaW5nID0gTWF0aC5tYXgoMCwgcGVuZGluZyAtIDEpO1xuICB9O1xuICBjb25zdCBuYXYgPSBjaHJvbWUud2ViTmF2aWdhdGlvbjtcbiAgbmF2Lm9uQmVmb3JlTmF2aWdhdGUuYWRkTGlzdGVuZXIob25TdGFydCk7XG4gIG5hdi5vbkNvbXBsZXRlZC5hZGRMaXN0ZW5lcihvbkVuZCk7XG4gIG5hdi5vbkVycm9yT2NjdXJyZWQuYWRkTGlzdGVuZXIob25FbmQpO1xuICByZXR1cm4ge1xuICAgIC8qKiDCv0VtcGV6w7MgYWxndW5hIG5hdmVnYWNpw7NuIGVuIGxvcyBwcsOzeGltb3MgYHdpdGhpbmAgbXM/ICovXG4gICAgYXN5bmMgc3RhcnRlZCh3aXRoaW46IG51bWJlcikge1xuICAgICAgY29uc3QgZW5kID0gRGF0ZS5ub3coKSArIHdpdGhpbjtcbiAgICAgIHdoaWxlICghc3RhcnRlZCAmJiBEYXRlLm5vdygpIDwgZW5kKSBhd2FpdCBzbGVlcCg1MCk7XG4gICAgICByZXR1cm4gc3RhcnRlZDtcbiAgICB9LFxuICAgIC8qKiBFc3BlcmEgYSBxdWUgdGVybWluZW4gbGFzIG5hdmVnYWNpb25lcyBlbiBjdXJzby4gKi9cbiAgICBhc3luYyBzZXR0bGVkKHRpbWVvdXQgPSAzMDAwMCkge1xuICAgICAgY29uc3QgZW5kID0gRGF0ZS5ub3coKSArIHRpbWVvdXQ7XG4gICAgICB3aGlsZSAocGVuZGluZyA+IDApIHtcbiAgICAgICAgaWYgKERhdGUubm93KCkgPiBlbmQpIHRocm93IG5ldyBFcnJvcihcIkxhIHDDoWdpbmEgdGFyZMOzIGRlbWFzaWFkbyBlbiBjYXJnYXJcIik7XG4gICAgICAgIGF3YWl0IHNsZWVwKDgwKTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHdhaXRGb3JMb2FkKHRhYklkLCB0aW1lb3V0KTtcbiAgICB9LFxuICAgIGRpc3Bvc2UoKSB7XG4gICAgICBuYXYub25CZWZvcmVOYXZpZ2F0ZS5yZW1vdmVMaXN0ZW5lcihvblN0YXJ0KTtcbiAgICAgIG5hdi5vbkNvbXBsZXRlZC5yZW1vdmVMaXN0ZW5lcihvbkVuZCk7XG4gICAgICBuYXYub25FcnJvck9jY3VycmVkLnJlbW92ZUxpc3RlbmVyKG9uRW5kKTtcbiAgICB9LFxuICB9O1xufVxuXG4vKiogR2FyYW50aXphIHF1ZSBlbCBjb250ZW50IHNjcmlwdCByZXNwb25kZSBlbiBlbCBmcmFtZSAobG8gaW55ZWN0YSBzaSBoYWNlIGZhbHRhKS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnN1cmVDb250ZW50KHRhYklkOiBudW1iZXIsIGZyYW1lSWQgPSAwKTogUHJvbWlzZTx2b2lkPiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgMjA7IGkrKykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByID0gYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiSWQsIHsga2luZDogXCJwaW5nXCIgfSBzYXRpc2ZpZXMgVG9Db250ZW50LCB7IGZyYW1lSWQgfSk7XG4gICAgICBpZiAocj8ub2spIHJldHVybjtcbiAgICB9IGNhdGNoIHtcbiAgICAgIC8qIGHDum4gbm8gZXN0w6EgKi9cbiAgICB9XG4gICAgaWYgKGkgPT09IDMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIFBlc3Rhw7FhIGFiaWVydGEgYW50ZXMgZGUgaW5zdGFsYXIgbGEgZXh0ZW5zacOzbjogdGFtYmnDqW4gZWwgaG9vayBkZSByZWQgKG11bmRvIGRlIGxhIHDDoWdpbmEpLlxuICAgICAgICBhd2FpdCBjaHJvbWUuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoeyB0YXJnZXQ6IHsgdGFiSWQsIGZyYW1lSWRzOiBbZnJhbWVJZF0gfSwgZmlsZXM6IFtcImhvb2suanNcIl0sIHdvcmxkOiBcIk1BSU5cIiB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgICAgIGF3YWl0IGNocm9tZS5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7IHRhcmdldDogeyB0YWJJZCwgZnJhbWVJZHM6IFtmcmFtZUlkXSB9LCBmaWxlczogW1wiY29udGVudC5qc1wiXSB9KTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gc2UgcHVlZGUgYWN0dWFyIGVuIGVzdGEgcMOhZ2luYSAoXCIgKyAoZSBhcyBFcnJvcikubWVzc2FnZSArIFwiKVwiKTtcbiAgICAgIH1cbiAgICB9XG4gICAgYXdhaXQgc2xlZXAoMTUwKTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoZnJhbWVJZCA/IFwiRWwgaWZyYW1lIG5vIHJlc3BvbmRlXCIgOiBcIkVsIGNvbnRlbnQgc2NyaXB0IG5vIHJlc3BvbmRlIGVuIGxhIHBlc3Rhw7FhXCIpO1xufVxuXG4vKiogRW52w61hIGEgdW4gZnJhbWUgY29uY3JldG8gKDAgPSBww6FnaW5hIHByaW5jaXBhbCkuIE51bmNhIGEgdG9kb3M6IGNhZGEgZnJhbWUgZWplY3V0YXLDrWEgZWwgcGFzby4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZW5kVG9UYWI8VCA9IHVua25vd24+KHRhYklkOiBudW1iZXIsIG1zZzogVG9Db250ZW50LCBmcmFtZUlkID0gMCk6IFByb21pc2U8VD4ge1xuICBhd2FpdCBlbnN1cmVDb250ZW50KHRhYklkLCBmcmFtZUlkKTtcbiAgcmV0dXJuIGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYklkLCBtc2csIHsgZnJhbWVJZCB9KTtcbn1cblxuLyoqIFJlY29ycmUgbGEgcnV0YSBkZSBpZnJhbWVzIGRlbCBwYXNvIHkgZGV2dWVsdmUgZWwgZnJhbWVJZCBkZWwgZG9jdW1lbnRvIGRlc3Rpbm8uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZnJhbWVJZEZvcih0YWJJZDogbnVtYmVyLCBmcmFtZTogRnJhbWVSZWZbXSB8IHVuZGVmaW5lZCwgdGltZW91dDogbnVtYmVyKTogUHJvbWlzZTxudW1iZXI+IHtcbiAgbGV0IGZpZCA9IDA7XG4gIGZvciAoY29uc3QgW2ksIHJlZl0gb2YgKGZyYW1lID8/IFtdKS5lbnRyaWVzKCkpIHtcbiAgICBjb25zdCBlbmQgPSBEYXRlLm5vdygpICsgdGltZW91dDtcbiAgICBsZXQgbmV4dDogbnVtYmVyIHwgdW5kZWZpbmVkO1xuICAgIC8vIEVsIHBhZHJlIGxvY2FsaXphIGVsIDxpZnJhbWU+IHkgbGUgbWFuZGEgdW5hIHNvbmRhOyBlbCBjb250ZW50IHNjcmlwdCBkZWwgaGlqbyBsYSByZXBvcnRhXG4gICAgLy8gYWwgYmFja2dyb3VuZCBjb24gc3UgZnJhbWVJZC4gU2kgZWwgaWZyYW1lIGHDum4gY2FyZ2EsIGxhIHNvbmRhIHNlIHBpZXJkZTogc2UgcmVpbnRlbnRhLlxuICAgIHdoaWxlIChuZXh0ID09IG51bGwpIHtcbiAgICAgIGNvbnN0IHIgPSBhd2FpdCBzZW5kVG9UYWI8eyB0b2tlbj86IHN0cmluZzsgZXJyb3I/OiBzdHJpbmcgfT4oXG4gICAgICAgIHRhYklkLFxuICAgICAgICB7IGtpbmQ6IFwiZnJhbWU6cmVzb2x2ZVwiLCBzZWxlY3RvcnM6IFtyZWYuc2VsZWN0b3IsIC4uLihyZWYuZmFsbGJhY2tzID8/IFtdKV0sIHRpbWVvdXQ6IE1hdGgubWF4KDAsIGVuZCAtIERhdGUubm93KCkpIH0sXG4gICAgICAgIGZpZCxcbiAgICAgICk7XG4gICAgICBpZiAoIXI/LnRva2VuKSB0aHJvdyBuZXcgRXJyb3IoYCR7cj8uZXJyb3IgPz8gXCJObyBzZSBlbmNvbnRyw7MgZWwgaWZyYW1lXCJ9IChuaXZlbCAke2kgKyAxfSlgKTtcbiAgICAgIGZvciAobGV0IGsgPSAwOyBrIDwgOCAmJiBuZXh0ID09IG51bGw7IGsrKykge1xuICAgICAgICBhd2FpdCBzbGVlcCg2MCk7XG4gICAgICAgIG5leHQgPSAoYXdhaXQgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyBraW5kOiBcImZyYW1lOnByb2JlZFwiLCB0b2tlbjogci50b2tlbiB9KSk/LmZyYW1lSWQ7XG4gICAgICB9XG4gICAgICBpZiAobmV4dCA9PSBudWxsICYmIERhdGUubm93KCkgPiBlbmQpIHRocm93IG5ldyBFcnJvcihgRWwgaWZyYW1lIMKrJHtyZWYuc2VsZWN0b3J9wrsgbm8gcmVzcG9uZGUgKG5pdmVsICR7aSArIDF9KWApO1xuICAgIH1cbiAgICBmaWQgPSBuZXh0O1xuICB9XG4gIHJldHVybiBmaWQ7XG59XG5cbi8qKiBWYWxvcmVzIGRlIHZhcmlhYmxlcyBwYXJhIHVuYSBlamVjdWNpw7NuOiBpbnRlZ3JhZGFzIGZpamFkYXMgdW5hIHZleiArIGxhcyBkZWwgZmx1am8uICovXG5leHBvcnQgZnVuY3Rpb24gcnVuVmFyaWFibGVzKGZsb3c6IEZsb3cpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgY29uc3QgYmFzZTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICBmb3IgKGNvbnN0IGIgb2YgQlVJTFRJTl9WQVJTKSBiYXNlW2JdID0gaW50ZXJwb2xhdGUoYHt7JHtifX19YCwge30pO1xuICBjb25zdCB2YXJzID0geyAuLi5iYXNlIH07XG4gIGZvciAoY29uc3QgW2ssIHZdIG9mIE9iamVjdC5lbnRyaWVzKGZsb3cudmFyaWFibGVzID8/IHt9KSkgdmFyc1trXSA9IGludGVycG9sYXRlKHYsIGJhc2UpO1xuICByZXR1cm4gdmFycztcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZVN0ZXAoc3RlcDogU3RlcCwgdmFyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IFN0ZXAge1xuICByZXR1cm4geyAuLi5zdGVwLCB2YWx1ZTogc3RlcC52YWx1ZSAhPSBudWxsID8gaW50ZXJwb2xhdGUoc3RlcC52YWx1ZSwgdmFycykgOiB1bmRlZmluZWQgfTtcbn1cblxuZXhwb3J0IGNsYXNzIFJ1bm5lciB7XG4gIHByaXZhdGUgc3RvcHBlZCA9IGZhbHNlO1xuICBydW5uaW5nID0gZmFsc2U7XG5cbiAgc3RvcCgpIHtcbiAgICB0aGlzLnN0b3BwZWQgPSB0cnVlO1xuICB9XG5cbiAgYXN5bmMgcnVuKGZsb3c6IEZsb3csIHNldHRpbmdzOiBTZXR0aW5ncywgaG9va3M6IFJ1bkhvb2tzLCBmcm9tID0gMCwgb25seT86IG51bWJlcik6IFByb21pc2U8UnVuU3VtbWFyeT4ge1xuICAgIHRoaXMuc3RvcHBlZCA9IGZhbHNlO1xuICAgIHRoaXMucnVubmluZyA9IHRydWU7XG4gICAgY29uc3QgdDAgPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IHZhcnMgPSBydW5WYXJpYWJsZXMoZmxvdyk7XG4gICAgY29uc3Qgc3RlcHMgPSBmbG93LnN0ZXBzO1xuICAgIGNvbnN0IGVuZCA9IG9ubHkgIT0gbnVsbCA/IG9ubHkgKyAxIDogc3RlcHMubGVuZ3RoO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc3RlcHMubGVuZ3RoOyBpKyspIGlmIChpID49IGZyb20gJiYgaSA8IGVuZCkgaG9va3Mub25TdGF0dXMoc3RlcHNbaV0hLmlkLCBcInBlbmRpbmdcIik7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdGFiID0gYXdhaXQgYWN0aXZlVGFiKCk7XG4gICAgICBjb25zdCB0YWJJZCA9IHRhYi5pZCE7XG4gICAgICBmb3IgKGxldCBpID0gZnJvbTsgaSA8IGVuZDsgaSsrKSB7XG4gICAgICAgIGlmICh0aGlzLnN0b3BwZWQpIHRocm93IG5ldyBFcnJvcihcIkRldGVuaWRvIHBvciBlbCB1c3VhcmlvXCIpO1xuICAgICAgICBjb25zdCBzdGVwID0gc3RlcHNbaV0hO1xuICAgICAgICBpZiAoIXN0ZXAuZW5hYmxlZCkge1xuICAgICAgICAgIGhvb2tzLm9uU3RhdHVzKHN0ZXAuaWQsIFwic2tpcHBlZFwiKTtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBob29rcy5vblN0YXR1cyhzdGVwLmlkLCBcInJ1bm5pbmdcIik7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgdGhpcy5leGVjKHRhYklkLCByZXNvbHZlU3RlcChzdGVwLCB2YXJzKSwgc2V0dGluZ3MpO1xuICAgICAgICAgIGhvb2tzLm9uU3RhdHVzKHN0ZXAuaWQsIFwib2tcIik7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBjb25zdCBtc2cgPSAoZSBhcyBFcnJvcikubWVzc2FnZTtcbiAgICAgICAgICBob29rcy5vblN0YXR1cyhzdGVwLmlkLCBcImVycm9yXCIsIG1zZyk7XG4gICAgICAgICAgcmV0dXJuIHsgYXQ6IHQwLCBvazogZmFsc2UsIG1zOiBEYXRlLm5vdygpIC0gdDAsIGZhaWxlZFN0ZXBJZDogc3RlcC5pZCwgZXJyb3I6IG1zZyB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChpIDwgZW5kIC0gMSAmJiBzZXR0aW5ncy5zdGVwRGVsYXkpIGF3YWl0IHNsZWVwKHNldHRpbmdzLnN0ZXBEZWxheSk7XG4gICAgICB9XG4gICAgICByZXR1cm4geyBhdDogdDAsIG9rOiB0cnVlLCBtczogRGF0ZS5ub3coKSAtIHQwIH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgcmV0dXJuIHsgYXQ6IHQwLCBvazogZmFsc2UsIG1zOiBEYXRlLm5vdygpIC0gdDAsIGVycm9yOiAoZSBhcyBFcnJvcikubWVzc2FnZSB9O1xuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLnJ1bm5pbmcgPSBmYWxzZTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGV4ZWModGFiSWQ6IG51bWJlciwgc3RlcDogU3RlcCwgc2V0dGluZ3M6IFNldHRpbmdzKSB7XG4gICAgc3dpdGNoIChzdGVwLnR5cGUpIHtcbiAgICAgIGNhc2UgXCJuYXZpZ2F0ZVwiOiB7XG4gICAgICAgIGlmICghc3RlcC52YWx1ZSkgdGhyb3cgbmV3IEVycm9yKFwiRmFsdGEgbGEgVVJMXCIpO1xuICAgICAgICBjb25zdCBuYXZzID0gd2F0Y2hOYXZpZ2F0aW9ucyh0YWJJZCk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHRhYklkLCB7IHVybDogc3RlcC52YWx1ZSB9KTtcbiAgICAgICAgICBhd2FpdCBuYXZzLnN0YXJ0ZWQoMzAwMCk7XG4gICAgICAgICAgYXdhaXQgbmF2cy5zZXR0bGVkKCk7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgbmF2cy5kaXNwb3NlKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY2FzZSBcIndhaXRcIjpcbiAgICAgICAgYXdhaXQgc2xlZXAoTnVtYmVyKHN0ZXAudmFsdWUpIHx8IDEwMDApO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgYWN0cyA9IHN0ZXAudHlwZSA9PT0gXCJjbGlja1wiIHx8IHN0ZXAudHlwZSA9PT0gXCJwcmVzc1wiO1xuICAgIGNvbnN0IHRpbWVvdXQgPSBzdGVwLnRpbWVvdXQgPz8gc2V0dGluZ3MudGltZW91dDtcbiAgICBsZXQgcmVzOiBTdGVwUmVzdWx0IHwgdW5kZWZpbmVkO1xuICAgIGxldCBmaWQgPSBhd2FpdCBmcmFtZUlkRm9yKHRhYklkLCBzdGVwLmZyYW1lLCB0aW1lb3V0KTtcbiAgICBjb25zdCBuYXZzID0gd2F0Y2hOYXZpZ2F0aW9ucyh0YWJJZCwgZmlkKTtcbiAgICB0cnkge1xuICAgICAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IDsgYXR0ZW1wdCsrKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgcmVzID0gYXdhaXQgc2VuZFRvVGFiPFN0ZXBSZXN1bHQ+KHRhYklkLCB7IGtpbmQ6IFwicnVuLXN0ZXBcIiwgc3RlcCwgc2V0dGluZ3MgfSwgZmlkKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGlmICghUE9SVF9DTE9TRUQudGVzdCgoZSBhcyBFcnJvcikubWVzc2FnZSkpIHRocm93IGU7XG4gICAgICAgICAgLy8gTGEgcMOhZ2luYSAobyBlbCBpZnJhbWUpIG5hdmVnw7MgbWllbnRyYXMgc2UgZWplY3V0YWJhIGVsIHBhc28uXG4gICAgICAgICAgYXdhaXQgbmF2cy5zZXR0bGVkKCk7XG4gICAgICAgICAgaWYgKGFjdHMpIHJldHVybjsgLy8gZWwgY2xpY2svdGVjbGEgeWEgcHJvdm9jw7MgbGEgbmF2ZWdhY2nDs25cbiAgICAgICAgICBpZiAoYXR0ZW1wdCA+PSAyKSB0aHJvdyBuZXcgRXJyb3IoXCJMYSBww6FnaW5hIG5vIHBhcsOzIGRlIG5hdmVnYXIgZHVyYW50ZSBlbCBwYXNvXCIpO1xuICAgICAgICAgIGZpZCA9IGF3YWl0IGZyYW1lSWRGb3IodGFiSWQsIHN0ZXAuZnJhbWUsIHRpbWVvdXQpO1xuICAgICAgICAgIGNvbnRpbnVlOyAvLyByZWludGVudGFyIGVuIGxhIHDDoWdpbmEgbnVldmFcbiAgICAgICAgfVxuICAgICAgICBpZiAoIXJlcykgdGhyb3cgbmV3IEVycm9yKFwiU2luIHJlc3B1ZXN0YSBkZSBsYSBww6FnaW5hXCIpO1xuICAgICAgICBpZiAoIXJlcy5vaykgdGhyb3cgbmV3IEVycm9yKHJlcy5lcnJvcik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgLy8gVW4gY2xpY2sgZW4gZW5sYWNlL3N1Ym1pdCBwdWVkZSBuYXZlZ2FyIGNvbiByZXRyYXNvICh2YWxpZGFjacOzbiwgcGV0aWNpw7NuIGFsIHNlcnZpZG9y4oCmKTpcbiAgICAgIC8vIGRhbW9zIHVuIG1hcmdlbiBwYXJhIHF1ZSBlbXBpZWNlIHksIHNpIGVtcGllemEsIGVzcGVyYW1vcyBhIHF1ZSBjYXJndWUuXG4gICAgICBpZiAoYWN0cyAmJiAoYXdhaXQgbmF2cy5zdGFydGVkKHJlcy5tYXlOYXZpZ2F0ZSA/IDE1MDAgOiAxNTApKSkgYXdhaXQgbmF2cy5zZXR0bGVkKCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIG5hdnMuZGlzcG9zZSgpO1xuICAgIH1cbiAgfVxufVxuIiwKICAgICIvLyBNaW5pIGhlbHBlcnMgZGUgVUkgc2luIGZyYW1ld29yazogaCgpIHBhcmEgY3JlYXIgRE9NLCBkacOhbG9nb3MsIHRvYXN0cyB5IGRlc2Nhcmdhcy5cblxudHlwZSBDaGlsZCA9IE5vZGUgfCBzdHJpbmcgfCBudW1iZXIgfCBudWxsIHwgdW5kZWZpbmVkIHwgZmFsc2UgfCBDaGlsZFtdO1xudHlwZSBQcm9wcyA9IFJlY29yZDxzdHJpbmcsIHVua25vd24+ICYgeyBjbGFzcz86IHN0cmluZyB8IGZhbHNlIHwgbnVsbDsgc3R5bGU/OiBzdHJpbmcgfTtcblxuZXhwb3J0IGZ1bmN0aW9uIGg8SyBleHRlbmRzIGtleW9mIEhUTUxFbGVtZW50VGFnTmFtZU1hcD4odGFnOiBLLCBwcm9wcz86IFByb3BzIHwgbnVsbCwgLi4uY2hpbGRyZW46IENoaWxkW10pOiBIVE1MRWxlbWVudFRhZ05hbWVNYXBbS10ge1xuICBjb25zdCBlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodGFnKTtcbiAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMocHJvcHMgPz8ge30pKSB7XG4gICAgaWYgKHYgPT0gbnVsbCB8fCB2ID09PSBmYWxzZSkgY29udGludWU7XG4gICAgaWYgKGsuc3RhcnRzV2l0aChcIm9uXCIpICYmIHR5cGVvZiB2ID09PSBcImZ1bmN0aW9uXCIpIGVsLmFkZEV2ZW50TGlzdGVuZXIoay5zbGljZSgyKS50b0xvd2VyQ2FzZSgpLCB2IGFzIEV2ZW50TGlzdGVuZXIpO1xuICAgIGVsc2UgaWYgKGsgPT09IFwiY2xhc3NcIikgZWwuY2xhc3NOYW1lID0gU3RyaW5nKHYpO1xuICAgIGVsc2UgaWYgKGsgPT09IFwidmFsdWVcIiB8fCBrID09PSBcImNoZWNrZWRcIiB8fCBrID09PSBcInNlbGVjdGVkXCIgfHwgayA9PT0gXCJpbmRldGVybWluYXRlXCIpIChlbCBhcyBhbnkpW2tdID0gdjtcbiAgICBlbHNlIGlmICh2ID09PSB0cnVlKSBlbC5zZXRBdHRyaWJ1dGUoaywgXCJcIik7XG4gICAgZWxzZSBlbC5zZXRBdHRyaWJ1dGUoaywgU3RyaW5nKHYpKTtcbiAgfVxuICBhcHBlbmQoZWwsIGNoaWxkcmVuKTtcbiAgcmV0dXJuIGVsO1xufVxuXG5mdW5jdGlvbiBhcHBlbmQoZWw6IE5vZGUsIGNoaWxkcmVuOiBDaGlsZFtdKSB7XG4gIGZvciAoY29uc3QgYyBvZiBjaGlsZHJlbikge1xuICAgIGlmIChjID09IG51bGwgfHwgYyA9PT0gZmFsc2UpIGNvbnRpbnVlO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGMpKSBhcHBlbmQoZWwsIGMpO1xuICAgIGVsc2UgZWwuYXBwZW5kQ2hpbGQoYyBpbnN0YW5jZW9mIE5vZGUgPyBjIDogZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoU3RyaW5nKGMpKSk7XG4gIH1cbn1cblxuLyoqIFJlLXJlbmRlcml6YSBjb25zZXJ2YW5kbyBlbCBmb2NvIHkgbGEgc2VsZWNjacOzbiBkZWwgaW5wdXQgYWN0aXZvIChwb3IgZGF0YS1rKSB5IGVsIHNjcm9sbC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb3JwaChyb290OiBIVE1MRWxlbWVudCwgbmV4dDogTm9kZSkge1xuICBjb25zdCBhY3RpdmUgPSBkb2N1bWVudC5hY3RpdmVFbGVtZW50IGFzIEhUTUxJbnB1dEVsZW1lbnQgfCBudWxsO1xuICBjb25zdCBrZXkgPSBhY3RpdmU/LmRhdGFzZXQ/Lms7XG4gIGNvbnN0IHNlbCA9IGtleSAmJiBcInNlbGVjdGlvblN0YXJ0XCIgaW4gYWN0aXZlISA/IFthY3RpdmUhLnNlbGVjdGlvblN0YXJ0LCBhY3RpdmUhLnNlbGVjdGlvbkVuZF0gOiBudWxsO1xuICBjb25zdCBzY3JvbGxlcnMgPSBbLi4ucm9vdC5xdWVyeVNlbGVjdG9yQWxsPEhUTUxFbGVtZW50PihcIltkYXRhLXNjcm9sbF1cIildLm1hcCgoZSkgPT4gW2UuZGF0YXNldC5zY3JvbGwsIGUuc2Nyb2xsVG9wXSBhcyBjb25zdCk7XG4gIHJvb3QucmVwbGFjZUNoaWxkcmVuKG5leHQpO1xuICBmb3IgKGNvbnN0IFtrLCB0b3BdIG9mIHNjcm9sbGVycykge1xuICAgIGNvbnN0IGUgPSByb290LnF1ZXJ5U2VsZWN0b3I8SFRNTEVsZW1lbnQ+KGBbZGF0YS1zY3JvbGw9XCIke2t9XCJdYCk7XG4gICAgaWYgKGUpIGUuc2Nyb2xsVG9wID0gdG9wO1xuICB9XG4gIGlmIChrZXkpIHtcbiAgICBjb25zdCBlbCA9IHJvb3QucXVlcnlTZWxlY3RvcjxIVE1MSW5wdXRFbGVtZW50PihgW2RhdGEtaz1cIiR7Q1NTLmVzY2FwZShrZXkpfVwiXWApO1xuICAgIGlmIChlbCkge1xuICAgICAgZWwuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsOiB0cnVlIH0pO1xuICAgICAgaWYgKHNlbCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGVsLnNldFNlbGVjdGlvblJhbmdlKHNlbFswXSwgc2VsWzFdKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLyogdGlwb3Mgc2luIHNlbGVjY2nDs24gKi9cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRGnDoWxvZ29zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5pbnRlcmZhY2UgQXNrT3B0cyB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIG1lc3NhZ2U/OiBzdHJpbmc7XG4gIGlucHV0Pzogc3RyaW5nOyAvLyBzaSBzZSBwYXNhLCBtdWVzdHJhIHVuIGNhbXBvIGRlIHRleHRvIGNvbiBlc3RlIHZhbG9yIGluaWNpYWxcbiAgcGxhY2Vob2xkZXI/OiBzdHJpbmc7XG4gIG9rPzogc3RyaW5nO1xuICBkYW5nZXI/OiBib29sZWFuO1xuICBvcHRpb25zPzogc3RyaW5nW107IC8vIHN1Z2VyZW5jaWFzIHBhcmEgZWwgaW5wdXRcbiAgZXh0cmE/OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBzdHJpbmcgfTsgLy8gYm90w7NuIGFsdGVybmF0aXZvXG59XG5cbi8qKiBEacOhbG9nbyBtb2RhbC4gRGV2dWVsdmUgZWwgdGV4dG8gKG8gXCJva1wiKSwgZWwgdmFsdWUgZGVsIGJvdMOzbiBleHRyYSwgbyBudWxsIHNpIHNlIGNhbmNlbGEuICovXG5leHBvcnQgZnVuY3Rpb24gYXNrKG86IEFza09wdHMpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgY29uc3QgbGlzdElkID0gXCJkbC1cIiArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnNsaWNlKDIpO1xuICAgIGNvbnN0IGlucHV0ID1cbiAgICAgIG8uaW5wdXQgIT0gbnVsbCA/IGgoXCJpbnB1dFwiLCB7IGNsYXNzOiBcImlucHV0XCIsIHZhbHVlOiBvLmlucHV0LCBwbGFjZWhvbGRlcjogby5wbGFjZWhvbGRlciwgbGlzdDogby5vcHRpb25zID8gbGlzdElkIDogbnVsbCB9KSA6IG51bGw7XG4gICAgY29uc3QgZGxnID0gaChcbiAgICAgIFwiZGlhbG9nXCIsXG4gICAgICB7IGNsYXNzOiBcImRpYWxvZ1wiIH0sXG4gICAgICBoKFxuICAgICAgICBcImZvcm1cIixcbiAgICAgICAgeyBtZXRob2Q6IFwiZGlhbG9nXCIgfSxcbiAgICAgICAgaChcImgzXCIsIG51bGwsIG8udGl0bGUpLFxuICAgICAgICBvLm1lc3NhZ2UgJiYgaChcInBcIiwgeyBjbGFzczogXCJtdXRlZFwiIH0sIG8ubWVzc2FnZSksXG4gICAgICAgIGlucHV0LFxuICAgICAgICBvLm9wdGlvbnMgJiYgaChcImRhdGFsaXN0XCIsIHsgaWQ6IGxpc3RJZCB9LCBvLm9wdGlvbnMubWFwKCh4KSA9PiBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IHggfSkpKSxcbiAgICAgICAgaChcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IFwicm93IGVuZFwiIH0sXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biBnaG9zdFwiLCB2YWx1ZTogXCJfX2NhbmNlbFwiLCB0eXBlOiBcInN1Ym1pdFwiIH0sIFwiQ2FuY2VsYXJcIiksXG4gICAgICAgICAgby5leHRyYSAmJiBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuXCIsIHZhbHVlOiBcIl9fZXh0cmFcIiwgdHlwZTogXCJzdWJtaXRcIiB9LCBvLmV4dHJhLmxhYmVsKSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIFwiICsgKG8uZGFuZ2VyID8gXCJkYW5nZXJcIiA6IFwicHJpbWFyeVwiKSwgdmFsdWU6IFwiX19va1wiLCB0eXBlOiBcInN1Ym1pdFwiIH0sIG8ub2sgPz8gXCJBY2VwdGFyXCIpLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApO1xuICAgIGRsZy5hZGRFdmVudExpc3RlbmVyKFwiY2xvc2VcIiwgKCkgPT4ge1xuICAgICAgY29uc3QgcnYgPSBkbGcucmV0dXJuVmFsdWU7XG4gICAgICBkbGcucmVtb3ZlKCk7XG4gICAgICBpZiAocnYgPT09IFwiX19va1wiKSByZXNvbHZlKGlucHV0ID8gaW5wdXQudmFsdWUgOiBcIm9rXCIpO1xuICAgICAgZWxzZSBpZiAocnYgPT09IFwiX19leHRyYVwiKSByZXNvbHZlKG8uZXh0cmEhLnZhbHVlKTtcbiAgICAgIGVsc2UgcmVzb2x2ZShudWxsKTtcbiAgICB9KTtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGRsZyk7XG4gICAgZGxnLnNob3dNb2RhbCgpO1xuICAgIGlmIChpbnB1dCkge1xuICAgICAgLy8gRW50ZXIgPSBhY2VwdGFyIChzaSBubywgZWwgZW52w61vIGltcGzDrWNpdG8gcHVsc2Fyw61hIGVsIHByaW1lciBib3TDs246IMKrQ2FuY2VsYXLCuykuXG4gICAgICBpbnB1dC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCAoZSkgPT4ge1xuICAgICAgICBpZiAoZS5rZXkgPT09IFwiRW50ZXJcIikge1xuICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICBkbGcuY2xvc2UoXCJfX29rXCIpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlucHV0LmZvY3VzKCk7XG4gICAgICBpbnB1dC5zZWxlY3QoKTtcbiAgICB9XG4gIH0pO1xufVxuXG5sZXQgdG9hc3RUaW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCB1bmRlZmluZWQ7XG5leHBvcnQgZnVuY3Rpb24gdG9hc3QodGV4dDogc3RyaW5nLCBraW5kOiBcIm9rXCIgfCBcImVycm9yXCIgfCBcImluZm9cIiA9IFwiaW5mb1wiKSB7XG4gIGxldCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwidG9hc3RcIik7XG4gIGlmICghZWwpIHtcbiAgICBlbCA9IGgoXCJkaXZcIiwgeyBpZDogXCJ0b2FzdFwiIH0pO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZWwpO1xuICB9XG4gIGVsLnRleHRDb250ZW50ID0gdGV4dDtcbiAgZWwuY2xhc3NOYW1lID0gXCJzaG93IFwiICsga2luZDtcbiAgY2xlYXJUaW1lb3V0KHRvYXN0VGltZXIpO1xuICB0b2FzdFRpbWVyID0gc2V0VGltZW91dCgoKSA9PiAoZWwhLmNsYXNzTmFtZSA9IFwiXCIpLCBraW5kID09PSBcImVycm9yXCIgPyA1MDAwIDogMjUwMCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZChmaWxlbmFtZTogc3RyaW5nLCBjb250ZW50OiBzdHJpbmcsIG1pbWUgPSBcImFwcGxpY2F0aW9uL2pzb25cIikge1xuICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKG5ldyBCbG9iKFtjb250ZW50XSwgeyB0eXBlOiBtaW1lIH0pKTtcbiAgY29uc3QgYSA9IGgoXCJhXCIsIHsgaHJlZjogdXJsLCBkb3dubG9hZDogZmlsZW5hbWUgfSk7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XG4gIGEuY2xpY2soKTtcbiAgYS5yZW1vdmUoKTtcbiAgc2V0VGltZW91dCgoKSA9PiBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCksIDIwMDApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGlja0ZpbGUoYWNjZXB0ID0gXCIuanNvbixhcHBsaWNhdGlvbi9qc29uXCIpOiBQcm9taXNlPEZpbGUgfCBudWxsPiB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgIGNvbnN0IGlucHV0ID0gaChcImlucHV0XCIsIHsgdHlwZTogXCJmaWxlXCIsIGFjY2VwdCB9KTtcbiAgICBpbnB1dC5hZGRFdmVudExpc3RlbmVyKFwiY2hhbmdlXCIsICgpID0+IHJlc29sdmUoaW5wdXQuZmlsZXM/LlswXSA/PyBudWxsKSk7XG4gICAgaW5wdXQuYWRkRXZlbnRMaXN0ZW5lcihcImNhbmNlbFwiLCAoKSA9PiByZXNvbHZlKG51bGwpKTtcbiAgICBpbnB1dC5jbGljaygpO1xuICB9KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHRpbWVBZ28odHM6IG51bWJlcik6IHN0cmluZyB7XG4gIGNvbnN0IHMgPSBNYXRoLnJvdW5kKChEYXRlLm5vdygpIC0gdHMpIC8gMTAwMCk7XG4gIGlmIChzIDwgNDUpIHJldHVybiBcImFob3JhXCI7XG4gIGNvbnN0IG0gPSBNYXRoLnJvdW5kKHMgLyA2MCk7XG4gIGlmIChtIDwgNjApIHJldHVybiBgaGFjZSAke219IG1pbmA7XG4gIGNvbnN0IGhyID0gTWF0aC5yb3VuZChtIC8gNjApO1xuICBpZiAoaHIgPCAyNCkgcmV0dXJuIGBoYWNlICR7aHJ9IGhgO1xuICBjb25zdCBkID0gTWF0aC5yb3VuZChociAvIDI0KTtcbiAgaWYgKGQgPCAzMCkgcmV0dXJuIGBoYWNlICR7ZH0gZGA7XG4gIHJldHVybiBuZXcgRGF0ZSh0cykudG9Mb2NhbGVEYXRlU3RyaW5nKCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBob3N0T2YodXJsPzogc3RyaW5nKTogc3RyaW5nIHtcbiAgaWYgKCF1cmwpIHJldHVybiBcIlwiO1xuICB0cnkge1xuICAgIHJldHVybiBuZXcgVVJMKHVybCkuaG9zdDtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIFwiXCI7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlYm91bmNlPEEgZXh0ZW5kcyB1bmtub3duW10+KGZuOiAoLi4uYTogQSkgPT4gdm9pZCwgbXM6IG51bWJlcikge1xuICBsZXQgdDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD4gfCB1bmRlZmluZWQ7XG4gIHJldHVybiAoLi4uYTogQSkgPT4ge1xuICAgIGNsZWFyVGltZW91dCh0KTtcbiAgICB0ID0gc2V0VGltZW91dCgoKSA9PiBmbiguLi5hKSwgbXMpO1xuICB9O1xufVxuIiwKICAgICJpbXBvcnQgeyB0b0RldlRvb2xzIH0gZnJvbSBcIi4uL3NoYXJlZC9kZXZ0b29sc1wiO1xuaW1wb3J0IHsgcGFyc2VJbXBvcnQsIHNsdWcsIHRvRXhwb3J0RmlsZSwgdG9QdXBwZXRlZXIgfSBmcm9tIFwiLi4vc2hhcmVkL2V4cG9ydGVyc1wiO1xuaW1wb3J0IHR5cGUgeyBQYW5lbFRvQmFja2dyb3VuZCwgUmVjb3JkZWRTdGVwIH0gZnJvbSBcIi4uL3NoYXJlZC9tZXNzYWdlc1wiO1xuaW1wb3J0ICogYXMgc3RvcmUgZnJvbSBcIi4uL3NoYXJlZC9zdG9yZVwiO1xuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgdHlwZSBGbG93LCB0eXBlIFJlY29yZGluZ1N0YXRlLCB0eXBlIFNldHRpbmdzLCB0eXBlIFN0ZXAsIHR5cGUgU3RlcFR5cGUgfSBmcm9tIFwiLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgeyB1aWQgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcbmltcG9ydCB7IGFjdGl2ZVRhYiwgZnJhbWVJZEZvciwgUnVubmVyLCBzZW5kVG9UYWIsIHR5cGUgU3RlcFN0YXR1cyB9IGZyb20gXCIuL3J1bm5lclwiO1xuaW1wb3J0IHsgYXNrLCBkZWJvdW5jZSwgZG93bmxvYWQsIHRvYXN0IH0gZnJvbSBcIi4vdWlcIjtcblxuZXhwb3J0IHR5cGUgVmlldyA9IFwibGlicmFyeVwiIHwgXCJlZGl0b3JcIiB8IFwic2V0dGluZ3NcIjtcblxuZXhwb3J0IGNvbnN0IHN0YXRlID0ge1xuICB2aWV3OiBcImxpYnJhcnlcIiBhcyBWaWV3LFxuICBmbG93czogW10gYXMgRmxvd1tdLFxuICBjdXJyZW50SWQ6IHVuZGVmaW5lZCBhcyBzdHJpbmcgfCB1bmRlZmluZWQsXG4gIHNldHRpbmdzOiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfSBhcyBTZXR0aW5ncyxcbiAgcmVjb3JkaW5nOiB1bmRlZmluZWQgYXMgUmVjb3JkaW5nU3RhdGUgfCB1bmRlZmluZWQsXG4gIGV4cGFuZGVkOiBuZXcgU2V0PHN0cmluZz4oKSxcbiAgc2VsZWN0ZWQ6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICBmaWx0ZXI6IHsgcTogXCJcIiwgZm9sZGVyOiBcIlwiLCB0YWdzOiBuZXcgU2V0PHN0cmluZz4oKSwgc29ydDogXCJ1cGRhdGVkXCIgYXMgXCJ1cGRhdGVkXCIgfCBcIm5hbWVcIiB8IFwibGFzdFJ1blwiIH0sXG4gIGNvbGxhcHNlZEZvbGRlcnM6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICBydW46IHVuZGVmaW5lZCBhcyB1bmRlZmluZWQgfCB7IGZsb3dJZDogc3RyaW5nOyBzdGF0dXM6IFJlY29yZDxzdHJpbmcsIFN0ZXBTdGF0dXM+OyBpbmZvOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IH0sXG4gIHBpY2tpbmc6IHVuZGVmaW5lZCBhcyBzdHJpbmcgfCB1bmRlZmluZWQsIC8vIGlkIGRlbCBwYXNvIHF1ZSBzZSBlc3TDoSByZS1hcHVudGFuZG9cbiAgZHJhZ0lkOiB1bmRlZmluZWQgYXMgc3RyaW5nIHwgdW5kZWZpbmVkLFxufTtcblxubGV0IHJlbmRlckZuOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG5leHBvcnQgY29uc3Qgc2V0UmVuZGVyID0gKGZuOiAoKSA9PiB2b2lkKSA9PiAocmVuZGVyRm4gPSBmbik7XG5leHBvcnQgY29uc3QgcmVuZGVyID0gKCkgPT4gcmVuZGVyRm4oKTtcblxuZXhwb3J0IGNvbnN0IHJ1bm5lciA9IG5ldyBSdW5uZXIoKTtcblxuZXhwb3J0IGNvbnN0IGN1cnJlbnQgPSAoKSA9PiBzdGF0ZS5mbG93cy5maW5kKChmKSA9PiBmLmlkID09PSBzdGF0ZS5jdXJyZW50SWQpO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUGVyc2lzdGVuY2lhIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBwZW5kaW5nU2F2ZXMgPSBuZXcgTWFwPHN0cmluZywgKCkgPT4gdm9pZD4oKTtcblxuLyoqIEd1YXJkYSB1biBmbHVqbyBjb24gZGVib3VuY2UgKHBhcmEgaW5wdXRzIGRlIHRleHRvKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzYXZlU29vbihmbG93OiBGbG93KSB7XG4gIGxldCBmbiA9IHBlbmRpbmdTYXZlcy5nZXQoZmxvdy5pZCk7XG4gIGlmICghZm4pIHtcbiAgICBmbiA9IGRlYm91bmNlKCgpID0+IHtcbiAgICAgIGNvbnN0IGYgPSBzdGF0ZS5mbG93cy5maW5kKCh4KSA9PiB4LmlkID09PSBmbG93LmlkKTtcbiAgICAgIGlmIChmKSB2b2lkIHN0b3JlLnNhdmVGbG93KGYpO1xuICAgIH0sIDMwMCk7XG4gICAgcGVuZGluZ1NhdmVzLnNldChmbG93LmlkLCBmbik7XG4gIH1cbiAgZm4oKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVOb3coZmxvdzogRmxvdykge1xuICBhd2FpdCBzdG9yZS5zYXZlRmxvdyhmbG93KTtcbiAgcmVuZGVyKCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWxvYWQoKSB7XG4gIHN0YXRlLmZsb3dzID0gYXdhaXQgc3RvcmUubGlzdEZsb3dzKCk7XG4gIHJlbmRlcigpO1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRmx1am9zIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlRmxvdygpIHtcbiAgY29uc3QgbmFtZSA9IGF3YWl0IGFzayh7IHRpdGxlOiBcIk51ZXZvIGZsdWpvXCIsIGlucHV0OiBcIlwiLCBwbGFjZWhvbGRlcjogXCJwLiBlai4gQWx0YSBkZSBjbGllbnRlXCIsIG9rOiBcIkNyZWFyXCIgfSk7XG4gIGlmIChuYW1lID09IG51bGwpIHJldHVybjtcbiAgY29uc3QgZm9sZGVyID0gc3RhdGUuZmlsdGVyLmZvbGRlciAmJiBzdGF0ZS5maWx0ZXIuZm9sZGVyICE9PSBcIl9fbm9uZVwiID8gc3RhdGUuZmlsdGVyLmZvbGRlciA6IHVuZGVmaW5lZDtcbiAgY29uc3QgZmxvdyA9IHN0b3JlLm5ld0Zsb3coeyBuYW1lOiBuYW1lLnRyaW0oKSB8fCBcIk51ZXZvIGZsdWpvXCIsIGZvbGRlciB9KTtcbiAgYXdhaXQgc3RvcmUuc2F2ZUZsb3coZmxvdyk7XG4gIC8vIEVsIGxpc3RlbmVyIGRlIHN0b3JhZ2UgcHVlZGUgaGFiZXJsbyBhw7FhZGlkbyB5YS5cbiAgaWYgKCFzdGF0ZS5mbG93cy5zb21lKChmKSA9PiBmLmlkID09PSBmbG93LmlkKSkgc3RhdGUuZmxvd3MudW5zaGlmdChmbG93KTtcbiAgb3BlbkZsb3coZmxvdy5pZCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBvcGVuRmxvdyhpZDogc3RyaW5nKSB7XG4gIHN0YXRlLmN1cnJlbnRJZCA9IGlkO1xuICBzdGF0ZS52aWV3ID0gXCJlZGl0b3JcIjtcbiAgc3RhdGUuZXhwYW5kZWQuY2xlYXIoKTtcbiAgaWYgKHN0YXRlLnJ1bj8uZmxvd0lkICE9PSBpZCkgc3RhdGUucnVuID0gdW5kZWZpbmVkO1xuICByZW5kZXIoKTtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIltkYXRhLXNjcm9sbF1cIik/LnNjcm9sbFRvKDAsIDApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZHVwbGljYXRlRmxvdyhmbG93OiBGbG93KSB7XG4gIGNvbnN0IGNvcHkgPSBzdHJ1Y3R1cmVkQ2xvbmUoZmxvdyk7XG4gIGNvcHkuaWQgPSB1aWQoKTtcbiAgY29weS5uYW1lID0gZmxvdy5uYW1lICsgXCIgKGNvcGlhKVwiO1xuICBjb3B5LmNyZWF0ZWRBdCA9IERhdGUubm93KCk7XG4gIGNvcHkubGFzdFJ1biA9IHVuZGVmaW5lZDtcbiAgY29weS5zdGVwcy5mb3JFYWNoKChzKSA9PiAocy5pZCA9IHVpZCgpKSk7XG4gIGF3YWl0IHN0b3JlLnNhdmVGbG93KGNvcHkpO1xuICBhd2FpdCByZWxvYWQoKTtcbiAgdG9hc3QoXCJGbHVqbyBkdXBsaWNhZG9cIiwgXCJva1wiKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbW92ZUZsb3dzKGlkczogc3RyaW5nW10pIHtcbiAgY29uc3QgbmFtZXMgPSBzdGF0ZS5mbG93cy5maWx0ZXIoKGYpID0+IGlkcy5pbmNsdWRlcyhmLmlkKSkubWFwKChmKSA9PiBmLm5hbWUpO1xuICBjb25zdCBvayA9IGF3YWl0IGFzayh7XG4gICAgdGl0bGU6IGlkcy5sZW5ndGggPT09IDEgPyBgwr9Cb3JyYXIgwqske25hbWVzWzBdfcK7P2AgOiBgwr9Cb3JyYXIgJHtpZHMubGVuZ3RofSBmbHVqb3M/YCxcbiAgICBtZXNzYWdlOiBcIk5vIHNlIHB1ZWRlIGRlc2hhY2VyLiBFeHBvcnRhIGFudGVzIHNpIHF1aWVyZXMgY29uc2VydmFybG9zLlwiLFxuICAgIG9rOiBcIkJvcnJhclwiLFxuICAgIGRhbmdlcjogdHJ1ZSxcbiAgfSk7XG4gIGlmICghb2spIHJldHVybjtcbiAgYXdhaXQgc3RvcmUuZGVsZXRlRmxvd3MoaWRzKTtcbiAgaWRzLmZvckVhY2goKGlkKSA9PiBzdGF0ZS5zZWxlY3RlZC5kZWxldGUoaWQpKTtcbiAgaWYgKHN0YXRlLmN1cnJlbnRJZCAmJiBpZHMuaW5jbHVkZXMoc3RhdGUuY3VycmVudElkKSkgc3RhdGUudmlldyA9IFwibGlicmFyeVwiO1xuICBhd2FpdCByZWxvYWQoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFsbEZvbGRlcnMoKTogc3RyaW5nW10ge1xuICByZXR1cm4gWy4uLm5ldyBTZXQoc3RhdGUuZmxvd3MubWFwKChmKSA9PiBmLmZvbGRlcikuZmlsdGVyKEJvb2xlYW4pIGFzIHN0cmluZ1tdKV0uc29ydCgoYSwgYikgPT4gYS5sb2NhbGVDb21wYXJlKGIpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFsbFRhZ3MoKTogc3RyaW5nW10ge1xuICByZXR1cm4gWy4uLm5ldyBTZXQoc3RhdGUuZmxvd3MuZmxhdE1hcCgoZikgPT4gZi50YWdzKSldLnNvcnQoKGEsIGIpID0+IGEubG9jYWxlQ29tcGFyZShiKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJlZEZsb3dzKCk6IEZsb3dbXSB7XG4gIGNvbnN0IHsgcSwgZm9sZGVyLCB0YWdzLCBzb3J0IH0gPSBzdGF0ZS5maWx0ZXI7XG4gIGNvbnN0IHRva2VucyA9IHEudG9Mb3dlckNhc2UoKS5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3QgbGlzdCA9IHN0YXRlLmZsb3dzLmZpbHRlcigoZikgPT4ge1xuICAgIGlmIChmb2xkZXIgPT09IFwiX19ub25lXCIgPyBmLmZvbGRlciA6IGZvbGRlciAmJiBmLmZvbGRlciAhPT0gZm9sZGVyKSByZXR1cm4gZmFsc2U7XG4gICAgZm9yIChjb25zdCB0IG9mIHRhZ3MpIGlmICghZi50YWdzLmluY2x1ZGVzKHQpKSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKCF0b2tlbnMubGVuZ3RoKSByZXR1cm4gdHJ1ZTtcbiAgICBjb25zdCBoYXkgPSBbZi5uYW1lLCBmLmRlc2NyaXB0aW9uLCBmLmZvbGRlciwgLi4uZi50YWdzLm1hcCgodCkgPT4gXCIjXCIgKyB0KSwgLi4uZi5zdGVwcy5tYXAoKHMpID0+IGAke3MubGFiZWwgPz8gXCJcIn0gJHtzLnR5cGUgPT09IFwibmF2aWdhdGVcIiA/IHMudmFsdWUgOiBcIlwifWApXVxuICAgICAgLmpvaW4oXCIgXCIpXG4gICAgICAudG9Mb3dlckNhc2UoKTtcbiAgICByZXR1cm4gdG9rZW5zLmV2ZXJ5KCh0KSA9PiBoYXkuaW5jbHVkZXModCkpO1xuICB9KTtcbiAgaWYgKHNvcnQgPT09IFwibmFtZVwiKSBsaXN0LnNvcnQoKGEsIGIpID0+IGEubmFtZS5sb2NhbGVDb21wYXJlKGIubmFtZSkpO1xuICBlbHNlIGlmIChzb3J0ID09PSBcImxhc3RSdW5cIikgbGlzdC5zb3J0KChhLCBiKSA9PiAoYi5sYXN0UnVuPy5hdCA/PyAwKSAtIChhLmxhc3RSdW4/LmF0ID8/IDApKTtcbiAgZWxzZSBsaXN0LnNvcnQoKGEsIGIpID0+IGIudXBkYXRlZEF0IC0gYS51cGRhdGVkQXQpO1xuICByZXR1cm4gbGlzdDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGJ1bGtNb3ZlKGlkczogc3RyaW5nW10pIHtcbiAgY29uc3QgZm9sZGVyID0gYXdhaXQgYXNrKHsgdGl0bGU6IFwiTW92ZXIgYSBjYXJwZXRhXCIsIGlucHV0OiBcIlwiLCBwbGFjZWhvbGRlcjogXCJOb21icmUgZGUgY2FycGV0YSAodmFjw61vID0gc2luIGNhcnBldGEpXCIsIG9wdGlvbnM6IGFsbEZvbGRlcnMoKSwgb2s6IFwiTW92ZXJcIiB9KTtcbiAgaWYgKGZvbGRlciA9PSBudWxsKSByZXR1cm47XG4gIGZvciAoY29uc3QgZiBvZiBzdGF0ZS5mbG93cy5maWx0ZXIoKHgpID0+IGlkcy5pbmNsdWRlcyh4LmlkKSkpIHtcbiAgICBmLmZvbGRlciA9IGZvbGRlci50cmltKCkgfHwgdW5kZWZpbmVkO1xuICAgIGF3YWl0IHN0b3JlLnNhdmVGbG93KGYpO1xuICB9XG4gIGF3YWl0IHJlbG9hZCgpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVsa1RhZyhpZHM6IHN0cmluZ1tdKSB7XG4gIGNvbnN0IHRhZyA9IGF3YWl0IGFzayh7IHRpdGxlOiBcIkHDsWFkaXIgZXRpcXVldGFcIiwgaW5wdXQ6IFwiXCIsIHBsYWNlaG9sZGVyOiBcImV0aXF1ZXRhXCIsIG9wdGlvbnM6IGFsbFRhZ3MoKSwgb2s6IFwiQcOxYWRpclwiIH0pO1xuICBjb25zdCB0ID0gdGFnPy50cmltKCkucmVwbGFjZSgvXiMvLCBcIlwiKTtcbiAgaWYgKCF0KSByZXR1cm47XG4gIGZvciAoY29uc3QgZiBvZiBzdGF0ZS5mbG93cy5maWx0ZXIoKHgpID0+IGlkcy5pbmNsdWRlcyh4LmlkKSkpIHtcbiAgICBpZiAoIWYudGFncy5pbmNsdWRlcyh0KSkgZi50YWdzLnB1c2godCk7XG4gICAgYXdhaXQgc3RvcmUuc2F2ZUZsb3coZik7XG4gIH1cbiAgYXdhaXQgcmVsb2FkKCk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBJbXBvcnQgLyBleHBvcnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmNvbnN0IHN0YW1wID0gKCkgPT4gbmV3IERhdGUoKS50b0lTT1N0cmluZygpLnNsaWNlKDAsIDEwKTtcblxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydEZsb3dzKGZsb3dzOiBGbG93W10pIHtcbiAgaWYgKCFmbG93cy5sZW5ndGgpIHJldHVybiB0b2FzdChcIk5vIGhheSBmbHVqb3MgcXVlIGV4cG9ydGFyXCIsIFwiZXJyb3JcIik7XG4gIGNvbnN0IG5hbWUgPSBmbG93cy5sZW5ndGggPT09IDEgPyBgcmFzdHJvLSR7c2x1ZyhmbG93c1swXSEubmFtZSl9LSR7c3RhbXAoKX0uanNvbmAgOiBgcmFzdHJvLSR7Zmxvd3MubGVuZ3RofS1mbHVqb3MtJHtzdGFtcCgpfS5qc29uYDtcbiAgZG93bmxvYWQobmFtZSwgSlNPTi5zdHJpbmdpZnkodG9FeHBvcnRGaWxlKGZsb3dzKSwgbnVsbCwgMikpO1xuICB0b2FzdChgJHtmbG93cy5sZW5ndGh9IGZsdWpvKHMpIGV4cG9ydGFkbyhzKWAsIFwib2tcIik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHBvcnRQdXBwZXRlZXIoZmxvdzogRmxvdykge1xuICBkb3dubG9hZChgJHtzbHVnKGZsb3cubmFtZSl9Lm1qc2AsIHRvUHVwcGV0ZWVyKGZsb3cpLCBcInRleHQvamF2YXNjcmlwdFwiKTtcbiAgdG9hc3QoXCJTY3JpcHQgZGUgUHVwcGV0ZWVyIGRlc2NhcmdhZG9cIiwgXCJva1wiKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGltcG9ydFRleHQodGV4dDogc3RyaW5nKSB7XG4gIGxldCBmbG93czogRmxvd1tdO1xuICBsZXQgcmVzdWx0OiBSZXR1cm5UeXBlPHR5cGVvZiBwYXJzZUltcG9ydD47XG4gIHRyeSB7XG4gICAgcmVzdWx0ID0gcGFyc2VJbXBvcnQodGV4dCk7XG4gICAgZmxvd3MgPSByZXN1bHQuZmxvd3M7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICByZXR1cm4gdG9hc3QoKGUgYXMgRXJyb3IpLm1lc3NhZ2UsIFwiZXJyb3JcIik7XG4gIH1cbiAgY29uc3QgZXhpc3RpbmcgPSBuZXcgU2V0KHN0YXRlLmZsb3dzLm1hcCgoZikgPT4gZi5pZCkpO1xuICBjb25zdCBjbGFzaGVzID0gZmxvd3MuZmlsdGVyKChmKSA9PiBleGlzdGluZy5oYXMoZi5pZCkpO1xuICBsZXQgbW9kZTogXCJvdmVyd3JpdGVcIiB8IFwiY29weVwiID0gXCJjb3B5XCI7XG4gIGlmIChjbGFzaGVzLmxlbmd0aCkge1xuICAgIGNvbnN0IHIgPSBhd2FpdCBhc2soe1xuICAgICAgdGl0bGU6IGAke2NsYXNoZXMubGVuZ3RofSBmbHVqbyhzKSB5YSBleGlzdGVuYCxcbiAgICAgIG1lc3NhZ2U6IGNsYXNoZXMubWFwKChmKSA9PiBmLm5hbWUpLmpvaW4oXCIsIFwiKSxcbiAgICAgIG9rOiBcIlNvYnJlc2NyaWJpclwiLFxuICAgICAgZXh0cmE6IHsgbGFiZWw6IFwiSW1wb3J0YXIgY29tbyBjb3BpYVwiLCB2YWx1ZTogXCJjb3B5XCIgfSxcbiAgICB9KTtcbiAgICBpZiAociA9PSBudWxsKSByZXR1cm47XG4gICAgbW9kZSA9IHIgPT09IFwiY29weVwiID8gXCJjb3B5XCIgOiBcIm92ZXJ3cml0ZVwiO1xuICB9XG4gIGZvciAoY29uc3QgZiBvZiBmbG93cykge1xuICAgIGlmIChleGlzdGluZy5oYXMoZi5pZCkgJiYgbW9kZSA9PT0gXCJjb3B5XCIpIHtcbiAgICAgIGYuaWQgPSB1aWQoKTtcbiAgICAgIGYubmFtZSArPSBcIiAoaW1wb3J0YWRvKVwiO1xuICAgIH1cbiAgICBhd2FpdCBzdG9yZS5zYXZlRmxvdyhmKTtcbiAgfVxuICBhd2FpdCByZWxvYWQoKTtcbiAgaWYgKHJlc3VsdC5zb3VyY2UgPT09IFwiZGV2dG9vbHNcIikge1xuICAgIGNvbnN0IG4gPSByZXN1bHQuc2tpcHBlZC5sZW5ndGg7XG4gICAgdG9hc3QoYEdyYWJhY2nDs24gZGUgRGV2VG9vbHMgaW1wb3J0YWRhJHtuID8gYCAoJHtufSBwYXNvKHMpIHNpbiBlcXVpdmFsZW50ZTogJHtbLi4ubmV3IFNldChyZXN1bHQuc2tpcHBlZCldLmpvaW4oXCIsIFwiKX0pYCA6IFwiXCJ9YCwgbiA/IFwiaW5mb1wiIDogXCJva1wiKTtcbiAgICBvcGVuRmxvdyhmbG93c1swXSEuaWQpO1xuICB9IGVsc2UgdG9hc3QoYCR7Zmxvd3MubGVuZ3RofSBmbHVqbyhzKSBpbXBvcnRhZG8ocylgLCBcIm9rXCIpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0RGV2VG9vbHMoZmxvdzogRmxvdykge1xuICBjb25zdCB7IGpzb24sIHdhcm5pbmdzIH0gPSB0b0RldlRvb2xzKGZsb3cpO1xuICBkb3dubG9hZChgJHtzbHVnKGZsb3cubmFtZSl9LnJlY29yZGVyLmpzb25gLCBKU09OLnN0cmluZ2lmeShqc29uLCBudWxsLCAyKSk7XG4gIHRvYXN0KFxuICAgIHdhcm5pbmdzID8gYEV4cG9ydGFkby4gJHt3YXJuaW5nc30gcGFzbyhzKSBlbiBpZnJhbWVzIHZhbiBzaW4gcnV0YSBkZSBmcmFtZTogcmV2w61zYWxvcyBlbiBEZXZUb29sc2AgOiBcIkV4cG9ydGFkbzogaW1ww7NydGFsbyBlbiBEZXZUb29scyDigLogUmVjb3JkZXJcIixcbiAgICB3YXJuaW5ncyA/IFwiaW5mb1wiIDogXCJva1wiLFxuICApO1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUGFzb3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRTdGVwKGZsb3c6IEZsb3csIHR5cGU6IFN0ZXBUeXBlLCBhZnRlcj86IHN0cmluZykge1xuICBjb25zdCBzdGVwID0gc3RvcmUubmV3U3RlcCh7IHR5cGUsIHZhbHVlOiB0eXBlID09PSBcInByZXNzXCIgPyBcIkVudGVyXCIgOiB0eXBlID09PSBcIndhaXRcIiA/IFwiMTAwMFwiIDogdHlwZSA9PT0gXCJjaGVja1wiID8gXCJ0cnVlXCIgOiB1bmRlZmluZWQgfSk7XG4gIGNvbnN0IGkgPSBhZnRlciA/IGZsb3cuc3RlcHMuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSBhZnRlcikgOiAtMTtcbiAgaWYgKGkgPj0gMCkgZmxvdy5zdGVwcy5zcGxpY2UoaSArIDEsIDAsIHN0ZXApO1xuICBlbHNlIGZsb3cuc3RlcHMucHVzaChzdGVwKTtcbiAgc3RhdGUuZXhwYW5kZWQuYWRkKHN0ZXAuaWQpO1xuICB2b2lkIHNhdmVOb3coZmxvdyk7XG4gIHJldHVybiBzdGVwO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbW92ZVN0ZXAoZmxvdzogRmxvdywgaWQ6IHN0cmluZywgYmVmb3JlSWQ6IHN0cmluZyB8IG51bGwpIHtcbiAgY29uc3QgZnJvbSA9IGZsb3cuc3RlcHMuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSBpZCk7XG4gIGlmIChmcm9tIDwgMCkgcmV0dXJuO1xuICBjb25zdCBbc10gPSBmbG93LnN0ZXBzLnNwbGljZShmcm9tLCAxKTtcbiAgY29uc3QgdG8gPSBiZWZvcmVJZCA/IGZsb3cuc3RlcHMuZmluZEluZGV4KCh4KSA9PiB4LmlkID09PSBiZWZvcmVJZCkgOiBmbG93LnN0ZXBzLmxlbmd0aDtcbiAgZmxvdy5zdGVwcy5zcGxpY2UodG8gPCAwID8gZmxvdy5zdGVwcy5sZW5ndGggOiB0bywgMCwgcyEpO1xuICB2b2lkIHNhdmVOb3coZmxvdyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkdXBsaWNhdGVTdGVwKGZsb3c6IEZsb3csIHN0ZXA6IFN0ZXApIHtcbiAgY29uc3QgaSA9IGZsb3cuc3RlcHMuaW5kZXhPZihzdGVwKTtcbiAgY29uc3QgY29weSA9IHsgLi4uc3RydWN0dXJlZENsb25lKHN0ZXApLCBpZDogdWlkKCkgfTtcbiAgZmxvdy5zdGVwcy5zcGxpY2UoaSArIDEsIDAsIGNvcHkpO1xuICB2b2lkIHNhdmVOb3coZmxvdyk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWxldGVTdGVwKGZsb3c6IEZsb3csIHN0ZXA6IFN0ZXApIHtcbiAgZmxvdy5zdGVwcyA9IGZsb3cuc3RlcHMuZmlsdGVyKChzKSA9PiBzICE9PSBzdGVwKTtcbiAgc3RhdGUuZXhwYW5kZWQuZGVsZXRlKHN0ZXAuaWQpO1xuICB2b2lkIHNhdmVOb3coZmxvdyk7XG59XG5cbi8qKiBSZS1hcHVudGEgZWwgc2VsZWN0b3IgZGUgdW4gcGFzbyBjbGljYW5kbyBlbiBsYSBww6FnaW5hLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBpY2tGb3IoZmxvdzogRmxvdywgc3RlcDogU3RlcCkge1xuICB0cnkge1xuICAgIGNvbnN0IHRhYiA9IGF3YWl0IGFjdGl2ZVRhYigpO1xuICAgIHN0YXRlLnBpY2tpbmcgPSBzdGVwLmlkO1xuICAgIHJlbmRlcigpO1xuICAgIGF3YWl0IHNlbmRUb1RhYih0YWIuaWQhLCB7IGtpbmQ6IFwicGluZ1wiIH0pO1xuICAgIC8vIFNpbiBmcmFtZUlkOiBzZSBkaWZ1bmRlIGEgdG9kb3MgbG9zIGZyYW1lcyB5IHJlc3BvbmRlIGFxdWVsIGRvbmRlIGNsaXF1ZSBlbCB1c3VhcmlvLlxuICAgIGNvbnN0IHI6IFJlY29yZGVkU3RlcCB8IG51bGwgPSBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQhLCB7IGtpbmQ6IFwicGlja1wiIH0pO1xuICAgIHZvaWQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkISwgeyBraW5kOiBcInBpY2s6Y2FuY2VsXCIgfSkuY2F0Y2goKCkgPT4ge30pO1xuICAgIGlmIChyKSB7XG4gICAgICBzdGVwLnNlbGVjdG9yID0gci5zZWxlY3RvcjtcbiAgICAgIHN0ZXAuZmFsbGJhY2tzID0gci5mYWxsYmFja3M7XG4gICAgICBzdGVwLmxhYmVsID0gci5sYWJlbDtcbiAgICAgIHN0ZXAuZnJhbWUgPSByLmZyYW1lO1xuICAgICAgaWYgKHN0ZXAudHlwZSA9PT0gXCJjbGlja1wiICYmIHIudHlwZSAhPT0gXCJjbGlja1wiKSB7XG4gICAgICAgIC8vIFNpIGFwdW50YXMgYSB1biBpbnB1dCBkZXNkZSB1biBwYXNvIHZhY8OtbywgYWRvcHRhIHN1IHRpcG8geSB2YWxvciBhY3R1YWwuXG4gICAgICAgIE9iamVjdC5hc3NpZ24oc3RlcCwgeyB0eXBlOiByLnR5cGUsIHZhbHVlOiByLnZhbHVlLCBvcHRpb25UZXh0OiByLm9wdGlvblRleHQsIHNlY3JldDogci5zZWNyZXQgfSk7XG4gICAgICB9XG4gICAgICBhd2FpdCBzYXZlTm93KGZsb3cpO1xuICAgICAgdG9hc3QoXCJFbGVtZW50byBhY3R1YWxpemFkb1wiLCBcIm9rXCIpO1xuICAgIH1cbiAgfSBjYXRjaCAoZSkge1xuICAgIHRvYXN0KChlIGFzIEVycm9yKS5tZXNzYWdlLCBcImVycm9yXCIpO1xuICB9IGZpbmFsbHkge1xuICAgIHN0YXRlLnBpY2tpbmcgPSB1bmRlZmluZWQ7XG4gICAgcmVuZGVyKCk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNhbmNlbFBpY2soKSB7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFiID0gYXdhaXQgYWN0aXZlVGFiKCk7XG4gICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkISwgeyBraW5kOiBcInBpY2s6Y2FuY2VsXCIgfSk7XG4gIH0gY2F0Y2gge1xuICAgIC8qIG5hZGEgKi9cbiAgfVxuICBzdGF0ZS5waWNraW5nID0gdW5kZWZpbmVkO1xuICByZW5kZXIoKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhpZ2hsaWdodFN0ZXAoc3RlcDogU3RlcCkge1xuICBpZiAoIXN0ZXAuc2VsZWN0b3IpIHJldHVybjtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWIgPSBhd2FpdCBhY3RpdmVUYWIoKTtcbiAgICBjb25zdCBmaWQgPSBhd2FpdCBmcmFtZUlkRm9yKHRhYi5pZCEsIHN0ZXAuZnJhbWUsIDMwMDApO1xuICAgIGNvbnN0IHIgPSBhd2FpdCBzZW5kVG9UYWI8eyBvazogYm9vbGVhbiB9Pih0YWIuaWQhLCB7IGtpbmQ6IFwiaGlnaGxpZ2h0XCIsIHNlbGVjdG9yOiBzdGVwLnNlbGVjdG9yLCBmYWxsYmFja3M6IHN0ZXAuZmFsbGJhY2tzIH0sIGZpZCk7XG4gICAgaWYgKCFyPy5vaykgdG9hc3QoXCJObyBzZSBlbmN1ZW50cmEgZW4gZXN0YSBww6FnaW5hXCIsIFwiZXJyb3JcIik7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICB0b2FzdCgoZSBhcyBFcnJvcikubWVzc2FnZSwgXCJlcnJvclwiKTtcbiAgfVxufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgR3JhYmFjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY29uc3QgYmcgPSA8VCA9IHsgb2s6IGJvb2xlYW47IGVycm9yPzogc3RyaW5nIH0+KG1zZzogUGFuZWxUb0JhY2tncm91bmQpOiBQcm9taXNlPFQ+ID0+IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKG1zZyk7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdGFydFJlY29yZGluZyhmbG93OiBGbG93LCBtb2RlOiBcInJlY29yZFwiIHwgXCJwb2ludFwiKSB7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFiID0gYXdhaXQgYWN0aXZlVGFiKCk7XG4gICAgaWYgKCF0YWIudXJsIHx8ICEvXihodHRwcz98ZmlsZSk6Ly50ZXN0KHRhYi51cmwpKSB7XG4gICAgICByZXR1cm4gdG9hc3QoXCJBYnJlIHVuYSBww6FnaW5hIHdlYiBlbiBsYSBwZXN0YcOxYSBhY3RpdmEgcGFyYSBncmFiYXJcIiwgXCJlcnJvclwiKTtcbiAgICB9XG4gICAgY29uc3QgciA9IGF3YWl0IGJnKHsga2luZDogXCJyZWNvcmQ6c3RhcnRcIiwgZmxvd0lkOiBmbG93LmlkLCB0YWJJZDogdGFiLmlkISwgbW9kZSB9KTtcbiAgICBpZiAoIXIub2spIHRvYXN0KHIuZXJyb3IgPz8gXCJObyBzZSBwdWRvIGVtcGV6YXIgYSBncmFiYXJcIiwgXCJlcnJvclwiKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHRvYXN0KChlIGFzIEVycm9yKS5tZXNzYWdlLCBcImVycm9yXCIpO1xuICB9XG59XG5cbmV4cG9ydCBjb25zdCBzdG9wUmVjb3JkaW5nID0gKCkgPT4gYmcoeyBraW5kOiBcInJlY29yZDpzdG9wXCIgfSk7XG5leHBvcnQgY29uc3QgcGF1c2VSZWNvcmRpbmcgPSAocGF1c2VkOiBib29sZWFuKSA9PiBiZyh7IGtpbmQ6IFwicmVjb3JkOnBhdXNlXCIsIHBhdXNlZCB9KTtcblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIFJlcHJvZHVjY2nDs24g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwbGF5KGZsb3c6IEZsb3csIGZyb20gPSAwLCBvbmx5PzogbnVtYmVyKSB7XG4gIGlmIChydW5uZXIucnVubmluZykgcmV0dXJuO1xuICBpZiAoc3RhdGUucmVjb3JkaW5nKSBhd2FpdCBzdG9wUmVjb3JkaW5nKCk7XG4gIHN0YXRlLnJ1biA9IHsgZmxvd0lkOiBmbG93LmlkLCBzdGF0dXM6IHt9LCBpbmZvOiB7fSB9O1xuICByZW5kZXIoKTtcbiAgY29uc3Qgc3VtbWFyeSA9IGF3YWl0IHJ1bm5lci5ydW4oZmxvdywgc3RhdGUuc2V0dGluZ3MsIHtcbiAgICBvblN0YXR1cyhpZCwgc3RhdHVzLCBpbmZvKSB7XG4gICAgICBpZiAoIXN0YXRlLnJ1bikgcmV0dXJuO1xuICAgICAgc3RhdGUucnVuLnN0YXR1c1tpZF0gPSBzdGF0dXM7XG4gICAgICBpZiAoaW5mbykgc3RhdGUucnVuLmluZm9baWRdID0gaW5mbztcbiAgICAgIHJlbmRlcigpO1xuICAgICAgaWYgKHN0YXR1cyA9PT0gXCJydW5uaW5nXCIpIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYFtkYXRhLXN0ZXA9XCIke2lkfVwiXWApPy5zY3JvbGxJbnRvVmlldyh7IGJsb2NrOiBcIm5lYXJlc3RcIiB9KTtcbiAgICB9LFxuICB9LCBmcm9tLCBvbmx5KTtcbiAgaWYgKG9ubHkgPT0gbnVsbCkge1xuICAgIGZsb3cubGFzdFJ1biA9IHN1bW1hcnk7XG4gICAgYXdhaXQgc3RvcmUuc2F2ZUZsb3coZmxvdywgZmFsc2UpO1xuICB9XG4gIHJlbmRlcigpO1xuICBpZiAoc3VtbWFyeS5vaykgdG9hc3QoYOKckyBDb21wbGV0YWRvIGVuICR7KHN1bW1hcnkubXMgLyAxMDAwKS50b0ZpeGVkKDEpfXNgLCBcIm9rXCIpO1xuICBlbHNlIHRvYXN0KGDinJcgJHtzdW1tYXJ5LmVycm9yfWAsIFwiZXJyb3JcIik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdG9wUGxheSgpIHtcbiAgcnVubmVyLnN0b3AoKTtcbn1cbiIsCiAgICAiaW1wb3J0IHsgU1RFUF9NRVRBLCB0eXBlIEZsb3csIHR5cGUgU3RlcCwgdHlwZSBTdGVwVHlwZSB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IEJVSUxUSU5fVkFSUyB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0ICogYXMgQSBmcm9tIFwiLi4vc3RhdGVcIjtcbmltcG9ydCB7IHN0YXRlIH0gZnJvbSBcIi4uL3N0YXRlXCI7XG5pbXBvcnQgeyBoLCB0aW1lQWdvIH0gZnJvbSBcIi4uL3VpXCI7XG5cbmNvbnN0IFRZUEVTID0gT2JqZWN0LmtleXMoU1RFUF9NRVRBKSBhcyBTdGVwVHlwZVtdO1xuXG5leHBvcnQgZnVuY3Rpb24gZWRpdG9yVmlldyhmbG93OiBGbG93KTogSFRNTEVsZW1lbnQge1xuICBjb25zdCByZWMgPSBzdGF0ZS5yZWNvcmRpbmc/LmZsb3dJZCA9PT0gZmxvdy5pZCA/IHN0YXRlLnJlY29yZGluZyA6IHVuZGVmaW5lZDtcbiAgY29uc3Qgb3RoZXJSZWMgPSBzdGF0ZS5yZWNvcmRpbmcgJiYgIXJlYztcbiAgY29uc3QgcnVubmluZyA9IEEucnVubmVyLnJ1bm5pbmc7XG4gIGNvbnN0IHJ1biA9IHN0YXRlLnJ1bj8uZmxvd0lkID09PSBmbG93LmlkID8gc3RhdGUucnVuIDogdW5kZWZpbmVkO1xuXG4gIGNvbnN0IHNldCA9IDxLIGV4dGVuZHMga2V5b2YgRmxvdz4oazogSywgdjogRmxvd1tLXSkgPT4ge1xuICAgIGZsb3dba10gPSB2O1xuICAgIEEuc2F2ZVNvb24oZmxvdyk7XG4gIH07XG5cbiAgcmV0dXJuIGgoXG4gICAgXCJkaXZcIixcbiAgICB7IGNsYXNzOiBcInZpZXdcIiB9LFxuICAgIGgoXG4gICAgICBcImhlYWRlclwiLFxuICAgICAgeyBjbGFzczogXCJ0b3BcIiB9LFxuICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biBnaG9zdCBzbVwiLCBvbmNsaWNrOiAoKSA9PiAoKHN0YXRlLnZpZXcgPSBcImxpYnJhcnlcIiksIEEucmVuZGVyKCkpIH0sIFwi4oaQIEZsdWpvc1wiKSxcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwicm93XCIgfSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiRXhwb3J0YXIgSlNPTlwiLCBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydEZsb3dzKFtmbG93XSkgfSwgXCLih6lcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIkV4cG9ydGFyIGEgUHVwcGV0ZWVyXCIsIG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0UHVwcGV0ZWVyKGZsb3cpIH0sIFwiSlNcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIkV4cG9ydGFyIGEgRGV2VG9vbHMgUmVjb3JkZXJcIiwgb25jbGljazogKCkgPT4gQS5leHBvcnREZXZUb29scyhmbG93KSB9LCBcIkRUXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiaWNvblwiLCB0aXRsZTogXCJEdXBsaWNhclwiLCBvbmNsaWNrOiAoKSA9PiBBLmR1cGxpY2F0ZUZsb3coZmxvdykgfSwgXCLip4lcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uIGRhbmdlclwiLCB0aXRsZTogXCJCb3JyYXIgZmx1am9cIiwgb25jbGljazogKCkgPT4gQS5yZW1vdmVGbG93cyhbZmxvdy5pZF0pIH0sIFwi8J+XkVwiKSxcbiAgICAgICksXG4gICAgKSxcbiAgICBoKFxuICAgICAgXCJtYWluXCIsXG4gICAgICB7IGNsYXNzOiBcInNjcm9sbFwiLCBcImRhdGEtc2Nyb2xsXCI6IFwiZWRpdG9yXCIgfSxcbiAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgIGNsYXNzOiBcInRpdGxlLWlucHV0XCIsXG4gICAgICAgIHZhbHVlOiBmbG93Lm5hbWUsXG4gICAgICAgIFwiZGF0YS1rXCI6IFwiZmxvdy1uYW1lXCIsXG4gICAgICAgIHBsYWNlaG9sZGVyOiBcIk5vbWJyZSBkZWwgZmx1am9cIixcbiAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiBzZXQoXCJuYW1lXCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSksXG4gICAgICB9KSxcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwibWV0YS1ncmlkXCIgfSxcbiAgICAgICAgaChcbiAgICAgICAgICBcImxhYmVsXCIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBoKFwic3BhblwiLCBudWxsLCBcIkNhcnBldGFcIiksXG4gICAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgICAgICBsaXN0OiBcImZvbGRlcnNcIixcbiAgICAgICAgICAgIHZhbHVlOiBmbG93LmZvbGRlciA/PyBcIlwiLFxuICAgICAgICAgICAgcGxhY2Vob2xkZXI6IFwi4oCUXCIsXG4gICAgICAgICAgICBcImRhdGEta1wiOiBcImZsb3ctZm9sZGVyXCIsXG4gICAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHNldChcImZvbGRlclwiLCAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWUudHJpbSgpIHx8IHVuZGVmaW5lZCksXG4gICAgICAgICAgfSksXG4gICAgICAgICAgaChcImRhdGFsaXN0XCIsIHsgaWQ6IFwiZm9sZGVyc1wiIH0sIEEuYWxsRm9sZGVycygpLm1hcCgoZikgPT4gaChcIm9wdGlvblwiLCB7IHZhbHVlOiBmIH0pKSksXG4gICAgICAgICksXG4gICAgICAgIGgoXCJsYWJlbFwiLCBudWxsLCBoKFwic3BhblwiLCBudWxsLCBcIkV0aXF1ZXRhc1wiKSwgdGFnRWRpdG9yKGZsb3cpKSxcbiAgICAgICksXG4gICAgICBoKFwidGV4dGFyZWFcIiwge1xuICAgICAgICBjbGFzczogXCJpbnB1dCBkZXNjXCIsXG4gICAgICAgIHJvd3M6IDEsXG4gICAgICAgIHBsYWNlaG9sZGVyOiBcIkRlc2NyaXBjacOzbiAvIG5vdGFzIChvcGNpb25hbClcIixcbiAgICAgICAgXCJkYXRhLWtcIjogXCJmbG93LWRlc2NcIixcbiAgICAgICAgdmFsdWU6IGZsb3cuZGVzY3JpcHRpb24gPz8gXCJcIixcbiAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiBzZXQoXCJkZXNjcmlwdGlvblwiLCAoZS50YXJnZXQgYXMgSFRNTFRleHRBcmVhRWxlbWVudCkudmFsdWUgfHwgdW5kZWZpbmVkKSxcbiAgICAgIH0pLFxuXG4gICAgICAvLyDilIDilIAgQmFycmEgZGUgYWNjaW9uZXMg4pSA4pSAXG4gICAgICBoKFxuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7IGNsYXNzOiBcImFjdGlvbnNcIiB9LFxuICAgICAgICByZWNcbiAgICAgICAgICA/IFtcbiAgICAgICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biByZWMgb25cIiwgb25jbGljazogKCkgPT4gQS5zdG9wUmVjb3JkaW5nKCkgfSwgXCLilqAgVGVybWluYXJcIiksXG4gICAgICAgICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG5cIiwgb25jbGljazogKCkgPT4gQS5wYXVzZVJlY29yZGluZyghcmVjLnBhdXNlZCkgfSwgcmVjLnBhdXNlZCA/IFwi4pa2IFJlYW51ZGFyXCIgOiBcIuKdmuKdmiBQYXVzYXJcIiksXG4gICAgICAgICAgICBdXG4gICAgICAgICAgOiBbXG4gICAgICAgICAgICAgIGgoXG4gICAgICAgICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICAgICAgICB7IGNsYXNzOiBcImJ0biByZWNcIiwgZGlzYWJsZWQ6IHJ1bm5pbmcgfHwgb3RoZXJSZWMsIHRpdGxlOiBcIlVzYSBsYSBww6FnaW5hIG5vcm1hbG1lbnRlOyB0b2RvIGxvIHF1ZSBoYWdhcyBzZSBncmFiYVwiLCBvbmNsaWNrOiAoKSA9PiBBLnN0YXJ0UmVjb3JkaW5nKGZsb3csIFwicmVjb3JkXCIpIH0sXG4gICAgICAgICAgICAgICAgXCLil48gR3JhYmFyXCIsXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICAgIGgoXG4gICAgICAgICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICBjbGFzczogXCJidG5cIixcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiBydW5uaW5nIHx8IG90aGVyUmVjLFxuICAgICAgICAgICAgICAgICAgdGl0bGU6IFwiQ2xpY2EgZWxlbWVudG9zIHBhcmEgYcOxYWRpcmxvcyBzaW4gcXVlIGxvcyBib3RvbmVzIGhhZ2FuIG5hZGFcIixcbiAgICAgICAgICAgICAgICAgIG9uY2xpY2s6ICgpID0+IEEuc3RhcnRSZWNvcmRpbmcoZmxvdywgXCJwb2ludFwiKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFwi4peOIFNlw7FhbGFyXCIsXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICBdLFxuICAgICAgICBydW5uaW5nXG4gICAgICAgICAgPyBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIGRhbmdlclwiLCBvbmNsaWNrOiBBLnN0b3BQbGF5IH0sIFwi4pagIFBhcmFyXCIpXG4gICAgICAgICAgOiBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHByaW1hcnlcIiwgZGlzYWJsZWQ6ICFmbG93LnN0ZXBzLmxlbmd0aCB8fCAhIXJlYywgb25jbGljazogKCkgPT4gQS5wbGF5KGZsb3cpIH0sIFwi4pa2IFJlcHJvZHVjaXJcIiksXG4gICAgICApLFxuICAgICAgcmVjICYmXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICB7IGNsYXNzOiBcImJhbm5lciBcIiArIChyZWMucGF1c2VkID8gXCJwYXVzZWRcIiA6IHJlYy5tb2RlKSB9LFxuICAgICAgICAgIHJlYy5wYXVzZWRcbiAgICAgICAgICAgID8gXCJHcmFiYWNpw7NuIGVuIHBhdXNhLlwiXG4gICAgICAgICAgICA6IHJlYy5tb2RlID09PSBcInJlY29yZFwiXG4gICAgICAgICAgICAgID8gXCJHcmFiYW5kbyBlbiBsYSBwZXN0YcOxYSBhY3RpdmEuIEJvdG9uZXMg4oaSIGNsaWNrLCBpbnB1dHMg4oaSIGVzY3JpYmlyIHN1IGNvbnRlbmlkby5cIlxuICAgICAgICAgICAgICA6IFwiTW9kbyBzZcOxYWxhcjogY2xpY2EgZWxlbWVudG9zIGRlIGxhIHDDoWdpbmEuIExvcyBib3RvbmVzIG5vIHNlIGVqZWN1dGFuLiBFc2MgcGFyYSBzYWxpci5cIixcbiAgICAgICAgKSxcbiAgICAgIG90aGVyUmVjICYmIGgoXCJkaXZcIiwgeyBjbGFzczogXCJiYW5uZXIgcGF1c2VkXCIgfSwgXCJTZSBlc3TDoSBncmFiYW5kbyBvdHJvIGZsdWpvLlwiKSxcbiAgICAgIHN0YXRlLnBpY2tpbmcgJiYgaChcImRpdlwiLCB7IGNsYXNzOiBcImJhbm5lciBwb2ludFwiIH0sIFwiQ2xpY2EgdW4gZWxlbWVudG8gZW4gbGEgcMOhZ2luYeKApiBcIiwgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biBzbVwiLCBvbmNsaWNrOiBBLmNhbmNlbFBpY2sgfSwgXCJDYW5jZWxhclwiKSksXG4gICAgICAhcnVubmluZyAmJiBmbG93Lmxhc3RSdW4gJiYgcnVuU3VtbWFyeShmbG93KSxcblxuICAgICAgdmFyaWFibGVzRWRpdG9yKGZsb3cpLFxuXG4gICAgICAvLyDilIDilIAgUGFzb3Mg4pSA4pSAXG4gICAgICBoKFxuICAgICAgICBcIm9sXCIsXG4gICAgICAgIHtcbiAgICAgICAgICBjbGFzczogXCJzdGVwc1wiLFxuICAgICAgICAgIG9uZHJhZ292ZXI6IChlOiBEcmFnRXZlbnQpID0+IGUucHJldmVudERlZmF1bHQoKSxcbiAgICAgICAgICBvbmRyb3A6IChlOiBEcmFnRXZlbnQpID0+IHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIGlmIChzdGF0ZS5kcmFnSWQpIEEubW92ZVN0ZXAoZmxvdywgc3RhdGUuZHJhZ0lkLCBudWxsKTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBmbG93LnN0ZXBzLm1hcCgocywgaSkgPT4gc3RlcFJvdyhmbG93LCBzLCBpLCBydW4pKSxcbiAgICAgICksXG4gICAgICBmbG93LnN0ZXBzLmxlbmd0aCA9PT0gMCAmJiAhcmVjICYmIGgoXCJwXCIsIHsgY2xhc3M6IFwiZW1wdHkgbXV0ZWRcIiB9LCBcIlNpbiBwYXNvcyB0b2RhdsOtYS4gUHVsc2EgXCIsIGgoXCJiXCIsIG51bGwsIFwiR3JhYmFyXCIpLCBcIiBvIGHDsWFkZSBwYXNvcyBhIG1hbm8uXCIpLFxuICAgICAgYWRkU3RlcE1lbnUoZmxvdyksXG4gICAgKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gcnVuU3VtbWFyeShmbG93OiBGbG93KSB7XG4gIGNvbnN0IHIgPSBmbG93Lmxhc3RSdW4hO1xuICBjb25zdCBpZHggPSByLmZhaWxlZFN0ZXBJZCA/IGZsb3cuc3RlcHMuZmluZEluZGV4KChzKSA9PiBzLmlkID09PSByLmZhaWxlZFN0ZXBJZCkgKyAxIDogMDtcbiAgcmV0dXJuIGgoXG4gICAgXCJkaXZcIixcbiAgICB7IGNsYXNzOiBcInN1bW1hcnkgXCIgKyAoci5vayA/IFwib2tcIiA6IFwiZXJyXCIpIH0sXG4gICAgci5vayA/IGDinJMgT0sgZW4gJHsoci5tcyAvIDEwMDApLnRvRml4ZWQoMSl9c2AgOiBg4pyXIEZhbGzDsyR7aWR4ID8gYCBlbiBlbCBwYXNvICR7aWR4fWAgOiBcIlwifTogJHtyLmVycm9yfWAsXG4gICAgaChcInNwYW5cIiwgeyBjbGFzczogXCJtdXRlZFwiIH0sIFwiIMK3IFwiICsgdGltZUFnbyhyLmF0KSksXG4gICk7XG59XG5cbmZ1bmN0aW9uIHRhZ0VkaXRvcihmbG93OiBGbG93KSB7XG4gIHJldHVybiBoKFxuICAgIFwiZGl2XCIsXG4gICAgeyBjbGFzczogXCJ0YWctZWRpdG9yXCIgfSxcbiAgICBmbG93LnRhZ3MubWFwKCh0KSA9PlxuICAgICAgaChcbiAgICAgICAgXCJzcGFuXCIsXG4gICAgICAgIHsgY2xhc3M6IFwiY2hpcFwiIH0sXG4gICAgICAgIFwiI1wiICsgdCxcbiAgICAgICAgaChcbiAgICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNsYXNzOiBcInhcIixcbiAgICAgICAgICAgIHRpdGxlOiBcIlF1aXRhclwiLFxuICAgICAgICAgICAgb25jbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICBmbG93LnRhZ3MgPSBmbG93LnRhZ3MuZmlsdGVyKCh4KSA9PiB4ICE9PSB0KTtcbiAgICAgICAgICAgICAgdm9pZCBBLnNhdmVOb3coZmxvdyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCLDl1wiLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICBjbGFzczogXCJ0YWctaW5wdXRcIixcbiAgICAgIHBsYWNlaG9sZGVyOiBmbG93LnRhZ3MubGVuZ3RoID8gXCIrXCIgOiBcImHDsWFkaXLigKZcIixcbiAgICAgIGxpc3Q6IFwiYWxsLXRhZ3NcIixcbiAgICAgIFwiZGF0YS1rXCI6IFwidGFnLWlucHV0XCIsXG4gICAgICBvbmtleWRvd246IChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGlucHV0ID0gZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudDtcbiAgICAgICAgaWYgKChlLmtleSA9PT0gXCJFbnRlclwiIHx8IGUua2V5ID09PSBcIixcIikgJiYgaW5wdXQudmFsdWUudHJpbSgpKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGNvbnN0IHQgPSBpbnB1dC52YWx1ZS50cmltKCkucmVwbGFjZSgvXiMvLCBcIlwiKS5yZXBsYWNlKC8sJC8sIFwiXCIpO1xuICAgICAgICAgIGlmICh0ICYmICFmbG93LnRhZ3MuaW5jbHVkZXModCkpIGZsb3cudGFncy5wdXNoKHQpO1xuICAgICAgICAgIGlucHV0LnZhbHVlID0gXCJcIjtcbiAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgfSBlbHNlIGlmIChlLmtleSA9PT0gXCJCYWNrc3BhY2VcIiAmJiAhaW5wdXQudmFsdWUgJiYgZmxvdy50YWdzLmxlbmd0aCkge1xuICAgICAgICAgIGZsb3cudGFncy5wb3AoKTtcbiAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICB9KSxcbiAgICBoKFwiZGF0YWxpc3RcIiwgeyBpZDogXCJhbGwtdGFnc1wiIH0sIEEuYWxsVGFncygpLm1hcCgodCkgPT4gaChcIm9wdGlvblwiLCB7IHZhbHVlOiB0IH0pKSksXG4gICk7XG59XG5cbmxldCB2YXJzT3BlbjogYm9vbGVhbiB8IHVuZGVmaW5lZDtcblxuZnVuY3Rpb24gdmFyaWFibGVzRWRpdG9yKGZsb3c6IEZsb3cpIHtcbiAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKGZsb3cudmFyaWFibGVzID8/IHt9KTtcbiAgY29uc3Qgd3JpdGUgPSAocGFpcnM6IFtzdHJpbmcsIHN0cmluZ11bXSkgPT4ge1xuICAgIGZsb3cudmFyaWFibGVzID0gT2JqZWN0LmZyb21FbnRyaWVzKHBhaXJzLmZpbHRlcigoW2tdKSA9PiBrLnRyaW0oKSkpO1xuICB9O1xuICByZXR1cm4gaChcbiAgICBcImRldGFpbHNcIixcbiAgICB7XG4gICAgICBjbGFzczogXCJ2YXJzXCIsXG4gICAgICBvcGVuOiB2YXJzT3BlbiA/PyBlbnRyaWVzLmxlbmd0aCA+IDAsXG4gICAgICBvbnRvZ2dsZTogKGU6IEV2ZW50KSA9PiAodmFyc09wZW4gPSAoZS50YXJnZXQgYXMgSFRNTERldGFpbHNFbGVtZW50KS5vcGVuKSxcbiAgICB9LFxuICAgIGgoXCJzdW1tYXJ5XCIsIG51bGwsIFwiVmFyaWFibGVzXCIsIGVudHJpZXMubGVuZ3RoID4gMCAmJiBoKFwic3BhblwiLCB7IGNsYXNzOiBcImNvdW50XCIgfSwgU3RyaW5nKGVudHJpZXMubGVuZ3RoKSkpLFxuICAgIGgoXG4gICAgICBcInBcIixcbiAgICAgIHsgY2xhc3M6IFwibXV0ZWQgc21hbGxcIiB9LFxuICAgICAgXCJVc2EgXCIsXG4gICAgICBoKFwiY29kZVwiLCBudWxsLCBcInt7bm9tYnJlfX1cIiksXG4gICAgICBcIiBlbiBjdWFscXVpZXIgdmFsb3IuIEludGVncmFkYXM6IFwiLFxuICAgICAgQlVJTFRJTl9WQVJTLm1hcCgoYiwgaSkgPT4gW2kgPyBcIiwgXCIgOiBcIlwiLCBoKFwiY29kZVwiLCBudWxsLCBge3ske2J9fX1gKV0pLFxuICAgICksXG4gICAgZW50cmllcy5tYXAoKFtrLCB2XSwgaSkgPT5cbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwidmFyLXJvd1wiIH0sXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc20gbW9ub1wiLFxuICAgICAgICAgIHZhbHVlOiBrLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiBcIm5vbWJyZVwiLFxuICAgICAgICAgIFwiZGF0YS1rXCI6IGB2YXItay0ke2l9YCxcbiAgICAgICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBwYWlycyA9IE9iamVjdC5lbnRyaWVzKGZsb3cudmFyaWFibGVzKTtcbiAgICAgICAgICAgIHBhaXJzW2ldID0gWyhlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS50cmltKCksIHZdO1xuICAgICAgICAgICAgd3JpdGUocGFpcnMpO1xuICAgICAgICAgICAgdm9pZCBBLnNhdmVOb3coZmxvdyk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICB2YWx1ZTogdixcbiAgICAgICAgICBwbGFjZWhvbGRlcjogXCJ2YWxvclwiLFxuICAgICAgICAgIFwiZGF0YS1rXCI6IGB2YXItdi0ke2l9YCxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIGZsb3cudmFyaWFibGVzW2tdID0gKGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuICAgICAgICAgICAgQS5zYXZlU29vbihmbG93KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgICAgaChcbiAgICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNsYXNzOiBcImljb25cIixcbiAgICAgICAgICAgIHRpdGxlOiBcIlF1aXRhclwiLFxuICAgICAgICAgICAgb25jbGljazogKCkgPT4ge1xuICAgICAgICAgICAgICBkZWxldGUgZmxvdy52YXJpYWJsZXNba107XG4gICAgICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiw5dcIixcbiAgICAgICAgKSxcbiAgICAgICksXG4gICAgKSxcbiAgICBoKFxuICAgICAgXCJidXR0b25cIixcbiAgICAgIHtcbiAgICAgICAgY2xhc3M6IFwiYnRuIHNtIGdob3N0XCIsXG4gICAgICAgIG9uY2xpY2s6ICgpID0+IHtcbiAgICAgICAgICBsZXQgbiA9IDE7XG4gICAgICAgICAgd2hpbGUgKGB2YXIke259YCBpbiBmbG93LnZhcmlhYmxlcykgbisrO1xuICAgICAgICAgIGZsb3cudmFyaWFibGVzW2B2YXIke259YF0gPSBcIlwiO1xuICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIFwiKyBWYXJpYWJsZVwiLFxuICAgICksXG4gICk7XG59XG5cbmZ1bmN0aW9uIHN1bW1hcnlWYWx1ZShzOiBTdGVwKTogc3RyaW5nIHtcbiAgaWYgKHMudmFsdWUgPT0gbnVsbCB8fCBzLnZhbHVlID09PSBcIlwiKSByZXR1cm4gXCJcIjtcbiAgaWYgKHMuc2VjcmV0KSByZXR1cm4gXCLigKLigKLigKLigKLigKLigKJcIjtcbiAgaWYgKHMudHlwZSA9PT0gXCJjaGVja1wiKSByZXR1cm4gcy52YWx1ZSA9PT0gXCJmYWxzZVwiID8gXCJkZXNtYXJjYXJcIiA6IFwibWFyY2FyXCI7XG4gIGlmIChzLnR5cGUgPT09IFwic2VsZWN0XCIpIHJldHVybiBzLm9wdGlvblRleHQgfHwgcy52YWx1ZTtcbiAgaWYgKHMudHlwZSA9PT0gXCJ3YWl0XCIpIHJldHVybiBgJHtzLnZhbHVlfSBtc2A7XG4gIHJldHVybiBzLnZhbHVlO1xufVxuXG5mdW5jdGlvbiBzdGVwUm93KGZsb3c6IEZsb3csIHM6IFN0ZXAsIGk6IG51bWJlciwgcnVuOiB0eXBlb2Ygc3RhdGUucnVuKSB7XG4gIGNvbnN0IG1ldGEgPSBTVEVQX01FVEFbcy50eXBlXTtcbiAgY29uc3Qgb3BlbiA9IHN0YXRlLmV4cGFuZGVkLmhhcyhzLmlkKTtcbiAgY29uc3Qgc3RhdHVzID0gcnVuPy5zdGF0dXNbcy5pZF07XG4gIGNvbnN0IGluZm8gPSBydW4/LmluZm9bcy5pZF07XG4gIGNvbnN0IHRpdGxlID1cbiAgICBzLnR5cGUgPT09IFwibmF2aWdhdGVcIiA/IHMubGFiZWwgfHwgcy52YWx1ZSB8fCBcIlVSTFwiIDogcy50eXBlID09PSBcInByZXNzXCIgPyBzLnZhbHVlIHx8IFwiRW50ZXJcIiA6IHMudHlwZSA9PT0gXCJ3YWl0XCIgPyBcIlwiIDogcy5sYWJlbCB8fCBzLnNlbGVjdG9yIHx8IFwic2luIGVsZW1lbnRvXCI7XG4gIGNvbnN0IHZhbCA9IHMudHlwZSA9PT0gXCJuYXZpZ2F0ZVwiIHx8IHMudHlwZSA9PT0gXCJwcmVzc1wiID8gXCJcIiA6IHN1bW1hcnlWYWx1ZShzKTtcblxuICBjb25zdCB0b2dnbGUgPSAoKSA9PiB7XG4gICAgb3BlbiA/IHN0YXRlLmV4cGFuZGVkLmRlbGV0ZShzLmlkKSA6IHN0YXRlLmV4cGFuZGVkLmFkZChzLmlkKTtcbiAgICBBLnJlbmRlcigpO1xuICB9O1xuXG4gIGNvbnN0IGxpID0gaChcbiAgICBcImxpXCIsXG4gICAge1xuICAgICAgY2xhc3M6IGBzdGVwIHQtJHtzLnR5cGV9JHtvcGVuID8gXCIgb3BlblwiIDogXCJcIn0ke3MuZW5hYmxlZCA/IFwiXCIgOiBcIiBkaXNhYmxlZFwifSR7c3RhdHVzID8gXCIgc3QtXCIgKyBzdGF0dXMgOiBcIlwifSR7c3RhdGUuZHJhZ0lkID09PSBzLmlkID8gXCIgZHJhZ2dpbmdcIiA6IFwiXCJ9YCxcbiAgICAgIFwiZGF0YS1zdGVwXCI6IHMuaWQsXG4gICAgICBvbmRyYWdzdGFydDogKGU6IERyYWdFdmVudCkgPT4ge1xuICAgICAgICBzdGF0ZS5kcmFnSWQgPSBzLmlkO1xuICAgICAgICBlLmRhdGFUcmFuc2ZlciEuZWZmZWN0QWxsb3dlZCA9IFwibW92ZVwiO1xuICAgICAgICBlLmRhdGFUcmFuc2ZlciEuc2V0RGF0YShcInRleHQvcGxhaW5cIiwgcy5pZCk7XG4gICAgICB9LFxuICAgICAgb25kcmFnZW5kOiAoKSA9PiB7XG4gICAgICAgIHN0YXRlLmRyYWdJZCA9IHVuZGVmaW5lZDtcbiAgICAgICAgbGkuZHJhZ2dhYmxlID0gZmFsc2U7XG4gICAgICAgIEEucmVuZGVyKCk7XG4gICAgICB9LFxuICAgICAgb25kcmFnb3ZlcjogKGU6IERyYWdFdmVudCkgPT4ge1xuICAgICAgICBpZiAoIXN0YXRlLmRyYWdJZCB8fCBzdGF0ZS5kcmFnSWQgPT09IHMuaWQpIHJldHVybjtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zdCByID0gbGkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGxpLmNsYXNzTGlzdC50b2dnbGUoXCJkcm9wLWJlZm9yZVwiLCBlLmNsaWVudFkgPCByLnRvcCArIHIuaGVpZ2h0IC8gMik7XG4gICAgICAgIGxpLmNsYXNzTGlzdC50b2dnbGUoXCJkcm9wLWFmdGVyXCIsIGUuY2xpZW50WSA+PSByLnRvcCArIHIuaGVpZ2h0IC8gMik7XG4gICAgICB9LFxuICAgICAgb25kcmFnbGVhdmU6ICgpID0+IGxpLmNsYXNzTGlzdC5yZW1vdmUoXCJkcm9wLWJlZm9yZVwiLCBcImRyb3AtYWZ0ZXJcIiksXG4gICAgICBvbmRyb3A6IChlOiBEcmFnRXZlbnQpID0+IHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBpZiAoIXN0YXRlLmRyYWdJZCB8fCBzdGF0ZS5kcmFnSWQgPT09IHMuaWQpIHJldHVybjtcbiAgICAgICAgY29uc3QgYWZ0ZXIgPSBsaS5jbGFzc0xpc3QuY29udGFpbnMoXCJkcm9wLWFmdGVyXCIpO1xuICAgICAgICBjb25zdCBuZXh0ID0gYWZ0ZXIgPyBmbG93LnN0ZXBzW2kgKyAxXT8uaWQgPz8gbnVsbCA6IHMuaWQ7XG4gICAgICAgIEEubW92ZVN0ZXAoZmxvdywgc3RhdGUuZHJhZ0lkLCBuZXh0ID09PSBzdGF0ZS5kcmFnSWQgPyBzLmlkIDogbmV4dCk7XG4gICAgICB9LFxuICAgIH0sXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcInN0ZXAtaFwiIH0sXG4gICAgICBoKFxuICAgICAgICBcInNwYW5cIixcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzOiBcImdyaXBcIixcbiAgICAgICAgICB0aXRsZTogXCJBcnJhc3RyYXIgcGFyYSByZW9yZGVuYXJcIixcbiAgICAgICAgICBvbm1vdXNlZG93bjogKCkgPT4gKGxpLmRyYWdnYWJsZSA9IHRydWUpLFxuICAgICAgICAgIG9ubW91c2V1cDogKCkgPT4gKGxpLmRyYWdnYWJsZSA9IGZhbHNlKSxcbiAgICAgICAgfSxcbiAgICAgICAgXCLii67ii65cIixcbiAgICAgICksXG4gICAgICBoKFwic3BhblwiLCB7IGNsYXNzOiBcIm51bVwiIH0sIFN0cmluZyhpICsgMSkpLFxuICAgICAgaChcInNwYW5cIiwgeyBjbGFzczogXCJiYWRnZVwiLCB0aXRsZTogbWV0YS5sYWJlbCB9LCBtZXRhLmljb24pLFxuICAgICAgaChcbiAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgeyBjbGFzczogXCJzdGVwLXRpdGxlXCIsIG9uY2xpY2s6IHRvZ2dsZSB9LFxuICAgICAgICBoKFwiYlwiLCBudWxsLCBtZXRhLmxhYmVsKSxcbiAgICAgICAgdGl0bGUgJiYgaChcInNwYW5cIiwgeyBjbGFzczogXCJsYmxcIiB9LCB0aXRsZSksXG4gICAgICAgICEhcy5mcmFtZT8ubGVuZ3RoICYmIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiZnJhbWUtdGFnXCIsIHRpdGxlOiBcIkRlbnRybyBkZSBpZnJhbWU6IFwiICsgcy5mcmFtZS5tYXAoKGYpID0+IGYuc2VsZWN0b3IpLmpvaW4oXCIgwrsgXCIpIH0sIHMuZnJhbWUubGVuZ3RoID4gMSA/IGBpZnJhbWUgw5cke3MuZnJhbWUubGVuZ3RofWAgOiBcImlmcmFtZVwiKSxcbiAgICAgICAgdmFsICYmIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwidmFsXCIgfSwgdmFsKSxcbiAgICAgICksXG4gICAgICBoKFwic3BhblwiLCB7IGNsYXNzOiBcInN0YXR1c1wiLCB0aXRsZTogaW5mbyA/PyBzdGF0dXMgPz8gXCJcIiB9LCBzdGF0dXNJY29uKHN0YXR1cykpLFxuICAgICksXG4gICAgc3RhdHVzID09PSBcImVycm9yXCIgJiYgaW5mbyAmJiBoKFwiZGl2XCIsIHsgY2xhc3M6IFwic3RlcC1lcnJcIiB9LCBpbmZvKSxcbiAgICBvcGVuICYmIHN0ZXBEZXRhaWxzKGZsb3csIHMsIGkpLFxuICApO1xuICByZXR1cm4gbGk7XG59XG5cbmZ1bmN0aW9uIHN0YXR1c0ljb24oc3Q/OiBzdHJpbmcpIHtcbiAgc3dpdGNoIChzdCkge1xuICAgIGNhc2UgXCJydW5uaW5nXCI6XG4gICAgICByZXR1cm4gaChcInNwYW5cIiwgeyBjbGFzczogXCJzcGluXCIgfSk7XG4gICAgY2FzZSBcIm9rXCI6XG4gICAgICByZXR1cm4gXCLinJNcIjtcbiAgICBjYXNlIFwiZXJyb3JcIjpcbiAgICAgIHJldHVybiBcIuKcl1wiO1xuICAgIGNhc2UgXCJza2lwcGVkXCI6XG4gICAgICByZXR1cm4gXCLigJNcIjtcbiAgICBkZWZhdWx0OlxuICAgICAgcmV0dXJuIFwiXCI7XG4gIH1cbn1cblxuZnVuY3Rpb24gc3RlcERldGFpbHMoZmxvdzogRmxvdywgczogU3RlcCwgaTogbnVtYmVyKSB7XG4gIGNvbnN0IG1ldGEgPSBTVEVQX01FVEFbcy50eXBlXTtcbiAgY29uc3Qgc2F2ZSA9ICgpID0+IEEuc2F2ZVNvb24oZmxvdyk7XG4gIGNvbnN0IGZpZWxkID0gKGxhYmVsOiBzdHJpbmcsIC4uLmNvbnRyb2w6IChOb2RlIHwgZmFsc2UgfCB1bmRlZmluZWQgfCBudWxsKVtdKSA9PiBoKFwibGFiZWxcIiwgeyBjbGFzczogXCJmaWVsZFwiIH0sIGgoXCJzcGFuXCIsIG51bGwsIGxhYmVsKSwgLi4uY29udHJvbCk7XG4gIGNvbnN0IHRhcmdldGFibGUgPSBtZXRhLm5lZWRzVGFyZ2V0IHx8IHMudHlwZSA9PT0gXCJwcmVzc1wiO1xuXG4gIHJldHVybiBoKFxuICAgIFwiZGl2XCIsXG4gICAgeyBjbGFzczogXCJzdGVwLWJvZHlcIiB9LFxuICAgIGZpZWxkKFxuICAgICAgXCJUaXBvXCIsXG4gICAgICBoKFxuICAgICAgICBcInNlbGVjdFwiLFxuICAgICAgICB7XG4gICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICBzLnR5cGUgPSAoZS50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlIGFzIFN0ZXBUeXBlO1xuICAgICAgICAgICAgdm9pZCBBLnNhdmVOb3coZmxvdyk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgVFlQRVMubWFwKCh0KSA9PiBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IHQsIHNlbGVjdGVkOiB0ID09PSBzLnR5cGUgfSwgYCR7U1RFUF9NRVRBW3RdLmljb259ICAke1NURVBfTUVUQVt0XS5sYWJlbH1gKSksXG4gICAgICApLFxuICAgICksXG4gICAgdGFyZ2V0YWJsZSAmJlxuICAgICAgZmllbGQoXG4gICAgICAgIHMudHlwZSA9PT0gXCJwcmVzc1wiID8gXCJFbGVtZW50byAob3BjaW9uYWwpXCIgOiBcIkVsZW1lbnRvXCIsXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICB7IGNsYXNzOiBcInJvdyB0aWdodFwiIH0sXG4gICAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtIG1vbm8gZ3Jvd1wiLFxuICAgICAgICAgICAgdmFsdWU6IHMuc2VsZWN0b3IgPz8gXCJcIixcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBcImNzcywgdGV4dD3igKYsIGxhYmVsPeKApiwgeHBhdGg94oCmLCBBID4+IEJcIixcbiAgICAgICAgICAgIFwiZGF0YS1rXCI6IGBzZWwtJHtzLmlkfWAsXG4gICAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgcy5zZWxlY3RvciA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSB8fCB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgIHNhdmUoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiQXB1bnRhciBlbiBsYSBww6FnaW5hXCIsIGRpc2FibGVkOiAhIXN0YXRlLnBpY2tpbmcsIG9uY2xpY2s6ICgpID0+IEEucGlja0ZvcihmbG93LCBzKSB9LCBcIvCfjq9cIiksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiUmVzYWx0YXIgZW4gbGEgcMOhZ2luYVwiLCBkaXNhYmxlZDogIXMuc2VsZWN0b3IsIG9uY2xpY2s6ICgpID0+IEEuaGlnaGxpZ2h0U3RlcChzKSB9LCBcIvCfkYFcIiksXG4gICAgICAgICksXG4gICAgICApLFxuICAgIHRhcmdldGFibGUgJiYgZnJhbWVGaWVsZChmbG93LCBzLCBmaWVsZCksXG4gICAgdGFyZ2V0YWJsZSAmJlxuICAgICAgISFzLmZhbGxiYWNrcz8ubGVuZ3RoICYmXG4gICAgICBoKFxuICAgICAgICBcImRldGFpbHNcIixcbiAgICAgICAgeyBjbGFzczogXCJmYWxsYmFja3NcIiB9LFxuICAgICAgICBoKFwic3VtbWFyeVwiLCBudWxsLCBgJHtzLmZhbGxiYWNrcy5sZW5ndGh9IHNlbGVjdG9yKGVzKSBhbHRlcm5hdGl2byhzKWApLFxuICAgICAgICBoKFwidGV4dGFyZWFcIiwge1xuICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtIG1vbm9cIixcbiAgICAgICAgICByb3dzOiBNYXRoLm1pbig1LCBzLmZhbGxiYWNrcy5sZW5ndGgpLFxuICAgICAgICAgIFwiZGF0YS1rXCI6IGBmYi0ke3MuaWR9YCxcbiAgICAgICAgICB2YWx1ZTogcy5mYWxsYmFja3Muam9pbihcIlxcblwiKSxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMuZmFsbGJhY2tzID0gKGUudGFyZ2V0IGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQpLnZhbHVlLnNwbGl0KFwiXFxuXCIpLm1hcCgoeCkgPT4geC50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgICAgIHNhdmUoKTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgdGFyZ2V0YWJsZSAmJlxuICAgICAgZmllbGQoXG4gICAgICAgIFwiTm9tYnJlXCIsXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICB2YWx1ZTogcy5sYWJlbCA/PyBcIlwiLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiBcIkRlc2NyaXBjacOzbiBsZWdpYmxlXCIsXG4gICAgICAgICAgXCJkYXRhLWtcIjogYGxibC0ke3MuaWR9YCxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMubGFiZWwgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWUgfHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgc2F2ZSgpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICBzLnR5cGUgIT09IFwiY2xpY2tcIiAmJiBzLnR5cGUgIT09IFwid2FpdEZvclwiICYmIHZhbHVlRmllbGQoZmxvdywgcywgZmllbGQpLFxuICAgIGgoXG4gICAgICBcImRpdlwiLFxuICAgICAgeyBjbGFzczogXCJyb3cgdHdvXCIgfSxcbiAgICAgIHMudHlwZSAhPT0gXCJuYXZpZ2F0ZVwiICYmXG4gICAgICAgIHMudHlwZSAhPT0gXCJ3YWl0XCIgJiZcbiAgICAgICAgZmllbGQoXG4gICAgICAgICAgXCJUaW1lb3V0IChtcylcIixcbiAgICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgICAgICBtaW46IDAsXG4gICAgICAgICAgICBzdGVwOiA1MDAsXG4gICAgICAgICAgICBwbGFjZWhvbGRlcjogU3RyaW5nKHN0YXRlLnNldHRpbmdzLnRpbWVvdXQpLFxuICAgICAgICAgICAgdmFsdWU6IHMudGltZW91dCA/PyBcIlwiLFxuICAgICAgICAgICAgXCJkYXRhLWtcIjogYHRvLSR7cy5pZH1gLFxuICAgICAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHYgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWVBc051bWJlcjtcbiAgICAgICAgICAgICAgcy50aW1lb3V0ID0gTnVtYmVyLmlzRmluaXRlKHYpID8gdiA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgc2F2ZSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKSxcbiAgICAgIGZpZWxkKFxuICAgICAgICBcIk5vdGFcIixcbiAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgIHZhbHVlOiBzLm5vdGUgPz8gXCJcIixcbiAgICAgICAgICBcImRhdGEta1wiOiBgbm90ZS0ke3MuaWR9YCxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMubm90ZSA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSB8fCB1bmRlZmluZWQ7XG4gICAgICAgICAgICBzYXZlKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICApLFxuICAgICksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcInJvdyBzdGVwLWZvb3RcIiB9LFxuICAgICAgaChcbiAgICAgICAgXCJsYWJlbFwiLFxuICAgICAgICB7IGNsYXNzOiBcInRvZ2dsZVwiIH0sXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgdHlwZTogXCJjaGVja2JveFwiLFxuICAgICAgICAgIGNoZWNrZWQ6IHMuZW5hYmxlZCxcbiAgICAgICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICBzLmVuYWJsZWQgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkuY2hlY2tlZDtcbiAgICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgICBcIkFjdGl2b1wiLFxuICAgICAgKSxcbiAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiZ3Jvd1wiIH0pLFxuICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biBzbSBnaG9zdFwiLCB0aXRsZTogXCJFamVjdXRhciBzb2xvIGVzdGUgcGFzb1wiLCBkaXNhYmxlZDogQS5ydW5uZXIucnVubmluZywgb25jbGljazogKCkgPT4gQS5wbGF5KGZsb3csIGksIGkpIH0sIFwi4pa2IFNvbG8gZXN0ZVwiKSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gc20gZ2hvc3RcIiwgdGl0bGU6IFwiUmVwcm9kdWNpciBkZXNkZSBlc3RlIHBhc29cIiwgZGlzYWJsZWQ6IEEucnVubmVyLnJ1bm5pbmcsIG9uY2xpY2s6ICgpID0+IEEucGxheShmbG93LCBpKSB9LCBcIuKWtiBEZXNkZSBhcXXDrVwiKSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIkR1cGxpY2FyIHBhc29cIiwgb25jbGljazogKCkgPT4gQS5kdXBsaWNhdGVTdGVwKGZsb3csIHMpIH0sIFwi4qeJXCIpLFxuICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb24gZGFuZ2VyXCIsIHRpdGxlOiBcIkJvcnJhciBwYXNvXCIsIG9uY2xpY2s6ICgpID0+IEEuZGVsZXRlU3RlcChmbG93LCBzKSB9LCBcIvCfl5FcIiksXG4gICAgKSxcbiAgKTtcbn1cblxuY29uc3QgRlJBTUVfU0VQID0gXCIgPj4gXCI7XG5cbmZ1bmN0aW9uIGZyYW1lRmllbGQoZmxvdzogRmxvdywgczogU3RlcCwgZmllbGQ6IChsOiBzdHJpbmcsIC4uLmM6IChOb2RlIHwgZmFsc2UgfCB1bmRlZmluZWQgfCBudWxsKVtdKSA9PiBIVE1MRWxlbWVudCkge1xuICByZXR1cm4gZmllbGQoXG4gICAgXCJJZnJhbWVcIixcbiAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgY2xhc3M6IFwiaW5wdXQgc20gbW9ub1wiLFxuICAgICAgdmFsdWU6IChzLmZyYW1lID8/IFtdKS5tYXAoKGYpID0+IGYuc2VsZWN0b3IpLmpvaW4oRlJBTUVfU0VQKSxcbiAgICAgIHBsYWNlaG9sZGVyOiBcIuKAlCBww6FnaW5hIHByaW5jaXBhbCDigJQgICAoaWZyYW1lI3BhZ28gPj4gaWZyYW1lW25hbWU9Y3ZjXSlcIixcbiAgICAgIFwiZGF0YS1rXCI6IGBmcmFtZS0ke3MuaWR9YCxcbiAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICBjb25zdCBwYXJ0cyA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS5zcGxpdChcIj4+XCIpLm1hcCgoeCkgPT4geC50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgLy8gQ29uc2VydmEgbG9zIGFsdGVybmF0aXZvcyBkZSBsb3Mgbml2ZWxlcyBxdWUgbm8gY2FtYmlhbi5cbiAgICAgICAgcy5mcmFtZSA9IHBhcnRzLmxlbmd0aCA/IHBhcnRzLm1hcCgoc2VsLCBpKSA9PiAocy5mcmFtZT8uW2ldPy5zZWxlY3RvciA9PT0gc2VsID8gcy5mcmFtZVtpXSEgOiB7IHNlbGVjdG9yOiBzZWwgfSkpIDogdW5kZWZpbmVkO1xuICAgICAgICBBLnNhdmVTb29uKGZsb3cpO1xuICAgICAgfSxcbiAgICB9KSxcbiAgICAhIXMuZnJhbWU/Lmxlbmd0aCAmJiBoKFwic21hbGxcIiwgeyBjbGFzczogXCJtdXRlZFwiIH0sIFwiUnV0YSBkZSBpZnJhbWVzIGRlc2RlIGxhIHDDoWdpbmEgcHJpbmNpcGFsLCBzZXBhcmFkYSBwb3IgPj5cIiksXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZhbHVlRmllbGQoZmxvdzogRmxvdywgczogU3RlcCwgZmllbGQ6IChsOiBzdHJpbmcsIC4uLmM6IChOb2RlIHwgZmFsc2UgfCB1bmRlZmluZWQgfCBudWxsKVtdKSA9PiBIVE1MRWxlbWVudCkge1xuICBjb25zdCBtZXRhID0gU1RFUF9NRVRBW3MudHlwZV07XG4gIGNvbnN0IG9uVmFsID0gKGU6IEV2ZW50KSA9PiB7XG4gICAgcy52YWx1ZSA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcbiAgICBBLnNhdmVTb29uKGZsb3cpO1xuICB9O1xuICBpZiAocy50eXBlID09PSBcImNoZWNrXCIpIHtcbiAgICByZXR1cm4gZmllbGQoXG4gICAgICBcIkVzdGFkb1wiLFxuICAgICAgaChcbiAgICAgICAgXCJzZWxlY3RcIixcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgICAgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgcy52YWx1ZSA9IChlLnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwidHJ1ZVwiLCBzZWxlY3RlZDogcy52YWx1ZSAhPT0gXCJmYWxzZVwiIH0sIFwi4piRIE1hcmNhZG9cIiksXG4gICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJmYWxzZVwiLCBzZWxlY3RlZDogcy52YWx1ZSA9PT0gXCJmYWxzZVwiIH0sIFwi4piQIERlc21hcmNhZG9cIiksXG4gICAgICApLFxuICAgICk7XG4gIH1cbiAgY29uc3QgbGFiZWxzOiBQYXJ0aWFsPFJlY29yZDxTdGVwVHlwZSwgc3RyaW5nPj4gPSB7IG5hdmlnYXRlOiBcIlVSTFwiLCBmaWxsOiBcIlRleHRvXCIsIHNlbGVjdDogXCJPcGNpw7NuICh2YWx1ZSlcIiwgcHJlc3M6IFwiVGVjbGFcIiwgd2FpdDogXCJNaWxpc2VndW5kb3NcIiwgYXNzZXJ0VGV4dDogXCJUZXh0byBlc3BlcmFkb1wiIH07XG4gIGNvbnN0IGlucHV0ID0gaChcImlucHV0XCIsIHtcbiAgICBjbGFzczogXCJpbnB1dCBzbVwiICsgKHMudHlwZSA9PT0gXCJuYXZpZ2F0ZVwiID8gXCIgbW9ub1wiIDogXCJcIiksXG4gICAgdHlwZTogcy5zZWNyZXQgPyBcInBhc3N3b3JkXCIgOiBzLnR5cGUgPT09IFwid2FpdFwiID8gXCJudW1iZXJcIiA6IFwidGV4dFwiLFxuICAgIHZhbHVlOiBzLnZhbHVlID8/IFwiXCIsXG4gICAgcGxhY2Vob2xkZXI6IG1ldGEudmFsdWVIaW50ID8/IFwiXCIsXG4gICAgbGlzdDogcy50eXBlID09PSBcInByZXNzXCIgPyBcImtleXNcIiA6IG51bGwsXG4gICAgXCJkYXRhLWtcIjogYHZhbC0ke3MuaWR9YCxcbiAgICBvbmlucHV0OiBvblZhbCxcbiAgfSk7XG4gIHJldHVybiBmaWVsZChcbiAgICBsYWJlbHNbcy50eXBlXSA/PyBcIlZhbG9yXCIsXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcInJvdyB0aWdodFwiIH0sXG4gICAgICBzLnR5cGUgPT09IFwiZmlsbFwiID8gaChcInRleHRhcmVhXCIsIHsgY2xhc3M6IFwiaW5wdXQgc20gZ3Jvd1wiLCByb3dzOiAxLCB2YWx1ZTogcy52YWx1ZSA/PyBcIlwiLCBcImRhdGEta1wiOiBgdmFsLSR7cy5pZH1gLCBwbGFjZWhvbGRlcjogbWV0YS52YWx1ZUhpbnQsIG9uaW5wdXQ6IG9uVmFsLCBzdHlsZTogcy5zZWNyZXQgPyBcIi13ZWJraXQtdGV4dC1zZWN1cml0eTogZGlzY1wiIDogdW5kZWZpbmVkIH0pIDogaW5wdXQsXG4gICAgICBzLnR5cGUgPT09IFwiZmlsbFwiICYmXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjbGFzczogXCJpY29uXCIsXG4gICAgICAgICAgICB0aXRsZTogcy5zZWNyZXQgPyBcIk1vc3RyYXIgKGRlamEgZGUgc2VyIHNlY3JldG8pXCIgOiBcIk1hcmNhciBjb21vIHNlY3JldG9cIixcbiAgICAgICAgICAgIG9uY2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgcy5zZWNyZXQgPSAhcy5zZWNyZXQgfHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzLnNlY3JldCA/IFwi8J+UklwiIDogXCLwn5STXCIsXG4gICAgICAgICksXG4gICAgKSxcbiAgICBzLnR5cGUgPT09IFwic2VsZWN0XCIgJiYgISFzLm9wdGlvblRleHQgJiYgaChcInNtYWxsXCIsIHsgY2xhc3M6IFwibXV0ZWRcIiB9LCBgVGV4dG8gdmlzaWJsZTogwqske3Mub3B0aW9uVGV4dH3Cu2ApLFxuICAgIHMudHlwZSA9PT0gXCJwcmVzc1wiICYmIGgoXCJkYXRhbGlzdFwiLCB7IGlkOiBcImtleXNcIiB9LCBbXCJFbnRlclwiLCBcIlRhYlwiLCBcIkVzY2FwZVwiLCBcIkFycm93RG93blwiLCBcIkFycm93VXBcIiwgXCJCYWNrc3BhY2VcIiwgXCIgXCJdLm1hcCgoaykgPT4gaChcIm9wdGlvblwiLCB7IHZhbHVlOiBrIH0pKSksXG4gICk7XG59XG5cbmZ1bmN0aW9uIGFkZFN0ZXBNZW51KGZsb3c6IEZsb3cpIHtcbiAgcmV0dXJuIGgoXG4gICAgXCJkZXRhaWxzXCIsXG4gICAgeyBjbGFzczogXCJtZW51IGFkZC1zdGVwXCIgfSxcbiAgICBoKFwic3VtbWFyeVwiLCB7IGNsYXNzOiBcImJ0biBnaG9zdCBzbVwiIH0sIFwiKyBBw7FhZGlyIHBhc29cIiksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcIm1lbnUtbGlzdFwiIH0sXG4gICAgICBUWVBFUy5tYXAoKHQpID0+XG4gICAgICAgIGgoXG4gICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBvbmNsaWNrOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5jbG9zZXN0KFwiZGV0YWlsc1wiKSEub3BlbiA9IGZhbHNlO1xuICAgICAgICAgICAgICBjb25zdCBzdGVwID0gQS5hZGRTdGVwKGZsb3csIHQpO1xuICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYFtkYXRhLXN0ZXA9XCIke3N0ZXAuaWR9XCJdYCk/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6IFwiY2VudGVyXCIsIGJlaGF2aW9yOiBcInNtb290aFwiIH0pLCA1MCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYCR7U1RFUF9NRVRBW3RdLmljb259ICAke1NURVBfTUVUQVt0XS5sYWJlbH1gLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICApO1xufVxuIiwKICAgICJpbXBvcnQgdHlwZSB7IEZsb3cgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgKiBhcyBBIGZyb20gXCIuLi9zdGF0ZVwiO1xuaW1wb3J0IHsgc3RhdGUgfSBmcm9tIFwiLi4vc3RhdGVcIjtcbmltcG9ydCB7IGgsIGhvc3RPZiwgcGlja0ZpbGUsIHRpbWVBZ28gfSBmcm9tIFwiLi4vdWlcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGxpYnJhcnlWaWV3KCk6IEhUTUxFbGVtZW50IHtcbiAgY29uc3QgZmxvd3MgPSBBLmZpbHRlcmVkRmxvd3MoKTtcbiAgY29uc3QgZm9sZGVycyA9IEEuYWxsRm9sZGVycygpO1xuICBjb25zdCB0YWdzID0gQS5hbGxUYWdzKCk7XG4gIGNvbnN0IHNlbCA9IFsuLi5zdGF0ZS5zZWxlY3RlZF0uZmlsdGVyKChpZCkgPT4gc3RhdGUuZmxvd3Muc29tZSgoZikgPT4gZi5pZCA9PT0gaWQpKTtcblxuICBjb25zdCBncm91cHMgPSBuZXcgTWFwPHN0cmluZywgRmxvd1tdPigpO1xuICBmb3IgKGNvbnN0IGYgb2YgZmxvd3MpIHtcbiAgICBjb25zdCBrID0gZi5mb2xkZXIgPz8gXCJcIjtcbiAgICBpZiAoIWdyb3Vwcy5oYXMoaykpIGdyb3Vwcy5zZXQoaywgW10pO1xuICAgIGdyb3Vwcy5nZXQoaykhLnB1c2goZik7XG4gIH1cbiAgY29uc3QgZ3JvdXBLZXlzID0gWy4uLmdyb3Vwcy5rZXlzKCldLnNvcnQoKGEsIGIpID0+IChhID09PSBcIlwiID8gMSA6IGIgPT09IFwiXCIgPyAtMSA6IGEubG9jYWxlQ29tcGFyZShiKSkpO1xuXG4gIHJldHVybiBoKFxuICAgIFwiZGl2XCIsXG4gICAgeyBjbGFzczogXCJ2aWV3XCIgfSxcbiAgICBoKFxuICAgICAgXCJoZWFkZXJcIixcbiAgICAgIHsgY2xhc3M6IFwidG9wXCIgfSxcbiAgICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJicmFuZFwiIH0sIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwibG9nb1wiIH0pLCBcIlJhc3Ryb1wiKSxcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwicm93XCIgfSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiSW1wb3J0YXJcIiwgb25jbGljazogaW1wb3J0RmlsZSB9LCBcIuKHqlwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiRXhwb3J0YXIgdG9kb1wiLCBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydEZsb3dzKHN0YXRlLmZsb3dzKSB9LCBcIuKHqVwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiQWp1c3Rlc1wiLCBvbmNsaWNrOiAoKSA9PiAoKHN0YXRlLnZpZXcgPSBcInNldHRpbmdzXCIpLCBBLnJlbmRlcigpKSB9LCBcIuKamVwiKSxcbiAgICAgICksXG4gICAgKSxcbiAgICBoKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IFwidG9vbGJhclwiIH0sXG4gICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICBjbGFzczogXCJpbnB1dCBzZWFyY2hcIixcbiAgICAgICAgdHlwZTogXCJzZWFyY2hcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6IFwiQnVzY2FyIHBvciBub21icmUsICNldGlxdWV0YSwgVVJMLCBjYW1wb+KAplwiLFxuICAgICAgICB2YWx1ZTogc3RhdGUuZmlsdGVyLnEsXG4gICAgICAgIFwiZGF0YS1rXCI6IFwic2VhcmNoXCIsXG4gICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgIHN0YXRlLmZpbHRlci5xID0gKGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gcHJpbWFyeVwiLCBvbmNsaWNrOiBBLmNyZWF0ZUZsb3cgfSwgXCIrIE51ZXZvXCIpLFxuICAgICksXG4gICAgKGZvbGRlcnMubGVuZ3RoID4gMCB8fCB0YWdzLmxlbmd0aCA+IDApICYmXG4gICAgICBoKFxuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7IGNsYXNzOiBcImZpbHRlcnNcIiB9LFxuICAgICAgICBoKFxuICAgICAgICAgIFwic2VsZWN0XCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLmZvbGRlciA9IChlLnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgaChcIm9wdGlvblwiLCB7IHZhbHVlOiBcIlwiLCBzZWxlY3RlZDogc3RhdGUuZmlsdGVyLmZvbGRlciA9PT0gXCJcIiB9LCBcIlRvZGFzIGxhcyBjYXJwZXRhc1wiKSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwiX19ub25lXCIsIHNlbGVjdGVkOiBzdGF0ZS5maWx0ZXIuZm9sZGVyID09PSBcIl9fbm9uZVwiIH0sIFwiU2luIGNhcnBldGFcIiksXG4gICAgICAgICAgZm9sZGVycy5tYXAoKGYpID0+IGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogZiwgc2VsZWN0ZWQ6IHN0YXRlLmZpbHRlci5mb2xkZXIgPT09IGYgfSwgXCLwn5OBIFwiICsgZikpLFxuICAgICAgICApLFxuICAgICAgICBoKFxuICAgICAgICAgIFwic2VsZWN0XCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLnNvcnQgPSAoZS50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlIGFzIHR5cGVvZiBzdGF0ZS5maWx0ZXIuc29ydDtcbiAgICAgICAgICAgICAgQS5yZW5kZXIoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwidXBkYXRlZFwiLCBzZWxlY3RlZDogc3RhdGUuZmlsdGVyLnNvcnQgPT09IFwidXBkYXRlZFwiIH0sIFwiUmVjaWVudGVzXCIpLFxuICAgICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJuYW1lXCIsIHNlbGVjdGVkOiBzdGF0ZS5maWx0ZXIuc29ydCA9PT0gXCJuYW1lXCIgfSwgXCJOb21icmVcIiksXG4gICAgICAgICAgaChcIm9wdGlvblwiLCB7IHZhbHVlOiBcImxhc3RSdW5cIiwgc2VsZWN0ZWQ6IHN0YXRlLmZpbHRlci5zb3J0ID09PSBcImxhc3RSdW5cIiB9LCBcIsOabHRpbWEgZWplY3VjacOzblwiKSxcbiAgICAgICAgKSxcbiAgICAgICAgdGFncy5sZW5ndGggPiAwICYmXG4gICAgICAgICAgaChcbiAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICB7IGNsYXNzOiBcImNoaXBzXCIgfSxcbiAgICAgICAgICAgIHRhZ3MubWFwKCh0KSA9PlxuICAgICAgICAgICAgICBoKFxuICAgICAgICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IFwiY2hpcFwiICsgKHN0YXRlLmZpbHRlci50YWdzLmhhcyh0KSA/IFwiIG9uXCIgOiBcIlwiKSxcbiAgICAgICAgICAgICAgICAgIG9uY2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLnRhZ3MuaGFzKHQpID8gc3RhdGUuZmlsdGVyLnRhZ3MuZGVsZXRlKHQpIDogc3RhdGUuZmlsdGVyLnRhZ3MuYWRkKHQpO1xuICAgICAgICAgICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFwiI1wiICsgdCxcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKSxcbiAgICAgICksXG4gICAgc2VsLmxlbmd0aCA+IDAgJiZcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwiYnVsa1wiIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIG51bGwsIGAke3NlbC5sZW5ndGh9IHNlbGVjY2lvbmFkbyhzKWApLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0Rmxvd3Moc3RhdGUuZmxvd3MuZmlsdGVyKChmKSA9PiBzZWwuaW5jbHVkZXMoZi5pZCkpKSB9LCBcIkV4cG9ydGFyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuYnVsa01vdmUoc2VsKSB9LCBcIk1vdmVyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuYnVsa1RhZyhzZWwpIH0sIFwiRXRpcXVldGFyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtIGRhbmdlclwiLCBvbmNsaWNrOiAoKSA9PiBBLnJlbW92ZUZsb3dzKHNlbCkgfSwgXCJCb3JyYXJcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIlF1aXRhciBzZWxlY2Npw7NuXCIsIG9uY2xpY2s6ICgpID0+IChzdGF0ZS5zZWxlY3RlZC5jbGVhcigpLCBBLnJlbmRlcigpKSB9LCBcIuKclVwiKSxcbiAgICAgICksXG4gICAgaChcbiAgICAgIFwibWFpblwiLFxuICAgICAgeyBjbGFzczogXCJzY3JvbGxcIiwgXCJkYXRhLXNjcm9sbFwiOiBcImxpYnJhcnlcIiB9LFxuICAgICAgc3RhdGUuZmxvd3MubGVuZ3RoID09PSAwXG4gICAgICAgID8gZW1wdHlTdGF0ZSgpXG4gICAgICAgIDogZmxvd3MubGVuZ3RoID09PSAwXG4gICAgICAgICAgPyBoKFwicFwiLCB7IGNsYXNzOiBcImVtcHR5IG11dGVkXCIgfSwgXCJOaW5nw7puIGZsdWpvIGNvaW5jaWRlIGNvbiBlbCBmaWx0cm8uXCIpXG4gICAgICAgICAgOiBncm91cEtleXMubWFwKChrKSA9PiBmb2xkZXJHcm91cChrLCBncm91cHMuZ2V0KGspISwgZ3JvdXBLZXlzLmxlbmd0aCA+IDEgfHwgayAhPT0gXCJcIikpLFxuICAgICksXG4gICk7XG59XG5cbmZ1bmN0aW9uIGZvbGRlckdyb3VwKG5hbWU6IHN0cmluZywgZmxvd3M6IEZsb3dbXSwgc2hvd0hlYWRlcjogYm9vbGVhbikge1xuICBjb25zdCBrZXkgPSBuYW1lIHx8IFwiX19ub25lXCI7XG4gIGNvbnN0IGNvbGxhcHNlZCA9IHN0YXRlLmNvbGxhcHNlZEZvbGRlcnMuaGFzKGtleSk7XG4gIHJldHVybiBoKFxuICAgIFwic2VjdGlvblwiLFxuICAgIHsgY2xhc3M6IFwiZ3JvdXBcIiB9LFxuICAgIHNob3dIZWFkZXIgJiZcbiAgICAgIGgoXG4gICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgIHtcbiAgICAgICAgICBjbGFzczogXCJncm91cC1oXCIsXG4gICAgICAgICAgb25jbGljazogKCkgPT4ge1xuICAgICAgICAgICAgY29sbGFwc2VkID8gc3RhdGUuY29sbGFwc2VkRm9sZGVycy5kZWxldGUoa2V5KSA6IHN0YXRlLmNvbGxhcHNlZEZvbGRlcnMuYWRkKGtleSk7XG4gICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiY2FyZXRcIiArIChjb2xsYXBzZWQgPyBcIlwiIDogXCIgb3BlblwiKSB9LCBcIuKWuFwiKSxcbiAgICAgICAgbmFtZSA/IFwi8J+TgSBcIiArIG5hbWUgOiBcIlNpbiBjYXJwZXRhXCIsXG4gICAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiY291bnRcIiB9LCBTdHJpbmcoZmxvd3MubGVuZ3RoKSksXG4gICAgICApLFxuICAgICFjb2xsYXBzZWQgJiYgZmxvd3MubWFwKGZsb3dDYXJkKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gZmxvd0NhcmQoZjogRmxvdykge1xuICBjb25zdCBob3N0ID0gaG9zdE9mKGYuc3RlcHMuZmluZCgocykgPT4gcy50eXBlID09PSBcIm5hdmlnYXRlXCIpPy52YWx1ZSk7XG4gIGNvbnN0IHJ1bm5pbmcgPSBBLnJ1bm5lci5ydW5uaW5nICYmIHN0YXRlLnJ1bj8uZmxvd0lkID09PSBmLmlkO1xuICByZXR1cm4gaChcbiAgICBcImFydGljbGVcIixcbiAgICB7IGNsYXNzOiBcImNhcmRcIiArIChzdGF0ZS5zZWxlY3RlZC5oYXMoZi5pZCkgPyBcIiBzZWxlY3RlZFwiIDogXCJcIikgfSxcbiAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgdHlwZTogXCJjaGVja2JveFwiLFxuICAgICAgY2xhc3M6IFwiY2hlY2tcIixcbiAgICAgIGNoZWNrZWQ6IHN0YXRlLnNlbGVjdGVkLmhhcyhmLmlkKSxcbiAgICAgIHRpdGxlOiBcIlNlbGVjY2lvbmFyXCIsXG4gICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkID8gc3RhdGUuc2VsZWN0ZWQuYWRkKGYuaWQpIDogc3RhdGUuc2VsZWN0ZWQuZGVsZXRlKGYuaWQpO1xuICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgfSxcbiAgICB9KSxcbiAgICBoKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IFwiY2FyZC1ib2R5XCIsIG9uY2xpY2s6ICgpID0+IEEub3BlbkZsb3coZi5pZCkgfSxcbiAgICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJjYXJkLXRpdGxlXCIgfSwgZi5sYXN0UnVuICYmIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiZG90IFwiICsgKGYubGFzdFJ1bi5vayA/IFwib2tcIiA6IFwiZXJyXCIpLCB0aXRsZTogbGFzdFJ1blRleHQoZikgfSksIGYubmFtZSksXG4gICAgICBoKFxuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7IGNsYXNzOiBcIm1ldGFcIiB9LFxuICAgICAgICBgJHtmLnN0ZXBzLmxlbmd0aH0gcGFzbyR7Zi5zdGVwcy5sZW5ndGggPT09IDEgPyBcIlwiIDogXCJzXCJ9YCxcbiAgICAgICAgaG9zdCAmJiBgIMK3ICR7aG9zdH1gLFxuICAgICAgICBgIMK3ICR7dGltZUFnbyhmLnVwZGF0ZWRBdCl9YCxcbiAgICAgICksXG4gICAgICBmLnRhZ3MubGVuZ3RoID4gMCAmJiBoKFwiZGl2XCIsIHsgY2xhc3M6IFwiY2hpcHNcIiB9LCBmLnRhZ3MubWFwKCh0KSA9PiBoKFwic3BhblwiLCB7IGNsYXNzOiBcImNoaXAgc3RhdGljXCIgfSwgXCIjXCIgKyB0KSkpLFxuICAgICksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcImNhcmQtYWN0aW9uc1wiIH0sXG4gICAgICBoKFxuICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICB7IGNsYXNzOiBcImljb24gcGxheVwiLCB0aXRsZTogXCJSZXByb2R1Y2lyIGVuIGxhIHBlc3Rhw7FhIGFjdGl2YVwiLCBkaXNhYmxlZDogQS5ydW5uZXIucnVubmluZywgb25jbGljazogKCkgPT4gQS5wbGF5KGYpIH0sXG4gICAgICAgIHJ1bm5pbmcgPyBcIuKAplwiIDogXCLilrZcIixcbiAgICAgICksXG4gICAgICBoKFxuICAgICAgICBcImRldGFpbHNcIixcbiAgICAgICAgeyBjbGFzczogXCJtZW51XCIgfSxcbiAgICAgICAgaChcInN1bW1hcnlcIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIk3DoXNcIiB9LCBcIuKLr1wiKSxcbiAgICAgICAgaChcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IFwibWVudS1saXN0XCIgfSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgb25jbGljazogKCkgPT4gQS5kdXBsaWNhdGVGbG93KGYpIH0sIFwi4qeJIER1cGxpY2FyXCIpLFxuICAgICAgICAgIGgoXCJidXR0b25cIiwgeyBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydEZsb3dzKFtmXSkgfSwgXCLih6kgRXhwb3J0YXIgSlNPTlwiKSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgb25jbGljazogKCkgPT4gQS5leHBvcnRQdXBwZXRlZXIoZikgfSwgXCLih6kgRXhwb3J0YXIgYSBQdXBwZXRlZXJcIiksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0RGV2VG9vbHMoZikgfSwgXCLih6kgRXhwb3J0YXIgYSBEZXZUb29scyBSZWNvcmRlclwiKSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiZGFuZ2VyXCIsIG9uY2xpY2s6ICgpID0+IEEucmVtb3ZlRmxvd3MoW2YuaWRdKSB9LCBcIvCfl5EgQm9ycmFyXCIpLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICApO1xufVxuXG5mdW5jdGlvbiBsYXN0UnVuVGV4dChmOiBGbG93KSB7XG4gIGNvbnN0IHIgPSBmLmxhc3RSdW4hO1xuICByZXR1cm4gci5vayA/IGBPSyAke3RpbWVBZ28oci5hdCl9ICgkeyhyLm1zIC8gMTAwMCkudG9GaXhlZCgxKX1zKWAgOiBgRmFsbMOzICR7dGltZUFnbyhyLmF0KX06ICR7ci5lcnJvcn1gO1xufVxuXG5mdW5jdGlvbiBlbXB0eVN0YXRlKCkge1xuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwiZW1wdHlcIiB9LFxuICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJlbXB0eS1hcnRcIiB9LCBcIuKXiSDihpIg4oyoIOKGkiDij45cIiksXG4gICAgaChcImgyXCIsIG51bGwsIFwiR3JhYmEgdHUgcHJpbWVyIGZsdWpvXCIpLFxuICAgIGgoXG4gICAgICBcIm9sXCIsXG4gICAgICB7IGNsYXNzOiBcIm11dGVkXCIgfSxcbiAgICAgIGgoXCJsaVwiLCBudWxsLCBcIkNyZWEgdW4gZmx1am8geSBhYnJlIGxhIHdlYiBxdWUgcXVpZXJhcyBhdXRvbWF0aXphci5cIiksXG4gICAgICBoKFwibGlcIiwgbnVsbCwgXCJQdWxzYSBcIiwgaChcImJcIiwgbnVsbCwgXCJHcmFiYXJcIiksIFwiIHkgdXNhIGxhIHDDoWdpbmEgY29uIG5vcm1hbGlkYWQ6IGxvcyBib3RvbmVzIHNlIGdyYWJhbiBjb21vIGNsaWNrIHkgbG9zIGlucHV0cyBjb21vIMKrZXNjcmliaXLCuyBjb24gc3UgY29udGVuaWRvLlwiKSxcbiAgICAgIGgoXCJsaVwiLCBudWxsLCBcIkVkaXRhLCByZW9yZGVuYSB5IGRhbGUgYSBcIiwgaChcImJcIiwgbnVsbCwgXCJSZXByb2R1Y2lyXCIpLCBcIi5cIiksXG4gICAgKSxcbiAgICBoKFwiZGl2XCIsIHsgY2xhc3M6IFwicm93IGNlbnRlclwiIH0sIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gcHJpbWFyeVwiLCBvbmNsaWNrOiBBLmNyZWF0ZUZsb3cgfSwgXCIrIE51ZXZvIGZsdWpvXCIpLCBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuXCIsIG9uY2xpY2s6IGltcG9ydEZpbGUgfSwgXCJJbXBvcnRhclwiKSksXG4gICk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGltcG9ydEZpbGUoKSB7XG4gIGNvbnN0IGZpbGUgPSBhd2FpdCBwaWNrRmlsZSgpO1xuICBpZiAoZmlsZSkgYXdhaXQgQS5pbXBvcnRUZXh0KGF3YWl0IGZpbGUudGV4dCgpKTtcbn1cbiIsCiAgICAiaW1wb3J0IHsgc2F2ZVNldHRpbmdzIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC9zdG9yZVwiO1xuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgdHlwZSBTZXR0aW5ncyB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCAqIGFzIEEgZnJvbSBcIi4uL3N0YXRlXCI7XG5pbXBvcnQgeyBzdGF0ZSB9IGZyb20gXCIuLi9zdGF0ZVwiO1xuaW1wb3J0IHsgaCwgdG9hc3QgfSBmcm9tIFwiLi4vdWlcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldHRpbmdzVmlldygpOiBIVE1MRWxlbWVudCB7XG4gIGNvbnN0IHMgPSBzdGF0ZS5zZXR0aW5ncztcbiAgY29uc3Qgc2V0ID0gPEsgZXh0ZW5kcyBrZXlvZiBTZXR0aW5ncz4oazogSywgdjogU2V0dGluZ3NbS10pID0+IHtcbiAgICBzW2tdID0gdjtcbiAgICB2b2lkIHNhdmVTZXR0aW5ncyhzKTtcbiAgfTtcbiAgY29uc3QgbnVtID0gKGs6IFwidGltZW91dFwiIHwgXCJzdGVwRGVsYXlcIiB8IFwia2V5RGVsYXlcIiwgbGFiZWw6IHN0cmluZywgaGludDogc3RyaW5nKSA9PlxuICAgIGgoXG4gICAgICBcImxhYmVsXCIsXG4gICAgICB7IGNsYXNzOiBcImZpZWxkXCIgfSxcbiAgICAgIGgoXCJzcGFuXCIsIG51bGwsIGxhYmVsKSxcbiAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgIG1pbjogMCxcbiAgICAgICAgc3RlcDogayA9PT0gXCJrZXlEZWxheVwiID8gNSA6IDEwMCxcbiAgICAgICAgdmFsdWU6IHNba10sXG4gICAgICAgIFwiZGF0YS1rXCI6IFwic2V0LVwiICsgayxcbiAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgdiA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZUFzTnVtYmVyO1xuICAgICAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUodikgJiYgdiA+PSAwKSBzZXQoaywgdik7XG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgaGludCksXG4gICAgKTtcblxuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwidmlld1wiIH0sXG4gICAgaChcbiAgICAgIFwiaGVhZGVyXCIsXG4gICAgICB7IGNsYXNzOiBcInRvcFwiIH0sXG4gICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIGdob3N0IHNtXCIsIG9uY2xpY2s6ICgpID0+ICgoc3RhdGUudmlldyA9IFwibGlicmFyeVwiKSwgQS5yZW5kZXIoKSkgfSwgXCLihpAgRmx1am9zXCIpLFxuICAgICAgaChcImJcIiwgbnVsbCwgXCJBanVzdGVzXCIpLFxuICAgICksXG4gICAgaChcbiAgICAgIFwibWFpblwiLFxuICAgICAgeyBjbGFzczogXCJzY3JvbGwgc2V0dGluZ3NcIiwgXCJkYXRhLXNjcm9sbFwiOiBcInNldHRpbmdzXCIgfSxcbiAgICAgIGgoXCJoM1wiLCBudWxsLCBcIlJlcHJvZHVjY2nDs25cIiksXG4gICAgICBudW0oXCJ0aW1lb3V0XCIsIFwiVGltZW91dCBwb3IgcGFzbyAobXMpXCIsIFwiQ3XDoW50byBlc3BlcmFyIGEgcXVlIGFwYXJlemNhIHVuIGVsZW1lbnRvIGFudGVzIGRlIGZhbGxhci5cIiksXG4gICAgICBudW0oXCJzdGVwRGVsYXlcIiwgXCJQYXVzYSBlbnRyZSBwYXNvcyAobXMpXCIsIFwiw5p0aWwgcGFyYSB2ZXIgbG8gcXVlIHBhc2EgbyBwYXJhIHdlYnMgbGVudGFzLlwiKSxcbiAgICAgIGgoXG4gICAgICAgIFwibGFiZWxcIixcbiAgICAgICAgeyBjbGFzczogXCJmaWVsZFwiIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIG51bGwsIFwiRm9ybWEgZGUgZXNjcmliaXJcIiksXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJzZWxlY3RcIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgICAgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgICBzZXQoXCJ0eXBlTW9kZVwiLCAoZS50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlIGFzIFNldHRpbmdzW1widHlwZU1vZGVcIl0pO1xuICAgICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJpbnN0YW50XCIsIHNlbGVjdGVkOiBzLnR5cGVNb2RlID09PSBcImluc3RhbnRcIiB9LCBcIkRlIGdvbHBlIChyw6FwaWRvKVwiKSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwia2V5c1wiLCBzZWxlY3RlZDogcy50eXBlTW9kZSA9PT0gXCJrZXlzXCIgfSwgXCJUZWNsYSBhIHRlY2xhIChyZWFsaXN0YSlcIiksXG4gICAgICAgICksXG4gICAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgXCJUZWNsYSBhIHRlY2xhIGRpc3BhcmEga2V5ZG93bi9rZXl1cDogw7p0aWwgcGFyYSBhdXRvY29tcGxldGFkb3MgeSBtw6FzY2FyYXMuXCIpLFxuICAgICAgKSxcbiAgICAgIHMudHlwZU1vZGUgPT09IFwia2V5c1wiICYmIG51bShcImtleURlbGF5XCIsIFwiUGF1c2EgZW50cmUgdGVjbGFzIChtcylcIiwgXCJcIiksXG4gICAgICBoKFxuICAgICAgICBcImxhYmVsXCIsXG4gICAgICAgIHsgY2xhc3M6IFwidG9nZ2xlXCIgfSxcbiAgICAgICAgaChcImlucHV0XCIsIHsgdHlwZTogXCJjaGVja2JveFwiLCBjaGVja2VkOiBzLmhpZ2hsaWdodCwgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4gc2V0KFwiaGlnaGxpZ2h0XCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkKSB9KSxcbiAgICAgICAgXCJSZXNhbHRhciBjYWRhIGVsZW1lbnRvIGFudGVzIGRlIGFjdHVhclwiLFxuICAgICAgKSxcbiAgICAgIGgoXG4gICAgICAgIFwibGFiZWxcIixcbiAgICAgICAgeyBjbGFzczogXCJ0b2dnbGVcIiB9LFxuICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgIHR5cGU6IFwiY2hlY2tib3hcIixcbiAgICAgICAgICBjaGVja2VkOiBzLmF1dG9XYWl0LFxuICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHNldChcImF1dG9XYWl0XCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkKTtcbiAgICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICAgIFwiRXNwZXJhciBhIHF1ZSBsYSBww6FnaW5hIHRlcm1pbmUgZGUgY2FyZ2FyIGFudGVzIGRlIGNhZGEgYWNjacOzblwiLFxuICAgICAgKSxcbiAgICAgIGgoXG4gICAgICAgIFwic21hbGxcIixcbiAgICAgICAgeyBjbGFzczogXCJtdXRlZFwiIH0sXG4gICAgICAgIFwiQW50ZXMgZGUgYWN0dWFyIGVzcGVyYSBhIHF1ZSBubyBoYXlhIHBldGljaW9uZXMgZW4gY3Vyc28gbmkgbG9hZGVycyB2aXNpYmxlcywgeSBhIHF1ZSBlbCBlbGVtZW50byBlc3TDqSBoYWJpbGl0YWRvIHkgc2luIG5hZGEgZW5jaW1hLlwiLFxuICAgICAgKSxcbiAgICAgIHMuYXV0b1dhaXQgJiZcbiAgICAgICAgaChcbiAgICAgICAgICBcImxhYmVsXCIsXG4gICAgICAgICAgeyBjbGFzczogXCJmaWVsZFwiIH0sXG4gICAgICAgICAgaChcInNwYW5cIiwgbnVsbCwgXCJTZWxlY3RvciBkZSBsb2FkZXJzIHByb3Bpb3NcIiksXG4gICAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgICAgICB0eXBlOiBcInRleHRcIixcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBcIi5taS1sb2FkZXIsICNvdmVybGF5LWNhcmdhbmRvXCIsXG4gICAgICAgICAgICB2YWx1ZTogcy5sb2FkZXJTZWxlY3RvcixcbiAgICAgICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpbnAgPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICAgICAgICBsZXQgb2sgPSB0cnVlO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChpbnAudmFsdWUudHJpbSgpKSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGlucC52YWx1ZSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIG9rID0gZmFsc2U7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaW5wLnNldEN1c3RvbVZhbGlkaXR5KG9rID8gXCJcIiA6IFwiU2VsZWN0b3IgQ1NTIG5vIHbDoWxpZG9cIik7XG4gICAgICAgICAgICAgIGlucC5yZXBvcnRWYWxpZGl0eSgpO1xuICAgICAgICAgICAgICBpZiAob2spIHNldChcImxvYWRlclNlbGVjdG9yXCIsIGlucC52YWx1ZSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgXCJPcGNpb25hbC4gU2Ugc3VtYSBhIGxvcyBsb2FkZXJzIGRlIEVsZW1lbnQgUGx1cywgQW50LCBWdWV0aWZ5LCBNVUksIEJvb3RzdHJhcOKApiBNaWVudHJhcyBhbGd1bm8gc2VhIHZpc2libGUsIFJhc3RybyBlc3BlcmEuXCIpLFxuICAgICAgICApLFxuICAgICAgaChcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgeyBjbGFzczogXCJyb3dcIiB9LFxuICAgICAgICBoKFxuICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiYnRuIHNtIGdob3N0XCIsXG4gICAgICAgICAgICBvbmNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIHN0YXRlLnNldHRpbmdzID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTIH07XG4gICAgICAgICAgICAgIHZvaWQgc2F2ZVNldHRpbmdzKHN0YXRlLnNldHRpbmdzKTtcbiAgICAgICAgICAgICAgQS5yZW5kZXIoKTtcbiAgICAgICAgICAgICAgdG9hc3QoXCJBanVzdGVzIHJlc3RhYmxlY2lkb3NcIiwgXCJva1wiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIlJlc3RhYmxlY2VyXCIsXG4gICAgICAgICksXG4gICAgICApLFxuICAgICAgaChcImgzXCIsIG51bGwsIFwiU2VsZWN0b3Jlc1wiKSxcbiAgICAgIGgoXG4gICAgICAgIFwicFwiLFxuICAgICAgICB7IGNsYXNzOiBcIm11dGVkIHNtYWxsXCIgfSxcbiAgICAgICAgXCJSYXN0cm8gZ2VuZXJhIHZhcmlvcyBzZWxlY3RvcmVzIHBvciBlbGVtZW50byB5IHBydWViYSBsb3MgYWx0ZXJuYXRpdm9zIHNpIGZhbGxhIGVsIHByaW5jaXBhbC4gT3JkZW4gZGUgcHJlZmVyZW5jaWE6IFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcImRhdGEtdGVzdGlkXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwiI2lkXCIpLFxuICAgICAgICBcIiBlc3RhYmxlLCBcIixcbiAgICAgICAgaChcImNvZGVcIiwgbnVsbCwgXCJuYW1lXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwibGFiZWw94oCmXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwiYXJpYS1sYWJlbFwiKSxcbiAgICAgICAgXCIsIFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcInBsYWNlaG9sZGVyXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwidGV4dD3igKZcIiksXG4gICAgICAgIFwiIHkgcG9yIMO6bHRpbW8gcnV0YSBDU1MuIElkcyB5IGNsYXNlcyBjb24gcGludGEgZGUgYXV0b2dlbmVyYWRhcyBzZSBpZ25vcmFuLiBBw7FhZGlyIFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcImRhdGEtdGVzdGlkXCIpLFxuICAgICAgICBcIiBhIGxhIGFwcCBlcyBsbyBxdWUgZGEgbG9zIGZsdWpvcyBtw6FzIHJvYnVzdG9zLlwiLFxuICAgICAgKSxcbiAgICAgIGgoXCJoM1wiLCBudWxsLCBcIkRhdG9zXCIpLFxuICAgICAgaChcInBcIiwgeyBjbGFzczogXCJtdXRlZCBzbWFsbFwiIH0sIGAke3N0YXRlLmZsb3dzLmxlbmd0aH0gZmx1am8ocyksICR7c3RhdGUuZmxvd3MucmVkdWNlKChuLCBmKSA9PiBuICsgZi5zdGVwcy5sZW5ndGgsIDApfSBwYXNvKHMpLiBTZSBndWFyZGFuIGVuIGVsIGFsbWFjZW5hbWllbnRvIGxvY2FsIGRlIGxhIGV4dGVuc2nDs24sIGVuIGVzdGUgbmF2ZWdhZG9yLmApLFxuICAgICksXG4gICk7XG59XG4iLAogICAgImltcG9ydCAqIGFzIHN0b3JlIGZyb20gXCIuLi9zaGFyZWQvc3RvcmVcIjtcbmltcG9ydCB7IGN1cnJlbnQsIGltcG9ydFRleHQsIHJlbmRlciwgc2V0UmVuZGVyLCBzdGF0ZSB9IGZyb20gXCIuL3N0YXRlXCI7XG5pbXBvcnQgeyBtb3JwaCB9IGZyb20gXCIuL3VpXCI7XG5pbXBvcnQgeyBlZGl0b3JWaWV3IH0gZnJvbSBcIi4vdmlld3MvZWRpdG9yXCI7XG5pbXBvcnQgeyBsaWJyYXJ5VmlldyB9IGZyb20gXCIuL3ZpZXdzL2xpYnJhcnlcIjtcbmltcG9ydCB7IHNldHRpbmdzVmlldyB9IGZyb20gXCIuL3ZpZXdzL3NldHRpbmdzXCI7XG5cbmNvbnN0IGFwcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXBwXCIpITtcblxubGV0IHNjaGVkdWxlZCA9IGZhbHNlO1xuc2V0UmVuZGVyKCgpID0+IHtcbiAgLy8gQWdydXBhIHJlbmRlcnMgZGVsIG1pc21vIHRpY2sgKHAuIGVqLiB2YXJpb3MgY2FtYmlvcyBkZSBzdG9yYWdlIHNlZ3VpZG9zKS5cbiAgaWYgKHNjaGVkdWxlZCkgcmV0dXJuO1xuICBzY2hlZHVsZWQgPSB0cnVlO1xuICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgc2NoZWR1bGVkID0gZmFsc2U7XG4gICAgY29uc3QgZmxvdyA9IGN1cnJlbnQoKTtcbiAgICBpZiAoc3RhdGUudmlldyA9PT0gXCJlZGl0b3JcIiAmJiAhZmxvdykgc3RhdGUudmlldyA9IFwibGlicmFyeVwiO1xuICAgIGNvbnN0IHZpZXcgPSBzdGF0ZS52aWV3ID09PSBcImVkaXRvclwiID8gZWRpdG9yVmlldyhmbG93ISkgOiBzdGF0ZS52aWV3ID09PSBcInNldHRpbmdzXCIgPyBzZXR0aW5nc1ZpZXcoKSA6IGxpYnJhcnlWaWV3KCk7XG4gICAgbW9ycGgoYXBwLCB2aWV3KTtcbiAgfSk7XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gYm9vdCgpIHtcbiAgW3N0YXRlLmZsb3dzLCBzdGF0ZS5zZXR0aW5ncywgc3RhdGUucmVjb3JkaW5nXSA9IGF3YWl0IFByb21pc2UuYWxsKFtzdG9yZS5saXN0Rmxvd3MoKSwgc3RvcmUuZ2V0U2V0dGluZ3MoKSwgc3RvcmUuZ2V0UmVjb3JkaW5nKCldKTtcbiAgcmVuZGVyKCk7XG5cbiAgY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gICAgbGV0IGRpcnR5ID0gZmFsc2U7XG4gICAgbGV0IGFwcGVuZGVkID0gZmFsc2U7XG4gICAgaWYgKGFyZWEgPT09IFwibG9jYWxcIikge1xuICAgICAgZm9yIChjb25zdCBbaywgeyBuZXdWYWx1ZSB9XSBvZiBPYmplY3QuZW50cmllcyhjaGFuZ2VzKSkge1xuICAgICAgICBpZiAoc3RvcmUuaXNGbG93S2V5KGspKSB7XG4gICAgICAgICAgY29uc3QgaWQgPSBrLnNsaWNlKDUpO1xuICAgICAgICAgIGNvbnN0IGkgPSBzdGF0ZS5mbG93cy5maW5kSW5kZXgoKGYpID0+IGYuaWQgPT09IGlkKTtcbiAgICAgICAgICBpZiAoIW5ld1ZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoaSA+PSAwKSBzdGF0ZS5mbG93cy5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChpID49IDApIHtcbiAgICAgICAgICAgIGFwcGVuZGVkIHx8PSBuZXdWYWx1ZS5zdGVwcy5sZW5ndGggPiBzdGF0ZS5mbG93c1tpXSEuc3RlcHMubGVuZ3RoO1xuICAgICAgICAgICAgc3RhdGUuZmxvd3NbaV0gPSBuZXdWYWx1ZTtcbiAgICAgICAgICB9IGVsc2Ugc3RhdGUuZmxvd3MudW5zaGlmdChuZXdWYWx1ZSk7XG4gICAgICAgICAgZGlydHkgPSB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKGsgPT09IFwic2V0dGluZ3NcIikge1xuICAgICAgICAgIHN0YXRlLnNldHRpbmdzID0geyAuLi5zdGF0ZS5zZXR0aW5ncywgLi4ubmV3VmFsdWUgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYXJlYSA9PT0gXCJzZXNzaW9uXCIgJiYgc3RvcmUuUkVDT1JESU5HX1NUT1JBR0VfS0VZIGluIGNoYW5nZXMpIHtcbiAgICAgIHN0YXRlLnJlY29yZGluZyA9IGNoYW5nZXNbc3RvcmUuUkVDT1JESU5HX1NUT1JBR0VfS0VZXSEubmV3VmFsdWU7XG4gICAgICBkaXJ0eSA9IHRydWU7XG4gICAgfVxuICAgIGlmICghZGlydHkpIHJldHVybjtcbiAgICByZW5kZXIoKTtcbiAgICAvLyBNaWVudHJhcyBzZSBncmFiYSwgc2VndWlyIGVsIMO6bHRpbW8gcGFzby5cbiAgICBpZiAoYXBwZW5kZWQgJiYgc3RhdGUucmVjb3JkaW5nPy5mbG93SWQgPT09IHN0YXRlLmN1cnJlbnRJZCkge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIltkYXRhLXNjcm9sbF1cIik7XG4gICAgICAgIGVsPy5zY3JvbGxUbyh7IHRvcDogZWwuc2Nyb2xsSGVpZ2h0LCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcbiAgICAgIH0sIDMwKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBDZXJyYXIgbWVuw7pzIGRlc3BsZWdhYmxlcyBhbCBjbGljYXIgZnVlcmEuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgZm9yIChjb25zdCBkIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTERldGFpbHNFbGVtZW50PihcImRldGFpbHMubWVudVtvcGVuXVwiKSkge1xuICAgIGlmICghZC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSkgZC5vcGVuID0gZmFsc2U7XG4gIH1cbn0pO1xuXG4vLyBJbXBvcnRhciBhcnJhc3RyYW5kbyB1biAuanNvbiBhbCBwYW5lbC5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnb3ZlclwiLCAoZSkgPT4ge1xuICBpZiAoZS5kYXRhVHJhbnNmZXI/LnR5cGVzLmluY2x1ZGVzKFwiRmlsZXNcIikpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwiZHJvcHBpbmdcIik7XG4gIH1cbn0pO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdsZWF2ZVwiLCAoZSkgPT4ge1xuICBpZiAoIWUucmVsYXRlZFRhcmdldCkgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiZHJvcHBpbmdcIik7XG59KTtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJkcm9wXCIsIGFzeW5jIChlKSA9PiB7XG4gIGNvbnN0IGZpbGUgPSBlLmRhdGFUcmFuc2Zlcj8uZmlsZXM/LlswXTtcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiZHJvcHBpbmdcIik7XG4gIGlmICghZmlsZSkgcmV0dXJuO1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGF3YWl0IGltcG9ydFRleHQoYXdhaXQgZmlsZS50ZXh0KCkpO1xufSk7XG5cbnZvaWQgYm9vdCgpO1xuIgogIF0sCiAgIm1hcHBpbmdzIjogIjtBQStFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLFNBQVM7QUFBQSxFQUNULFdBQVc7QUFBQSxFQUNYLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFdBQVc7QUFBQSxFQUNYLFVBQVU7QUFBQSxFQUNWLGdCQUFnQjtBQUNsQjtBQW1CTyxJQUFNLFlBQXlHO0FBQUEsRUFDcEgsVUFBVSxFQUFFLE9BQU8sUUFBUSxNQUFNLEtBQUssYUFBYSxPQUFPLFdBQVcsWUFBWTtBQUFBLEVBQ2pGLE9BQU8sRUFBRSxPQUFPLFNBQVMsTUFBTSxLQUFLLGFBQWEsS0FBSztBQUFBLEVBQ3RELE1BQU0sRUFBRSxPQUFPLFlBQVksTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLHVCQUF1QjtBQUFBLEVBQzNGLFFBQVEsRUFBRSxPQUFPLGVBQWUsTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLHFCQUFxQjtBQUFBLEVBQzlGLE9BQU8sRUFBRSxPQUFPLFVBQVUsTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLGVBQWU7QUFBQSxFQUNsRixPQUFPLEVBQUUsT0FBTyxTQUFTLE1BQU0sS0FBSyxhQUFhLE9BQU8sV0FBVyxzQkFBc0I7QUFBQSxFQUN6RixNQUFNLEVBQUUsT0FBTyxXQUFXLE1BQU0sS0FBSyxhQUFhLE9BQU8sV0FBVyxlQUFlO0FBQUEsRUFDbkYsU0FBUyxFQUFFLE9BQU8sYUFBYSxNQUFNLEtBQUssYUFBYSxLQUFLO0FBQUEsRUFDNUQsWUFBWSxFQUFFLE9BQU8sYUFBYSxNQUFNLEtBQUssYUFBYSxNQUFNLFdBQVcsaUJBQWlCO0FBQzlGOzs7QUNwSE8sSUFBTSxNQUFNLE1BQWMsT0FBTyxXQUFXLEVBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLEVBQUU7QUFHNUYsU0FBUyxjQUFjLENBQUMsR0FBb0I7QUFBQSxFQUNqRCxPQUNFLEVBQUUsU0FBUyxNQUNYLFNBQVMsS0FBSyxDQUFDLEtBQ2Ysb0JBQW9CLEtBQUssQ0FBQyxLQUMxQixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLGtCQUFrQixLQUFLLENBQUMsS0FDeEIsdUZBQXVGLEtBQUssQ0FBQyxLQUM1Rix1QkFBdUIsS0FBSyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsS0FDNUQsMkNBQTJDLEtBQUssQ0FBQztBQUFBO0FBSTlDLElBQU0sUUFBUSxDQUFDLE9BQWUsSUFBSSxRQUFjLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBRy9FLFNBQVMsT0FBTyxDQUFDLE1BQWtDO0FBQUEsRUFDakQsUUFBUTtBQUFBLFNBQ0Q7QUFBQSxNQUNILE9BQU8sT0FBTyxLQUFLLElBQUksQ0FBQztBQUFBLFNBQ3JCO0FBQUEsTUFDSCxPQUFPLE9BQU8sV0FBVztBQUFBLFNBQ3RCO0FBQUEsTUFDSCxPQUFPLE9BQU8sS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQVMsQ0FBQztBQUFBLFNBQ2hEO0FBQUEsTUFDSCxPQUFPLFFBQVEsS0FBSyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLElBQUk7QUFBQSxTQUNyRTtBQUFBLE1BQ0gsT0FBTyxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQTtBQUFBLEVBRS9DO0FBQUE7QUFJSyxTQUFTLFdBQVcsQ0FBQyxNQUFjLE1BQXNDO0FBQUEsRUFDOUUsT0FBTyxLQUFLLFFBQVEsNkJBQTZCLENBQUMsR0FBRyxTQUFpQixLQUFLLFNBQVMsUUFBUSxJQUFJLEtBQUssQ0FBQztBQUFBO0FBR2pHLElBQU0sZUFBZSxDQUFDLGNBQWMsU0FBUyxnQkFBZ0IsY0FBYyxRQUFROzs7QUNsQzFGLElBQU0sY0FBYztBQUNwQixJQUFNLGVBQWU7QUFDckIsSUFBTSxnQkFBZ0I7QUFFdEIsZUFBc0IsU0FBUyxHQUFvQjtBQUFBLEVBQ2pELE1BQU0sTUFBTSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksSUFBSTtBQUFBLEVBQy9DLE9BQU8sT0FBTyxRQUFRLEdBQUcsRUFDdEIsT0FBTyxFQUFFLE9BQU8sRUFBRSxXQUFXLFdBQVcsQ0FBQyxFQUN6QyxJQUFJLElBQUksT0FBTyxDQUFTLEVBQ3hCLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxZQUFZLEVBQUUsU0FBUztBQUFBO0FBUTdDLGVBQXNCLFFBQVEsQ0FBQyxNQUFZLFFBQVEsTUFBcUI7QUFBQSxFQUN0RSxJQUFJO0FBQUEsSUFBTyxLQUFLLFlBQVksS0FBSyxJQUFJO0FBQUEsRUFDckMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEdBQUcsY0FBYyxLQUFLLEtBQUssS0FBSyxDQUFDO0FBQUEsRUFDaEUsT0FBTztBQUFBO0FBR1QsZUFBc0IsV0FBVyxDQUFDLEtBQThCO0FBQUEsRUFDOUQsTUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sY0FBYyxFQUFFLENBQUM7QUFBQTtBQVc5RCxTQUFTLE9BQU8sQ0FBQyxVQUF5QixDQUFDLEdBQVM7QUFBQSxFQUN6RCxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsRUFDckIsT0FBTztBQUFBLElBQ0wsSUFBSSxJQUFJO0FBQUEsSUFDUixNQUFNO0FBQUEsSUFDTixNQUFNLENBQUM7QUFBQSxJQUNQLFdBQVcsQ0FBQztBQUFBLElBQ1osT0FBTyxDQUFDO0FBQUEsSUFDUixXQUFXO0FBQUEsSUFDWCxXQUFXO0FBQUEsT0FDUjtBQUFBLEVBQ0w7QUFBQTtBQUdLLFNBQVMsT0FBTyxDQUFDLFNBQW1EO0FBQUEsRUFDekUsT0FBTyxFQUFFLElBQUksSUFBSSxHQUFHLFNBQVMsU0FBUyxRQUFRO0FBQUE7QUFHaEQsZUFBc0IsV0FBVyxHQUFzQjtBQUFBLEVBQ3JELE1BQU0sS0FBSyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksWUFBWSxHQUFHO0FBQUEsRUFDekQsT0FBTyxLQUFLLHFCQUFzQixLQUFLLENBQUMsRUFBRztBQUFBO0FBRzdDLGVBQXNCLFlBQVksQ0FBQyxHQUE0QjtBQUFBLEVBQzdELE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxHQUFHLGVBQWUsRUFBRSxDQUFDO0FBQUE7QUFHdEQsZUFBc0IsWUFBWSxHQUF3QztBQUFBLEVBQ3hFLFFBQVEsTUFBTSxPQUFPLFFBQVEsUUFBUSxJQUFJLGFBQWEsR0FBRztBQUFBO0FBUXBELElBQU0sWUFBWSxDQUFDLE1BQWMsRUFBRSxXQUFXLFdBQVc7QUFDekQsSUFBTSx3QkFBd0I7OztBQ3REOUIsU0FBUyxtQkFBbUIsQ0FBQyxNQUFvQztBQUFBLEVBQ3RFLElBQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLENBQUMsTUFBTSxRQUFTLEtBQXFCLEtBQUs7QUFBQSxJQUFHLE9BQU87QUFBQSxFQUM3RixNQUFNLFFBQVMsS0FBcUI7QUFBQSxFQUNwQyxPQUFPLFdBQVcsUUFBUSxNQUFNLEtBQUssQ0FBQyxNQUFNLE1BQU0sRUFBRSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsRUFBRSxTQUFTLEtBQUssRUFBRSxTQUFTLGVBQWMsU0FBUyxHQUFFO0FBQUE7QUFTbEosU0FBUyxZQUFZLENBQUMsS0FBd0MsU0FBMEQ7QUFBQSxFQUN0SCxNQUFNLFNBQW1CLENBQUM7QUFBQSxFQUMxQixNQUFNLFFBQWtCLENBQUM7QUFBQSxFQUN6QixNQUFNLGFBQXVCLENBQUM7QUFBQSxFQUM5QixNQUFNLFFBQWtCLENBQUM7QUFBQSxFQUN6QixJQUFJO0FBQUEsRUFDSixXQUFXLFNBQVMsT0FBTyxDQUFDLEdBQUc7QUFBQSxJQUM3QixNQUFNLFFBQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLENBQUMsS0FBSztBQUFBLElBQ25ELElBQUksTUFBTSxXQUFXO0FBQUEsTUFBRztBQUFBLElBQ3hCLE1BQU0sSUFBSSxNQUFNO0FBQUEsSUFFaEIsSUFBSSxlQUFlLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDdkIsSUFBSSxFQUFFLFdBQVcsT0FBTyxHQUFHO0FBQUEsTUFDekIsTUFBTSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsUUFBUSxxQkFBcUIsRUFBRTtBQUFBLE1BQ3BELFNBQVMsRUFBRSxRQUFRLFVBQVUsRUFBRTtBQUFBLE1BQy9CLElBQUk7QUFBQSxRQUFTLE1BQU0sS0FBSyxTQUFTLEVBQUUsUUFBUSxVQUFVLEVBQUUsR0FBRztBQUFBLE1BQ3JEO0FBQUEsY0FBTSxLQUFLLFFBQVEsS0FBSyxlQUFlLEtBQUssVUFBVSxDQUFDLElBQUk7QUFBQSxJQUNsRSxFQUFPLFNBQUksRUFBRSxXQUFXLE9BQU8sR0FBRztBQUFBLE1BQ2hDLFNBQVMsRUFBRSxNQUFNLENBQUM7QUFBQSxNQUNsQixNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQUEsSUFDakMsRUFBTyxTQUFJLEVBQUUsV0FBVyxRQUFRO0FBQUEsTUFBRyxNQUFNLEtBQUssU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQUEsSUFDOUQ7QUFBQSxNQUNILE1BQU0sTUFBTSxFQUFFLFdBQVcsU0FBUyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFBQSxPQUNsRCwrQkFBK0IsS0FBSyxHQUFHLElBQUksU0FBUyxZQUFZLEtBQUssR0FBRztBQUFBO0FBQUEsRUFFN0U7QUFBQSxFQUNBLE9BQU8sRUFBRSxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxLQUFLO0FBQUE7QUFHckcsU0FBUyxjQUFjLENBQUMsS0FBc0I7QUFBQSxFQUM1QyxNQUFNLE1BQU0sQ0FBQyxHQUFHLElBQUksU0FBUyxvQkFBb0IsR0FBRyxHQUFHLElBQUksU0FBUyx1QkFBdUIsR0FBRyxHQUFHLElBQUksU0FBUyx1QkFBdUIsQ0FBQztBQUFBLEVBQ3RJLE9BQU8sSUFBSSxLQUFLLENBQUMsTUFBTSxlQUFlLEVBQUUsR0FBSSxRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUM7QUFBQTtBQUdqRSxTQUFTLFFBQVEsQ0FBQyxPQUFxRDtBQUFBLEVBQ3JFLE9BQU8sT0FBTyxTQUFTLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLFNBQVMsSUFBSSxFQUFFLElBQUk7QUFBQTtBQUduRSxTQUFTLFlBQVksQ0FBQyxLQUFxRDtBQUFBLEVBQ2hGLE1BQU0sUUFBZ0IsQ0FBQztBQUFBLEVBQ3ZCLE1BQU0sVUFBb0IsQ0FBQztBQUFBLEVBQzNCLFdBQVcsS0FBSyxJQUFJLE9BQU87QUFBQSxJQUN6QixJQUFJLEVBQUUsVUFBVSxFQUFFLFdBQVcsUUFBUTtBQUFBLE1BQ25DLFFBQVEsS0FBSyxHQUFHLEVBQUUsd0JBQXdCO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLFVBQVUsRUFBRSxTQUFTO0FBQUEsSUFDM0IsTUFBTSxTQUFTLGFBQWEsRUFBRSxXQUFXLE9BQU87QUFBQSxJQUNoRCxPQUFPLGFBQWEsYUFBYSxPQUFPO0FBQUEsSUFDeEMsTUFBTSxTQUFTLEVBQUUsVUFBVSxXQUFXLE9BQU8sU0FBUyxFQUFFLEtBQUssR0FBRyxTQUFTLEVBQUUsUUFBUTtBQUFBLElBQ25GLE1BQU0sUUFBUSxPQUFPLFFBQVE7QUFBQSxJQUM3QixRQUFRLEVBQUU7QUFBQSxXQUNIO0FBQUEsV0FDQTtBQUFBLFFBQ0g7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sWUFBWSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFBQSxRQUN0RDtBQUFBLFdBQ0c7QUFBQSxXQUNBO0FBQUEsUUFDSCxJQUFJLENBQUM7QUFBQSxVQUFVLFFBQVEsS0FBSyxFQUFFLE9BQU8sc0JBQXNCO0FBQUEsUUFDdEQ7QUFBQSxnQkFBTSxLQUFLLFFBQVEsRUFBRSxNQUFNLFlBQVksUUFBUSxPQUFPLE1BQU0sRUFBRSxTQUFTLGdCQUFnQiw0QkFBNEIsVUFBVSxDQUFDLENBQUM7QUFBQSxRQUNwSTtBQUFBLFdBQ0csVUFBVTtBQUFBLFFBQ2IsSUFBSSxDQUFDLFVBQVU7QUFBQSxVQUNiLFFBQVEsS0FBSyw0QkFBNEI7QUFBQSxVQUN6QztBQUFBLFFBQ0Y7QUFBQSxRQUVBLE1BQU0sT0FBTyxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3hCLElBQUksTUFBTSxTQUFTLFdBQVcsS0FBSyxhQUFhLFlBQVksS0FBSyxVQUFVLEtBQUssS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUs7QUFBQSxVQUFHLE1BQU0sSUFBSTtBQUFBLFFBQ25JLE1BQU0sS0FBSyxRQUFRLEVBQUUsTUFBTSxXQUFXLFFBQVEsT0FBTyxPQUFPLEVBQUUsU0FBUyxHQUFHLENBQUMsQ0FBQztBQUFBLFFBQzVFO0FBQUEsTUFDRjtBQUFBLFdBQ0s7QUFBQSxRQUNILE1BQU0sS0FBSyxRQUFRLEVBQUUsTUFBTSxTQUFTLE9BQU8sRUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDO0FBQUEsUUFDOUQ7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJO0FBQUEsVUFBVSxNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sY0FBYyxRQUFRLE1BQU0sQ0FBQyxDQUFDO0FBQUEsUUFDdkU7QUFBQTtBQUFBLFFBRUEsUUFBUSxLQUFLLEVBQUUsSUFBSTtBQUFBO0FBQUEsRUFFekI7QUFBQSxFQUNBLE1BQU0sT0FBTyxRQUFRLEVBQUUsTUFBTSxJQUFJLFNBQVMseUJBQXlCLE1BQU0sQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO0FBQUEsRUFDOUYsT0FBTyxFQUFFLE1BQU0sUUFBUTtBQUFBO0FBS3pCLFNBQVMsWUFBWSxDQUFDLEtBQXFCO0FBQUEsRUFDekMsSUFBSSxJQUFJLFdBQVcsT0FBTztBQUFBLElBQUcsT0FBTyxRQUFRLElBQUksTUFBTSxDQUFDO0FBQUEsRUFFdkQsTUFBTSxJQUFJLElBQUksUUFBUSxNQUFNO0FBQUEsRUFDNUIsSUFBSSxJQUFJO0FBQUEsSUFBRyxPQUFPLGFBQWEsSUFBSSxNQUFNLElBQUksQ0FBQyxDQUFDO0FBQUEsRUFDL0MsSUFBSSxJQUFJLFdBQVcsUUFBUTtBQUFBLElBQUcsT0FBTyxRQUFRLElBQUksTUFBTSxDQUFDO0FBQUEsRUFDeEQsSUFBSSxJQUFJLFdBQVcsUUFBUTtBQUFBLElBQUcsT0FBTyxTQUFTLElBQUksTUFBTSxDQUFDO0FBQUEsRUFDekQsT0FBTztBQUFBO0FBSUYsU0FBUyxVQUFVLENBQUMsTUFBcUQ7QUFBQSxFQUM5RSxNQUFNLFFBQWtCO0FBQUEsSUFDdEIsRUFBRSxNQUFNLGVBQWUsT0FBTyxNQUFNLFFBQVEsS0FBSyxtQkFBbUIsR0FBRyxVQUFVLE9BQU8sVUFBVSxPQUFPLGFBQWEsTUFBTTtBQUFBLEVBQzlIO0FBQUEsRUFDQSxJQUFJLFdBQVc7QUFBQSxFQUNmLFdBQVcsS0FBSyxLQUFLLE9BQU87QUFBQSxJQUMxQixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQVM7QUFBQSxJQUNoQixJQUFJLEVBQUUsT0FBTztBQUFBLE1BQVE7QUFBQSxJQUNyQixNQUFNLFlBQVksQ0FBQyxFQUFFLFVBQVUsR0FBSSxFQUFFLGFBQWEsQ0FBQyxDQUFFLEVBQUUsT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDcEcsTUFBTSxPQUFPLEVBQUUsUUFBUSxRQUFRLGNBQWUsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLFFBQVEsSUFBSSxDQUFDLEVBQUc7QUFBQSxJQUN2RixRQUFRLEVBQUU7QUFBQSxXQUNIO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksS0FBSyxFQUFFLFNBQVMsR0FBRyxDQUFDO0FBQUEsUUFDbkQ7QUFBQSxXQUNHO0FBQUEsV0FDQTtBQUFBLFFBQ0gsTUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLE1BQU0sU0FBUyxHQUFHLFNBQVMsRUFBRSxDQUFDO0FBQUEsUUFDN0Q7QUFBQSxXQUNHO0FBQUEsV0FDQTtBQUFBLFFBQ0gsTUFBTSxLQUFLLEVBQUUsTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFLFNBQVMsR0FBRyxDQUFDO0FBQUEsUUFDNUQ7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLFdBQVcsUUFBUSxRQUFRLEtBQUssRUFBRSxTQUFTLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxRQUFRLFFBQVEsS0FBSyxFQUFFLFNBQVMsUUFBUSxDQUFDO0FBQUEsUUFDbkk7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLHFCQUFxQixLQUFLLENBQUM7QUFBQSxRQUM5QztBQUFBLFdBQ0c7QUFBQSxRQUNILE1BQU0sS0FBSztBQUFBLFVBQ1QsTUFBTTtBQUFBLFVBQ04sUUFBUTtBQUFBLFVBQ1IsWUFBWSw2Q0FBNkMsS0FBSyxVQUFVLEVBQUUsWUFBWSxFQUFFLHVEQUF1RCxLQUFLLFVBQVUsRUFBRSxTQUFTLEVBQUU7QUFBQSxRQUM3SyxDQUFDO0FBQUEsUUFDRDtBQUFBLFdBQ0c7QUFBQSxRQUNILE1BQU0sS0FBSyxFQUFFLE1BQU0scUJBQXFCLFFBQVEsUUFBUSxZQUFZLGdEQUFnRCxPQUFPLEVBQUUsS0FBSyxLQUFLLFNBQVMsQ0FBQztBQUFBLFFBQ2pKO0FBQUE7QUFBQSxFQUVOO0FBQUEsRUFDQSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sS0FBSyxNQUFNLE1BQU0sR0FBRyxTQUFTO0FBQUE7OztBQzVLaEQsU0FBUyxZQUFZLENBQUMsT0FBMkI7QUFBQSxFQUN0RCxPQUFPLEVBQUUsUUFBUSxVQUFVLFNBQVMsR0FBRyxZQUFZLElBQUksS0FBSyxFQUFFLFlBQVksR0FBRyxPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sS0FBSyxHQUFHLFNBQVMsVUFBVSxFQUFFLEVBQUU7QUFBQTtBQUd2SSxJQUFNLGFBQXlCLENBQUMsWUFBWSxTQUFTLFFBQVEsVUFBVSxTQUFTLFNBQVMsUUFBUSxXQUFXLFlBQVk7QUFVakgsU0FBUyxXQUFXLENBQUMsTUFBNEI7QUFBQSxFQUN0RCxJQUFJO0FBQUEsRUFDSixJQUFJO0FBQUEsSUFDRixPQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDdEIsTUFBTTtBQUFBLElBQ04sTUFBTSxJQUFJLE1BQU0sOEJBQThCO0FBQUE7QUFBQSxFQUVoRCxJQUFJLG9CQUFvQixJQUFJLEdBQUc7QUFBQSxJQUM3QixRQUFRLE1BQU0sWUFBWSxhQUFhLElBQUk7QUFBQSxJQUMzQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksR0FBRyxRQUFRLFlBQVksUUFBUTtBQUFBLEVBQ3REO0FBQUEsRUFDQSxPQUFPLEVBQUUsT0FBTyxZQUFZLElBQUksR0FBRyxRQUFRLFVBQVUsU0FBUyxDQUFDLEVBQUU7QUFBQTtBQUduRSxTQUFTLFdBQVcsQ0FBQyxNQUF1QjtBQUFBLEVBQzFDLE1BQU0sTUFBaUIsTUFBTSxRQUFRLElBQUksSUFDckMsT0FDQSxRQUFRLE9BQU8sU0FBUyxhQUFZLFdBQVcsU0FBUSxNQUFNLFFBQVMsS0FBb0IsS0FBSyxJQUM1RixLQUFvQixRQUNyQixRQUFRLE9BQU8sU0FBUyxhQUFZLFdBQVcsUUFDN0MsQ0FBQyxJQUFJLElBQ0wsQ0FBQztBQUFBLEVBQ1QsSUFBSSxDQUFDLElBQUk7QUFBQSxJQUFRLE1BQU0sSUFBSSxNQUFNLHdDQUF3QztBQUFBLEVBRXpFLE9BQU8sSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNO0FBQUEsSUFDdkIsTUFBTSxJQUFJO0FBQUEsSUFDVixJQUFJLENBQUMsTUFBTSxRQUFRLEVBQUUsS0FBSztBQUFBLE1BQUcsTUFBTSxJQUFJLE1BQU0sYUFBYSxJQUFJLGtCQUFrQjtBQUFBLElBQ2hGLE1BQU0sUUFBZ0IsRUFBRSxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU07QUFBQSxNQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsU0FBUyxFQUFFLElBQUk7QUFBQSxRQUFHLE1BQU0sSUFBSSxNQUFNLFFBQVEsSUFBSSxTQUFTLEVBQUUsUUFBUSxJQUFJLHNCQUFzQjtBQUFBLE1BQ2pILE9BQU8sS0FBSyxHQUFHLElBQUksT0FBTyxFQUFFLE9BQU8sV0FBVyxFQUFFLEtBQUssSUFBSSxHQUFHLFNBQVMsRUFBRSxZQUFZLE1BQU07QUFBQSxLQUMxRjtBQUFBLElBQ0QsT0FBTyxRQUFRO0FBQUEsTUFDYixJQUFJLE9BQU8sRUFBRSxPQUFPLFdBQVcsRUFBRSxLQUFLLElBQUk7QUFBQSxNQUMxQyxNQUFNLE9BQU8sRUFBRSxRQUFRLGFBQWEsSUFBSSxHQUFHO0FBQUEsTUFDM0MsYUFBYSxFQUFFO0FBQUEsTUFDZixRQUFRLEVBQUU7QUFBQSxNQUNWLE1BQU0sTUFBTSxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUUsS0FBSyxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQUEsTUFDcEQsV0FBVyxFQUFFLGFBQWEsT0FBTyxFQUFFLGNBQWMsV0FBVyxFQUFFLFlBQVksQ0FBQztBQUFBLE1BQzNFO0FBQUEsTUFDQSxXQUFXLE9BQU8sRUFBRSxjQUFjLFdBQVcsRUFBRSxZQUFZLEtBQUssSUFBSTtBQUFBLElBQ3RFLENBQUM7QUFBQSxHQUNGO0FBQUE7QUFNSCxTQUFTLFVBQVUsQ0FBQyxLQUFxQjtBQUFBLEVBQ3ZDLElBQUksSUFBSSxXQUFXLE9BQU87QUFBQSxJQUFHLE9BQU8sYUFBYSxLQUFLLFVBQVUsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBRTVFLE1BQU0sSUFBSSxJQUFJLFFBQVEsTUFBTTtBQUFBLEVBQzVCLElBQUksSUFBSTtBQUFBLElBQUcsT0FBTyxHQUFHLFdBQVcsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssV0FBVyxJQUFJLE1BQU0sSUFBSSxDQUFDLENBQUM7QUFBQSxFQUMvRSxJQUFJLElBQUksV0FBVyxRQUFRO0FBQUEsSUFBRyxPQUFPLGFBQWEsS0FBSyxVQUFVLElBQUksTUFBTSxDQUFDLENBQUM7QUFBQSxFQUM3RSxJQUFJLElBQUksV0FBVyxRQUFRO0FBQUEsSUFBRyxPQUFPLGNBQWMsSUFBSSxNQUFNLENBQUM7QUFBQSxFQUM5RCxPQUFPO0FBQUE7QUFHVCxJQUFNLEtBQUssQ0FBQyxNQUFjLEtBQUssVUFBVSxDQUFDO0FBRzFDLFNBQVMsT0FBTyxDQUFDLEdBQW1CO0FBQUEsRUFDbEMsSUFBSSxDQUFDLE9BQU8sS0FBSyxDQUFDO0FBQUEsSUFBRyxPQUFPLEdBQUcsQ0FBQztBQUFBLEVBQ2hDLE9BQU8sT0FBTyxHQUFHLENBQUMsSUFBSTtBQUFBO0FBR3hCLFNBQVMsT0FBTyxDQUFDLE1BQVksTUFBTSxRQUFnQjtBQUFBLEVBQ2pELE1BQU0sT0FBTyxDQUFDLEtBQUssVUFBVyxHQUFJLEtBQUssYUFBYSxDQUFDLENBQUUsRUFBRSxJQUFJLFVBQVU7QUFBQSxFQUN2RSxJQUFJLEtBQUssV0FBVztBQUFBLElBQUcsT0FBTyxHQUFHLGVBQWUsR0FBRyxLQUFLLEVBQUc7QUFBQSxFQUMzRCxPQUFPLGlCQUFpQixLQUFLLElBQUksQ0FBQyxNQUFNLEdBQUcsZUFBZSxHQUFHLENBQUMsSUFBSSxFQUFFLEtBQUssSUFBSTtBQUFBO0FBSS9FLFNBQVMsU0FBUyxDQUFDLE1BQWdDO0FBQUEsRUFDakQsSUFBSSxDQUFDLEtBQUssT0FBTztBQUFBLElBQVE7QUFBQSxFQUN6QixNQUFNLE9BQU8sS0FBSyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFVLEdBQUksRUFBRSxhQUFhLENBQUMsQ0FBRSxFQUFFLElBQUksVUFBVSxDQUFDO0FBQUEsRUFDdkYsT0FBTyxpQkFBaUIsS0FBSyxVQUFVLElBQUk7QUFBQTtBQUd0QyxTQUFTLFdBQVcsQ0FBQyxNQUFvQjtBQUFBLEVBQzlDLE1BQU0sTUFBZ0IsQ0FBQztBQUFBLEVBQ3ZCLElBQUksS0FBSyxNQUFNLEtBQUssb0NBQW9DLElBQUksS0FBSyxFQUFFLGVBQWUsR0FBRztBQUFBLEVBQ3JGLElBQUksS0FBSyxxREFBcUQsS0FBSyxLQUFLLElBQUksZ0JBQWdCO0FBQUEsRUFDNUYsSUFBSSxLQUFLLGlEQUFpRDtBQUFBLEVBQzFELElBQUksS0FBSyxFQUFFO0FBQUEsRUFDWCxJQUFJLEtBQUssaUJBQWlCO0FBQUEsRUFDMUIsSUFBSSxLQUFLLGdCQUFnQixLQUFLLFVBQVUsS0FBSyxhQUFhLENBQUMsR0FBRyxNQUFNLENBQUMsSUFBSTtBQUFBLEVBQ3pFLElBQUksS0FBSyxvQkFBb0I7QUFBQSxFQUM3QixJQUFJLEtBQUssbUNBQW1DO0FBQUEsRUFDNUMsSUFBSSxLQUFLLCtCQUErQjtBQUFBLEVBQ3hDLElBQUksS0FBSyx3REFBd0Q7QUFBQSxFQUNqRSxJQUFJLEtBQUssbUVBQW1FO0FBQUEsRUFDNUUsSUFBSSxLQUFLLGtEQUFrRDtBQUFBLEVBQzNELElBQUksS0FBSyxJQUFJO0FBQUEsRUFDYixJQUFJLEtBQUssNEhBQTRIO0FBQUEsRUFDckksSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUNYLElBQUksS0FBSyxNQUFNLEtBQUssQ0FBQyxPQUFPLEdBQUcsT0FBTyxNQUFNLEdBQUc7QUFBQSxJQUM3QyxJQUFJLEtBQUsscUZBQXFGO0FBQUEsSUFDOUYsSUFBSSxLQUFLLGdDQUFnQztBQUFBLElBQ3pDLElBQUksS0FBSyw2QkFBNkI7QUFBQSxJQUN0QyxJQUFJLEtBQUssOEJBQThCO0FBQUEsSUFDdkMsSUFBSSxLQUFLLGdGQUFnRjtBQUFBLElBQ3pGLElBQUksS0FBSyxrQ0FBa0M7QUFBQSxJQUMzQyxJQUFJLEtBQUssS0FBSztBQUFBLElBQ2QsSUFBSSxLQUFLLGFBQWE7QUFBQSxJQUN0QixJQUFJLEtBQUssR0FBRztBQUFBLElBQ1osSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUNiO0FBQUEsRUFDQSxJQUFJLEtBQUsscUdBQXFHO0FBQUEsRUFDOUcsSUFBSSxLQUFLLHVDQUF1QztBQUFBLEVBQ2hELElBQUksS0FBSyw0QkFBNEI7QUFBQSxFQUNyQyxJQUFJLEtBQUssT0FBTztBQUFBLEVBRWhCLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRyxNQUFNO0FBQUEsSUFDM0IsTUFBTSxVQUFVLFFBQVEsSUFBSSxNQUFNLEVBQUUsT0FBTyxFQUFFLFFBQVEsTUFBTSxFQUFFLFVBQVU7QUFBQSxJQUN2RSxJQUFJLENBQUMsRUFBRSxTQUFTO0FBQUEsTUFDZCxJQUFJLEtBQUssVUFBVSxnQkFBZ0I7QUFBQSxNQUNuQztBQUFBLElBQ0Y7QUFBQSxJQUNBLElBQUksS0FBSyxPQUFPO0FBQUEsSUFDaEIsTUFBTSxNQUFNLEVBQUUsU0FBUztBQUFBLElBQ3ZCLE1BQU0sS0FBSyxVQUFVLENBQUM7QUFBQSxJQUN0QixNQUFNLE1BQU0sS0FBSyxNQUFNO0FBQUEsSUFDdkIsTUFBTSxNQUFNLE1BQU0sUUFBUSxHQUFHLEdBQUc7QUFBQSxJQUNoQyxJQUFJLE1BQU0sRUFBRSxTQUFTLGNBQWMsRUFBRSxTQUFTO0FBQUEsTUFBUSxJQUFJLEtBQUssT0FBTyxlQUFlLEtBQUs7QUFBQSxJQUMxRixRQUFRLEVBQUU7QUFBQSxXQUNIO0FBQUEsUUFDSCxJQUFJLEtBQUsscUJBQXFCLFFBQVEsR0FBRyxvQ0FBb0M7QUFBQSxRQUM3RTtBQUFBLFdBQ0c7QUFBQSxRQUNILElBQUksS0FBSyx1QkFBdUI7QUFBQSxRQUNoQyxJQUFJLEtBQUssZ0VBQWdFO0FBQUEsUUFDekUsSUFBSSxLQUFLLE9BQU8sSUFBSSxZQUFZO0FBQUEsUUFDaEMsSUFBSSxLQUFLLE9BQU87QUFBQSxRQUNoQjtBQUFBLFdBQ0c7QUFBQSxRQUNILElBQUksS0FBSyxXQUFXLElBQUksVUFBVSxRQUFRLEdBQUcsS0FBSztBQUFBLFFBQ2xEO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLFdBQVcsY0FBYyxHQUFHLFdBQVcsRUFBRSxRQUFTLENBQUMsTUFBTSxRQUFRLEdBQUcsS0FBSztBQUFBLFFBQ2xGO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLEtBQUs7QUFBQSxRQUNkLElBQUksS0FBSyx3QkFBd0IsSUFBSSxpQkFBaUI7QUFBQSxRQUN0RCxJQUFJLEtBQUssa0dBQWtHLFFBQVEsNEJBQTRCO0FBQUEsUUFDL0ksSUFBSSxLQUFLLEtBQUs7QUFBQSxRQUNkO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxFQUFFO0FBQUEsVUFBVSxJQUFJLEtBQUssV0FBVyxJQUFJLFlBQVk7QUFBQSxRQUNwRCxJQUFJLEtBQUssdUJBQXVCO0FBQUEsUUFDaEMsSUFBSSxLQUFLLGdFQUFnRTtBQUFBLFFBQ3pFLElBQUksS0FBSywyQkFBMkIsR0FBRyxPQUFPLE9BQU8sS0FBSztBQUFBLFFBQzFELElBQUksS0FBSyxPQUFPO0FBQUEsUUFDaEI7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJLEtBQUssNENBQTRDLE9BQU8sR0FBRyxLQUFLLFNBQVM7QUFBQSxRQUM3RTtBQUFBLFdBQ0c7QUFBQSxRQUNILElBQUksS0FBSyxXQUFXLElBQUksV0FBVztBQUFBLFFBQ25DO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLEtBQUs7QUFBQSxRQUNkLElBQUksS0FBSyx3QkFBd0IsSUFBSSxpQkFBaUI7QUFBQSxRQUN0RCxJQUFJLEtBQUssbUVBQW1FO0FBQUEsUUFDNUUsSUFBSSxLQUFLLHlCQUF5QixRQUFRLEdBQUcsOEJBQThCLElBQUksa0JBQWtCLElBQUksUUFBUSxXQUFXLEVBQUUscUJBQXFCO0FBQUEsUUFDL0ksSUFBSSxLQUFLLEtBQUs7QUFBQSxRQUNkO0FBQUE7QUFBQSxJQUVKLElBQUksTUFBTSxFQUFFLFNBQVMsY0FBYyxFQUFFLFNBQVM7QUFBQSxNQUFRLElBQUksS0FBSyxLQUFLO0FBQUEsR0FDckU7QUFBQSxFQUVELElBQUksS0FBSyxvQkFBb0IsS0FBSyxLQUFLLFFBQVEsTUFBTSxHQUFHLFVBQVU7QUFBQSxFQUNsRSxJQUFJLEtBQUssZUFBZTtBQUFBLEVBQ3hCLElBQUksS0FBSyxrQ0FBa0M7QUFBQSxFQUMzQyxJQUFJLEtBQUssd0RBQXdEO0FBQUEsRUFDakUsSUFBSSxLQUFLLHlCQUF5QjtBQUFBLEVBQ2xDLElBQUksS0FBSyxhQUFhO0FBQUEsRUFDdEIsSUFBSSxLQUFLLDBCQUEwQjtBQUFBLEVBQ25DLElBQUksS0FBSyxHQUFHO0FBQUEsRUFDWixPQUFPLElBQUksS0FBSztBQUFBLENBQUksSUFBSTtBQUFBO0FBQUE7QUFHbkIsSUFBTSxPQUFPLENBQUMsTUFDbkIsRUFDRyxVQUFVLEtBQUssRUFDZixRQUFRLFVBQVUsRUFBRSxFQUNwQixZQUFZLEVBQ1osUUFBUSxlQUFlLEdBQUcsRUFDMUIsUUFBUSxVQUFVLEVBQUUsS0FBSzs7O0FDbE05QixJQUFNLGNBQWM7QUFHcEIsSUFBTSxZQUFZLE9BQU8sSUFBSSxnQkFBZ0IsU0FBUyxNQUFNLEVBQUUsSUFBSSxLQUFLLENBQUMsS0FBSztBQUU3RSxlQUFzQixTQUFTLEdBQTZCO0FBQUEsRUFDMUQsSUFBSTtBQUFBLElBQVcsT0FBTyxPQUFPLEtBQUssSUFBSSxTQUFTO0FBQUEsRUFDL0MsT0FBTyxPQUFPLE1BQU0sT0FBTyxLQUFLLE1BQU0sRUFBRSxRQUFRLE1BQU0sZUFBZSxLQUFLLENBQUM7QUFBQSxFQUMzRSxJQUFJLENBQUMsS0FBSztBQUFBLElBQUksTUFBTSxJQUFJLE1BQU0sdUJBQXVCO0FBQUEsRUFDckQsT0FBTztBQUFBO0FBR1QsZUFBZSxXQUFXLENBQUMsT0FBZSxVQUFVLE9BQU87QUFBQSxFQUN6RCxNQUFNLFFBQVEsS0FBSyxJQUFJO0FBQUEsRUFDdkIsT0FBTyxLQUFLLElBQUksSUFBSSxRQUFRLFNBQVM7QUFBQSxJQUNuQyxNQUFNLElBQUksTUFBTSxPQUFPLEtBQUssSUFBSSxLQUFLO0FBQUEsSUFDckMsSUFBSSxFQUFFLFdBQVc7QUFBQSxNQUFZO0FBQUEsSUFDN0IsTUFBTSxNQUFNLEdBQUc7QUFBQSxFQUNqQjtBQUFBLEVBQ0EsTUFBTSxJQUFJLE1BQU0scUNBQXFDO0FBQUE7QUFJdkQsU0FBUyxnQkFBZ0IsQ0FBQyxPQUFlLFVBQVUsR0FBRztBQUFBLEVBQ3BELElBQUksVUFBVTtBQUFBLEVBQ2QsSUFBSSxVQUFVO0FBQUEsRUFDZCxNQUFNLE9BQU8sQ0FBQyxNQUEwQyxFQUFFLFVBQVUsVUFBVSxFQUFFLFlBQVksS0FBSyxFQUFFLFlBQVk7QUFBQSxFQUMvRyxNQUFNLFVBQVUsQ0FBQyxNQUFpRTtBQUFBLElBQ2hGLElBQUksS0FBSyxDQUFDO0FBQUEsTUFBSSxVQUFVLE1BQU87QUFBQTtBQUFBLEVBRWpDLE1BQU0sUUFBUSxDQUFDLE1BQTBDO0FBQUEsSUFDdkQsSUFBSSxLQUFLLENBQUM7QUFBQSxNQUFHLFVBQVUsS0FBSyxJQUFJLEdBQUcsVUFBVSxDQUFDO0FBQUE7QUFBQSxFQUVoRCxNQUFNLE1BQU0sT0FBTztBQUFBLEVBQ25CLElBQUksaUJBQWlCLFlBQVksT0FBTztBQUFBLEVBQ3hDLElBQUksWUFBWSxZQUFZLEtBQUs7QUFBQSxFQUNqQyxJQUFJLGdCQUFnQixZQUFZLEtBQUs7QUFBQSxFQUNyQyxPQUFPO0FBQUEsU0FFQyxRQUFPLENBQUMsUUFBZ0I7QUFBQSxNQUM1QixNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUk7QUFBQSxNQUN6QixPQUFPLENBQUMsV0FBVyxLQUFLLElBQUksSUFBSTtBQUFBLFFBQUssTUFBTSxNQUFNLEVBQUU7QUFBQSxNQUNuRCxPQUFPO0FBQUE7QUFBQSxTQUdILFFBQU8sQ0FBQyxVQUFVLE9BQU87QUFBQSxNQUM3QixNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUk7QUFBQSxNQUN6QixPQUFPLFVBQVUsR0FBRztBQUFBLFFBQ2xCLElBQUksS0FBSyxJQUFJLElBQUk7QUFBQSxVQUFLLE1BQU0sSUFBSSxNQUFNLHFDQUFxQztBQUFBLFFBQzNFLE1BQU0sTUFBTSxFQUFFO0FBQUEsTUFDaEI7QUFBQSxNQUNBLE1BQU0sWUFBWSxPQUFPLE9BQU87QUFBQTtBQUFBLElBRWxDLE9BQU8sR0FBRztBQUFBLE1BQ1IsSUFBSSxpQkFBaUIsZUFBZSxPQUFPO0FBQUEsTUFDM0MsSUFBSSxZQUFZLGVBQWUsS0FBSztBQUFBLE1BQ3BDLElBQUksZ0JBQWdCLGVBQWUsS0FBSztBQUFBO0FBQUEsRUFFNUM7QUFBQTtBQUlGLGVBQXNCLGFBQWEsQ0FBQyxPQUFlLFVBQVUsR0FBa0I7QUFBQSxFQUM3RSxTQUFTLElBQUksRUFBRyxJQUFJLElBQUksS0FBSztBQUFBLElBQzNCLElBQUk7QUFBQSxNQUNGLE1BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxZQUFZLE9BQU8sRUFBRSxNQUFNLE9BQU8sR0FBdUIsRUFBRSxRQUFRLENBQUM7QUFBQSxNQUNoRyxJQUFJLEdBQUc7QUFBQSxRQUFJO0FBQUEsTUFDWCxNQUFNO0FBQUEsSUFHUixJQUFJLE1BQU0sR0FBRztBQUFBLE1BQ1gsSUFBSTtBQUFBLFFBRUYsTUFBTSxPQUFPLFVBQVUsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLFVBQVUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxPQUFPLENBQUMsU0FBUyxHQUFHLE9BQU8sT0FBTyxDQUFDLEVBQUUsTUFBTSxNQUFNLEVBQUU7QUFBQSxRQUNsSSxNQUFNLE9BQU8sVUFBVSxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sVUFBVSxDQUFDLE9BQU8sRUFBRSxHQUFHLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQztBQUFBLFFBQ3RHLE9BQU8sR0FBRztBQUFBLFFBQ1YsTUFBTSxJQUFJLE1BQU0sd0NBQXlDLEVBQVksVUFBVSxHQUFHO0FBQUE7QUFBQSxJQUV0RjtBQUFBLElBQ0EsTUFBTSxNQUFNLEdBQUc7QUFBQSxFQUNqQjtBQUFBLEVBQ0EsTUFBTSxJQUFJLE1BQU0sVUFBVSwwQkFBMEIsNkNBQTZDO0FBQUE7QUFJbkcsZUFBc0IsU0FBc0IsQ0FBQyxPQUFlLEtBQWdCLFVBQVUsR0FBZTtBQUFBLEVBQ25HLE1BQU0sY0FBYyxPQUFPLE9BQU87QUFBQSxFQUNsQyxPQUFPLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSyxFQUFFLFFBQVEsQ0FBQztBQUFBO0FBSXhELGVBQXNCLFVBQVUsQ0FBQyxPQUFlLE9BQStCLFNBQWtDO0FBQUEsRUFDL0csSUFBSSxNQUFNO0FBQUEsRUFDVixZQUFZLEdBQUcsU0FBUyxTQUFTLENBQUMsR0FBRyxRQUFRLEdBQUc7QUFBQSxJQUM5QyxNQUFNLE1BQU0sS0FBSyxJQUFJLElBQUk7QUFBQSxJQUN6QixJQUFJO0FBQUEsSUFHSixPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ25CLE1BQU0sSUFBSSxNQUFNLFVBQ2QsT0FDQSxFQUFFLE1BQU0saUJBQWlCLFdBQVcsQ0FBQyxJQUFJLFVBQVUsR0FBSSxJQUFJLGFBQWEsQ0FBQyxDQUFFLEdBQUcsU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLEtBQUssSUFBSSxDQUFDLEVBQUUsR0FDckgsR0FDRjtBQUFBLE1BQ0EsSUFBSSxDQUFDLEdBQUc7QUFBQSxRQUFPLE1BQU0sSUFBSSxNQUFNLEdBQUcsR0FBRyxTQUFTLHFDQUFxQyxJQUFJLElBQUk7QUFBQSxNQUMzRixTQUFTLElBQUksRUFBRyxJQUFJLEtBQUssUUFBUSxNQUFNLEtBQUs7QUFBQSxRQUMxQyxNQUFNLE1BQU0sRUFBRTtBQUFBLFFBQ2QsUUFBUSxNQUFNLE9BQU8sUUFBUSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQUEsTUFDdkY7QUFBQSxNQUNBLElBQUksUUFBUSxRQUFRLEtBQUssSUFBSSxJQUFJO0FBQUEsUUFBSyxNQUFNLElBQUksTUFBTSxjQUFjLElBQUksZ0NBQWdDLElBQUksSUFBSTtBQUFBLElBQ2xIO0FBQUEsSUFDQSxNQUFNO0FBQUEsRUFDUjtBQUFBLEVBQ0EsT0FBTztBQUFBO0FBSUYsU0FBUyxZQUFZLENBQUMsTUFBb0M7QUFBQSxFQUMvRCxNQUFNLE9BQStCLENBQUM7QUFBQSxFQUN0QyxXQUFXLEtBQUs7QUFBQSxJQUFjLEtBQUssS0FBSyxZQUFZLEtBQUssT0FBTyxDQUFDLENBQUM7QUFBQSxFQUNsRSxNQUFNLE9BQU8sS0FBSyxLQUFLO0FBQUEsRUFDdkIsWUFBWSxHQUFHLE1BQU0sT0FBTyxRQUFRLEtBQUssYUFBYSxDQUFDLENBQUM7QUFBQSxJQUFHLEtBQUssS0FBSyxZQUFZLEdBQUcsSUFBSTtBQUFBLEVBQ3hGLE9BQU87QUFBQTtBQUdULFNBQVMsV0FBVyxDQUFDLE1BQVksTUFBb0M7QUFBQSxFQUNuRSxPQUFPLEtBQUssTUFBTSxPQUFPLEtBQUssU0FBUyxPQUFPLFlBQVksS0FBSyxPQUFPLElBQUksSUFBSSxVQUFVO0FBQUE7QUFBQTtBQUduRixNQUFNLE9BQU87QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNsQixVQUFVO0FBQUEsRUFFVixJQUFJLEdBQUc7QUFBQSxJQUNMLEtBQUssVUFBVTtBQUFBO0FBQUEsT0FHWCxJQUFHLENBQUMsTUFBWSxVQUFvQixPQUFpQixPQUFPLEdBQUcsTUFBb0M7QUFBQSxJQUN2RyxLQUFLLFVBQVU7QUFBQSxJQUNmLEtBQUssVUFBVTtBQUFBLElBQ2YsTUFBTSxLQUFLLEtBQUssSUFBSTtBQUFBLElBQ3BCLE1BQU0sT0FBTyxhQUFhLElBQUk7QUFBQSxJQUM5QixNQUFNLFFBQVEsS0FBSztBQUFBLElBQ25CLE1BQU0sTUFBTSxRQUFRLE9BQU8sT0FBTyxJQUFJLE1BQU07QUFBQSxJQUM1QyxTQUFTLElBQUksRUFBRyxJQUFJLE1BQU0sUUFBUTtBQUFBLE1BQUssSUFBSSxLQUFLLFFBQVEsSUFBSTtBQUFBLFFBQUssTUFBTSxTQUFTLE1BQU0sR0FBSSxJQUFJLFNBQVM7QUFBQSxJQUV2RyxJQUFJO0FBQUEsTUFDRixNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQUEsTUFDNUIsTUFBTSxRQUFRLElBQUk7QUFBQSxNQUNsQixTQUFTLElBQUksS0FBTSxJQUFJLEtBQUssS0FBSztBQUFBLFFBQy9CLElBQUksS0FBSztBQUFBLFVBQVMsTUFBTSxJQUFJLE1BQU0seUJBQXlCO0FBQUEsUUFDM0QsTUFBTSxPQUFPLE1BQU07QUFBQSxRQUNuQixJQUFJLENBQUMsS0FBSyxTQUFTO0FBQUEsVUFDakIsTUFBTSxTQUFTLEtBQUssSUFBSSxTQUFTO0FBQUEsVUFDakM7QUFBQSxRQUNGO0FBQUEsUUFDQSxNQUFNLFNBQVMsS0FBSyxJQUFJLFNBQVM7QUFBQSxRQUNqQyxJQUFJO0FBQUEsVUFDRixNQUFNLEtBQUssS0FBSyxPQUFPLFlBQVksTUFBTSxJQUFJLEdBQUcsUUFBUTtBQUFBLFVBQ3hELE1BQU0sU0FBUyxLQUFLLElBQUksSUFBSTtBQUFBLFVBQzVCLE9BQU8sR0FBRztBQUFBLFVBQ1YsTUFBTSxNQUFPLEVBQVk7QUFBQSxVQUN6QixNQUFNLFNBQVMsS0FBSyxJQUFJLFNBQVMsR0FBRztBQUFBLFVBQ3BDLE9BQU8sRUFBRSxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxjQUFjLEtBQUssSUFBSSxPQUFPLElBQUk7QUFBQTtBQUFBLFFBRXJGLElBQUksSUFBSSxNQUFNLEtBQUssU0FBUztBQUFBLFVBQVcsTUFBTSxNQUFNLFNBQVMsU0FBUztBQUFBLE1BQ3ZFO0FBQUEsTUFDQSxPQUFPLEVBQUUsSUFBSSxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssSUFBSSxJQUFJLEdBQUc7QUFBQSxNQUMvQyxPQUFPLEdBQUc7QUFBQSxNQUNWLE9BQU8sRUFBRSxJQUFJLElBQUksSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxPQUFRLEVBQVksUUFBUTtBQUFBLGNBQzdFO0FBQUEsTUFDQSxLQUFLLFVBQVU7QUFBQTtBQUFBO0FBQUEsT0FJTCxLQUFJLENBQUMsT0FBZSxNQUFZLFVBQW9CO0FBQUEsSUFDaEUsUUFBUSxLQUFLO0FBQUEsV0FDTixZQUFZO0FBQUEsUUFDZixJQUFJLENBQUMsS0FBSztBQUFBLFVBQU8sTUFBTSxJQUFJLE1BQU0sY0FBYztBQUFBLFFBQy9DLE1BQU0sT0FBTyxpQkFBaUIsS0FBSztBQUFBLFFBQ25DLElBQUk7QUFBQSxVQUNGLE1BQU0sT0FBTyxLQUFLLE9BQU8sT0FBTyxFQUFFLEtBQUssS0FBSyxNQUFNLENBQUM7QUFBQSxVQUNuRCxNQUFNLEtBQUssUUFBUSxJQUFJO0FBQUEsVUFDdkIsTUFBTSxLQUFLLFFBQVE7QUFBQSxrQkFDbkI7QUFBQSxVQUNBLEtBQUssUUFBUTtBQUFBO0FBQUEsUUFFZjtBQUFBLE1BQ0Y7QUFBQSxXQUNLO0FBQUEsUUFDSCxNQUFNLE1BQU0sT0FBTyxLQUFLLEtBQUssS0FBSyxJQUFJO0FBQUEsUUFDdEM7QUFBQTtBQUFBLElBR0osTUFBTSxPQUFPLEtBQUssU0FBUyxXQUFXLEtBQUssU0FBUztBQUFBLElBQ3BELE1BQU0sVUFBVSxLQUFLLFdBQVcsU0FBUztBQUFBLElBQ3pDLElBQUk7QUFBQSxJQUNKLElBQUksTUFBTSxNQUFNLFdBQVcsT0FBTyxLQUFLLE9BQU8sT0FBTztBQUFBLElBQ3JELE1BQU0sT0FBTyxpQkFBaUIsT0FBTyxHQUFHO0FBQUEsSUFDeEMsSUFBSTtBQUFBLE1BQ0YsU0FBUyxVQUFVLElBQUssV0FBVztBQUFBLFFBQ2pDLElBQUk7QUFBQSxVQUNGLE1BQU0sTUFBTSxVQUFzQixPQUFPLEVBQUUsTUFBTSxZQUFZLE1BQU0sU0FBUyxHQUFHLEdBQUc7QUFBQSxVQUNsRixPQUFPLEdBQUc7QUFBQSxVQUNWLElBQUksQ0FBQyxZQUFZLEtBQU0sRUFBWSxPQUFPO0FBQUEsWUFBRyxNQUFNO0FBQUEsVUFFbkQsTUFBTSxLQUFLLFFBQVE7QUFBQSxVQUNuQixJQUFJO0FBQUEsWUFBTTtBQUFBLFVBQ1YsSUFBSSxXQUFXO0FBQUEsWUFBRyxNQUFNLElBQUksTUFBTSw4Q0FBOEM7QUFBQSxVQUNoRixNQUFNLE1BQU0sV0FBVyxPQUFPLEtBQUssT0FBTyxPQUFPO0FBQUEsVUFDakQ7QUFBQTtBQUFBLFFBRUYsSUFBSSxDQUFDO0FBQUEsVUFBSyxNQUFNLElBQUksTUFBTSw0QkFBNEI7QUFBQSxRQUN0RCxJQUFJLENBQUMsSUFBSTtBQUFBLFVBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLO0FBQUEsUUFDdEM7QUFBQSxNQUNGO0FBQUEsTUFHQSxJQUFJLFFBQVMsTUFBTSxLQUFLLFFBQVEsSUFBSSxjQUFjLE9BQU8sR0FBRztBQUFBLFFBQUksTUFBTSxLQUFLLFFBQVE7QUFBQSxjQUNuRjtBQUFBLE1BQ0EsS0FBSyxRQUFRO0FBQUE7QUFBQTtBQUduQjs7O0FDdE9PLFNBQVMsQ0FBd0MsQ0FBQyxLQUFRLFVBQXlCLFVBQTZDO0FBQUEsRUFDckksTUFBTSxLQUFLLFNBQVMsY0FBYyxHQUFHO0FBQUEsRUFDckMsWUFBWSxHQUFHLE1BQU0sT0FBTyxRQUFRLFNBQVMsQ0FBQyxDQUFDLEdBQUc7QUFBQSxJQUNoRCxJQUFJLEtBQUssUUFBUSxNQUFNO0FBQUEsTUFBTztBQUFBLElBQzlCLElBQUksRUFBRSxXQUFXLElBQUksS0FBSyxPQUFPLE1BQU07QUFBQSxNQUFZLEdBQUcsaUJBQWlCLEVBQUUsTUFBTSxDQUFDLEVBQUUsWUFBWSxHQUFHLENBQWtCO0FBQUEsSUFDOUcsU0FBSSxNQUFNO0FBQUEsTUFBUyxHQUFHLFlBQVksT0FBTyxDQUFDO0FBQUEsSUFDMUMsU0FBSSxNQUFNLFdBQVcsTUFBTSxhQUFhLE1BQU0sY0FBYyxNQUFNO0FBQUEsTUFBa0IsR0FBVyxLQUFLO0FBQUEsSUFDcEcsU0FBSSxNQUFNO0FBQUEsTUFBTSxHQUFHLGFBQWEsR0FBRyxFQUFFO0FBQUEsSUFDckM7QUFBQSxTQUFHLGFBQWEsR0FBRyxPQUFPLENBQUMsQ0FBQztBQUFBLEVBQ25DO0FBQUEsRUFDQSxPQUFPLElBQUksUUFBUTtBQUFBLEVBQ25CLE9BQU87QUFBQTtBQUdULFNBQVMsTUFBTSxDQUFDLElBQVUsVUFBbUI7QUFBQSxFQUMzQyxXQUFXLEtBQUssVUFBVTtBQUFBLElBQ3hCLElBQUksS0FBSyxRQUFRLE1BQU07QUFBQSxNQUFPO0FBQUEsSUFDOUIsSUFBSSxNQUFNLFFBQVEsQ0FBQztBQUFBLE1BQUcsT0FBTyxJQUFJLENBQUM7QUFBQSxJQUM3QjtBQUFBLFNBQUcsWUFBWSxhQUFhLE9BQU8sSUFBSSxTQUFTLGVBQWUsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUFBLEVBQ2hGO0FBQUE7QUFJSyxTQUFTLEtBQUssQ0FBQyxNQUFtQixNQUFZO0FBQUEsRUFDbkQsTUFBTSxTQUFTLFNBQVM7QUFBQSxFQUN4QixNQUFNLE1BQU0sUUFBUSxTQUFTO0FBQUEsRUFDN0IsTUFBTSxNQUFNLE9BQU8sb0JBQW9CLFNBQVUsQ0FBQyxPQUFRLGdCQUFnQixPQUFRLFlBQVksSUFBSTtBQUFBLEVBQ2xHLE1BQU0sWUFBWSxDQUFDLEdBQUcsS0FBSyxpQkFBOEIsZUFBZSxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFFBQVEsUUFBUSxFQUFFLFNBQVMsQ0FBVTtBQUFBLEVBQzlILEtBQUssZ0JBQWdCLElBQUk7QUFBQSxFQUN6QixZQUFZLEdBQUcsUUFBUSxXQUFXO0FBQUEsSUFDaEMsTUFBTSxJQUFJLEtBQUssY0FBMkIsaUJBQWlCLEtBQUs7QUFBQSxJQUNoRSxJQUFJO0FBQUEsTUFBRyxFQUFFLFlBQVk7QUFBQSxFQUN2QjtBQUFBLEVBQ0EsSUFBSSxLQUFLO0FBQUEsSUFDUCxNQUFNLEtBQUssS0FBSyxjQUFnQyxZQUFZLElBQUksT0FBTyxHQUFHLEtBQUs7QUFBQSxJQUMvRSxJQUFJLElBQUk7QUFBQSxNQUNOLEdBQUcsTUFBTSxFQUFFLGVBQWUsS0FBSyxDQUFDO0FBQUEsTUFDaEMsSUFBSSxLQUFLO0FBQUEsUUFDUCxJQUFJO0FBQUEsVUFDRixHQUFHLGtCQUFrQixJQUFJLElBQUksSUFBSSxFQUFFO0FBQUEsVUFDbkMsTUFBTTtBQUFBLE1BR1Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBO0FBaUJLLFNBQVMsR0FBRyxDQUFDLEdBQW9DO0FBQUEsRUFDdEQsT0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQUEsSUFDOUIsTUFBTSxTQUFTLFFBQVEsS0FBSyxPQUFPLEVBQUUsU0FBUyxFQUFFLEVBQUUsTUFBTSxDQUFDO0FBQUEsSUFDekQsTUFBTSxRQUNKLEVBQUUsU0FBUyxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sU0FBUyxPQUFPLEVBQUUsT0FBTyxhQUFhLEVBQUUsYUFBYSxNQUFNLEVBQUUsVUFBVSxTQUFTLEtBQUssQ0FBQyxJQUFJO0FBQUEsSUFDbEksTUFBTSxNQUFNLEVBQ1YsVUFDQSxFQUFFLE9BQU8sU0FBUyxHQUNsQixFQUNFLFFBQ0EsRUFBRSxRQUFRLFNBQVMsR0FDbkIsRUFBRSxNQUFNLE1BQU0sRUFBRSxLQUFLLEdBQ3JCLEVBQUUsV0FBVyxFQUFFLEtBQUssRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLE9BQU8sR0FDakQsT0FDQSxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsSUFBSSxPQUFPLEdBQUcsRUFBRSxRQUFRLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUMxRixFQUNFLE9BQ0EsRUFBRSxPQUFPLFVBQVUsR0FDbkIsRUFBRSxVQUFVLEVBQUUsT0FBTyxhQUFhLE9BQU8sWUFBWSxNQUFNLFNBQVMsR0FBRyxVQUFVLEdBQ2pGLEVBQUUsU0FBUyxFQUFFLFVBQVUsRUFBRSxPQUFPLE9BQU8sT0FBTyxXQUFXLE1BQU0sU0FBUyxHQUFHLEVBQUUsTUFBTSxLQUFLLEdBQ3hGLEVBQUUsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFLFNBQVMsV0FBVyxZQUFZLE9BQU8sUUFBUSxNQUFNLFNBQVMsR0FBRyxFQUFFLE1BQU0sU0FBUyxDQUNySCxDQUNGLENBQ0Y7QUFBQSxJQUNBLElBQUksaUJBQWlCLFNBQVMsTUFBTTtBQUFBLE1BQ2xDLE1BQU0sS0FBSyxJQUFJO0FBQUEsTUFDZixJQUFJLE9BQU87QUFBQSxNQUNYLElBQUksT0FBTztBQUFBLFFBQVEsUUFBUSxRQUFRLE1BQU0sUUFBUSxJQUFJO0FBQUEsTUFDaEQsU0FBSSxPQUFPO0FBQUEsUUFBVyxRQUFRLEVBQUUsTUFBTyxLQUFLO0FBQUEsTUFDNUM7QUFBQSxnQkFBUSxJQUFJO0FBQUEsS0FDbEI7QUFBQSxJQUNELFNBQVMsS0FBSyxZQUFZLEdBQUc7QUFBQSxJQUM3QixJQUFJLFVBQVU7QUFBQSxJQUNkLElBQUksT0FBTztBQUFBLE1BRVQsTUFBTSxpQkFBaUIsV0FBVyxDQUFDLE1BQU07QUFBQSxRQUN2QyxJQUFJLEVBQUUsUUFBUSxTQUFTO0FBQUEsVUFDckIsRUFBRSxlQUFlO0FBQUEsVUFDakIsSUFBSSxNQUFNLE1BQU07QUFBQSxRQUNsQjtBQUFBLE9BQ0Q7QUFBQSxNQUNELE1BQU0sTUFBTTtBQUFBLE1BQ1osTUFBTSxPQUFPO0FBQUEsSUFDZjtBQUFBLEdBQ0Q7QUFBQTtBQUdILElBQUk7QUFDRyxTQUFTLEtBQUssQ0FBQyxNQUFjLE9BQWdDLFFBQVE7QUFBQSxFQUMxRSxJQUFJLEtBQUssU0FBUyxlQUFlLE9BQU87QUFBQSxFQUN4QyxJQUFJLENBQUMsSUFBSTtBQUFBLElBQ1AsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLFFBQVEsQ0FBQztBQUFBLElBQzdCLFNBQVMsS0FBSyxZQUFZLEVBQUU7QUFBQSxFQUM5QjtBQUFBLEVBQ0EsR0FBRyxjQUFjO0FBQUEsRUFDakIsR0FBRyxZQUFZLFVBQVU7QUFBQSxFQUN6QixhQUFhLFVBQVU7QUFBQSxFQUN2QixhQUFhLFdBQVcsTUFBTyxHQUFJLFlBQVksSUFBSyxTQUFTLFVBQVUsT0FBTyxJQUFJO0FBQUE7QUFHN0UsU0FBUyxRQUFRLENBQUMsVUFBa0IsU0FBaUIsT0FBTyxvQkFBb0I7QUFBQSxFQUNyRixNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSSxLQUFLLENBQUMsT0FBTyxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQztBQUFBLEVBQ25FLE1BQU0sSUFBSSxFQUFFLEtBQUssRUFBRSxNQUFNLEtBQUssVUFBVSxTQUFTLENBQUM7QUFBQSxFQUNsRCxTQUFTLEtBQUssWUFBWSxDQUFDO0FBQUEsRUFDM0IsRUFBRSxNQUFNO0FBQUEsRUFDUixFQUFFLE9BQU87QUFBQSxFQUNULFdBQVcsTUFBTSxJQUFJLGdCQUFnQixHQUFHLEdBQUcsSUFBSTtBQUFBO0FBRzFDLFNBQVMsUUFBUSxDQUFDLFNBQVMsMEJBQWdEO0FBQUEsRUFDaEYsT0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQUEsSUFDOUIsTUFBTSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sUUFBUSxPQUFPLENBQUM7QUFBQSxJQUNqRCxNQUFNLGlCQUFpQixVQUFVLE1BQU0sUUFBUSxNQUFNLFFBQVEsTUFBTSxJQUFJLENBQUM7QUFBQSxJQUN4RSxNQUFNLGlCQUFpQixVQUFVLE1BQU0sUUFBUSxJQUFJLENBQUM7QUFBQSxJQUNwRCxNQUFNLE1BQU07QUFBQSxHQUNiO0FBQUE7QUFHSSxTQUFTLE9BQU8sQ0FBQyxJQUFvQjtBQUFBLEVBQzFDLE1BQU0sSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLElBQUksTUFBTSxJQUFJO0FBQUEsRUFDN0MsSUFBSSxJQUFJO0FBQUEsSUFBSSxPQUFPO0FBQUEsRUFDbkIsTUFBTSxJQUFJLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUMzQixJQUFJLElBQUk7QUFBQSxJQUFJLE9BQU8sUUFBUTtBQUFBLEVBQzNCLE1BQU0sS0FBSyxLQUFLLE1BQU0sSUFBSSxFQUFFO0FBQUEsRUFDNUIsSUFBSSxLQUFLO0FBQUEsSUFBSSxPQUFPLFFBQVE7QUFBQSxFQUM1QixNQUFNLElBQUksS0FBSyxNQUFNLEtBQUssRUFBRTtBQUFBLEVBQzVCLElBQUksSUFBSTtBQUFBLElBQUksT0FBTyxRQUFRO0FBQUEsRUFDM0IsT0FBTyxJQUFJLEtBQUssRUFBRSxFQUFFLG1CQUFtQjtBQUFBO0FBR2xDLFNBQVMsTUFBTSxDQUFDLEtBQXNCO0FBQUEsRUFDM0MsSUFBSSxDQUFDO0FBQUEsSUFBSyxPQUFPO0FBQUEsRUFDakIsSUFBSTtBQUFBLElBQ0YsT0FBTyxJQUFJLElBQUksR0FBRyxFQUFFO0FBQUEsSUFDcEIsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBO0FBQUE7QUFJSixTQUFTLFFBQTZCLENBQUMsSUFBdUIsSUFBWTtBQUFBLEVBQy9FLElBQUk7QUFBQSxFQUNKLE9BQU8sSUFBSSxNQUFTO0FBQUEsSUFDbEIsYUFBYSxDQUFDO0FBQUEsSUFDZCxJQUFJLFdBQVcsTUFBTSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUU7QUFBQTtBQUFBOzs7QUMvSjlCLElBQU0sUUFBUTtBQUFBLEVBQ25CLE1BQU07QUFBQSxFQUNOLE9BQU8sQ0FBQztBQUFBLEVBQ1IsV0FBVztBQUFBLEVBQ1gsVUFBVSxLQUFLLGlCQUFpQjtBQUFBLEVBQ2hDLFdBQVc7QUFBQSxFQUNYLFVBQVUsSUFBSTtBQUFBLEVBQ2QsVUFBVSxJQUFJO0FBQUEsRUFDZCxRQUFRLEVBQUUsR0FBRyxJQUFJLFFBQVEsSUFBSSxNQUFNLElBQUksS0FBZSxNQUFNLFVBQTRDO0FBQUEsRUFDeEcsa0JBQWtCLElBQUk7QUFBQSxFQUN0QixLQUFLO0FBQUEsRUFDTCxTQUFTO0FBQUEsRUFDVCxRQUFRO0FBQ1Y7QUFFQSxJQUFJLFdBQXVCLE1BQU07QUFDMUIsSUFBTSxZQUFZLENBQUMsT0FBb0IsV0FBVztBQUNsRCxJQUFNLFNBQVMsTUFBTSxTQUFTO0FBRTlCLElBQU0sU0FBUyxJQUFJO0FBRW5CLElBQU0sVUFBVSxNQUFNLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sTUFBTSxTQUFTO0FBSTdFLElBQU0sZUFBZSxJQUFJO0FBR2xCLFNBQVMsUUFBUSxDQUFDLE1BQVk7QUFBQSxFQUNuQyxJQUFJLEtBQUssYUFBYSxJQUFJLEtBQUssRUFBRTtBQUFBLEVBQ2pDLElBQUksQ0FBQyxJQUFJO0FBQUEsSUFDUCxLQUFLLFNBQVMsTUFBTTtBQUFBLE1BQ2xCLE1BQU0sSUFBSSxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEtBQUssRUFBRTtBQUFBLE1BQ2xELElBQUk7QUFBQSxRQUFjLFNBQVMsQ0FBQztBQUFBLE9BQzNCLEdBQUc7QUFBQSxJQUNOLGFBQWEsSUFBSSxLQUFLLElBQUksRUFBRTtBQUFBLEVBQzlCO0FBQUEsRUFDQSxHQUFHO0FBQUE7QUFHTCxlQUFzQixPQUFPLENBQUMsTUFBWTtBQUFBLEVBQ3hDLE1BQVksU0FBUyxJQUFJO0FBQUEsRUFDekIsT0FBTztBQUFBO0FBR1QsZUFBc0IsTUFBTSxHQUFHO0FBQUEsRUFDN0IsTUFBTSxRQUFRLE1BQVksVUFBVTtBQUFBLEVBQ3BDLE9BQU87QUFBQTtBQUtULGVBQXNCLFVBQVUsR0FBRztBQUFBLEVBQ2pDLE1BQU0sT0FBTyxNQUFNLElBQUksRUFBRSxPQUFPLGVBQWUsT0FBTyxJQUFJLGFBQWEsMEJBQTBCLElBQUksUUFBUSxDQUFDO0FBQUEsRUFDOUcsSUFBSSxRQUFRO0FBQUEsSUFBTTtBQUFBLEVBQ2xCLE1BQU0sU0FBUyxNQUFNLE9BQU8sVUFBVSxNQUFNLE9BQU8sV0FBVyxXQUFXLE1BQU0sT0FBTyxTQUFTO0FBQUEsRUFDL0YsTUFBTSxPQUFhLFFBQVEsRUFBRSxNQUFNLEtBQUssS0FBSyxLQUFLLGVBQWUsT0FBTyxDQUFDO0FBQUEsRUFDekUsTUFBWSxTQUFTLElBQUk7QUFBQSxFQUV6QixJQUFJLENBQUMsTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLEVBQUU7QUFBQSxJQUFHLE1BQU0sTUFBTSxRQUFRLElBQUk7QUFBQSxFQUN4RSxTQUFTLEtBQUssRUFBRTtBQUFBO0FBR1gsU0FBUyxRQUFRLENBQUMsSUFBWTtBQUFBLEVBQ25DLE1BQU0sWUFBWTtBQUFBLEVBQ2xCLE1BQU0sT0FBTztBQUFBLEVBQ2IsTUFBTSxTQUFTLE1BQU07QUFBQSxFQUNyQixJQUFJLE1BQU0sS0FBSyxXQUFXO0FBQUEsSUFBSSxNQUFNLE1BQU07QUFBQSxFQUMxQyxPQUFPO0FBQUEsRUFDUCxTQUFTLGNBQWMsZUFBZSxHQUFHLFNBQVMsR0FBRyxDQUFDO0FBQUE7QUFHeEQsZUFBc0IsYUFBYSxDQUFDLE1BQVk7QUFBQSxFQUM5QyxNQUFNLE9BQU8sZ0JBQWdCLElBQUk7QUFBQSxFQUNqQyxLQUFLLEtBQUssSUFBSTtBQUFBLEVBQ2QsS0FBSyxPQUFPLEtBQUssT0FBTztBQUFBLEVBQ3hCLEtBQUssWUFBWSxLQUFLLElBQUk7QUFBQSxFQUMxQixLQUFLLFVBQVU7QUFBQSxFQUNmLEtBQUssTUFBTSxRQUFRLENBQUMsTUFBTyxFQUFFLEtBQUssSUFBSSxDQUFFO0FBQUEsRUFDeEMsTUFBWSxTQUFTLElBQUk7QUFBQSxFQUN6QixNQUFNLE9BQU87QUFBQSxFQUNiLE1BQU0sbUJBQW1CLElBQUk7QUFBQTtBQUcvQixlQUFzQixXQUFXLENBQUMsS0FBZTtBQUFBLEVBQy9DLE1BQU0sUUFBUSxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sSUFBSSxTQUFTLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJO0FBQUEsRUFDN0UsTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUFBLElBQ25CLE9BQU8sSUFBSSxXQUFXLElBQUksWUFBWSxNQUFNLFNBQVMsV0FBVyxJQUFJO0FBQUEsSUFDcEUsU0FBUztBQUFBLElBQ1QsSUFBSTtBQUFBLElBQ0osUUFBUTtBQUFBLEVBQ1YsQ0FBQztBQUFBLEVBQ0QsSUFBSSxDQUFDO0FBQUEsSUFBSTtBQUFBLEVBQ1QsTUFBWSxZQUFZLEdBQUc7QUFBQSxFQUMzQixJQUFJLFFBQVEsQ0FBQyxPQUFPLE1BQU0sU0FBUyxPQUFPLEVBQUUsQ0FBQztBQUFBLEVBQzdDLElBQUksTUFBTSxhQUFhLElBQUksU0FBUyxNQUFNLFNBQVM7QUFBQSxJQUFHLE1BQU0sT0FBTztBQUFBLEVBQ25FLE1BQU0sT0FBTztBQUFBO0FBR1IsU0FBUyxVQUFVLEdBQWE7QUFBQSxFQUNyQyxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sT0FBTyxDQUFhLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFBQTtBQUc5RyxTQUFTLE9BQU8sR0FBYTtBQUFBLEVBQ2xDLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLE1BQU0sUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztBQUFBO0FBR3BGLFNBQVMsYUFBYSxHQUFXO0FBQUEsRUFDdEMsUUFBUSxHQUFHLFFBQVEsTUFBTSxTQUFTLE1BQU07QUFBQSxFQUN4QyxNQUFNLFNBQVMsRUFBRSxZQUFZLEVBQUUsTUFBTSxLQUFLLEVBQUUsT0FBTyxPQUFPO0FBQUEsRUFDMUQsTUFBTSxPQUFPLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTTtBQUFBLElBQ3JDLElBQUksV0FBVyxXQUFXLEVBQUUsU0FBUyxVQUFVLEVBQUUsV0FBVztBQUFBLE1BQVEsT0FBTztBQUFBLElBQzNFLFdBQVcsS0FBSztBQUFBLE1BQU0sSUFBSSxDQUFDLEVBQUUsS0FBSyxTQUFTLENBQUM7QUFBQSxRQUFHLE9BQU87QUFBQSxJQUN0RCxJQUFJLENBQUMsT0FBTztBQUFBLE1BQVEsT0FBTztBQUFBLElBQzNCLE1BQU0sTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLGFBQWEsRUFBRSxRQUFRLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQyxNQUFNLE1BQU0sQ0FBQyxHQUFHLEdBQUcsRUFBRSxNQUFNLElBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRSxTQUFTLE1BQU0sRUFBRSxTQUFTLGFBQWEsRUFBRSxRQUFRLElBQUksQ0FBQyxFQUMzSixLQUFLLEdBQUcsRUFDUixZQUFZO0FBQUEsSUFDZixPQUFPLE9BQU8sTUFBTSxDQUFDLE1BQU0sSUFBSSxTQUFTLENBQUMsQ0FBQztBQUFBLEdBQzNDO0FBQUEsRUFDRCxJQUFJLFNBQVM7QUFBQSxJQUFRLEtBQUssS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLEtBQUssY0FBYyxFQUFFLElBQUksQ0FBQztBQUFBLEVBQ2hFLFNBQUksU0FBUztBQUFBLElBQVcsS0FBSyxLQUFLLENBQUMsR0FBRyxPQUFPLEVBQUUsU0FBUyxNQUFNLE1BQU0sRUFBRSxTQUFTLE1BQU0sRUFBRTtBQUFBLEVBQ3ZGO0FBQUEsU0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsWUFBWSxFQUFFLFNBQVM7QUFBQSxFQUNsRCxPQUFPO0FBQUE7QUFHVCxlQUFzQixRQUFRLENBQUMsS0FBZTtBQUFBLEVBQzVDLE1BQU0sU0FBUyxNQUFNLElBQUksRUFBRSxPQUFPLG1CQUFtQixPQUFPLElBQUksYUFBYSwyQ0FBMkMsU0FBUyxXQUFXLEdBQUcsSUFBSSxRQUFRLENBQUM7QUFBQSxFQUM1SixJQUFJLFVBQVU7QUFBQSxJQUFNO0FBQUEsRUFDcEIsV0FBVyxLQUFLLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUMsR0FBRztBQUFBLElBQzdELEVBQUUsU0FBUyxPQUFPLEtBQUssS0FBSztBQUFBLElBQzVCLE1BQVksU0FBUyxDQUFDO0FBQUEsRUFDeEI7QUFBQSxFQUNBLE1BQU0sT0FBTztBQUFBO0FBR2YsZUFBc0IsT0FBTyxDQUFDLEtBQWU7QUFBQSxFQUMzQyxNQUFNLE1BQU0sTUFBTSxJQUFJLEVBQUUsT0FBTyxtQkFBbUIsT0FBTyxJQUFJLGFBQWEsWUFBWSxTQUFTLFFBQVEsR0FBRyxJQUFJLFNBQVMsQ0FBQztBQUFBLEVBQ3hILE1BQU0sSUFBSSxLQUFLLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRTtBQUFBLEVBQ3RDLElBQUksQ0FBQztBQUFBLElBQUc7QUFBQSxFQUNSLFdBQVcsS0FBSyxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sSUFBSSxTQUFTLEVBQUUsRUFBRSxDQUFDLEdBQUc7QUFBQSxJQUM3RCxJQUFJLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQztBQUFBLE1BQUcsRUFBRSxLQUFLLEtBQUssQ0FBQztBQUFBLElBQ3RDLE1BQVksU0FBUyxDQUFDO0FBQUEsRUFDeEI7QUFBQSxFQUNBLE1BQU0sT0FBTztBQUFBO0FBS2YsSUFBTSxRQUFRLE1BQU0sSUFBSSxLQUFLLEVBQUUsWUFBWSxFQUFFLE1BQU0sR0FBRyxFQUFFO0FBRWpELFNBQVMsV0FBVyxDQUFDLE9BQWU7QUFBQSxFQUN6QyxJQUFJLENBQUMsTUFBTTtBQUFBLElBQVEsT0FBTyxNQUFNLDhCQUE4QixPQUFPO0FBQUEsRUFDckUsTUFBTSxPQUFPLE1BQU0sV0FBVyxJQUFJLFVBQVUsS0FBSyxNQUFNLEdBQUksSUFBSSxLQUFLLE1BQU0sV0FBVyxVQUFVLE1BQU0saUJBQWlCLE1BQU07QUFBQSxFQUM1SCxTQUFTLE1BQU0sS0FBSyxVQUFVLGFBQWEsS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDM0QsTUFBTSxHQUFHLE1BQU0sZ0NBQWdDLElBQUk7QUFBQTtBQUc5QyxTQUFTLGVBQWUsQ0FBQyxNQUFZO0FBQUEsRUFDMUMsU0FBUyxHQUFHLEtBQUssS0FBSyxJQUFJLFNBQVMsWUFBWSxJQUFJLEdBQUcsaUJBQWlCO0FBQUEsRUFDdkUsTUFBTSxrQ0FBa0MsSUFBSTtBQUFBO0FBRzlDLGVBQXNCLFVBQVUsQ0FBQyxNQUFjO0FBQUEsRUFDN0MsSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLEVBQ0osSUFBSTtBQUFBLElBQ0YsU0FBUyxZQUFZLElBQUk7QUFBQSxJQUN6QixRQUFRLE9BQU87QUFBQSxJQUNmLE9BQU8sR0FBRztBQUFBLElBQ1YsT0FBTyxNQUFPLEVBQVksU0FBUyxPQUFPO0FBQUE7QUFBQSxFQUU1QyxNQUFNLFdBQVcsSUFBSSxJQUFJLE1BQU0sTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQztBQUFBLEVBQ3JELE1BQU0sVUFBVSxNQUFNLE9BQU8sQ0FBQyxNQUFNLFNBQVMsSUFBSSxFQUFFLEVBQUUsQ0FBQztBQUFBLEVBQ3RELElBQUksT0FBNkI7QUFBQSxFQUNqQyxJQUFJLFFBQVEsUUFBUTtBQUFBLElBQ2xCLE1BQU0sSUFBSSxNQUFNLElBQUk7QUFBQSxNQUNsQixPQUFPLEdBQUcsUUFBUTtBQUFBLE1BQ2xCLFNBQVMsUUFBUSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLElBQUk7QUFBQSxNQUM3QyxJQUFJO0FBQUEsTUFDSixPQUFPLEVBQUUsT0FBTyx1QkFBdUIsT0FBTyxPQUFPO0FBQUEsSUFDdkQsQ0FBQztBQUFBLElBQ0QsSUFBSSxLQUFLO0FBQUEsTUFBTTtBQUFBLElBQ2YsT0FBTyxNQUFNLFNBQVMsU0FBUztBQUFBLEVBQ2pDO0FBQUEsRUFDQSxXQUFXLEtBQUssT0FBTztBQUFBLElBQ3JCLElBQUksU0FBUyxJQUFJLEVBQUUsRUFBRSxLQUFLLFNBQVMsUUFBUTtBQUFBLE1BQ3pDLEVBQUUsS0FBSyxJQUFJO0FBQUEsTUFDWCxFQUFFLFFBQVE7QUFBQSxJQUNaO0FBQUEsSUFDQSxNQUFZLFNBQVMsQ0FBQztBQUFBLEVBQ3hCO0FBQUEsRUFDQSxNQUFNLE9BQU87QUFBQSxFQUNiLElBQUksT0FBTyxXQUFXLFlBQVk7QUFBQSxJQUNoQyxNQUFNLElBQUksT0FBTyxRQUFRO0FBQUEsSUFDekIsTUFBTSxrQ0FBa0MsSUFBSSxLQUFLLDhCQUE4QixDQUFDLEdBQUcsSUFBSSxJQUFJLE9BQU8sT0FBTyxDQUFDLEVBQUUsS0FBSyxJQUFJLE9BQU8sTUFBTSxJQUFJLFNBQVMsSUFBSTtBQUFBLElBQ25KLFNBQVMsTUFBTSxHQUFJLEVBQUU7QUFBQSxFQUN2QixFQUFPO0FBQUEsVUFBTSxHQUFHLE1BQU0sZ0NBQWdDLElBQUk7QUFBQTtBQUdyRCxTQUFTLGNBQWMsQ0FBQyxNQUFZO0FBQUEsRUFDekMsUUFBUSxNQUFNLGFBQWEsV0FBVyxJQUFJO0FBQUEsRUFDMUMsU0FBUyxHQUFHLEtBQUssS0FBSyxJQUFJLG1CQUFtQixLQUFLLFVBQVUsTUFBTSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzFFLE1BQ0UsV0FBVyxjQUFjLDZFQUE2RSwrQ0FDdEcsV0FBVyxTQUFTLElBQ3RCO0FBQUE7QUFLSyxTQUFTLE9BQU8sQ0FBQyxNQUFZLE1BQWdCLE9BQWdCO0FBQUEsRUFDbEUsTUFBTSxPQUFhLFFBQVEsRUFBRSxNQUFNLE9BQU8sU0FBUyxVQUFVLFVBQVUsU0FBUyxTQUFTLFNBQVMsU0FBUyxVQUFVLFNBQVMsVUFBVSxDQUFDO0FBQUEsRUFDekksTUFBTSxJQUFJLFFBQVEsS0FBSyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxLQUFLLElBQUk7QUFBQSxFQUNoRSxJQUFJLEtBQUs7QUFBQSxJQUFHLEtBQUssTUFBTSxPQUFPLElBQUksR0FBRyxHQUFHLElBQUk7QUFBQSxFQUN2QztBQUFBLFNBQUssTUFBTSxLQUFLLElBQUk7QUFBQSxFQUN6QixNQUFNLFNBQVMsSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUNyQixRQUFRLElBQUk7QUFBQSxFQUNqQixPQUFPO0FBQUE7QUFHRixTQUFTLFFBQVEsQ0FBQyxNQUFZLElBQVksVUFBeUI7QUFBQSxFQUN4RSxNQUFNLE9BQU8sS0FBSyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFO0FBQUEsRUFDcEQsSUFBSSxPQUFPO0FBQUEsSUFBRztBQUFBLEVBQ2QsT0FBTyxLQUFLLEtBQUssTUFBTSxPQUFPLE1BQU0sQ0FBQztBQUFBLEVBQ3JDLE1BQU0sS0FBSyxXQUFXLEtBQUssTUFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxJQUFJLEtBQUssTUFBTTtBQUFBLEVBQ2xGLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxLQUFLLE1BQU0sU0FBUyxJQUFJLEdBQUcsQ0FBRTtBQUFBLEVBQ25ELFFBQVEsSUFBSTtBQUFBO0FBR1osU0FBUyxhQUFhLENBQUMsTUFBWSxNQUFZO0FBQUEsRUFDcEQsTUFBTSxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUk7QUFBQSxFQUNqQyxNQUFNLE9BQU8sS0FBSyxnQkFBZ0IsSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFO0FBQUEsRUFDbkQsS0FBSyxNQUFNLE9BQU8sSUFBSSxHQUFHLEdBQUcsSUFBSTtBQUFBLEVBQzNCLFFBQVEsSUFBSTtBQUFBO0FBR1osU0FBUyxVQUFVLENBQUMsTUFBWSxNQUFZO0FBQUEsRUFDakQsS0FBSyxRQUFRLEtBQUssTUFBTSxPQUFPLENBQUMsTUFBTSxNQUFNLElBQUk7QUFBQSxFQUNoRCxNQUFNLFNBQVMsT0FBTyxLQUFLLEVBQUU7QUFBQSxFQUN4QixRQUFRLElBQUk7QUFBQTtBQUluQixlQUFzQixPQUFPLENBQUMsTUFBWSxNQUFZO0FBQUEsRUFDcEQsSUFBSTtBQUFBLElBQ0YsTUFBTSxNQUFNLE1BQU0sVUFBVTtBQUFBLElBQzVCLE1BQU0sVUFBVSxLQUFLO0FBQUEsSUFDckIsT0FBTztBQUFBLElBQ1AsTUFBTSxVQUFVLElBQUksSUFBSyxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBQUEsSUFFekMsTUFBTSxJQUF5QixNQUFNLE9BQU8sS0FBSyxZQUFZLElBQUksSUFBSyxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBQUEsSUFDakYsT0FBTyxLQUFLLFlBQVksSUFBSSxJQUFLLEVBQUUsTUFBTSxjQUFjLENBQUMsRUFBRSxNQUFNLE1BQU0sRUFBRTtBQUFBLElBQzdFLElBQUksR0FBRztBQUFBLE1BQ0wsS0FBSyxXQUFXLEVBQUU7QUFBQSxNQUNsQixLQUFLLFlBQVksRUFBRTtBQUFBLE1BQ25CLEtBQUssUUFBUSxFQUFFO0FBQUEsTUFDZixLQUFLLFFBQVEsRUFBRTtBQUFBLE1BQ2YsSUFBSSxLQUFLLFNBQVMsV0FBVyxFQUFFLFNBQVMsU0FBUztBQUFBLFFBRS9DLE9BQU8sT0FBTyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sT0FBTyxFQUFFLE9BQU8sWUFBWSxFQUFFLFlBQVksUUFBUSxFQUFFLE9BQU8sQ0FBQztBQUFBLE1BQ2xHO0FBQUEsTUFDQSxNQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ2xCLE1BQU0sd0JBQXdCLElBQUk7QUFBQSxJQUNwQztBQUFBLElBQ0EsT0FBTyxHQUFHO0FBQUEsSUFDVixNQUFPLEVBQVksU0FBUyxPQUFPO0FBQUEsWUFDbkM7QUFBQSxJQUNBLE1BQU0sVUFBVTtBQUFBLElBQ2hCLE9BQU87QUFBQTtBQUFBO0FBSVgsZUFBc0IsVUFBVSxHQUFHO0FBQUEsRUFDakMsSUFBSTtBQUFBLElBQ0YsTUFBTSxNQUFNLE1BQU0sVUFBVTtBQUFBLElBQzVCLE1BQU0sT0FBTyxLQUFLLFlBQVksSUFBSSxJQUFLLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFBQSxJQUM5RCxNQUFNO0FBQUEsRUFHUixNQUFNLFVBQVU7QUFBQSxFQUNoQixPQUFPO0FBQUE7QUFHVCxlQUFzQixhQUFhLENBQUMsTUFBWTtBQUFBLEVBQzlDLElBQUksQ0FBQyxLQUFLO0FBQUEsSUFBVTtBQUFBLEVBQ3BCLElBQUk7QUFBQSxJQUNGLE1BQU0sTUFBTSxNQUFNLFVBQVU7QUFBQSxJQUM1QixNQUFNLE1BQU0sTUFBTSxXQUFXLElBQUksSUFBSyxLQUFLLE9BQU8sSUFBSTtBQUFBLElBQ3RELE1BQU0sSUFBSSxNQUFNLFVBQTJCLElBQUksSUFBSyxFQUFFLE1BQU0sYUFBYSxVQUFVLEtBQUssVUFBVSxXQUFXLEtBQUssVUFBVSxHQUFHLEdBQUc7QUFBQSxJQUNsSSxJQUFJLENBQUMsR0FBRztBQUFBLE1BQUksTUFBTSxrQ0FBa0MsT0FBTztBQUFBLElBQzNELE9BQU8sR0FBRztBQUFBLElBQ1YsTUFBTyxFQUFZLFNBQVMsT0FBTztBQUFBO0FBQUE7QUFNdkMsSUFBTSxLQUFLLENBQXNDLFFBQXVDLE9BQU8sUUFBUSxZQUFZLEdBQUc7QUFFdEgsZUFBc0IsY0FBYyxDQUFDLE1BQVksTUFBMEI7QUFBQSxFQUN6RSxJQUFJO0FBQUEsSUFDRixNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQUEsSUFDNUIsSUFBSSxDQUFDLElBQUksT0FBTyxDQUFDLGtCQUFrQixLQUFLLElBQUksR0FBRyxHQUFHO0FBQUEsTUFDaEQsT0FBTyxNQUFNLHdEQUF3RCxPQUFPO0FBQUEsSUFDOUU7QUFBQSxJQUNBLE1BQU0sSUFBSSxNQUFNLEdBQUcsRUFBRSxNQUFNLGdCQUFnQixRQUFRLEtBQUssSUFBSSxPQUFPLElBQUksSUFBSyxLQUFLLENBQUM7QUFBQSxJQUNsRixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQUksTUFBTSxFQUFFLFNBQVMsK0JBQStCLE9BQU87QUFBQSxJQUNsRSxPQUFPLEdBQUc7QUFBQSxJQUNWLE1BQU8sRUFBWSxTQUFTLE9BQU87QUFBQTtBQUFBO0FBSWhDLElBQU0sZ0JBQWdCLE1BQU0sR0FBRyxFQUFFLE1BQU0sY0FBYyxDQUFDO0FBQ3RELElBQU0saUJBQWlCLENBQUMsV0FBb0IsR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLE9BQU8sQ0FBQztBQUl0RixlQUFzQixJQUFJLENBQUMsTUFBWSxPQUFPLEdBQUcsTUFBZTtBQUFBLEVBQzlELElBQUksT0FBTztBQUFBLElBQVM7QUFBQSxFQUNwQixJQUFJLE1BQU07QUFBQSxJQUFXLE1BQU0sY0FBYztBQUFBLEVBQ3pDLE1BQU0sTUFBTSxFQUFFLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxFQUFFO0FBQUEsRUFDcEQsT0FBTztBQUFBLEVBQ1AsTUFBTSxVQUFVLE1BQU0sT0FBTyxJQUFJLE1BQU0sTUFBTSxVQUFVO0FBQUEsSUFDckQsUUFBUSxDQUFDLElBQUksUUFBUSxNQUFNO0FBQUEsTUFDekIsSUFBSSxDQUFDLE1BQU07QUFBQSxRQUFLO0FBQUEsTUFDaEIsTUFBTSxJQUFJLE9BQU8sTUFBTTtBQUFBLE1BQ3ZCLElBQUk7QUFBQSxRQUFNLE1BQU0sSUFBSSxLQUFLLE1BQU07QUFBQSxNQUMvQixPQUFPO0FBQUEsTUFDUCxJQUFJLFdBQVc7QUFBQSxRQUFXLFNBQVMsY0FBYyxlQUFlLE1BQU0sR0FBRyxlQUFlLEVBQUUsT0FBTyxVQUFVLENBQUM7QUFBQTtBQUFBLEVBRWhILEdBQUcsTUFBTSxJQUFJO0FBQUEsRUFDYixJQUFJLFFBQVEsTUFBTTtBQUFBLElBQ2hCLEtBQUssVUFBVTtBQUFBLElBQ2YsTUFBWSxTQUFTLE1BQU0sS0FBSztBQUFBLEVBQ2xDO0FBQUEsRUFDQSxPQUFPO0FBQUEsRUFDUCxJQUFJLFFBQVE7QUFBQSxJQUFJLE1BQU0sb0JBQW9CLFFBQVEsS0FBSyxNQUFNLFFBQVEsQ0FBQyxNQUFNLElBQUk7QUFBQSxFQUMzRTtBQUFBLFVBQU0sS0FBSyxRQUFRLFNBQVMsT0FBTztBQUFBO0FBR25DLFNBQVMsUUFBUSxHQUFHO0FBQUEsRUFDekIsT0FBTyxLQUFLO0FBQUE7OztBQzFWZCxJQUFNLFFBQVEsT0FBTyxLQUFLLFNBQVM7QUFFNUIsU0FBUyxVQUFVLENBQUMsTUFBeUI7QUFBQSxFQUNsRCxNQUFNLE1BQU0sTUFBTSxXQUFXLFdBQVcsS0FBSyxLQUFLLE1BQU0sWUFBWTtBQUFBLEVBQ3BFLE1BQU0sV0FBVyxNQUFNLGFBQWEsQ0FBQztBQUFBLEVBQ3JDLE1BQU0sVUFBWSxPQUFPO0FBQUEsRUFDekIsTUFBTSxNQUFNLE1BQU0sS0FBSyxXQUFXLEtBQUssS0FBSyxNQUFNLE1BQU07QUFBQSxFQUV4RCxNQUFNLE1BQU0sQ0FBdUIsR0FBTSxNQUFlO0FBQUEsSUFDdEQsS0FBSyxLQUFLO0FBQUEsSUFDUixTQUFTLElBQUk7QUFBQTtBQUFBLEVBR2pCLE9BQU8sRUFDTCxPQUNBLEVBQUUsT0FBTyxPQUFPLEdBQ2hCLEVBQ0UsVUFDQSxFQUFFLE9BQU8sTUFBTSxHQUNmLEVBQUUsVUFBVSxFQUFFLE9BQU8sZ0JBQWdCLFNBQVMsT0FBUSxNQUFNLE9BQU8sV0FBYyxPQUFPLEdBQUcsR0FBRyxVQUFVLEdBQ3hHLEVBQ0UsT0FDQSxFQUFFLE9BQU8sTUFBTSxHQUNmLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLGlCQUFpQixTQUFTLE1BQVEsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLEdBQUcsR0FBRyxHQUNoRyxFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsT0FBTyx3QkFBd0IsU0FBUyxNQUFRLGdCQUFnQixJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQzFHLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLGdDQUFnQyxTQUFTLE1BQVEsZUFBZSxJQUFJLEVBQUUsR0FBRyxJQUFJLEdBQ2pILEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLFlBQVksU0FBUyxNQUFRLGNBQWMsSUFBSSxFQUFFLEdBQUcsR0FBRyxHQUMzRixFQUFFLFVBQVUsRUFBRSxPQUFPLGVBQWUsT0FBTyxnQkFBZ0IsU0FBUyxNQUFRLFlBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxFQUFFLEdBQUcsY0FBSSxDQUM1RyxDQUNGLEdBQ0EsRUFDRSxRQUNBLEVBQUUsT0FBTyxVQUFVLGVBQWUsU0FBUyxHQUMzQyxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE9BQU8sS0FBSztBQUFBLElBQ1osVUFBVTtBQUFBLElBQ1YsYUFBYTtBQUFBLElBQ2IsU0FBUyxDQUFDLE1BQWEsSUFBSSxRQUFTLEVBQUUsT0FBNEIsS0FBSztBQUFBLEVBQ3pFLENBQUMsR0FDRCxFQUNFLE9BQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsRUFDRSxTQUNBLE1BQ0EsRUFBRSxRQUFRLE1BQU0sU0FBUyxHQUN6QixFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLE9BQU8sS0FBSyxVQUFVO0FBQUEsSUFDdEIsYUFBYTtBQUFBLElBQ2IsVUFBVTtBQUFBLElBQ1YsU0FBUyxDQUFDLE1BQWEsSUFBSSxVQUFXLEVBQUUsT0FBNEIsTUFBTSxLQUFLLEtBQUssU0FBUztBQUFBLEVBQy9GLENBQUMsR0FDRCxFQUFFLFlBQVksRUFBRSxJQUFJLFVBQVUsR0FBSyxXQUFXLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQ3ZGLEdBQ0EsRUFBRSxTQUFTLE1BQU0sRUFBRSxRQUFRLE1BQU0sV0FBVyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQ2hFLEdBQ0EsRUFBRSxZQUFZO0FBQUEsSUFDWixPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixhQUFhO0FBQUEsSUFDYixVQUFVO0FBQUEsSUFDVixPQUFPLEtBQUssZUFBZTtBQUFBLElBQzNCLFNBQVMsQ0FBQyxNQUFhLElBQUksZUFBZ0IsRUFBRSxPQUErQixTQUFTLFNBQVM7QUFBQSxFQUNoRyxDQUFDLEdBR0QsRUFDRSxPQUNBLEVBQUUsT0FBTyxVQUFVLEdBQ25CLE1BQ0k7QUFBQSxJQUNFLEVBQUUsVUFBVSxFQUFFLE9BQU8sY0FBYyxTQUFTLE1BQVEsY0FBYyxFQUFFLEdBQUcsWUFBWTtBQUFBLElBQ25GLEVBQUUsVUFBVSxFQUFFLE9BQU8sT0FBTyxTQUFTLE1BQVEsZUFBZSxDQUFDLElBQUksTUFBTSxFQUFFLEdBQUcsSUFBSSxTQUFTLGVBQWUsV0FBVztBQUFBLEVBQ3JILElBQ0E7QUFBQSxJQUNFLEVBQ0UsVUFDQSxFQUFFLE9BQU8sV0FBVyxVQUFVLFdBQVcsVUFBVSxPQUFPLHlEQUF5RCxTQUFTLE1BQVEsZUFBZSxNQUFNLFFBQVEsRUFBRSxHQUNuSyxVQUNGO0FBQUEsSUFDQSxFQUNFLFVBQ0E7QUFBQSxNQUNFLE9BQU87QUFBQSxNQUNQLFVBQVUsV0FBVztBQUFBLE1BQ3JCLE9BQU87QUFBQSxNQUNQLFNBQVMsTUFBUSxlQUFlLE1BQU0sT0FBTztBQUFBLElBQy9DLEdBQ0EsV0FDRjtBQUFBLEVBQ0YsR0FDSixVQUNJLEVBQUUsVUFBVSxFQUFFLE9BQU8sY0FBYyxTQUFXLFNBQVMsR0FBRyxTQUFTLElBQ25FLEVBQUUsVUFBVSxFQUFFLE9BQU8sZUFBZSxVQUFVLENBQUMsS0FBSyxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssU0FBUyxNQUFRLEtBQUssSUFBSSxFQUFFLEdBQUcsY0FBYyxDQUM5SCxHQUNBLE9BQ0UsRUFDRSxPQUNBLEVBQUUsT0FBTyxhQUFhLElBQUksU0FBUyxXQUFXLElBQUksTUFBTSxHQUN4RCxJQUFJLFNBQ0Esd0JBQ0EsSUFBSSxTQUFTLFdBQ1gsb0ZBQ0EseUZBQ1IsR0FDRixZQUFZLEVBQUUsT0FBTyxFQUFFLE9BQU8sZ0JBQWdCLEdBQUcsOEJBQThCLEdBQy9FLE1BQU0sV0FBVyxFQUFFLE9BQU8sRUFBRSxPQUFPLGVBQWUsR0FBRyxvQ0FBb0MsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLFNBQVcsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUM1SixDQUFDLFdBQVcsS0FBSyxXQUFXLFdBQVcsSUFBSSxHQUUzQyxnQkFBZ0IsSUFBSSxHQUdwQixFQUNFLE1BQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFlBQVksQ0FBQyxNQUFpQixFQUFFLGVBQWU7QUFBQSxJQUMvQyxRQUFRLENBQUMsTUFBaUI7QUFBQSxNQUN4QixFQUFFLGVBQWU7QUFBQSxNQUNqQixJQUFJLE1BQU07QUFBQSxRQUFVLFNBQVMsTUFBTSxNQUFNLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFekQsR0FDQSxLQUFLLE1BQU0sSUFBSSxDQUFDLEdBQUcsTUFBTSxRQUFRLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUNuRCxHQUNBLEtBQUssTUFBTSxXQUFXLEtBQUssQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sY0FBYyxHQUFHLDZCQUE2QixFQUFFLEtBQUssTUFBTSxRQUFRLEdBQUcsd0JBQXdCLEdBQ2pKLFlBQVksSUFBSSxDQUNsQixDQUNGO0FBQUE7QUFHRixTQUFTLFVBQVUsQ0FBQyxNQUFZO0FBQUEsRUFDOUIsTUFBTSxJQUFJLEtBQUs7QUFBQSxFQUNmLE1BQU0sTUFBTSxFQUFFLGVBQWUsS0FBSyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLFlBQVksSUFBSSxJQUFJO0FBQUEsRUFDeEYsT0FBTyxFQUNMLE9BQ0EsRUFBRSxPQUFPLGNBQWMsRUFBRSxLQUFLLE9BQU8sT0FBTyxHQUM1QyxFQUFFLEtBQUssWUFBWSxFQUFFLEtBQUssTUFBTSxRQUFRLENBQUMsT0FBTyxVQUFVLE1BQU0sZUFBZSxRQUFRLE9BQU8sRUFBRSxTQUNoRyxFQUFFLFFBQVEsRUFBRSxPQUFPLFFBQVEsR0FBRyxRQUFRLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FDckQ7QUFBQTtBQUdGLFNBQVMsU0FBUyxDQUFDLE1BQVk7QUFBQSxFQUM3QixPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sYUFBYSxHQUN0QixLQUFLLEtBQUssSUFBSSxDQUFDLE1BQ2IsRUFDRSxRQUNBLEVBQUUsT0FBTyxPQUFPLEdBQ2hCLE1BQU0sR0FDTixFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLFNBQVMsTUFBTTtBQUFBLE1BQ2IsS0FBSyxPQUFPLEtBQUssS0FBSyxPQUFPLENBQUMsTUFBTSxNQUFNLENBQUM7QUFBQSxNQUNwQyxRQUFRLElBQUk7QUFBQTtBQUFBLEVBRXZCLEdBQ0EsR0FDRixDQUNGLENBQ0YsR0FDQSxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLGFBQWEsS0FBSyxLQUFLLFNBQVMsTUFBTTtBQUFBLElBQ3RDLE1BQU07QUFBQSxJQUNOLFVBQVU7QUFBQSxJQUNWLFdBQVcsQ0FBQyxNQUFxQjtBQUFBLE1BQy9CLE1BQU0sUUFBUSxFQUFFO0FBQUEsTUFDaEIsS0FBSyxFQUFFLFFBQVEsV0FBVyxFQUFFLFFBQVEsUUFBUSxNQUFNLE1BQU0sS0FBSyxHQUFHO0FBQUEsUUFDOUQsRUFBRSxlQUFlO0FBQUEsUUFDakIsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLLEVBQUUsUUFBUSxNQUFNLEVBQUUsRUFBRSxRQUFRLE1BQU0sRUFBRTtBQUFBLFFBQy9ELElBQUksS0FBSyxDQUFDLEtBQUssS0FBSyxTQUFTLENBQUM7QUFBQSxVQUFHLEtBQUssS0FBSyxLQUFLLENBQUM7QUFBQSxRQUNqRCxNQUFNLFFBQVE7QUFBQSxRQUNQLFFBQVEsSUFBSTtBQUFBLE1BQ3JCLEVBQU8sU0FBSSxFQUFFLFFBQVEsZUFBZSxDQUFDLE1BQU0sU0FBUyxLQUFLLEtBQUssUUFBUTtBQUFBLFFBQ3BFLEtBQUssS0FBSyxJQUFJO0FBQUEsUUFDUCxRQUFRLElBQUk7QUFBQSxNQUNyQjtBQUFBO0FBQUEsRUFFSixDQUFDLEdBQ0QsRUFBRSxZQUFZLEVBQUUsSUFBSSxXQUFXLEdBQUssUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUNyRjtBQUFBO0FBR0YsSUFBSTtBQUVKLFNBQVMsZUFBZSxDQUFDLE1BQVk7QUFBQSxFQUNuQyxNQUFNLFVBQVUsT0FBTyxRQUFRLEtBQUssYUFBYSxDQUFDLENBQUM7QUFBQSxFQUNuRCxNQUFNLFFBQVEsQ0FBQyxVQUE4QjtBQUFBLElBQzNDLEtBQUssWUFBWSxPQUFPLFlBQVksTUFBTSxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQUE7QUFBQSxFQUVyRSxPQUFPLEVBQ0wsV0FDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsTUFBTSxZQUFZLFFBQVEsU0FBUztBQUFBLElBQ25DLFVBQVUsQ0FBQyxNQUFjLFdBQVksRUFBRSxPQUE4QjtBQUFBLEVBQ3ZFLEdBQ0EsRUFBRSxXQUFXLE1BQU0sYUFBYSxRQUFRLFNBQVMsS0FBSyxFQUFFLFFBQVEsRUFBRSxPQUFPLFFBQVEsR0FBRyxPQUFPLFFBQVEsTUFBTSxDQUFDLENBQUMsR0FDM0csRUFDRSxLQUNBLEVBQUUsT0FBTyxjQUFjLEdBQ3ZCLFFBQ0EsRUFBRSxRQUFRLE1BQU0sWUFBWSxHQUM1QixxQ0FDQSxhQUFhLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJLE9BQU8sSUFBSSxFQUFFLFFBQVEsTUFBTSxLQUFLLEtBQUssQ0FBQyxDQUFDLENBQ3pFLEdBQ0EsUUFBUSxJQUFJLEVBQUUsR0FBRyxJQUFJLE1BQ25CLEVBQ0UsT0FDQSxFQUFFLE9BQU8sVUFBVSxHQUNuQixFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLGFBQWE7QUFBQSxJQUNiLFVBQVUsU0FBUztBQUFBLElBQ25CLFVBQVUsQ0FBQyxNQUFhO0FBQUEsTUFDdEIsTUFBTSxRQUFRLE9BQU8sUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUMzQyxNQUFNLEtBQUssQ0FBRSxFQUFFLE9BQTRCLE1BQU0sS0FBSyxHQUFHLENBQUM7QUFBQSxNQUMxRCxNQUFNLEtBQUs7QUFBQSxNQUNKLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFdkIsQ0FBQyxHQUNELEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsYUFBYTtBQUFBLElBQ2IsVUFBVSxTQUFTO0FBQUEsSUFDbkIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixLQUFLLFVBQVUsS0FBTSxFQUFFLE9BQTRCO0FBQUEsTUFDakQsU0FBUyxJQUFJO0FBQUE7QUFBQSxFQUVuQixDQUFDLEdBQ0QsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxTQUFTLE1BQU07QUFBQSxNQUNiLE9BQU8sS0FBSyxVQUFVO0FBQUEsTUFDZixRQUFRLElBQUk7QUFBQTtBQUFBLEVBRXZCLEdBQ0EsR0FDRixDQUNGLENBQ0YsR0FDQSxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFNBQVMsTUFBTTtBQUFBLE1BQ2IsSUFBSSxJQUFJO0FBQUEsTUFDUixPQUFPLE1BQU0sT0FBTyxLQUFLO0FBQUEsUUFBVztBQUFBLE1BQ3BDLEtBQUssVUFBVSxNQUFNLE9BQU87QUFBQSxNQUNyQixRQUFRLElBQUk7QUFBQTtBQUFBLEVBRXZCLEdBQ0EsWUFDRixDQUNGO0FBQUE7QUFHRixTQUFTLFlBQVksQ0FBQyxHQUFpQjtBQUFBLEVBQ3JDLElBQUksRUFBRSxTQUFTLFFBQVEsRUFBRSxVQUFVO0FBQUEsSUFBSSxPQUFPO0FBQUEsRUFDOUMsSUFBSSxFQUFFO0FBQUEsSUFBUSxPQUFPO0FBQUEsRUFDckIsSUFBSSxFQUFFLFNBQVM7QUFBQSxJQUFTLE9BQU8sRUFBRSxVQUFVLFVBQVUsY0FBYztBQUFBLEVBQ25FLElBQUksRUFBRSxTQUFTO0FBQUEsSUFBVSxPQUFPLEVBQUUsY0FBYyxFQUFFO0FBQUEsRUFDbEQsSUFBSSxFQUFFLFNBQVM7QUFBQSxJQUFRLE9BQU8sR0FBRyxFQUFFO0FBQUEsRUFDbkMsT0FBTyxFQUFFO0FBQUE7QUFHWCxTQUFTLE9BQU8sQ0FBQyxNQUFZLEdBQVMsR0FBVyxLQUF1QjtBQUFBLEVBQ3RFLE1BQU0sT0FBTyxVQUFVLEVBQUU7QUFBQSxFQUN6QixNQUFNLE9BQU8sTUFBTSxTQUFTLElBQUksRUFBRSxFQUFFO0FBQUEsRUFDcEMsTUFBTSxTQUFTLEtBQUssT0FBTyxFQUFFO0FBQUEsRUFDN0IsTUFBTSxPQUFPLEtBQUssS0FBSyxFQUFFO0FBQUEsRUFDekIsTUFBTSxRQUNKLEVBQUUsU0FBUyxhQUFhLEVBQUUsU0FBUyxFQUFFLFNBQVMsUUFBUSxFQUFFLFNBQVMsVUFBVSxFQUFFLFNBQVMsVUFBVSxFQUFFLFNBQVMsU0FBUyxLQUFLLEVBQUUsU0FBUyxFQUFFLFlBQVk7QUFBQSxFQUNwSixNQUFNLE1BQU0sRUFBRSxTQUFTLGNBQWMsRUFBRSxTQUFTLFVBQVUsS0FBSyxhQUFhLENBQUM7QUFBQSxFQUU3RSxNQUFNLFNBQVMsTUFBTTtBQUFBLElBQ25CLE9BQU8sTUFBTSxTQUFTLE9BQU8sRUFBRSxFQUFFLElBQUksTUFBTSxTQUFTLElBQUksRUFBRSxFQUFFO0FBQUEsSUFDMUQsT0FBTztBQUFBO0FBQUEsRUFHWCxNQUFNLEtBQUssRUFDVCxNQUNBO0FBQUEsSUFDRSxPQUFPLFVBQVUsRUFBRSxPQUFPLE9BQU8sVUFBVSxLQUFLLEVBQUUsVUFBVSxLQUFLLGNBQWMsU0FBUyxTQUFTLFNBQVMsS0FBSyxNQUFNLFdBQVcsRUFBRSxLQUFLLGNBQWM7QUFBQSxJQUNySixhQUFhLEVBQUU7QUFBQSxJQUNmLGFBQWEsQ0FBQyxNQUFpQjtBQUFBLE1BQzdCLE1BQU0sU0FBUyxFQUFFO0FBQUEsTUFDakIsRUFBRSxhQUFjLGdCQUFnQjtBQUFBLE1BQ2hDLEVBQUUsYUFBYyxRQUFRLGNBQWMsRUFBRSxFQUFFO0FBQUE7QUFBQSxJQUU1QyxXQUFXLE1BQU07QUFBQSxNQUNmLE1BQU0sU0FBUztBQUFBLE1BQ2YsR0FBRyxZQUFZO0FBQUEsTUFDYixPQUFPO0FBQUE7QUFBQSxJQUVYLFlBQVksQ0FBQyxNQUFpQjtBQUFBLE1BQzVCLElBQUksQ0FBQyxNQUFNLFVBQVUsTUFBTSxXQUFXLEVBQUU7QUFBQSxRQUFJO0FBQUEsTUFDNUMsRUFBRSxlQUFlO0FBQUEsTUFDakIsTUFBTSxJQUFJLEdBQUcsc0JBQXNCO0FBQUEsTUFDbkMsR0FBRyxVQUFVLE9BQU8sZUFBZSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQUEsTUFDbkUsR0FBRyxVQUFVLE9BQU8sY0FBYyxFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQUE7QUFBQSxJQUVyRSxhQUFhLE1BQU0sR0FBRyxVQUFVLE9BQU8sZUFBZSxZQUFZO0FBQUEsSUFDbEUsUUFBUSxDQUFDLE1BQWlCO0FBQUEsTUFDeEIsRUFBRSxlQUFlO0FBQUEsTUFDakIsRUFBRSxnQkFBZ0I7QUFBQSxNQUNsQixJQUFJLENBQUMsTUFBTSxVQUFVLE1BQU0sV0FBVyxFQUFFO0FBQUEsUUFBSTtBQUFBLE1BQzVDLE1BQU0sUUFBUSxHQUFHLFVBQVUsU0FBUyxZQUFZO0FBQUEsTUFDaEQsTUFBTSxPQUFPLFFBQVEsS0FBSyxNQUFNLElBQUksSUFBSSxNQUFNLE9BQU8sRUFBRTtBQUFBLE1BQ3JELFNBQVMsTUFBTSxNQUFNLFFBQVEsU0FBUyxNQUFNLFNBQVMsRUFBRSxLQUFLLElBQUk7QUFBQTtBQUFBLEVBRXRFLEdBQ0EsRUFDRSxPQUNBLEVBQUUsT0FBTyxTQUFTLEdBQ2xCLEVBQ0UsUUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsYUFBYSxNQUFPLEdBQUcsWUFBWTtBQUFBLElBQ25DLFdBQVcsTUFBTyxHQUFHLFlBQVk7QUFBQSxFQUNuQyxHQUNBLElBQ0YsR0FDQSxFQUFFLFFBQVEsRUFBRSxPQUFPLE1BQU0sR0FBRyxPQUFPLElBQUksQ0FBQyxDQUFDLEdBQ3pDLEVBQUUsUUFBUSxFQUFFLE9BQU8sU0FBUyxPQUFPLEtBQUssTUFBTSxHQUFHLEtBQUssSUFBSSxHQUMxRCxFQUNFLFVBQ0EsRUFBRSxPQUFPLGNBQWMsU0FBUyxPQUFPLEdBQ3ZDLEVBQUUsS0FBSyxNQUFNLEtBQUssS0FBSyxHQUN2QixTQUFTLEVBQUUsUUFBUSxFQUFFLE9BQU8sTUFBTSxHQUFHLEtBQUssR0FDMUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxVQUFVLEVBQUUsUUFBUSxFQUFFLE9BQU8sYUFBYSxPQUFPLHVCQUF1QixFQUFFLE1BQU0sSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sU0FBUyxJQUFJLFdBQVcsRUFBRSxNQUFNLFdBQVcsUUFBUSxHQUM1TCxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sTUFBTSxHQUFHLEdBQUcsQ0FDeEMsR0FDQSxFQUFFLFFBQVEsRUFBRSxPQUFPLFVBQVUsT0FBTyxRQUFRLFVBQVUsR0FBRyxHQUFHLFdBQVcsTUFBTSxDQUFDLENBQ2hGLEdBQ0EsV0FBVyxXQUFXLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxXQUFXLEdBQUcsSUFBSSxHQUNsRSxRQUFRLFlBQVksTUFBTSxHQUFHLENBQUMsQ0FDaEM7QUFBQSxFQUNBLE9BQU87QUFBQTtBQUdULFNBQVMsVUFBVSxDQUFDLElBQWE7QUFBQSxFQUMvQixRQUFRO0FBQUEsU0FDRDtBQUFBLE1BQ0gsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLE9BQU8sQ0FBQztBQUFBLFNBQy9CO0FBQUEsTUFDSCxPQUFPO0FBQUEsU0FDSjtBQUFBLE1BQ0gsT0FBTztBQUFBLFNBQ0o7QUFBQSxNQUNILE9BQU87QUFBQTtBQUFBLE1BRVAsT0FBTztBQUFBO0FBQUE7QUFJYixTQUFTLFdBQVcsQ0FBQyxNQUFZLEdBQVMsR0FBVztBQUFBLEVBQ25ELE1BQU0sT0FBTyxVQUFVLEVBQUU7QUFBQSxFQUN6QixNQUFNLE9BQU8sTUFBUSxTQUFTLElBQUk7QUFBQSxFQUNsQyxNQUFNLFFBQVEsQ0FBQyxVQUFrQixZQUFpRCxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLFFBQVEsTUFBTSxLQUFLLEdBQUcsR0FBRyxPQUFPO0FBQUEsRUFDbkosTUFBTSxhQUFhLEtBQUssZUFBZSxFQUFFLFNBQVM7QUFBQSxFQUVsRCxPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sWUFBWSxHQUNyQixNQUNFLFFBQ0EsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3RCLEVBQUUsT0FBUSxFQUFFLE9BQTZCO0FBQUEsTUFDbEMsUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUV2QixHQUNBLE1BQU0sSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxHQUFHLFVBQVUsTUFBTSxFQUFFLEtBQUssR0FBRyxHQUFHLFVBQVUsR0FBRyxTQUFTLFVBQVUsR0FBRyxPQUFPLENBQUMsQ0FDbkgsQ0FDRixHQUNBLGNBQ0UsTUFDRSxFQUFFLFNBQVMsVUFBVSx3QkFBd0IsWUFDN0MsRUFDRSxPQUNBLEVBQUUsT0FBTyxZQUFZLEdBQ3JCLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsT0FBTyxFQUFFLFlBQVk7QUFBQSxJQUNyQixhQUFhO0FBQUEsSUFDYixVQUFVLE9BQU8sRUFBRTtBQUFBLElBQ25CLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDckIsRUFBRSxXQUFZLEVBQUUsT0FBNEIsU0FBUztBQUFBLE1BQ3JELEtBQUs7QUFBQTtBQUFBLEVBRVQsQ0FBQyxHQUNELEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLHdCQUF3QixVQUFVLENBQUMsQ0FBQyxNQUFNLFNBQVMsU0FBUyxNQUFRLFFBQVEsTUFBTSxDQUFDLEVBQUUsR0FBRyxjQUFJLEdBQ2hJLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLHlCQUF5QixVQUFVLENBQUMsRUFBRSxVQUFVLFNBQVMsTUFBUSxjQUFjLENBQUMsRUFBRSxHQUFHLGNBQUksQ0FDL0gsQ0FDRixHQUNGLGNBQWMsV0FBVyxNQUFNLEdBQUcsS0FBSyxHQUN2QyxjQUNFLENBQUMsQ0FBQyxFQUFFLFdBQVcsVUFDZixFQUNFLFdBQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsRUFBRSxXQUFXLE1BQU0sR0FBRyxFQUFFLFVBQVUsb0NBQW9DLEdBQ3RFLEVBQUUsWUFBWTtBQUFBLElBQ1osT0FBTztBQUFBLElBQ1AsTUFBTSxLQUFLLElBQUksR0FBRyxFQUFFLFVBQVUsTUFBTTtBQUFBLElBQ3BDLFVBQVUsTUFBTSxFQUFFO0FBQUEsSUFDbEIsT0FBTyxFQUFFLFVBQVUsS0FBSztBQUFBLENBQUk7QUFBQSxJQUM1QixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLEVBQUUsWUFBYSxFQUFFLE9BQStCLE1BQU0sTUFBTTtBQUFBLENBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLE9BQU8sT0FBTztBQUFBLE1BQ3JHLEtBQUs7QUFBQTtBQUFBLEVBRVQsQ0FBQyxDQUNILEdBQ0YsY0FDRSxNQUNFLFVBQ0EsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxPQUFPLEVBQUUsU0FBUztBQUFBLElBQ2xCLGFBQWE7QUFBQSxJQUNiLFVBQVUsT0FBTyxFQUFFO0FBQUEsSUFDbkIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixFQUFFLFFBQVMsRUFBRSxPQUE0QixTQUFTO0FBQUEsTUFDbEQsS0FBSztBQUFBO0FBQUEsRUFFVCxDQUFDLENBQ0gsR0FDRixFQUFFLFNBQVMsV0FBVyxFQUFFLFNBQVMsYUFBYSxXQUFXLE1BQU0sR0FBRyxLQUFLLEdBQ3ZFLEVBQ0UsT0FDQSxFQUFFLE9BQU8sVUFBVSxHQUNuQixFQUFFLFNBQVMsY0FDVCxFQUFFLFNBQVMsVUFDWCxNQUNFLGdCQUNBLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sS0FBSztBQUFBLElBQ0wsTUFBTTtBQUFBLElBQ04sYUFBYSxPQUFPLE1BQU0sU0FBUyxPQUFPO0FBQUEsSUFDMUMsT0FBTyxFQUFFLFdBQVc7QUFBQSxJQUNwQixVQUFVLE1BQU0sRUFBRTtBQUFBLElBQ2xCLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDckIsTUFBTSxJQUFLLEVBQUUsT0FBNEI7QUFBQSxNQUN6QyxFQUFFLFVBQVUsT0FBTyxTQUFTLENBQUMsSUFBSSxJQUFJO0FBQUEsTUFDckMsS0FBSztBQUFBO0FBQUEsRUFFVCxDQUFDLENBQ0gsR0FDRixNQUNFLFFBQ0EsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxPQUFPLEVBQUUsUUFBUTtBQUFBLElBQ2pCLFVBQVUsUUFBUSxFQUFFO0FBQUEsSUFDcEIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixFQUFFLE9BQVEsRUFBRSxPQUE0QixTQUFTO0FBQUEsTUFDakQsS0FBSztBQUFBO0FBQUEsRUFFVCxDQUFDLENBQ0gsQ0FDRixHQUNBLEVBQ0UsT0FDQSxFQUFFLE9BQU8sZ0JBQWdCLEdBQ3pCLEVBQ0UsU0FDQSxFQUFFLE9BQU8sU0FBUyxHQUNsQixFQUFFLFNBQVM7QUFBQSxJQUNULE1BQU07QUFBQSxJQUNOLFNBQVMsRUFBRTtBQUFBLElBQ1gsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUN0QixFQUFFLFVBQVcsRUFBRSxPQUE0QjtBQUFBLE1BQ3BDLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFdkIsQ0FBQyxHQUNELFFBQ0YsR0FDQSxFQUFFLFFBQVEsRUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUMzQixFQUFFLFVBQVUsRUFBRSxPQUFPLGdCQUFnQixPQUFPLDJCQUEyQixVQUFZLE9BQU8sU0FBUyxTQUFTLE1BQVEsS0FBSyxNQUFNLEdBQUcsQ0FBQyxFQUFFLEdBQUcsYUFBYSxHQUNySixFQUFFLFVBQVUsRUFBRSxPQUFPLGdCQUFnQixPQUFPLDhCQUE4QixVQUFZLE9BQU8sU0FBUyxTQUFTLE1BQVEsS0FBSyxNQUFNLENBQUMsRUFBRSxHQUFHLGNBQWMsR0FDdEosRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8saUJBQWlCLFNBQVMsTUFBUSxjQUFjLE1BQU0sQ0FBQyxFQUFFLEdBQUcsR0FBRyxHQUNuRyxFQUFFLFVBQVUsRUFBRSxPQUFPLGVBQWUsT0FBTyxlQUFlLFNBQVMsTUFBUSxXQUFXLE1BQU0sQ0FBQyxFQUFFLEdBQUcsY0FBSSxDQUN4RyxDQUNGO0FBQUE7QUFHRixJQUFNLFlBQVk7QUFFbEIsU0FBUyxVQUFVLENBQUMsTUFBWSxHQUFTLE9BQThFO0FBQUEsRUFDckgsT0FBTyxNQUNMLFVBQ0EsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxRQUFRLEVBQUUsU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxTQUFTO0FBQUEsSUFDNUQsYUFBYTtBQUFBLElBQ2IsVUFBVSxTQUFTLEVBQUU7QUFBQSxJQUNyQixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLE1BQU0sUUFBUyxFQUFFLE9BQTRCLE1BQU0sTUFBTSxJQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsRUFBRSxPQUFPLE9BQU87QUFBQSxNQUVsRyxFQUFFLFFBQVEsTUFBTSxTQUFTLE1BQU0sSUFBSSxDQUFDLEtBQUssTUFBTyxFQUFFLFFBQVEsSUFBSSxhQUFhLE1BQU0sRUFBRSxNQUFNLEtBQU0sRUFBRSxVQUFVLElBQUksQ0FBRSxJQUFJO0FBQUEsTUFDbkgsU0FBUyxJQUFJO0FBQUE7QUFBQSxFQUVuQixDQUFDLEdBQ0QsQ0FBQyxDQUFDLEVBQUUsT0FBTyxVQUFVLEVBQUUsU0FBUyxFQUFFLE9BQU8sUUFBUSxHQUFHLDREQUE0RCxDQUNsSDtBQUFBO0FBR0YsU0FBUyxVQUFVLENBQUMsTUFBWSxHQUFTLE9BQThFO0FBQUEsRUFDckgsTUFBTSxPQUFPLFVBQVUsRUFBRTtBQUFBLEVBQ3pCLE1BQU0sUUFBUSxDQUFDLE1BQWE7QUFBQSxJQUMxQixFQUFFLFFBQVMsRUFBRSxPQUE0QjtBQUFBLElBQ3ZDLFNBQVMsSUFBSTtBQUFBO0FBQUEsRUFFakIsSUFBSSxFQUFFLFNBQVMsU0FBUztBQUFBLElBQ3RCLE9BQU8sTUFDTCxVQUNBLEVBQ0UsVUFDQTtBQUFBLE1BQ0UsT0FBTztBQUFBLE1BQ1AsVUFBVSxDQUFDLE1BQWE7QUFBQSxRQUN0QixFQUFFLFFBQVMsRUFBRSxPQUE2QjtBQUFBLFFBQ25DLFFBQVEsSUFBSTtBQUFBO0FBQUEsSUFFdkIsR0FDQSxFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsVUFBVSxFQUFFLFVBQVUsUUFBUSxHQUFHLFdBQVcsR0FDekUsRUFBRSxVQUFVLEVBQUUsT0FBTyxTQUFTLFVBQVUsRUFBRSxVQUFVLFFBQVEsR0FBRyxjQUFjLENBQy9FLENBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQSxNQUFNLFNBQTRDLEVBQUUsVUFBVSxPQUFPLE1BQU0sU0FBUyxRQUFRLGtCQUFrQixPQUFPLFNBQVMsTUFBTSxnQkFBZ0IsWUFBWSxpQkFBaUI7QUFBQSxFQUNqTCxNQUFNLFFBQVEsRUFBRSxTQUFTO0FBQUEsSUFDdkIsT0FBTyxjQUFjLEVBQUUsU0FBUyxhQUFhLFVBQVU7QUFBQSxJQUN2RCxNQUFNLEVBQUUsU0FBUyxhQUFhLEVBQUUsU0FBUyxTQUFTLFdBQVc7QUFBQSxJQUM3RCxPQUFPLEVBQUUsU0FBUztBQUFBLElBQ2xCLGFBQWEsS0FBSyxhQUFhO0FBQUEsSUFDL0IsTUFBTSxFQUFFLFNBQVMsVUFBVSxTQUFTO0FBQUEsSUFDcEMsVUFBVSxPQUFPLEVBQUU7QUFBQSxJQUNuQixTQUFTO0FBQUEsRUFDWCxDQUFDO0FBQUEsRUFDRCxPQUFPLE1BQ0wsT0FBTyxFQUFFLFNBQVMsU0FDbEIsRUFDRSxPQUNBLEVBQUUsT0FBTyxZQUFZLEdBQ3JCLEVBQUUsU0FBUyxTQUFTLEVBQUUsWUFBWSxFQUFFLE9BQU8saUJBQWlCLE1BQU0sR0FBRyxPQUFPLEVBQUUsU0FBUyxJQUFJLFVBQVUsT0FBTyxFQUFFLE1BQU0sYUFBYSxLQUFLLFdBQVcsU0FBUyxPQUFPLE9BQU8sRUFBRSxTQUFTLGdDQUFnQyxVQUFVLENBQUMsSUFBSSxPQUNsTyxFQUFFLFNBQVMsVUFDVCxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLE9BQU8sRUFBRSxTQUFTLGtDQUFrQztBQUFBLElBQ3BELFNBQVMsTUFBTTtBQUFBLE1BQ2IsRUFBRSxTQUFTLENBQUMsRUFBRSxVQUFVO0FBQUEsTUFDakIsUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUV2QixHQUNBLEVBQUUsU0FBUyxpQkFBTyxjQUNwQixDQUNKLEdBQ0EsRUFBRSxTQUFTLFlBQVksQ0FBQyxDQUFDLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsR0FBRyxtQkFBbUIsRUFBRSxhQUFhLEdBQzFHLEVBQUUsU0FBUyxXQUFXLEVBQUUsWUFBWSxFQUFFLElBQUksT0FBTyxHQUFHLENBQUMsU0FBUyxPQUFPLFVBQVUsYUFBYSxXQUFXLGFBQWEsR0FBRyxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUNoSztBQUFBO0FBR0YsU0FBUyxXQUFXLENBQUMsTUFBWTtBQUFBLEVBQy9CLE9BQU8sRUFDTCxXQUNBLEVBQUUsT0FBTyxnQkFBZ0IsR0FDekIsRUFBRSxXQUFXLEVBQUUsT0FBTyxlQUFlLEdBQUcsZUFBZSxHQUN2RCxFQUNFLE9BQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsTUFBTSxJQUFJLENBQUMsTUFDVCxFQUNFLFVBQ0E7QUFBQSxJQUNFLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDcEIsRUFBRSxPQUF1QixRQUFRLFNBQVMsRUFBRyxPQUFPO0FBQUEsTUFDckQsTUFBTSxPQUFTLFFBQVEsTUFBTSxDQUFDO0FBQUEsTUFDOUIsV0FBVyxNQUFNLFNBQVMsY0FBYyxlQUFlLEtBQUssTUFBTSxHQUFHLGVBQWUsRUFBRSxPQUFPLFVBQVUsVUFBVSxTQUFTLENBQUMsR0FBRyxFQUFFO0FBQUE7QUFBQSxFQUVwSSxHQUNBLEdBQUcsVUFBVSxHQUFHLFNBQVMsVUFBVSxHQUFHLE9BQ3hDLENBQ0YsQ0FDRixDQUNGO0FBQUE7OztBQ2htQkssU0FBUyxXQUFXLEdBQWdCO0FBQUEsRUFDekMsTUFBTSxRQUFVLGNBQWM7QUFBQSxFQUM5QixNQUFNLFVBQVksV0FBVztBQUFBLEVBQzdCLE1BQU0sT0FBUyxRQUFRO0FBQUEsRUFDdkIsTUFBTSxNQUFNLENBQUMsR0FBRyxNQUFNLFFBQVEsRUFBRSxPQUFPLENBQUMsT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQztBQUFBLEVBRW5GLE1BQU0sU0FBUyxJQUFJO0FBQUEsRUFDbkIsV0FBVyxLQUFLLE9BQU87QUFBQSxJQUNyQixNQUFNLElBQUksRUFBRSxVQUFVO0FBQUEsSUFDdEIsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDO0FBQUEsTUFBRyxPQUFPLElBQUksR0FBRyxDQUFDLENBQUM7QUFBQSxJQUNwQyxPQUFPLElBQUksQ0FBQyxFQUFHLEtBQUssQ0FBQztBQUFBLEVBQ3ZCO0FBQUEsRUFDQSxNQUFNLFlBQVksQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTyxNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFFO0FBQUEsRUFFdkcsT0FBTyxFQUNMLE9BQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsRUFDRSxVQUNBLEVBQUUsT0FBTyxNQUFNLEdBQ2YsRUFBRSxPQUFPLEVBQUUsT0FBTyxRQUFRLEdBQUcsRUFBRSxRQUFRLEVBQUUsT0FBTyxPQUFPLENBQUMsR0FBRyxRQUFRLEdBQ25FLEVBQ0UsT0FDQSxFQUFFLE9BQU8sTUFBTSxHQUNmLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLFlBQVksU0FBUyxXQUFXLEdBQUcsR0FBRyxHQUMxRSxFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxNQUFRLFlBQVksTUFBTSxLQUFLLEVBQUUsR0FBRyxHQUFHLEdBQ3JHLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLFdBQVcsU0FBUyxPQUFRLE1BQU0sT0FBTyxZQUFlLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FDOUcsQ0FDRixHQUNBLEVBQ0UsT0FDQSxFQUFFLE9BQU8sVUFBVSxHQUNuQixFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLGFBQWE7QUFBQSxJQUNiLE9BQU8sTUFBTSxPQUFPO0FBQUEsSUFDcEIsVUFBVTtBQUFBLElBQ1YsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixNQUFNLE9BQU8sSUFBSyxFQUFFLE9BQTRCO0FBQUEsTUFDOUMsT0FBTztBQUFBO0FBQUEsRUFFYixDQUFDLEdBQ0QsRUFBRSxVQUFVLEVBQUUsT0FBTyxlQUFlLFNBQVcsV0FBVyxHQUFHLFNBQVMsQ0FDeEUsSUFDQyxRQUFRLFNBQVMsS0FBSyxLQUFLLFNBQVMsTUFDbkMsRUFDRSxPQUNBLEVBQUUsT0FBTyxVQUFVLEdBQ25CLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUN0QixNQUFNLE9BQU8sU0FBVSxFQUFFLE9BQTZCO0FBQUEsTUFDcEQsT0FBTztBQUFBO0FBQUEsRUFFYixHQUNBLEVBQUUsVUFBVSxFQUFFLE9BQU8sSUFBSSxVQUFVLE1BQU0sT0FBTyxXQUFXLEdBQUcsR0FBRyxvQkFBb0IsR0FDckYsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLFVBQVUsTUFBTSxPQUFPLFdBQVcsU0FBUyxHQUFHLGFBQWEsR0FDMUYsUUFBUSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEdBQUcsVUFBVSxNQUFNLE9BQU8sV0FBVyxFQUFFLEdBQUcsa0JBQVEsQ0FBQyxDQUFDLENBQzlGLEdBQ0EsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3RCLE1BQU0sT0FBTyxPQUFRLEVBQUUsT0FBNkI7QUFBQSxNQUNsRCxPQUFPO0FBQUE7QUFBQSxFQUViLEdBQ0EsRUFBRSxVQUFVLEVBQUUsT0FBTyxXQUFXLFVBQVUsTUFBTSxPQUFPLFNBQVMsVUFBVSxHQUFHLFdBQVcsR0FDeEYsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLFVBQVUsTUFBTSxPQUFPLFNBQVMsT0FBTyxHQUFHLFFBQVEsR0FDL0UsRUFBRSxVQUFVLEVBQUUsT0FBTyxXQUFXLFVBQVUsTUFBTSxPQUFPLFNBQVMsVUFBVSxHQUFHLGtCQUFrQixDQUNqRyxHQUNBLEtBQUssU0FBUyxLQUNaLEVBQ0UsT0FDQSxFQUFFLE9BQU8sUUFBUSxHQUNqQixLQUFLLElBQUksQ0FBQyxNQUNSLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTyxVQUFVLE1BQU0sT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLFFBQVE7QUFBQSxJQUNwRCxTQUFTLE1BQU07QUFBQSxNQUNiLE1BQU0sT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLE1BQU0sT0FBTyxLQUFLLE9BQU8sQ0FBQyxJQUFJLE1BQU0sT0FBTyxLQUFLLElBQUksQ0FBQztBQUFBLE1BQzlFLE9BQU87QUFBQTtBQUFBLEVBRWIsR0FDQSxNQUFNLENBQ1IsQ0FDRixDQUNGLENBQ0osR0FDRixJQUFJLFNBQVMsS0FDWCxFQUNFLE9BQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsRUFBRSxRQUFRLE1BQU0sR0FBRyxJQUFJLHdCQUF3QixHQUMvQyxFQUFFLFVBQVUsRUFBRSxPQUFPLFVBQVUsU0FBUyxNQUFRLFlBQVksTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNLElBQUksU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEVBQUUsR0FBRyxVQUFVLEdBQ3hILEVBQUUsVUFBVSxFQUFFLE9BQU8sVUFBVSxTQUFTLE1BQVEsU0FBUyxHQUFHLEVBQUUsR0FBRyxPQUFPLEdBQ3hFLEVBQUUsVUFBVSxFQUFFLE9BQU8sVUFBVSxTQUFTLE1BQVEsUUFBUSxHQUFHLEVBQUUsR0FBRyxXQUFXLEdBQzNFLEVBQUUsVUFBVSxFQUFFLE9BQU8saUJBQWlCLFNBQVMsTUFBUSxZQUFZLEdBQUcsRUFBRSxHQUFHLFFBQVEsR0FDbkYsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sb0JBQW9CLFNBQVMsT0FBTyxNQUFNLFNBQVMsTUFBTSxHQUFLLE9BQU8sR0FBRyxHQUFHLEdBQUcsQ0FDcEgsR0FDRixFQUNFLFFBQ0EsRUFBRSxPQUFPLFVBQVUsZUFBZSxVQUFVLEdBQzVDLE1BQU0sTUFBTSxXQUFXLElBQ25CLFdBQVcsSUFDWCxNQUFNLFdBQVcsSUFDZixFQUFFLEtBQUssRUFBRSxPQUFPLGNBQWMsR0FBRyxzQ0FBc0MsSUFDdkUsVUFBVSxJQUFJLENBQUMsTUFBTSxZQUFZLEdBQUcsT0FBTyxJQUFJLENBQUMsR0FBSSxVQUFVLFNBQVMsS0FBSyxNQUFNLEVBQUUsQ0FBQyxDQUM3RixDQUNGO0FBQUE7QUFHRixTQUFTLFdBQVcsQ0FBQyxNQUFjLE9BQWUsWUFBcUI7QUFBQSxFQUNyRSxNQUFNLE1BQU0sUUFBUTtBQUFBLEVBQ3BCLE1BQU0sWUFBWSxNQUFNLGlCQUFpQixJQUFJLEdBQUc7QUFBQSxFQUNoRCxPQUFPLEVBQ0wsV0FDQSxFQUFFLE9BQU8sUUFBUSxHQUNqQixjQUNFLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsU0FBUyxNQUFNO0FBQUEsTUFDYixZQUFZLE1BQU0saUJBQWlCLE9BQU8sR0FBRyxJQUFJLE1BQU0saUJBQWlCLElBQUksR0FBRztBQUFBLE1BQzdFLE9BQU87QUFBQTtBQUFBLEVBRWIsR0FDQSxFQUFFLFFBQVEsRUFBRSxPQUFPLFdBQVcsWUFBWSxLQUFLLFNBQVMsR0FBRyxHQUFHLEdBQzlELE9BQU8sa0JBQVEsT0FBTyxlQUN0QixFQUFFLFFBQVEsRUFBRSxPQUFPLFFBQVEsR0FBRyxPQUFPLE1BQU0sTUFBTSxDQUFDLENBQ3BELEdBQ0YsQ0FBQyxhQUFhLE1BQU0sSUFBSSxRQUFRLENBQ2xDO0FBQUE7QUFHRixTQUFTLFFBQVEsQ0FBQyxHQUFTO0FBQUEsRUFDekIsTUFBTSxPQUFPLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsU0FBUyxVQUFVLEdBQUcsS0FBSztBQUFBLEVBQ3JFLE1BQU0sVUFBWSxPQUFPLFdBQVcsTUFBTSxLQUFLLFdBQVcsRUFBRTtBQUFBLEVBQzVELE9BQU8sRUFDTCxXQUNBLEVBQUUsT0FBTyxVQUFVLE1BQU0sU0FBUyxJQUFJLEVBQUUsRUFBRSxJQUFJLGNBQWMsSUFBSSxHQUNoRSxFQUFFLFNBQVM7QUFBQSxJQUNULE1BQU07QUFBQSxJQUNOLE9BQU87QUFBQSxJQUNQLFNBQVMsTUFBTSxTQUFTLElBQUksRUFBRSxFQUFFO0FBQUEsSUFDaEMsT0FBTztBQUFBLElBQ1AsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUNyQixFQUFFLE9BQTRCLFVBQVUsTUFBTSxTQUFTLElBQUksRUFBRSxFQUFFLElBQUksTUFBTSxTQUFTLE9BQU8sRUFBRSxFQUFFO0FBQUEsTUFDNUYsT0FBTztBQUFBO0FBQUEsRUFFYixDQUFDLEdBQ0QsRUFDRSxPQUNBLEVBQUUsT0FBTyxhQUFhLFNBQVMsTUFBUSxTQUFTLEVBQUUsRUFBRSxFQUFFLEdBQ3RELEVBQUUsT0FBTyxFQUFFLE9BQU8sYUFBYSxHQUFHLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxPQUFPLFVBQVUsRUFBRSxRQUFRLEtBQUssT0FBTyxRQUFRLE9BQU8sWUFBWSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUMxSSxFQUNFLE9BQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsR0FBRyxFQUFFLE1BQU0sY0FBYyxFQUFFLE1BQU0sV0FBVyxJQUFJLEtBQUssT0FDckQsUUFBUSxNQUFNLFFBQ2QsTUFBTSxRQUFRLEVBQUUsU0FBUyxHQUMzQixHQUNBLEVBQUUsS0FBSyxTQUFTLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxRQUFRLEdBQUcsRUFBRSxLQUFLLElBQUksQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLE9BQU8sY0FBYyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FDbkgsR0FDQSxFQUNFLE9BQ0EsRUFBRSxPQUFPLGVBQWUsR0FDeEIsRUFDRSxVQUNBLEVBQUUsT0FBTyxhQUFhLE9BQU8sbUNBQW1DLFVBQVksT0FBTyxTQUFTLFNBQVMsTUFBUSxLQUFLLENBQUMsRUFBRSxHQUNySCxVQUFVLE1BQU0sR0FDbEIsR0FDQSxFQUNFLFdBQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsRUFBRSxXQUFXLEVBQUUsT0FBTyxRQUFRLE9BQU8sTUFBTSxHQUFHLEdBQUcsR0FDakQsRUFDRSxPQUNBLEVBQUUsT0FBTyxZQUFZLEdBQ3JCLEVBQUUsVUFBVSxFQUFFLFNBQVMsTUFBUSxjQUFjLENBQUMsRUFBRSxHQUFHLFlBQVksR0FDL0QsRUFBRSxVQUFVLEVBQUUsU0FBUyxNQUFRLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLGlCQUFpQixHQUNwRSxFQUFFLFVBQVUsRUFBRSxTQUFTLE1BQVEsZ0JBQWdCLENBQUMsRUFBRSxHQUFHLHdCQUF3QixHQUM3RSxFQUFFLFVBQVUsRUFBRSxTQUFTLE1BQVEsZUFBZSxDQUFDLEVBQUUsR0FBRyxnQ0FBZ0MsR0FDcEYsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLFNBQVMsTUFBUSxZQUFZLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxHQUFHLHFCQUFXLENBQ3BGLENBQ0YsQ0FDRixDQUNGO0FBQUE7QUFHRixTQUFTLFdBQVcsQ0FBQyxHQUFTO0FBQUEsRUFDNUIsTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUNaLE9BQU8sRUFBRSxLQUFLLE1BQU0sUUFBUSxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssTUFBTSxRQUFRLENBQUMsUUFBUSxTQUFTLFFBQVEsRUFBRSxFQUFFLE1BQU0sRUFBRTtBQUFBO0FBR3BHLFNBQVMsVUFBVSxHQUFHO0FBQUEsRUFDcEIsT0FBTyxFQUNMLE9BQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsRUFBRSxPQUFPLEVBQUUsT0FBTyxZQUFZLEdBQUcsV0FBVyxHQUM1QyxFQUFFLE1BQU0sTUFBTSx1QkFBdUIsR0FDckMsRUFDRSxNQUNBLEVBQUUsT0FBTyxRQUFRLEdBQ2pCLEVBQUUsTUFBTSxNQUFNLHNEQUFzRCxHQUNwRSxFQUFFLE1BQU0sTUFBTSxVQUFVLEVBQUUsS0FBSyxNQUFNLFFBQVEsR0FBRyxrSEFBa0gsR0FDbEssRUFBRSxNQUFNLE1BQU0sNkJBQTZCLEVBQUUsS0FBSyxNQUFNLFlBQVksR0FBRyxHQUFHLENBQzVFLEdBQ0EsRUFBRSxPQUFPLEVBQUUsT0FBTyxhQUFhLEdBQUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxlQUFlLFNBQVcsV0FBVyxHQUFHLGVBQWUsR0FBRyxFQUFFLFVBQVUsRUFBRSxPQUFPLE9BQU8sU0FBUyxXQUFXLEdBQUcsVUFBVSxDQUFDLENBQ2pMO0FBQUE7QUFHRixlQUFlLFVBQVUsR0FBRztBQUFBLEVBQzFCLE1BQU0sT0FBTyxNQUFNLFNBQVM7QUFBQSxFQUM1QixJQUFJO0FBQUEsSUFBTSxNQUFRLFdBQVcsTUFBTSxLQUFLLEtBQUssQ0FBQztBQUFBOzs7QUMzTnpDLFNBQVMsWUFBWSxHQUFnQjtBQUFBLEVBQzFDLE1BQU0sSUFBSSxNQUFNO0FBQUEsRUFDaEIsTUFBTSxNQUFNLENBQTJCLEdBQU0sTUFBbUI7QUFBQSxJQUM5RCxFQUFFLEtBQUs7QUFBQSxJQUNGLGFBQWEsQ0FBQztBQUFBO0FBQUEsRUFFckIsTUFBTSxNQUFNLENBQUMsR0FBeUMsT0FBZSxTQUNuRSxFQUNFLFNBQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsRUFBRSxRQUFRLE1BQU0sS0FBSyxHQUNyQixFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLEtBQUs7QUFBQSxJQUNMLE1BQU0sTUFBTSxhQUFhLElBQUk7QUFBQSxJQUM3QixPQUFPLEVBQUU7QUFBQSxJQUNULFVBQVUsU0FBUztBQUFBLElBQ25CLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDckIsTUFBTSxJQUFLLEVBQUUsT0FBNEI7QUFBQSxNQUN6QyxJQUFJLE9BQU8sU0FBUyxDQUFDLEtBQUssS0FBSztBQUFBLFFBQUcsSUFBSSxHQUFHLENBQUM7QUFBQTtBQUFBLEVBRTlDLENBQUMsR0FDRCxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsR0FBRyxJQUFJLENBQ3JDO0FBQUEsRUFFRixPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sT0FBTyxHQUNoQixFQUNFLFVBQ0EsRUFBRSxPQUFPLE1BQU0sR0FDZixFQUFFLFVBQVUsRUFBRSxPQUFPLGdCQUFnQixTQUFTLE9BQVEsTUFBTSxPQUFPLFdBQWMsT0FBTyxHQUFHLEdBQUcsVUFBVSxHQUN4RyxFQUFFLEtBQUssTUFBTSxTQUFTLENBQ3hCLEdBQ0EsRUFDRSxRQUNBLEVBQUUsT0FBTyxtQkFBbUIsZUFBZSxXQUFXLEdBQ3RELEVBQUUsTUFBTSxNQUFNLGNBQWMsR0FDNUIsSUFBSSxXQUFXLHlCQUF5Qiw0REFBNEQsR0FDcEcsSUFBSSxhQUFhLDBCQUEwQiwrQ0FBK0MsR0FDMUYsRUFDRSxTQUNBLEVBQUUsT0FBTyxRQUFRLEdBQ2pCLEVBQUUsUUFBUSxNQUFNLG1CQUFtQixHQUNuQyxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFVBQVUsQ0FBQyxNQUFhO0FBQUEsTUFDdEIsSUFBSSxZQUFhLEVBQUUsT0FBNkIsS0FBNkI7QUFBQSxNQUMzRSxPQUFPO0FBQUE7QUFBQSxFQUViLEdBQ0EsRUFBRSxVQUFVLEVBQUUsT0FBTyxXQUFXLFVBQVUsRUFBRSxhQUFhLFVBQVUsR0FBRyxtQkFBbUIsR0FDekYsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLFVBQVUsRUFBRSxhQUFhLE9BQU8sR0FBRywwQkFBMEIsQ0FDNUYsR0FDQSxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsR0FBRyw0RUFBNEUsQ0FDN0csR0FDQSxFQUFFLGFBQWEsVUFBVSxJQUFJLFlBQVksMkJBQTJCLEVBQUUsR0FDdEUsRUFDRSxTQUNBLEVBQUUsT0FBTyxTQUFTLEdBQ2xCLEVBQUUsU0FBUyxFQUFFLE1BQU0sWUFBWSxTQUFTLEVBQUUsV0FBVyxVQUFVLENBQUMsTUFBYSxJQUFJLGFBQWMsRUFBRSxPQUE0QixPQUFPLEVBQUUsQ0FBQyxHQUN2SSx3Q0FDRixHQUNBLEVBQ0UsU0FDQSxFQUFFLE9BQU8sU0FBUyxHQUNsQixFQUFFLFNBQVM7QUFBQSxJQUNULE1BQU07QUFBQSxJQUNOLFNBQVMsRUFBRTtBQUFBLElBQ1gsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUN0QixJQUFJLFlBQWEsRUFBRSxPQUE0QixPQUFPO0FBQUEsTUFDcEQsT0FBTztBQUFBO0FBQUEsRUFFYixDQUFDLEdBQ0QsZ0VBQ0YsR0FDQSxFQUNFLFNBQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsc0lBQ0YsR0FDQSxFQUFFLFlBQ0EsRUFDRSxTQUNBLEVBQUUsT0FBTyxRQUFRLEdBQ2pCLEVBQUUsUUFBUSxNQUFNLDZCQUE2QixHQUM3QyxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLGFBQWE7QUFBQSxJQUNiLE9BQU8sRUFBRTtBQUFBLElBQ1QsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixNQUFNLE1BQU0sRUFBRTtBQUFBLE1BQ2QsSUFBSSxLQUFLO0FBQUEsTUFDVCxJQUFJO0FBQUEsUUFDRixJQUFJLElBQUksTUFBTSxLQUFLO0FBQUEsVUFBRyxTQUFTLGNBQWMsSUFBSSxLQUFLO0FBQUEsUUFDdEQsTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBO0FBQUEsTUFFUCxJQUFJLGtCQUFrQixLQUFLLEtBQUssd0JBQXdCO0FBQUEsTUFDeEQsSUFBSSxlQUFlO0FBQUEsTUFDbkIsSUFBSTtBQUFBLFFBQUksSUFBSSxrQkFBa0IsSUFBSSxLQUFLO0FBQUE7QUFBQSxFQUUzQyxDQUFDLEdBQ0QsRUFBRSxTQUFTLEVBQUUsT0FBTyxRQUFRLEdBQUcsNEhBQTRILENBQzdKLEdBQ0YsRUFDRSxPQUNBLEVBQUUsT0FBTyxNQUFNLEdBQ2YsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxTQUFTLE1BQU07QUFBQSxNQUNiLE1BQU0sV0FBVyxLQUFLLGlCQUFpQjtBQUFBLE1BQ2xDLGFBQWEsTUFBTSxRQUFRO0FBQUEsTUFDOUIsT0FBTztBQUFBLE1BQ1QsTUFBTSx5QkFBeUIsSUFBSTtBQUFBO0FBQUEsRUFFdkMsR0FDQSxhQUNGLENBQ0YsR0FDQSxFQUFFLE1BQU0sTUFBTSxZQUFZLEdBQzFCLEVBQ0UsS0FDQSxFQUFFLE9BQU8sY0FBYyxHQUN2Qix3SEFDQSxFQUFFLFFBQVEsTUFBTSxhQUFhLEdBQzdCLE1BQ0EsRUFBRSxRQUFRLE1BQU0sS0FBSyxHQUNyQixjQUNBLEVBQUUsUUFBUSxNQUFNLE1BQU0sR0FDdEIsTUFDQSxFQUFFLFFBQVEsTUFBTSxTQUFTLEdBQ3pCLE1BQ0EsRUFBRSxRQUFRLE1BQU0sWUFBWSxHQUM1QixNQUNBLEVBQUUsUUFBUSxNQUFNLGFBQWEsR0FDN0IsTUFDQSxFQUFFLFFBQVEsTUFBTSxRQUFRLEdBQ3hCLHVGQUNBLEVBQUUsUUFBUSxNQUFNLGFBQWEsR0FDN0IsaURBQ0YsR0FDQSxFQUFFLE1BQU0sTUFBTSxPQUFPLEdBQ3JCLEVBQUUsS0FBSyxFQUFFLE9BQU8sY0FBYyxHQUFHLEdBQUcsTUFBTSxNQUFNLG9CQUFvQixNQUFNLE1BQU0sT0FBTyxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUUsTUFBTSxRQUFRLENBQUMsc0ZBQXNGLENBQzlNLENBQ0Y7QUFBQTs7O0FDdEpGLElBQU0sTUFBTSxTQUFTLGVBQWUsS0FBSztBQUV6QyxJQUFJLFlBQVk7QUFDaEIsVUFBVSxNQUFNO0FBQUEsRUFFZCxJQUFJO0FBQUEsSUFBVztBQUFBLEVBQ2YsWUFBWTtBQUFBLEVBQ1osZUFBZSxNQUFNO0FBQUEsSUFDbkIsWUFBWTtBQUFBLElBQ1osTUFBTSxPQUFPLFFBQVE7QUFBQSxJQUNyQixJQUFJLE1BQU0sU0FBUyxZQUFZLENBQUM7QUFBQSxNQUFNLE1BQU0sT0FBTztBQUFBLElBQ25ELE1BQU0sT0FBTyxNQUFNLFNBQVMsV0FBVyxXQUFXLElBQUssSUFBSSxNQUFNLFNBQVMsYUFBYSxhQUFhLElBQUksWUFBWTtBQUFBLElBQ3BILE1BQU0sS0FBSyxJQUFJO0FBQUEsR0FDaEI7QUFBQSxDQUNGO0FBRUQsZUFBZSxJQUFJLEdBQUc7QUFBQSxFQUNwQixDQUFDLE1BQU0sT0FBTyxNQUFNLFVBQVUsTUFBTSxTQUFTLElBQUksTUFBTSxRQUFRLElBQUksQ0FBTyxVQUFVLEdBQVMsWUFBWSxHQUFTLGFBQWEsQ0FBQyxDQUFDO0FBQUEsRUFDakksT0FBTztBQUFBLEVBRVAsT0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLFNBQVMsU0FBUztBQUFBLElBQ3RELElBQUksUUFBUTtBQUFBLElBQ1osSUFBSSxXQUFXO0FBQUEsSUFDZixJQUFJLFNBQVMsU0FBUztBQUFBLE1BQ3BCLFlBQVksS0FBSyxlQUFlLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFBQSxRQUN2RCxJQUFVLFVBQVUsQ0FBQyxHQUFHO0FBQUEsVUFDdEIsTUFBTSxLQUFLLEVBQUUsTUFBTSxDQUFDO0FBQUEsVUFDcEIsTUFBTSxJQUFJLE1BQU0sTUFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUFBLFVBQ2xELElBQUksQ0FBQyxVQUFVO0FBQUEsWUFDYixJQUFJLEtBQUs7QUFBQSxjQUFHLE1BQU0sTUFBTSxPQUFPLEdBQUcsQ0FBQztBQUFBLFVBQ3JDLEVBQU8sU0FBSSxLQUFLLEdBQUc7QUFBQSxZQUNqQixhQUFhLFNBQVMsTUFBTSxTQUFTLE1BQU0sTUFBTSxHQUFJLE1BQU07QUFBQSxZQUMzRCxNQUFNLE1BQU0sS0FBSztBQUFBLFVBQ25CLEVBQU87QUFBQSxrQkFBTSxNQUFNLFFBQVEsUUFBUTtBQUFBLFVBQ25DLFFBQVE7QUFBQSxRQUNWLEVBQU8sU0FBSSxNQUFNLFlBQVk7QUFBQSxVQUMzQixNQUFNLFdBQVcsS0FBSyxNQUFNLGFBQWEsU0FBUztBQUFBLFFBQ3BEO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLElBQUksU0FBUyxhQUFtQix5QkFBeUIsU0FBUztBQUFBLE1BQ2hFLE1BQU0sWUFBWSxRQUFjLHVCQUF3QjtBQUFBLE1BQ3hELFFBQVE7QUFBQSxJQUNWO0FBQUEsSUFDQSxJQUFJLENBQUM7QUFBQSxNQUFPO0FBQUEsSUFDWixPQUFPO0FBQUEsSUFFUCxJQUFJLFlBQVksTUFBTSxXQUFXLFdBQVcsTUFBTSxXQUFXO0FBQUEsTUFDM0QsV0FBVyxNQUFNO0FBQUEsUUFDZixNQUFNLEtBQUssU0FBUyxjQUFjLGVBQWU7QUFBQSxRQUNqRCxJQUFJLFNBQVMsRUFBRSxLQUFLLEdBQUcsY0FBYyxVQUFVLFNBQVMsQ0FBQztBQUFBLFNBQ3hELEVBQUU7QUFBQSxJQUNQO0FBQUEsR0FDRDtBQUFBO0FBSUgsU0FBUyxpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFBQSxFQUN4QyxXQUFXLEtBQUssU0FBUyxpQkFBcUMsb0JBQW9CLEdBQUc7QUFBQSxJQUNuRixJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsTUFBYztBQUFBLE1BQUcsRUFBRSxPQUFPO0FBQUEsRUFDOUM7QUFBQSxDQUNEO0FBR0QsU0FBUyxpQkFBaUIsWUFBWSxDQUFDLE1BQU07QUFBQSxFQUMzQyxJQUFJLEVBQUUsY0FBYyxNQUFNLFNBQVMsT0FBTyxHQUFHO0FBQUEsSUFDM0MsRUFBRSxlQUFlO0FBQUEsSUFDakIsU0FBUyxLQUFLLFVBQVUsSUFBSSxVQUFVO0FBQUEsRUFDeEM7QUFBQSxDQUNEO0FBQ0QsU0FBUyxpQkFBaUIsYUFBYSxDQUFDLE1BQU07QUFBQSxFQUM1QyxJQUFJLENBQUMsRUFBRTtBQUFBLElBQWUsU0FBUyxLQUFLLFVBQVUsT0FBTyxVQUFVO0FBQUEsQ0FDaEU7QUFDRCxTQUFTLGlCQUFpQixRQUFRLE9BQU8sTUFBTTtBQUFBLEVBQzdDLE1BQU0sT0FBTyxFQUFFLGNBQWMsUUFBUTtBQUFBLEVBQ3JDLFNBQVMsS0FBSyxVQUFVLE9BQU8sVUFBVTtBQUFBLEVBQ3pDLElBQUksQ0FBQztBQUFBLElBQU07QUFBQSxFQUNYLEVBQUUsZUFBZTtBQUFBLEVBQ2pCLE1BQU0sV0FBVyxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQUEsQ0FDbkM7QUFFSSxLQUFLOyIsCiAgImRlYnVnSWQiOiAiREVBRDZDODU5MUYxNkFBNjY0NzU2RTIxNjQ3NTZFMjEiLAogICJuYW1lcyI6IFtdCn0=
