// src/shared/types.ts
var DEFAULT_SETTINGS = {
  timeout: 8000,
  stepDelay: 250,
  typeMode: "instant",
  keyDelay: 25,
  highlight: true,
  autoWait: true,
  loaderSelector: ""
};
var STEP_META = {
  navigate: { label: "Ir a", icon: "↗", needsTarget: false, valueHint: "https://…" },
  click: { label: "Click", icon: "◉", needsTarget: true },
  fill: { label: "Escribir", icon: "⌨", needsTarget: true, valueHint: "texto o {{variable}}" },
  select: { label: "Seleccionar", icon: "☰", needsTarget: true, valueHint: "value de la opción" },
  check: { label: "Marcar", icon: "☑", needsTarget: true, valueHint: "true / false" },
  press: { label: "Tecla", icon: "⏎", needsTarget: false, valueHint: "Enter, Tab, Escape…" },
  wait: { label: "Esperar", icon: "⏱", needsTarget: false, valueHint: "milisegundos" },
  waitFor: { label: "Esperar a", icon: "⌛", needsTarget: true },
  assertText: { label: "Comprobar", icon: "✓", needsTarget: true, valueHint: "texto esperado" }
};

// src/shared/util.ts
var uid = () => crypto.randomUUID().slice(0, 8) + Date.now().toString(36).slice(-4);
function looksGenerated(s) {
  return s.length > 40 || /\d{4,}/.test(s) || /[-_:]\d+[-_:]\d+$/.test(s) || /^[a-f0-9-]{10,}$/i.test(s) || /^:r[0-9a-z]+:?$/.test(s) || /^(ember|ext-gen|react-|mui-|radix-|headlessui-|downshift-|rc-|el-id-|v-\d|input-\d)/i.test(s) || /[_-][a-zA-Z0-9]{5,}$/.test(s) && /\d.*\d/.test(s.slice(-6)) || /^(css|sc|jsx|emotion|svelte)-[a-z0-9]+$/i.test(s);
}
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function builtin(name) {
  switch (name) {
    case "$timestamp":
      return String(Date.now());
    case "$uuid":
      return crypto.randomUUID();
    case "$randomInt":
      return String(Math.floor(Math.random() * 1e6));
    case "$randomEmail":
      return `test+${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}@example.com`;
    case "$today":
      return new Date().toISOString().slice(0, 10);
  }
  return;
}
function interpolate(text, vars) {
  return text.replace(/\{\{\s*([$\w.-]+)\s*\}\}/g, (m, name) => vars[name] ?? builtin(name) ?? m);
}
var BUILTIN_VARS = ["$timestamp", "$uuid", "$randomEmail", "$randomInt", "$today"];

// src/shared/store.ts
var FLOW_PREFIX = "flow:";
var SETTINGS_KEY = "settings";
var RECORDING_KEY = "recording";
async function listFlows() {
  const all = await chrome.storage.local.get(null);
  return Object.entries(all).filter(([k]) => k.startsWith(FLOW_PREFIX)).map(([, v]) => v).sort((a, b) => b.updatedAt - a.updatedAt);
}
async function saveFlow(flow, touch = true) {
  if (touch)
    flow.updatedAt = Date.now();
  await chrome.storage.local.set({ [FLOW_PREFIX + flow.id]: flow });
  return flow;
}
async function deleteFlows(ids) {
  await chrome.storage.local.remove(ids.map((id) => FLOW_PREFIX + id));
}
function newFlow(partial = {}) {
  const now = Date.now();
  return {
    id: uid(),
    name: "Nuevo flujo",
    tags: [],
    variables: {},
    steps: [],
    createdAt: now,
    updatedAt: now,
    ...partial
  };
}
function newStep(partial) {
  return { id: uid(), enabled: true, ...partial };
}
async function getSettings() {
  const s = (await chrome.storage.local.get(SETTINGS_KEY))[SETTINGS_KEY];
  return { ...DEFAULT_SETTINGS, ...s ?? {} };
}
async function saveSettings(s) {
  await chrome.storage.local.set({ [SETTINGS_KEY]: s });
}
async function getRecording() {
  return (await chrome.storage.session.get(RECORDING_KEY))[RECORDING_KEY];
}
var isFlowKey = (k) => k.startsWith(FLOW_PREFIX);
var RECORDING_STORAGE_KEY = RECORDING_KEY;

// src/shared/devtools.ts
function isDevToolsRecording(data) {
  if (!data || typeof data !== "object" || !Array.isArray(data.steps))
    return false;
  const steps = data.steps;
  return "title" in data && steps.some((s) => s && (s.type === "setViewport" || Array.isArray(s.selectors) || s.type === "navigate" && ("url" in s)));
}
function mapSelectors(raw, isInput) {
  const stable = [];
  const named = [];
  const positional = [];
  const xpath = [];
  let name;
  for (const entry of raw ?? []) {
    const parts = Array.isArray(entry) ? entry : [entry];
    if (parts.length !== 1)
      continue;
    const s = parts[0];
    if (hasGeneratedId(s))
      continue;
    if (s.startsWith("aria/")) {
      const n = s.slice(5).replace(/\[role="[^"]*"\]$/, "");
      name ??= n.replace(/\s*\*$/, "");
      if (isInput)
        named.push(`label=${n.replace(/\s*\*$/, "")}`);
      else
        named.push(`text=${n}`, `[aria-label=${JSON.stringify(n)}]`);
    } else if (s.startsWith("text/")) {
      name ??= s.slice(5);
      named.push(`text=${s.slice(5)}`);
    } else if (s.startsWith("xpath/"))
      xpath.push(`xpath=${s.slice(6)}`);
    else {
      const css = s.startsWith("pierce/") ? s.slice(7) : s;
      (/^#[\w-]+$|^[\w-]*\[[^\]]+\]$/.test(css) ? stable : positional).push(css);
    }
  }
  return { selectors: [...new Set([...stable, ...named, ...positional, ...xpath])].slice(0, 6), name };
}
function hasGeneratedId(sel) {
  const ids = [...sel.matchAll(/#((?:\\.|[\w-])+)/g), ...sel.matchAll(/@id=["']([^"']+)["']/g), ...sel.matchAll(/\[id=["']?([^"'\]]+)/g)];
  return ids.some((m) => looksGenerated(m[1].replace(/\\/g, "")));
}
function mapFrame(frame) {
  return frame?.length ? frame.map((i) => ({ selector: `frame=${i}` })) : undefined;
}
function fromDevTools(rec) {
  const steps = [];
  const skipped = [];
  for (const s of rec.steps) {
    if (s.target && s.target !== "main") {
      skipped.push(`${s.type} (en otra ventana)`);
      continue;
    }
    const isInput = s.type === "change";
    const mapped = mapSelectors(s.selectors, isInput);
    const [selector, ...fallbacks] = mapped.selectors;
    const target = { selector, fallbacks, frame: mapFrame(s.frame), timeout: s.timeout };
    const label = mapped.name ?? selector;
    switch (s.type) {
      case "setViewport":
      case "keyUp":
        break;
      case "navigate":
        steps.push(newStep({ type: "navigate", value: s.url }));
        break;
      case "click":
      case "doubleClick":
        if (!selector)
          skipped.push(s.type + " sin selector usable");
        else
          steps.push(newStep({ type: "click", ...target, label, note: s.type === "doubleClick" ? "doble click en DevTools" : undefined }));
        break;
      case "change": {
        if (!selector) {
          skipped.push("change sin selector usable");
          break;
        }
        const prev = steps.at(-1);
        if (prev?.type === "click" && prev.selector === selector && JSON.stringify(prev.frame) === JSON.stringify(target.frame))
          steps.pop();
        steps.push(newStep({ type: "fill", ...target, label, value: s.value ?? "" }));
        break;
      }
      case "keyDown":
        steps.push(newStep({ type: "press", value: s.key ?? "Enter" }));
        break;
      case "waitForElement":
        if (selector)
          steps.push(newStep({ type: "waitFor", ...target, label }));
        break;
      default:
        skipped.push(s.type);
    }
  }
  const flow = newFlow({ name: rec.title || "Grabación de DevTools", tags: ["devtools"], steps });
  return { flow, skipped };
}
function toDTSelector(sel) {
  if (sel.startsWith("text="))
    return `text/${sel.slice(5)}`;
  if (sel.startsWith("label="))
    return `aria/${sel.slice(6)}`;
  if (sel.startsWith("xpath="))
    return `xpath/${sel.slice(6)}`;
  return sel;
}
function toDevTools(flow) {
  const steps = [
    { type: "setViewport", width: 1280, height: 800, deviceScaleFactor: 1, isMobile: false, hasTouch: false, isLandscape: false }
  ];
  let warnings = 0;
  for (const s of flow.steps) {
    if (!s.enabled)
      continue;
    if (s.frame?.length)
      warnings++;
    const selectors = [s.selector, ...s.fallbacks ?? []].filter(Boolean).map((x) => [toDTSelector(x)]);
    const base = { target: "main", selectors, ...s.timeout ? { timeout: s.timeout } : {} };
    switch (s.type) {
      case "navigate":
        steps.push({ type: "navigate", url: s.value ?? "" });
        break;
      case "click":
      case "check":
        steps.push({ type: "click", ...base, offsetX: 1, offsetY: 1 });
        break;
      case "fill":
      case "select":
        steps.push({ type: "change", ...base, value: s.value ?? "" });
        break;
      case "press":
        steps.push({ type: "keyDown", target: "main", key: s.value || "Enter" }, { type: "keyUp", target: "main", key: s.value || "Enter" });
        break;
      case "waitFor":
        steps.push({ type: "waitForElement", ...base });
        break;
      case "assertText":
        steps.push({
          type: "waitForExpression",
          target: "main",
          expression: `(() => { const e = document.querySelector(${JSON.stringify(s.selector ?? "")}); return !!e && (e.value ?? e.innerText).includes(${JSON.stringify(s.value ?? "")}); })()`
        });
        break;
      case "wait":
        steps.push({ type: "waitForExpression", target: "main", expression: `new Promise((r) => setTimeout(() => r(true), ${Number(s.value) || 1000}))` });
        break;
    }
  }
  return { json: { title: flow.name, steps }, warnings };
}

// src/shared/exporters.ts
function toExportFile(flows) {
  return { format: "rastro", version: 1, exportedAt: new Date().toISOString(), flows: flows.map((f) => ({ ...f, lastRun: undefined })) };
}
var STEP_TYPES = ["navigate", "click", "fill", "select", "check", "press", "wait", "waitFor", "assertText"];
function parseImport(text) {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error("El fichero no es JSON válido");
  }
  if (isDevToolsRecording(data)) {
    const { flow, skipped } = fromDevTools(data);
    return { flows: [flow], source: "devtools", skipped };
  }
  return { flows: parseRastro(data), source: "rastro", skipped: [] };
}
function parseRastro(data) {
  const raw = Array.isArray(data) ? data : data && typeof data === "object" && ("flows" in data) && Array.isArray(data.flows) ? data.flows : data && typeof data === "object" && ("steps" in data) ? [data] : [];
  if (!raw.length)
    throw new Error("No se encontraron flujos en el fichero");
  return raw.map((r, i) => {
    const f = r;
    if (!Array.isArray(f.steps))
      throw new Error(`El flujo #${i + 1} no tiene pasos`);
    const steps = f.steps.map((s, j) => {
      if (!s || !STEP_TYPES.includes(s.type))
        throw new Error(`Paso ${j + 1} de «${f.name ?? i + 1}»: tipo desconocido`);
      return { ...s, id: typeof s.id === "string" ? s.id : uid(), enabled: s.enabled !== false };
    });
    return newFlow({
      id: typeof f.id === "string" ? f.id : uid(),
      name: String(f.name ?? `Importado ${i + 1}`),
      description: f.description,
      folder: f.folder,
      tags: Array.isArray(f.tags) ? f.tags.map(String) : [],
      variables: f.variables && typeof f.variables === "object" ? f.variables : {},
      steps,
      createdAt: typeof f.createdAt === "number" ? f.createdAt : Date.now()
    });
  });
}
function ppSelector(sel) {
  if (sel.startsWith("text="))
    return `::-p-text(${JSON.stringify(sel.slice(5))})`;
  if (sel.startsWith("label="))
    return `::-p-aria(${JSON.stringify(sel.slice(6))})`;
  if (sel.startsWith("xpath="))
    return `::-p-xpath(${sel.slice(6)})`;
  return sel;
}
var js = (s) => JSON.stringify(s);
function jsValue(v) {
  if (!/\{\{/.test(v))
    return js(v);
  return "v(" + js(v) + ")";
}
function locator(step, ctx = "page") {
  const sels = [step.selector, ...step.fallbacks ?? []].map(ppSelector);
  if (sels.length === 1)
    return `${ctx}.locator(${js(sels[0])})`;
  return `Locator.race([${sels.map((x) => `${ctx}.locator(${js(x)})`).join(", ")}])`;
}
function frameExpr(step) {
  if (!step.frame?.length)
    return;
  const path = step.frame.map((f) => [f.selector, ...f.fallbacks ?? []].map(ppSelector));
  return `await frameOf(${JSON.stringify(path)})`;
}
function toPuppeteer(flow) {
  const out = [];
  out.push(`// ${flow.name} — exportado desde Rastro el ${new Date().toLocaleString()}`);
  out.push(`// Requiere: npm i puppeteer   ·   Ejecutar: node ${slug(flow.name)}.mjs  (o bun)`);
  out.push(`import puppeteer, { Locator } from "puppeteer";`);
  out.push("");
  out.push(`const T = 8000;`);
  out.push(`const vars = ${JSON.stringify(flow.variables ?? {}, null, 2)};`);
  out.push(`const builtins = {`);
  out.push(`  $timestamp: String(Date.now()),`);
  out.push(`  $uuid: crypto.randomUUID(),`);
  out.push(`  $randomInt: String(Math.floor(Math.random() * 1e6)),`);
  out.push(`  $randomEmail: \`test+\${Date.now().toString(36)}@example.com\`,`);
  out.push(`  $today: new Date().toISOString().slice(0, 10),`);
  out.push(`};`);
  out.push(`const v = (s) => s.replace(/\\{\\{\\s*([$\\w.-]+)\\s*\\}\\}/g, (m, k) => vars[k] != null ? v(vars[k]) : builtins[k] ?? m);`);
  out.push("");
  if (flow.steps.some((st) => st.frame?.length)) {
    out.push(`/** Baja por la ruta de iframes: en cada nivel, el primer selector que aparezca. */`);
    out.push(`async function frameOf(path) {`);
    out.push(`  let f = page.mainFrame();`);
    out.push(`  for (const sels of path) {`);
    out.push(`    const el = await Locator.race(sels.map((s) => f.locator(s))).waitHandle();`);
    out.push(`    f = await el.contentFrame();`);
    out.push(`  }`);
    out.push(`  return f;`);
    out.push(`}`);
    out.push("");
  }
  out.push(`const browser = await puppeteer.launch({ headless: process.env.HEADLESS !== "0" ? "new" : false });`);
  out.push(`const page = await browser.newPage();`);
  out.push(`page.setDefaultTimeout(T);`);
  out.push(`try {`);
  flow.steps.forEach((s, i) => {
    const comment = `  // ${i + 1}. ${s.type}${s.label ? ` · ${s.label}` : ""}`;
    if (!s.enabled) {
      out.push(comment + " (desactivado)");
      return;
    }
    out.push(comment);
    const val = s.value ?? "";
    const fr = frameExpr(s);
    const ctx = fr ? "f" : "page";
    const loc = () => locator(s, ctx);
    if (fr && s.type !== "navigate" && s.type !== "wait")
      out.push(`  {`, `  const f = ${fr};`);
    switch (s.type) {
      case "navigate":
        out.push(`  await page.goto(${jsValue(val)}, { waitUntil: "networkidle2" });`);
        break;
      case "click":
        out.push(`  await Promise.all([`);
        out.push(`    page.waitForNavigation({ timeout: 1500 }).catch(() => {}),`);
        out.push(`    ${loc()}.click(),`);
        out.push(`  ]);`);
        break;
      case "fill":
        out.push(`  await ${loc()}.fill(${jsValue(val)});`);
        break;
      case "select":
        out.push(`  await ${ctx}.select(${js(ppSelector(s.selector))}, ${jsValue(val)});`);
        break;
      case "check":
        out.push(`  {`);
        out.push(`    const el = await ${loc()}.waitHandle();`);
        out.push(`    if ((await el.evaluate((e) => e.checked ?? e.getAttribute("aria-checked") === "true")) !== ${val !== "false"}) await el.click();`);
        out.push(`  }`);
        break;
      case "press":
        if (s.selector)
          out.push(`  await ${loc()}.click();`);
        out.push(`  await Promise.all([`);
        out.push(`    page.waitForNavigation({ timeout: 1500 }).catch(() => {}),`);
        out.push(`    page.keyboard.press(${js(val || "Enter")}),`);
        out.push(`  ]);`);
        break;
      case "wait":
        out.push(`  await new Promise((r) => setTimeout(r, ${Number(val) || 1000}));`);
        break;
      case "waitFor":
        out.push(`  await ${loc()}.wait();`);
        break;
      case "assertText":
        out.push(`  {`);
        out.push(`    const el = await ${loc()}.waitHandle();`);
        out.push(`    const txt = await el.evaluate((e) => e.value ?? e.innerText);`);
        out.push(`    if (!txt.includes(${jsValue(val)})) throw new Error(\`Paso ${i + 1}: se esperaba ${val.replace(/[`$\\]/g, "")} y hay \${txt}\`);`);
        out.push(`  }`);
        break;
    }
    if (fr && s.type !== "navigate" && s.type !== "wait")
      out.push(`  }`);
  });
  out.push(`  console.log("✓ ${flow.name.replace(/"/g, "'")}: OK");`);
  out.push(`} catch (e) {`);
  out.push(`  console.error("✗", e.message);`);
  out.push(`  await page.screenshot({ path: "rastro-error.png" });`);
  out.push(`  process.exitCode = 1;`);
  out.push(`} finally {`);
  out.push(`  await browser.close();`);
  out.push(`}`);
  return out.join(`
`) + `
`;
}
var slug = (s) => s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "flujo";

// src/panel/runner.ts
var PORT_CLOSED = /message port closed|Receiving end does not exist|back\/forward cache|context invalidated/i;
var pinnedTab = Number(new URLSearchParams(location.search).get("tab")) || undefined;
async function activeTab() {
  if (pinnedTab)
    return chrome.tabs.get(pinnedTab);
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id)
    throw new Error("No hay pestaña activa");
  return tab;
}
async function waitForLoad(tabId, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === "complete")
      return;
    await sleep(120);
  }
  throw new Error("La página tardó demasiado en cargar");
}
function watchNavigations(tabId, frameId = 0) {
  let started = false;
  let pending = 0;
  const mine = (d) => d.tabId === tabId && (d.frameId === 0 || d.frameId === frameId);
  const onStart = (d) => {
    if (mine(d))
      started = true, pending++;
  };
  const onEnd = (d) => {
    if (mine(d))
      pending = Math.max(0, pending - 1);
  };
  const nav = chrome.webNavigation;
  nav.onBeforeNavigate.addListener(onStart);
  nav.onCompleted.addListener(onEnd);
  nav.onErrorOccurred.addListener(onEnd);
  return {
    async started(within) {
      const end = Date.now() + within;
      while (!started && Date.now() < end)
        await sleep(50);
      return started;
    },
    async settled(timeout = 30000) {
      const end = Date.now() + timeout;
      while (pending > 0) {
        if (Date.now() > end)
          throw new Error("La página tardó demasiado en cargar");
        await sleep(80);
      }
      await waitForLoad(tabId, timeout);
    },
    dispose() {
      nav.onBeforeNavigate.removeListener(onStart);
      nav.onCompleted.removeListener(onEnd);
      nav.onErrorOccurred.removeListener(onEnd);
    }
  };
}
async function ensureContent(tabId, frameId = 0) {
  for (let i = 0;i < 20; i++) {
    try {
      const r = await chrome.tabs.sendMessage(tabId, { kind: "ping" }, { frameId });
      if (r?.ok)
        return;
    } catch {}
    if (i === 3) {
      try {
        await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["hook.js"], world: "MAIN" }).catch(() => {});
        await chrome.scripting.executeScript({ target: { tabId, frameIds: [frameId] }, files: ["content.js"] });
      } catch (e) {
        throw new Error("No se puede actuar en esta página (" + e.message + ")");
      }
    }
    await sleep(150);
  }
  throw new Error(frameId ? "El iframe no responde" : "El content script no responde en la pestaña");
}
async function sendToTab(tabId, msg, frameId = 0) {
  await ensureContent(tabId, frameId);
  return chrome.tabs.sendMessage(tabId, msg, { frameId });
}
async function frameIdFor(tabId, frame, timeout) {
  let fid = 0;
  for (const [i, ref] of (frame ?? []).entries()) {
    const end = Date.now() + timeout;
    let next;
    while (next == null) {
      const r = await sendToTab(tabId, { kind: "frame:resolve", selectors: [ref.selector, ...ref.fallbacks ?? []], timeout: Math.max(0, end - Date.now()) }, fid);
      if (!r?.token)
        throw new Error(`${r?.error ?? "No se encontró el iframe"} (nivel ${i + 1})`);
      for (let k = 0;k < 8 && next == null; k++) {
        await sleep(60);
        next = (await chrome.runtime.sendMessage({ kind: "frame:probed", token: r.token }))?.frameId;
      }
      if (next == null && Date.now() > end)
        throw new Error(`El iframe «${ref.selector}» no responde (nivel ${i + 1})`);
    }
    fid = next;
  }
  return fid;
}
function runVariables(flow) {
  const base = {};
  for (const b of BUILTIN_VARS)
    base[b] = interpolate(`{{${b}}}`, {});
  const vars = { ...base };
  for (const [k, v] of Object.entries(flow.variables ?? {}))
    vars[k] = interpolate(v, base);
  return vars;
}
function resolveStep(step, vars) {
  return { ...step, value: step.value != null ? interpolate(step.value, vars) : undefined };
}

class Runner {
  stopped = false;
  running = false;
  stop() {
    this.stopped = true;
  }
  async run(flow, settings, hooks, from = 0, only) {
    this.stopped = false;
    this.running = true;
    const t0 = Date.now();
    const vars = runVariables(flow);
    const steps = flow.steps;
    const end = only != null ? only + 1 : steps.length;
    for (let i = 0;i < steps.length; i++)
      if (i >= from && i < end)
        hooks.onStatus(steps[i].id, "pending");
    try {
      const tab = await activeTab();
      const tabId = tab.id;
      for (let i = from;i < end; i++) {
        if (this.stopped)
          throw new Error("Detenido por el usuario");
        const step = steps[i];
        if (!step.enabled) {
          hooks.onStatus(step.id, "skipped");
          continue;
        }
        hooks.onStatus(step.id, "running");
        try {
          await this.exec(tabId, resolveStep(step, vars), settings);
          hooks.onStatus(step.id, "ok");
        } catch (e) {
          const msg = e.message;
          hooks.onStatus(step.id, "error", msg);
          return { at: t0, ok: false, ms: Date.now() - t0, failedStepId: step.id, error: msg };
        }
        if (i < end - 1 && settings.stepDelay)
          await sleep(settings.stepDelay);
      }
      return { at: t0, ok: true, ms: Date.now() - t0 };
    } catch (e) {
      return { at: t0, ok: false, ms: Date.now() - t0, error: e.message };
    } finally {
      this.running = false;
    }
  }
  async exec(tabId, step, settings) {
    switch (step.type) {
      case "navigate": {
        if (!step.value)
          throw new Error("Falta la URL");
        const navs = watchNavigations(tabId);
        try {
          await chrome.tabs.update(tabId, { url: step.value });
          await navs.started(3000);
          await navs.settled();
        } finally {
          navs.dispose();
        }
        return;
      }
      case "wait":
        await sleep(Number(step.value) || 1000);
        return;
    }
    const acts = step.type === "click" || step.type === "press";
    const timeout = step.timeout ?? settings.timeout;
    let res;
    let fid = await frameIdFor(tabId, step.frame, timeout);
    const navs = watchNavigations(tabId, fid);
    try {
      for (let attempt = 0;; attempt++) {
        try {
          res = await sendToTab(tabId, { kind: "run-step", step, settings }, fid);
        } catch (e) {
          if (!PORT_CLOSED.test(e.message))
            throw e;
          await navs.settled();
          if (acts)
            return;
          if (attempt >= 2)
            throw new Error("La página no paró de navegar durante el paso");
          fid = await frameIdFor(tabId, step.frame, timeout);
          continue;
        }
        if (!res)
          throw new Error("Sin respuesta de la página");
        if (!res.ok)
          throw new Error(res.error);
        break;
      }
      if (acts && await navs.started(res.mayNavigate ? 1500 : 150))
        await navs.settled();
    } finally {
      navs.dispose();
    }
  }
}

// src/panel/ui.ts
function h(tag, props, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props ?? {})) {
    if (v == null || v === false)
      continue;
    if (k.startsWith("on") && typeof v === "function")
      el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === "class")
      el.className = String(v);
    else if (k === "value" || k === "checked" || k === "selected" || k === "indeterminate")
      el[k] = v;
    else if (v === true)
      el.setAttribute(k, "");
    else
      el.setAttribute(k, String(v));
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children) {
    if (c == null || c === false)
      continue;
    if (Array.isArray(c))
      append(el, c);
    else
      el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}
function morph(root, next) {
  const active = document.activeElement;
  const key = active?.dataset?.k;
  const sel = key && "selectionStart" in active ? [active.selectionStart, active.selectionEnd] : null;
  const scrollers = [...root.querySelectorAll("[data-scroll]")].map((e) => [e.dataset.scroll, e.scrollTop]);
  root.replaceChildren(next);
  for (const [k, top] of scrollers) {
    const e = root.querySelector(`[data-scroll="${k}"]`);
    if (e)
      e.scrollTop = top;
  }
  if (key) {
    const el = root.querySelector(`[data-k="${CSS.escape(key)}"]`);
    if (el) {
      el.focus({ preventScroll: true });
      if (sel) {
        try {
          el.setSelectionRange(sel[0], sel[1]);
        } catch {}
      }
    }
  }
}
function ask(o) {
  return new Promise((resolve) => {
    const listId = "dl-" + Math.random().toString(36).slice(2);
    const input = o.input != null ? h("input", { class: "input", value: o.input, placeholder: o.placeholder, list: o.options ? listId : null }) : null;
    const dlg = h("dialog", { class: "dialog" }, h("form", { method: "dialog" }, h("h3", null, o.title), o.message && h("p", { class: "muted" }, o.message), input, o.options && h("datalist", { id: listId }, o.options.map((x) => h("option", { value: x }))), h("div", { class: "row end" }, h("button", { class: "btn ghost", value: "__cancel", type: "submit" }, "Cancelar"), o.extra && h("button", { class: "btn", value: "__extra", type: "submit" }, o.extra.label), h("button", { class: "btn " + (o.danger ? "danger" : "primary"), value: "__ok", type: "submit" }, o.ok ?? "Aceptar"))));
    dlg.addEventListener("close", () => {
      const rv = dlg.returnValue;
      dlg.remove();
      if (rv === "__ok")
        resolve(input ? input.value : "ok");
      else if (rv === "__extra")
        resolve(o.extra.value);
      else
        resolve(null);
    });
    document.body.appendChild(dlg);
    dlg.showModal();
    if (input) {
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          e.preventDefault();
          dlg.close("__ok");
        }
      });
      input.focus();
      input.select();
    }
  });
}
var toastTimer;
function toast(text, kind = "info") {
  let el = document.getElementById("toast");
  if (!el) {
    el = h("div", { id: "toast" });
    document.body.appendChild(el);
  }
  el.textContent = text;
  el.className = "show " + kind;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.className = "", kind === "error" ? 5000 : 2500);
}
function download(filename, content, mime = "application/json") {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = h("a", { href: url, download: filename });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
function pickFile(accept = ".json,application/json") {
  return new Promise((resolve) => {
    const input = h("input", { type: "file", accept });
    input.addEventListener("change", () => resolve(input.files?.[0] ?? null));
    input.addEventListener("cancel", () => resolve(null));
    input.click();
  });
}
function timeAgo(ts) {
  const s = Math.round((Date.now() - ts) / 1000);
  if (s < 45)
    return "ahora";
  const m = Math.round(s / 60);
  if (m < 60)
    return `hace ${m} min`;
  const hr = Math.round(m / 60);
  if (hr < 24)
    return `hace ${hr} h`;
  const d = Math.round(hr / 24);
  if (d < 30)
    return `hace ${d} d`;
  return new Date(ts).toLocaleDateString();
}
function hostOf(url) {
  if (!url)
    return "";
  try {
    return new URL(url).host;
  } catch {
    return "";
  }
}
function debounce(fn, ms) {
  let t;
  return (...a) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...a), ms);
  };
}

// src/panel/state.ts
var state = {
  view: "library",
  flows: [],
  currentId: undefined,
  settings: { ...DEFAULT_SETTINGS },
  recording: undefined,
  expanded: new Set,
  selected: new Set,
  filter: { q: "", folder: "", tags: new Set, sort: "updated" },
  collapsedFolders: new Set,
  run: undefined,
  picking: undefined,
  dragId: undefined
};
var renderFn = () => {};
var setRender = (fn) => renderFn = fn;
var render = () => renderFn();
var runner = new Runner;
var current = () => state.flows.find((f) => f.id === state.currentId);
var pendingSaves = new Map;
function saveSoon(flow) {
  let fn = pendingSaves.get(flow.id);
  if (!fn) {
    fn = debounce(() => {
      const f = state.flows.find((x) => x.id === flow.id);
      if (f)
        saveFlow(f);
    }, 300);
    pendingSaves.set(flow.id, fn);
  }
  fn();
}
async function saveNow(flow) {
  await saveFlow(flow);
  render();
}
async function reload() {
  state.flows = await listFlows();
  render();
}
async function createFlow() {
  const name = await ask({ title: "Nuevo flujo", input: "", placeholder: "p. ej. Alta de cliente", ok: "Crear" });
  if (name == null)
    return;
  const folder = state.filter.folder && state.filter.folder !== "__none" ? state.filter.folder : undefined;
  const flow = newFlow({ name: name.trim() || "Nuevo flujo", folder });
  await saveFlow(flow);
  if (!state.flows.some((f) => f.id === flow.id))
    state.flows.unshift(flow);
  openFlow(flow.id);
}
function openFlow(id) {
  state.currentId = id;
  state.view = "editor";
  state.expanded.clear();
  if (state.run?.flowId !== id)
    state.run = undefined;
  render();
  document.querySelector("[data-scroll]")?.scrollTo(0, 0);
}
async function duplicateFlow(flow) {
  const copy = structuredClone(flow);
  copy.id = uid();
  copy.name = flow.name + " (copia)";
  copy.createdAt = Date.now();
  copy.lastRun = undefined;
  copy.steps.forEach((s) => s.id = uid());
  await saveFlow(copy);
  await reload();
  toast("Flujo duplicado", "ok");
}
async function removeFlows(ids) {
  const names = state.flows.filter((f) => ids.includes(f.id)).map((f) => f.name);
  const ok = await ask({
    title: ids.length === 1 ? `¿Borrar «${names[0]}»?` : `¿Borrar ${ids.length} flujos?`,
    message: "No se puede deshacer. Exporta antes si quieres conservarlos.",
    ok: "Borrar",
    danger: true
  });
  if (!ok)
    return;
  await deleteFlows(ids);
  ids.forEach((id) => state.selected.delete(id));
  if (state.currentId && ids.includes(state.currentId))
    state.view = "library";
  await reload();
}
function allFolders() {
  return [...new Set(state.flows.map((f) => f.folder).filter(Boolean))].sort((a, b) => a.localeCompare(b));
}
function allTags() {
  return [...new Set(state.flows.flatMap((f) => f.tags))].sort((a, b) => a.localeCompare(b));
}
function filteredFlows() {
  const { q, folder, tags, sort } = state.filter;
  const tokens = q.toLowerCase().split(/\s+/).filter(Boolean);
  const list = state.flows.filter((f) => {
    if (folder === "__none" ? f.folder : folder && f.folder !== folder)
      return false;
    for (const t of tags)
      if (!f.tags.includes(t))
        return false;
    if (!tokens.length)
      return true;
    const hay = [f.name, f.description, f.folder, ...f.tags.map((t) => "#" + t), ...f.steps.map((s) => `${s.label ?? ""} ${s.type === "navigate" ? s.value : ""}`)].join(" ").toLowerCase();
    return tokens.every((t) => hay.includes(t));
  });
  if (sort === "name")
    list.sort((a, b) => a.name.localeCompare(b.name));
  else if (sort === "lastRun")
    list.sort((a, b) => (b.lastRun?.at ?? 0) - (a.lastRun?.at ?? 0));
  else
    list.sort((a, b) => b.updatedAt - a.updatedAt);
  return list;
}
async function bulkMove(ids) {
  const folder = await ask({ title: "Mover a carpeta", input: "", placeholder: "Nombre de carpeta (vacío = sin carpeta)", options: allFolders(), ok: "Mover" });
  if (folder == null)
    return;
  for (const f of state.flows.filter((x) => ids.includes(x.id))) {
    f.folder = folder.trim() || undefined;
    await saveFlow(f);
  }
  await reload();
}
async function bulkTag(ids) {
  const tag = await ask({ title: "Añadir etiqueta", input: "", placeholder: "etiqueta", options: allTags(), ok: "Añadir" });
  const t = tag?.trim().replace(/^#/, "");
  if (!t)
    return;
  for (const f of state.flows.filter((x) => ids.includes(x.id))) {
    if (!f.tags.includes(t))
      f.tags.push(t);
    await saveFlow(f);
  }
  await reload();
}
var stamp = () => new Date().toISOString().slice(0, 10);
function exportFlows(flows) {
  if (!flows.length)
    return toast("No hay flujos que exportar", "error");
  const name = flows.length === 1 ? `rastro-${slug(flows[0].name)}-${stamp()}.json` : `rastro-${flows.length}-flujos-${stamp()}.json`;
  download(name, JSON.stringify(toExportFile(flows), null, 2));
  toast(`${flows.length} flujo(s) exportado(s)`, "ok");
}
function exportPuppeteer(flow) {
  download(`${slug(flow.name)}.mjs`, toPuppeteer(flow), "text/javascript");
  toast("Script de Puppeteer descargado", "ok");
}
async function importText(text) {
  let flows;
  let result;
  try {
    result = parseImport(text);
    flows = result.flows;
  } catch (e) {
    return toast(e.message, "error");
  }
  const existing = new Set(state.flows.map((f) => f.id));
  const clashes = flows.filter((f) => existing.has(f.id));
  let mode = "copy";
  if (clashes.length) {
    const r = await ask({
      title: `${clashes.length} flujo(s) ya existen`,
      message: clashes.map((f) => f.name).join(", "),
      ok: "Sobrescribir",
      extra: { label: "Importar como copia", value: "copy" }
    });
    if (r == null)
      return;
    mode = r === "copy" ? "copy" : "overwrite";
  }
  for (const f of flows) {
    if (existing.has(f.id) && mode === "copy") {
      f.id = uid();
      f.name += " (importado)";
    }
    await saveFlow(f);
  }
  await reload();
  if (result.source === "devtools") {
    const n = result.skipped.length;
    toast(`Grabación de DevTools importada${n ? ` (${n} paso(s) sin equivalente: ${[...new Set(result.skipped)].join(", ")})` : ""}`, n ? "info" : "ok");
    openFlow(flows[0].id);
  } else
    toast(`${flows.length} flujo(s) importado(s)`, "ok");
}
function exportDevTools(flow) {
  const { json, warnings } = toDevTools(flow);
  download(`${slug(flow.name)}.recorder.json`, JSON.stringify(json, null, 2));
  toast(warnings ? `Exportado. ${warnings} paso(s) en iframes van sin ruta de frame: revísalos en DevTools` : "Exportado: impórtalo en DevTools › Recorder", warnings ? "info" : "ok");
}
function addStep(flow, type, after) {
  const step = newStep({ type, value: type === "press" ? "Enter" : type === "wait" ? "1000" : type === "check" ? "true" : undefined });
  const i = after ? flow.steps.findIndex((s) => s.id === after) : -1;
  if (i >= 0)
    flow.steps.splice(i + 1, 0, step);
  else
    flow.steps.push(step);
  state.expanded.add(step.id);
  saveNow(flow);
  return step;
}
function moveStep(flow, id, beforeId) {
  const from = flow.steps.findIndex((s) => s.id === id);
  if (from < 0)
    return;
  const [s] = flow.steps.splice(from, 1);
  const to = beforeId ? flow.steps.findIndex((x) => x.id === beforeId) : flow.steps.length;
  flow.steps.splice(to < 0 ? flow.steps.length : to, 0, s);
  saveNow(flow);
}
function duplicateStep(flow, step) {
  const i = flow.steps.indexOf(step);
  const copy = { ...structuredClone(step), id: uid() };
  flow.steps.splice(i + 1, 0, copy);
  saveNow(flow);
}
function deleteStep(flow, step) {
  flow.steps = flow.steps.filter((s) => s !== step);
  state.expanded.delete(step.id);
  saveNow(flow);
}
async function pickFor(flow, step) {
  try {
    const tab = await activeTab();
    state.picking = step.id;
    render();
    await sendToTab(tab.id, { kind: "ping" });
    const r = await chrome.tabs.sendMessage(tab.id, { kind: "pick" });
    chrome.tabs.sendMessage(tab.id, { kind: "pick:cancel" }).catch(() => {});
    if (r) {
      step.selector = r.selector;
      step.fallbacks = r.fallbacks;
      step.label = r.label;
      step.frame = r.frame;
      if (step.type === "click" && r.type !== "click") {
        Object.assign(step, { type: r.type, value: r.value, optionText: r.optionText, secret: r.secret });
      }
      await saveNow(flow);
      toast("Elemento actualizado", "ok");
    }
  } catch (e) {
    toast(e.message, "error");
  } finally {
    state.picking = undefined;
    render();
  }
}
async function cancelPick() {
  try {
    const tab = await activeTab();
    await chrome.tabs.sendMessage(tab.id, { kind: "pick:cancel" });
  } catch {}
  state.picking = undefined;
  render();
}
async function highlightStep(step) {
  if (!step.selector)
    return;
  try {
    const tab = await activeTab();
    const fid = await frameIdFor(tab.id, step.frame, 3000);
    const r = await sendToTab(tab.id, { kind: "highlight", selector: step.selector, fallbacks: step.fallbacks }, fid);
    if (!r?.ok)
      toast("No se encuentra en esta página", "error");
  } catch (e) {
    toast(e.message, "error");
  }
}
var bg = (msg) => chrome.runtime.sendMessage(msg);
async function startRecording(flow, mode) {
  try {
    const tab = await activeTab();
    if (!tab.url || !/^(https?|file):/.test(tab.url)) {
      return toast("Abre una página web en la pestaña activa para grabar", "error");
    }
    const r = await bg({ kind: "record:start", flowId: flow.id, tabId: tab.id, mode });
    if (!r.ok)
      toast(r.error ?? "No se pudo empezar a grabar", "error");
  } catch (e) {
    toast(e.message, "error");
  }
}
var stopRecording = () => bg({ kind: "record:stop" });
var pauseRecording = (paused) => bg({ kind: "record:pause", paused });
async function play(flow, from = 0, only) {
  if (runner.running)
    return;
  if (state.recording)
    await stopRecording();
  state.run = { flowId: flow.id, status: {}, info: {} };
  render();
  const summary = await runner.run(flow, state.settings, {
    onStatus(id, status, info) {
      if (!state.run)
        return;
      state.run.status[id] = status;
      if (info)
        state.run.info[id] = info;
      render();
      if (status === "running")
        document.querySelector(`[data-step="${id}"]`)?.scrollIntoView({ block: "nearest" });
    }
  }, from, only);
  if (only == null) {
    flow.lastRun = summary;
    await saveFlow(flow, false);
  }
  render();
  if (summary.ok)
    toast(`✓ Completado en ${(summary.ms / 1000).toFixed(1)}s`, "ok");
  else
    toast(`✗ ${summary.error}`, "error");
}
function stopPlay() {
  runner.stop();
}

// src/panel/views/editor.ts
var TYPES = Object.keys(STEP_META);
function editorView(flow) {
  const rec = state.recording?.flowId === flow.id ? state.recording : undefined;
  const otherRec = state.recording && !rec;
  const running = runner.running;
  const run = state.run?.flowId === flow.id ? state.run : undefined;
  const set = (k, v) => {
    flow[k] = v;
    saveSoon(flow);
  };
  return h("div", { class: "view" }, h("header", { class: "top" }, h("button", { class: "btn ghost sm", onclick: () => (state.view = "library", render()) }, "← Flujos"), h("div", { class: "row" }, h("button", { class: "icon", title: "Exportar JSON", onclick: () => exportFlows([flow]) }, "⇩"), h("button", { class: "icon", title: "Exportar a Puppeteer", onclick: () => exportPuppeteer(flow) }, "JS"), h("button", { class: "icon", title: "Exportar a DevTools Recorder", onclick: () => exportDevTools(flow) }, "DT"), h("button", { class: "icon", title: "Duplicar", onclick: () => duplicateFlow(flow) }, "⧉"), h("button", { class: "icon danger", title: "Borrar flujo", onclick: () => removeFlows([flow.id]) }, "\uD83D\uDDD1"))), h("main", { class: "scroll", "data-scroll": "editor" }, h("input", {
    class: "title-input",
    value: flow.name,
    "data-k": "flow-name",
    placeholder: "Nombre del flujo",
    oninput: (e) => set("name", e.target.value)
  }), h("div", { class: "meta-grid" }, h("label", null, h("span", null, "Carpeta"), h("input", {
    class: "input sm",
    list: "folders",
    value: flow.folder ?? "",
    placeholder: "—",
    "data-k": "flow-folder",
    oninput: (e) => set("folder", e.target.value.trim() || undefined)
  }), h("datalist", { id: "folders" }, allFolders().map((f) => h("option", { value: f })))), h("label", null, h("span", null, "Etiquetas"), tagEditor(flow))), h("textarea", {
    class: "input desc",
    rows: 1,
    placeholder: "Descripción / notas (opcional)",
    "data-k": "flow-desc",
    value: flow.description ?? "",
    oninput: (e) => set("description", e.target.value || undefined)
  }), h("div", { class: "actions" }, rec ? [
    h("button", { class: "btn rec on", onclick: () => stopRecording() }, "■ Terminar"),
    h("button", { class: "btn", onclick: () => pauseRecording(!rec.paused) }, rec.paused ? "▶ Reanudar" : "❚❚ Pausar")
  ] : [
    h("button", { class: "btn rec", disabled: running || otherRec, title: "Usa la página normalmente; todo lo que hagas se graba", onclick: () => startRecording(flow, "record") }, "● Grabar"),
    h("button", {
      class: "btn",
      disabled: running || otherRec,
      title: "Clica elementos para añadirlos sin que los botones hagan nada",
      onclick: () => startRecording(flow, "point")
    }, "◎ Señalar")
  ], running ? h("button", { class: "btn danger", onclick: stopPlay }, "■ Parar") : h("button", { class: "btn primary", disabled: !flow.steps.length || !!rec, onclick: () => play(flow) }, "▶ Reproducir")), rec && h("div", { class: "banner " + (rec.paused ? "paused" : rec.mode) }, rec.paused ? "Grabación en pausa." : rec.mode === "record" ? "Grabando en la pestaña activa. Botones → click, inputs → escribir su contenido." : "Modo señalar: clica elementos de la página. Los botones no se ejecutan. Esc para salir."), otherRec && h("div", { class: "banner paused" }, "Se está grabando otro flujo."), state.picking && h("div", { class: "banner point" }, "Clica un elemento en la página… ", h("button", { class: "btn sm", onclick: cancelPick }, "Cancelar")), !running && flow.lastRun && runSummary(flow), variablesEditor(flow), h("ol", {
    class: "steps",
    ondragover: (e) => e.preventDefault(),
    ondrop: (e) => {
      e.preventDefault();
      if (state.dragId)
        moveStep(flow, state.dragId, null);
    }
  }, flow.steps.map((s, i) => stepRow(flow, s, i, run))), flow.steps.length === 0 && !rec && h("p", { class: "empty muted" }, "Sin pasos todavía. Pulsa ", h("b", null, "Grabar"), " o añade pasos a mano."), addStepMenu(flow)));
}
function runSummary(flow) {
  const r = flow.lastRun;
  const idx = r.failedStepId ? flow.steps.findIndex((s) => s.id === r.failedStepId) + 1 : 0;
  return h("div", { class: "summary " + (r.ok ? "ok" : "err") }, r.ok ? `✓ OK en ${(r.ms / 1000).toFixed(1)}s` : `✗ Falló${idx ? ` en el paso ${idx}` : ""}: ${r.error}`, h("span", { class: "muted" }, " · " + timeAgo(r.at)));
}
function tagEditor(flow) {
  return h("div", { class: "tag-editor" }, flow.tags.map((t) => h("span", { class: "chip" }, "#" + t, h("button", {
    class: "x",
    title: "Quitar",
    onclick: () => {
      flow.tags = flow.tags.filter((x) => x !== t);
      saveNow(flow);
    }
  }, "×"))), h("input", {
    class: "tag-input",
    placeholder: flow.tags.length ? "+" : "añadir…",
    list: "all-tags",
    "data-k": "tag-input",
    onkeydown: (e) => {
      const input = e.target;
      if ((e.key === "Enter" || e.key === ",") && input.value.trim()) {
        e.preventDefault();
        const t = input.value.trim().replace(/^#/, "").replace(/,$/, "");
        if (t && !flow.tags.includes(t))
          flow.tags.push(t);
        input.value = "";
        saveNow(flow);
      } else if (e.key === "Backspace" && !input.value && flow.tags.length) {
        flow.tags.pop();
        saveNow(flow);
      }
    }
  }), h("datalist", { id: "all-tags" }, allTags().map((t) => h("option", { value: t }))));
}
var varsOpen;
function variablesEditor(flow) {
  const entries = Object.entries(flow.variables ?? {});
  const write = (pairs) => {
    flow.variables = Object.fromEntries(pairs.filter(([k]) => k.trim()));
  };
  return h("details", {
    class: "vars",
    open: varsOpen ?? entries.length > 0,
    ontoggle: (e) => varsOpen = e.target.open
  }, h("summary", null, "Variables", entries.length > 0 && h("span", { class: "count" }, String(entries.length))), h("p", { class: "muted small" }, "Usa ", h("code", null, "{{nombre}}"), " en cualquier valor. Integradas: ", BUILTIN_VARS.map((b, i) => [i ? ", " : "", h("code", null, `{{${b}}}`)])), entries.map(([k, v], i) => h("div", { class: "var-row" }, h("input", {
    class: "input sm mono",
    value: k,
    placeholder: "nombre",
    "data-k": `var-k-${i}`,
    onchange: (e) => {
      const pairs = Object.entries(flow.variables);
      pairs[i] = [e.target.value.trim(), v];
      write(pairs);
      saveNow(flow);
    }
  }), h("input", {
    class: "input sm",
    value: v,
    placeholder: "valor",
    "data-k": `var-v-${i}`,
    oninput: (e) => {
      flow.variables[k] = e.target.value;
      saveSoon(flow);
    }
  }), h("button", {
    class: "icon",
    title: "Quitar",
    onclick: () => {
      delete flow.variables[k];
      saveNow(flow);
    }
  }, "×"))), h("button", {
    class: "btn sm ghost",
    onclick: () => {
      let n = 1;
      while (`var${n}` in flow.variables)
        n++;
      flow.variables[`var${n}`] = "";
      saveNow(flow);
    }
  }, "+ Variable"));
}
function summaryValue(s) {
  if (s.value == null || s.value === "")
    return "";
  if (s.secret)
    return "••••••";
  if (s.type === "check")
    return s.value === "false" ? "desmarcar" : "marcar";
  if (s.type === "select")
    return s.optionText || s.value;
  if (s.type === "wait")
    return `${s.value} ms`;
  return s.value;
}
function stepRow(flow, s, i, run) {
  const meta = STEP_META[s.type];
  const open = state.expanded.has(s.id);
  const status = run?.status[s.id];
  const info = run?.info[s.id];
  const title = s.type === "navigate" ? s.label || s.value || "URL" : s.type === "press" ? s.value || "Enter" : s.type === "wait" ? "" : s.label || s.selector || "sin elemento";
  const val = s.type === "navigate" || s.type === "press" ? "" : summaryValue(s);
  const toggle = () => {
    open ? state.expanded.delete(s.id) : state.expanded.add(s.id);
    render();
  };
  const li = h("li", {
    class: `step t-${s.type}${open ? " open" : ""}${s.enabled ? "" : " disabled"}${status ? " st-" + status : ""}${state.dragId === s.id ? " dragging" : ""}`,
    "data-step": s.id,
    ondragstart: (e) => {
      state.dragId = s.id;
      e.dataTransfer.effectAllowed = "move";
      e.dataTransfer.setData("text/plain", s.id);
    },
    ondragend: () => {
      state.dragId = undefined;
      li.draggable = false;
      render();
    },
    ondragover: (e) => {
      if (!state.dragId || state.dragId === s.id)
        return;
      e.preventDefault();
      const r = li.getBoundingClientRect();
      li.classList.toggle("drop-before", e.clientY < r.top + r.height / 2);
      li.classList.toggle("drop-after", e.clientY >= r.top + r.height / 2);
    },
    ondragleave: () => li.classList.remove("drop-before", "drop-after"),
    ondrop: (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!state.dragId || state.dragId === s.id)
        return;
      const after = li.classList.contains("drop-after");
      const next = after ? flow.steps[i + 1]?.id ?? null : s.id;
      moveStep(flow, state.dragId, next === state.dragId ? s.id : next);
    }
  }, h("div", { class: "step-h" }, h("span", {
    class: "grip",
    title: "Arrastrar para reordenar",
    onmousedown: () => li.draggable = true,
    onmouseup: () => li.draggable = false
  }, "⋮⋮"), h("span", { class: "num" }, String(i + 1)), h("span", { class: "badge", title: meta.label }, meta.icon), h("button", { class: "step-title", onclick: toggle }, h("b", null, meta.label), title && h("span", { class: "lbl" }, title), !!s.frame?.length && h("span", { class: "frame-tag", title: "Dentro de iframe: " + s.frame.map((f) => f.selector).join(" » ") }, s.frame.length > 1 ? `iframe ×${s.frame.length}` : "iframe"), val && h("span", { class: "val" }, val)), h("span", { class: "status", title: info ?? status ?? "" }, statusIcon(status))), status === "error" && info && h("div", { class: "step-err" }, info), open && stepDetails(flow, s, i));
  return li;
}
function statusIcon(st) {
  switch (st) {
    case "running":
      return h("span", { class: "spin" });
    case "ok":
      return "✓";
    case "error":
      return "✗";
    case "skipped":
      return "–";
    default:
      return "";
  }
}
function stepDetails(flow, s, i) {
  const meta = STEP_META[s.type];
  const save = () => saveSoon(flow);
  const field = (label, ...control) => h("label", { class: "field" }, h("span", null, label), ...control);
  const targetable = meta.needsTarget || s.type === "press";
  return h("div", { class: "step-body" }, field("Tipo", h("select", {
    class: "input sm",
    onchange: (e) => {
      s.type = e.target.value;
      saveNow(flow);
    }
  }, TYPES.map((t) => h("option", { value: t, selected: t === s.type }, `${STEP_META[t].icon}  ${STEP_META[t].label}`)))), targetable && field(s.type === "press" ? "Elemento (opcional)" : "Elemento", h("div", { class: "row tight" }, h("input", {
    class: "input sm mono grow",
    value: s.selector ?? "",
    placeholder: "css, text=…, label=…, xpath=…",
    "data-k": `sel-${s.id}`,
    oninput: (e) => {
      s.selector = e.target.value || undefined;
      save();
    }
  }), h("button", { class: "icon", title: "Apuntar en la página", disabled: !!state.picking, onclick: () => pickFor(flow, s) }, "\uD83C\uDFAF"), h("button", { class: "icon", title: "Resaltar en la página", disabled: !s.selector, onclick: () => highlightStep(s) }, "\uD83D\uDC41"))), targetable && frameField(flow, s, field), targetable && !!s.fallbacks?.length && h("details", { class: "fallbacks" }, h("summary", null, `${s.fallbacks.length} selector(es) alternativo(s)`), h("textarea", {
    class: "input sm mono",
    rows: Math.min(5, s.fallbacks.length),
    "data-k": `fb-${s.id}`,
    value: s.fallbacks.join(`
`),
    oninput: (e) => {
      s.fallbacks = e.target.value.split(`
`).map((x) => x.trim()).filter(Boolean);
      save();
    }
  })), targetable && field("Nombre", h("input", {
    class: "input sm",
    value: s.label ?? "",
    placeholder: "Descripción legible",
    "data-k": `lbl-${s.id}`,
    oninput: (e) => {
      s.label = e.target.value || undefined;
      save();
    }
  })), s.type !== "click" && s.type !== "waitFor" && valueField(flow, s, field), h("div", { class: "row two" }, s.type !== "navigate" && s.type !== "wait" && field("Timeout (ms)", h("input", {
    class: "input sm",
    type: "number",
    min: 0,
    step: 500,
    placeholder: String(state.settings.timeout),
    value: s.timeout ?? "",
    "data-k": `to-${s.id}`,
    oninput: (e) => {
      const v = e.target.valueAsNumber;
      s.timeout = Number.isFinite(v) ? v : undefined;
      save();
    }
  })), field("Nota", h("input", {
    class: "input sm",
    value: s.note ?? "",
    "data-k": `note-${s.id}`,
    oninput: (e) => {
      s.note = e.target.value || undefined;
      save();
    }
  }))), h("div", { class: "row step-foot" }, h("label", { class: "toggle" }, h("input", {
    type: "checkbox",
    checked: s.enabled,
    onchange: (e) => {
      s.enabled = e.target.checked;
      saveNow(flow);
    }
  }), "Activo"), h("span", { class: "grow" }), h("button", { class: "btn sm ghost", title: "Ejecutar solo este paso", disabled: runner.running, onclick: () => play(flow, i, i) }, "▶ Solo este"), h("button", { class: "btn sm ghost", title: "Reproducir desde este paso", disabled: runner.running, onclick: () => play(flow, i) }, "▶ Desde aquí"), h("button", { class: "icon", title: "Duplicar paso", onclick: () => duplicateStep(flow, s) }, "⧉"), h("button", { class: "icon danger", title: "Borrar paso", onclick: () => deleteStep(flow, s) }, "\uD83D\uDDD1")));
}
var FRAME_SEP = " >> ";
function frameField(flow, s, field) {
  return field("Iframe", h("input", {
    class: "input sm mono",
    value: (s.frame ?? []).map((f) => f.selector).join(FRAME_SEP),
    placeholder: "— página principal —   (iframe#pago >> iframe[name=cvc])",
    "data-k": `frame-${s.id}`,
    oninput: (e) => {
      const parts = e.target.value.split(">>").map((x) => x.trim()).filter(Boolean);
      s.frame = parts.length ? parts.map((sel, i) => s.frame?.[i]?.selector === sel ? s.frame[i] : { selector: sel }) : undefined;
      saveSoon(flow);
    }
  }), !!s.frame?.length && h("small", { class: "muted" }, "Ruta de iframes desde la página principal, separada por >>"));
}
function valueField(flow, s, field) {
  const meta = STEP_META[s.type];
  const onVal = (e) => {
    s.value = e.target.value;
    saveSoon(flow);
  };
  if (s.type === "check") {
    return field("Estado", h("select", {
      class: "input sm",
      onchange: (e) => {
        s.value = e.target.value;
        saveNow(flow);
      }
    }, h("option", { value: "true", selected: s.value !== "false" }, "☑ Marcado"), h("option", { value: "false", selected: s.value === "false" }, "☐ Desmarcado")));
  }
  const labels = { navigate: "URL", fill: "Texto", select: "Opción (value)", press: "Tecla", wait: "Milisegundos", assertText: "Texto esperado" };
  const input = h("input", {
    class: "input sm" + (s.type === "navigate" ? " mono" : ""),
    type: s.secret ? "password" : s.type === "wait" ? "number" : "text",
    value: s.value ?? "",
    placeholder: meta.valueHint ?? "",
    list: s.type === "press" ? "keys" : null,
    "data-k": `val-${s.id}`,
    oninput: onVal
  });
  return field(labels[s.type] ?? "Valor", h("div", { class: "row tight" }, s.type === "fill" ? h("textarea", { class: "input sm grow", rows: 1, value: s.value ?? "", "data-k": `val-${s.id}`, placeholder: meta.valueHint, oninput: onVal, style: s.secret ? "-webkit-text-security: disc" : undefined }) : input, s.type === "fill" && h("button", {
    class: "icon",
    title: s.secret ? "Mostrar (deja de ser secreto)" : "Marcar como secreto",
    onclick: () => {
      s.secret = !s.secret || undefined;
      saveNow(flow);
    }
  }, s.secret ? "\uD83D\uDD12" : "\uD83D\uDD13")), s.type === "select" && !!s.optionText && h("small", { class: "muted" }, `Texto visible: «${s.optionText}»`), s.type === "press" && h("datalist", { id: "keys" }, ["Enter", "Tab", "Escape", "ArrowDown", "ArrowUp", "Backspace", " "].map((k) => h("option", { value: k }))));
}
function addStepMenu(flow) {
  return h("details", { class: "menu add-step" }, h("summary", { class: "btn ghost sm" }, "+ Añadir paso"), h("div", { class: "menu-list" }, TYPES.map((t) => h("button", {
    onclick: (e) => {
      e.target.closest("details").open = false;
      const step = addStep(flow, t);
      setTimeout(() => document.querySelector(`[data-step="${step.id}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" }), 50);
    }
  }, `${STEP_META[t].icon}  ${STEP_META[t].label}`))));
}

// src/panel/views/library.ts
function libraryView() {
  const flows = filteredFlows();
  const folders = allFolders();
  const tags = allTags();
  const sel = [...state.selected].filter((id) => state.flows.some((f) => f.id === id));
  const groups = new Map;
  for (const f of flows) {
    const k = f.folder ?? "";
    if (!groups.has(k))
      groups.set(k, []);
    groups.get(k).push(f);
  }
  const groupKeys = [...groups.keys()].sort((a, b) => a === "" ? 1 : b === "" ? -1 : a.localeCompare(b));
  return h("div", { class: "view" }, h("header", { class: "top" }, h("div", { class: "brand" }, h("span", { class: "logo" }), "Rastro"), h("div", { class: "row" }, h("button", { class: "icon", title: "Importar", onclick: importFile }, "⇪"), h("button", { class: "icon", title: "Exportar todo", onclick: () => exportFlows(state.flows) }, "⇩"), h("button", { class: "icon", title: "Ajustes", onclick: () => (state.view = "settings", render()) }, "⚙"))), h("div", { class: "toolbar" }, h("input", {
    class: "input search",
    type: "search",
    placeholder: "Buscar por nombre, #etiqueta, URL, campo…",
    value: state.filter.q,
    "data-k": "search",
    oninput: (e) => {
      state.filter.q = e.target.value;
      render();
    }
  }), h("button", { class: "btn primary", onclick: createFlow }, "+ Nuevo")), (folders.length > 0 || tags.length > 0) && h("div", { class: "filters" }, h("select", {
    class: "input sm",
    onchange: (e) => {
      state.filter.folder = e.target.value;
      render();
    }
  }, h("option", { value: "", selected: state.filter.folder === "" }, "Todas las carpetas"), h("option", { value: "__none", selected: state.filter.folder === "__none" }, "Sin carpeta"), folders.map((f) => h("option", { value: f, selected: state.filter.folder === f }, "\uD83D\uDCC1 " + f))), h("select", {
    class: "input sm",
    onchange: (e) => {
      state.filter.sort = e.target.value;
      render();
    }
  }, h("option", { value: "updated", selected: state.filter.sort === "updated" }, "Recientes"), h("option", { value: "name", selected: state.filter.sort === "name" }, "Nombre"), h("option", { value: "lastRun", selected: state.filter.sort === "lastRun" }, "Última ejecución")), tags.length > 0 && h("div", { class: "chips" }, tags.map((t) => h("button", {
    class: "chip" + (state.filter.tags.has(t) ? " on" : ""),
    onclick: () => {
      state.filter.tags.has(t) ? state.filter.tags.delete(t) : state.filter.tags.add(t);
      render();
    }
  }, "#" + t)))), sel.length > 0 && h("div", { class: "bulk" }, h("span", null, `${sel.length} seleccionado(s)`), h("button", { class: "btn sm", onclick: () => exportFlows(state.flows.filter((f) => sel.includes(f.id))) }, "Exportar"), h("button", { class: "btn sm", onclick: () => bulkMove(sel) }, "Mover"), h("button", { class: "btn sm", onclick: () => bulkTag(sel) }, "Etiquetar"), h("button", { class: "btn sm danger", onclick: () => removeFlows(sel) }, "Borrar"), h("button", { class: "icon", title: "Quitar selección", onclick: () => (state.selected.clear(), render()) }, "✕")), h("main", { class: "scroll", "data-scroll": "library" }, state.flows.length === 0 ? emptyState() : flows.length === 0 ? h("p", { class: "empty muted" }, "Ningún flujo coincide con el filtro.") : groupKeys.map((k) => folderGroup(k, groups.get(k), groupKeys.length > 1 || k !== ""))));
}
function folderGroup(name, flows, showHeader) {
  const key = name || "__none";
  const collapsed = state.collapsedFolders.has(key);
  return h("section", { class: "group" }, showHeader && h("button", {
    class: "group-h",
    onclick: () => {
      collapsed ? state.collapsedFolders.delete(key) : state.collapsedFolders.add(key);
      render();
    }
  }, h("span", { class: "caret" + (collapsed ? "" : " open") }, "▸"), name ? "\uD83D\uDCC1 " + name : "Sin carpeta", h("span", { class: "count" }, String(flows.length))), !collapsed && flows.map(flowCard));
}
function flowCard(f) {
  const host = hostOf(f.steps.find((s) => s.type === "navigate")?.value);
  const running = runner.running && state.run?.flowId === f.id;
  return h("article", { class: "card" + (state.selected.has(f.id) ? " selected" : "") }, h("input", {
    type: "checkbox",
    class: "check",
    checked: state.selected.has(f.id),
    title: "Seleccionar",
    onchange: (e) => {
      e.target.checked ? state.selected.add(f.id) : state.selected.delete(f.id);
      render();
    }
  }), h("div", { class: "card-body", onclick: () => openFlow(f.id) }, h("div", { class: "card-title" }, f.lastRun && h("span", { class: "dot " + (f.lastRun.ok ? "ok" : "err"), title: lastRunText(f) }), f.name), h("div", { class: "meta" }, `${f.steps.length} paso${f.steps.length === 1 ? "" : "s"}`, host && ` · ${host}`, ` · ${timeAgo(f.updatedAt)}`), f.tags.length > 0 && h("div", { class: "chips" }, f.tags.map((t) => h("span", { class: "chip static" }, "#" + t)))), h("div", { class: "card-actions" }, h("button", { class: "icon play", title: "Reproducir en la pestaña activa", disabled: runner.running, onclick: () => play(f) }, running ? "…" : "▶"), h("details", { class: "menu" }, h("summary", { class: "icon", title: "Más" }, "⋯"), h("div", { class: "menu-list" }, h("button", { onclick: () => duplicateFlow(f) }, "⧉ Duplicar"), h("button", { onclick: () => exportFlows([f]) }, "⇩ Exportar JSON"), h("button", { onclick: () => exportPuppeteer(f) }, "⇩ Exportar a Puppeteer"), h("button", { onclick: () => exportDevTools(f) }, "⇩ Exportar a DevTools Recorder"), h("button", { class: "danger", onclick: () => removeFlows([f.id]) }, "\uD83D\uDDD1 Borrar")))));
}
function lastRunText(f) {
  const r = f.lastRun;
  return r.ok ? `OK ${timeAgo(r.at)} (${(r.ms / 1000).toFixed(1)}s)` : `Falló ${timeAgo(r.at)}: ${r.error}`;
}
function emptyState() {
  return h("div", { class: "empty" }, h("div", { class: "empty-art" }, "◉ → ⌨ → ⏎"), h("h2", null, "Graba tu primer flujo"), h("ol", { class: "muted" }, h("li", null, "Crea un flujo y abre la web que quieras automatizar."), h("li", null, "Pulsa ", h("b", null, "Grabar"), " y usa la página con normalidad: los botones se graban como click y los inputs como «escribir» con su contenido."), h("li", null, "Edita, reordena y dale a ", h("b", null, "Reproducir"), ".")), h("div", { class: "row center" }, h("button", { class: "btn primary", onclick: createFlow }, "+ Nuevo flujo"), h("button", { class: "btn", onclick: importFile }, "Importar")));
}
async function importFile() {
  const file = await pickFile();
  if (file)
    await importText(await file.text());
}

// src/panel/views/settings.ts
function settingsView() {
  const s = state.settings;
  const set = (k, v) => {
    s[k] = v;
    saveSettings(s);
  };
  const num = (k, label, hint) => h("label", { class: "field" }, h("span", null, label), h("input", {
    class: "input sm",
    type: "number",
    min: 0,
    step: k === "keyDelay" ? 5 : 100,
    value: s[k],
    "data-k": "set-" + k,
    oninput: (e) => {
      const v = e.target.valueAsNumber;
      if (Number.isFinite(v) && v >= 0)
        set(k, v);
    }
  }), h("small", { class: "muted" }, hint));
  return h("div", { class: "view" }, h("header", { class: "top" }, h("button", { class: "btn ghost sm", onclick: () => (state.view = "library", render()) }, "← Flujos"), h("b", null, "Ajustes")), h("main", { class: "scroll settings", "data-scroll": "settings" }, h("h3", null, "Reproducción"), num("timeout", "Timeout por paso (ms)", "Cuánto esperar a que aparezca un elemento antes de fallar."), num("stepDelay", "Pausa entre pasos (ms)", "Útil para ver lo que pasa o para webs lentas."), h("label", { class: "field" }, h("span", null, "Forma de escribir"), h("select", {
    class: "input sm",
    onchange: (e) => {
      set("typeMode", e.target.value);
      render();
    }
  }, h("option", { value: "instant", selected: s.typeMode === "instant" }, "De golpe (rápido)"), h("option", { value: "keys", selected: s.typeMode === "keys" }, "Tecla a tecla (realista)")), h("small", { class: "muted" }, "Tecla a tecla dispara keydown/keyup: útil para autocompletados y máscaras.")), s.typeMode === "keys" && num("keyDelay", "Pausa entre teclas (ms)", ""), h("label", { class: "toggle" }, h("input", { type: "checkbox", checked: s.highlight, onchange: (e) => set("highlight", e.target.checked) }), "Resaltar cada elemento antes de actuar"), h("label", { class: "toggle" }, h("input", {
    type: "checkbox",
    checked: s.autoWait,
    onchange: (e) => {
      set("autoWait", e.target.checked);
      render();
    }
  }), "Esperar a que la página termine de cargar antes de cada acción"), h("small", { class: "muted" }, "Antes de actuar espera a que no haya peticiones en curso ni loaders visibles, y a que el elemento esté habilitado y sin nada encima."), s.autoWait && h("label", { class: "field" }, h("span", null, "Selector de loaders propios"), h("input", {
    class: "input sm",
    type: "text",
    placeholder: ".mi-loader, #overlay-cargando",
    value: s.loaderSelector,
    oninput: (e) => {
      const inp = e.target;
      let ok = true;
      try {
        if (inp.value.trim())
          document.querySelector(inp.value);
      } catch {
        ok = false;
      }
      inp.setCustomValidity(ok ? "" : "Selector CSS no válido");
      inp.reportValidity();
      if (ok)
        set("loaderSelector", inp.value);
    }
  }), h("small", { class: "muted" }, "Opcional. Se suma a los loaders de Element Plus, Ant, Vuetify, MUI, Bootstrap… Mientras alguno sea visible, Rastro espera.")), h("div", { class: "row" }, h("button", {
    class: "btn sm ghost",
    onclick: () => {
      state.settings = { ...DEFAULT_SETTINGS };
      saveSettings(state.settings);
      render();
      toast("Ajustes restablecidos", "ok");
    }
  }, "Restablecer")), h("h3", null, "Selectores"), h("p", { class: "muted small" }, "Rastro genera varios selectores por elemento y prueba los alternativos si falla el principal. Orden de preferencia: ", h("code", null, "data-testid"), ", ", h("code", null, "#id"), " estable, ", h("code", null, "name"), ", ", h("code", null, "label=…"), ", ", h("code", null, "aria-label"), ", ", h("code", null, "placeholder"), ", ", h("code", null, "text=…"), " y por último ruta CSS. Ids y clases con pinta de autogeneradas se ignoran. Añadir ", h("code", null, "data-testid"), " a la app es lo que da los flujos más robustos."), h("h3", null, "Datos"), h("p", { class: "muted small" }, `${state.flows.length} flujo(s), ${state.flows.reduce((n, f) => n + f.steps.length, 0)} paso(s). Se guardan en el almacenamiento local de la extensión, en este navegador.`)));
}

// src/panel/main.ts
var app = document.getElementById("app");
var scheduled = false;
setRender(() => {
  if (scheduled)
    return;
  scheduled = true;
  queueMicrotask(() => {
    scheduled = false;
    const flow = current();
    if (state.view === "editor" && !flow)
      state.view = "library";
    const view = state.view === "editor" ? editorView(flow) : state.view === "settings" ? settingsView() : libraryView();
    morph(app, view);
  });
});
async function boot() {
  [state.flows, state.settings, state.recording] = await Promise.all([listFlows(), getSettings(), getRecording()]);
  render();
  chrome.storage.onChanged.addListener((changes, area) => {
    let dirty = false;
    let appended = false;
    if (area === "local") {
      for (const [k, { newValue }] of Object.entries(changes)) {
        if (isFlowKey(k)) {
          const id = k.slice(5);
          const i = state.flows.findIndex((f) => f.id === id);
          if (!newValue) {
            if (i >= 0)
              state.flows.splice(i, 1);
          } else if (i >= 0) {
            appended ||= newValue.steps.length > state.flows[i].steps.length;
            state.flows[i] = newValue;
          } else
            state.flows.unshift(newValue);
          dirty = true;
        } else if (k === "settings") {
          state.settings = { ...state.settings, ...newValue };
        }
      }
    }
    if (area === "session" && RECORDING_STORAGE_KEY in changes) {
      state.recording = changes[RECORDING_STORAGE_KEY].newValue;
      dirty = true;
    }
    if (!dirty)
      return;
    render();
    if (appended && state.recording?.flowId === state.currentId) {
      setTimeout(() => {
        const el = document.querySelector("[data-scroll]");
        el?.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
      }, 30);
    }
  });
}
document.addEventListener("click", (e) => {
  for (const d of document.querySelectorAll("details.menu[open]")) {
    if (!d.contains(e.target))
      d.open = false;
  }
});
document.addEventListener("dragover", (e) => {
  if (e.dataTransfer?.types.includes("Files")) {
    e.preventDefault();
    document.body.classList.add("dropping");
  }
});
document.addEventListener("dragleave", (e) => {
  if (!e.relatedTarget)
    document.body.classList.remove("dropping");
});
document.addEventListener("drop", async (e) => {
  const file = e.dataTransfer?.files?.[0];
  document.body.classList.remove("dropping");
  if (!file)
    return;
  e.preventDefault();
  await importText(await file.text());
});
boot();

//# debugId=A8FB6D6E822711AB64756E2164756E21
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsic3JjL3NoYXJlZC90eXBlcy50cyIsICJzcmMvc2hhcmVkL3V0aWwudHMiLCAic3JjL3NoYXJlZC9zdG9yZS50cyIsICJzcmMvc2hhcmVkL2RldnRvb2xzLnRzIiwgInNyYy9zaGFyZWQvZXhwb3J0ZXJzLnRzIiwgInNyYy9wYW5lbC9ydW5uZXIudHMiLCAic3JjL3BhbmVsL3VpLnRzIiwgInNyYy9wYW5lbC9zdGF0ZS50cyIsICJzcmMvcGFuZWwvdmlld3MvZWRpdG9yLnRzIiwgInNyYy9wYW5lbC92aWV3cy9saWJyYXJ5LnRzIiwgInNyYy9wYW5lbC92aWV3cy9zZXR0aW5ncy50cyIsICJzcmMvcGFuZWwvbWFpbi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsKICAgICJleHBvcnQgdHlwZSBTdGVwVHlwZSA9XG4gIHwgXCJuYXZpZ2F0ZVwiIC8vIGlyIGEgdW5hIFVSTFxuICB8IFwiY2xpY2tcIiAvLyBjbGljayBlbiBib3TDs24vZW5sYWNlL2N1YWxxdWllciBjb3NhXG4gIHwgXCJmaWxsXCIgLy8gZXNjcmliaXIgZW4gaW5wdXQvdGV4dGFyZWEvY29udGVudGVkaXRhYmxlXG4gIHwgXCJzZWxlY3RcIiAvLyBlbGVnaXIgb3BjacOzbiBkZSB1biA8c2VsZWN0PlxuICB8IFwiY2hlY2tcIiAvLyBtYXJjYXIvZGVzbWFyY2FyIGNoZWNrYm94IG8gcmFkaW9cbiAgfCBcInByZXNzXCIgLy8gcHVsc2FyIHVuYSB0ZWNsYSAoRW50ZXIsIFRhYuKApilcbiAgfCBcIndhaXRcIiAvLyBlc3BlcmFyIE4gbXNcbiAgfCBcIndhaXRGb3JcIiAvLyBlc3BlcmFyIGEgcXVlIGFwYXJlemNhIHVuIGVsZW1lbnRvXG4gIHwgXCJhc3NlcnRUZXh0XCI7IC8vIGNvbXByb2JhciBxdWUgdW4gZWxlbWVudG8gY29udGllbmUgdW4gdGV4dG9cblxuLyoqIFVuIG5pdmVsIGRlIGxhIHJ1dGEgaGFzdGEgdW4gaWZyYW1lOiBzZWxlY3RvcmVzIGRlbCBlbGVtZW50byA8aWZyYW1lPiBlbiBzdSBkb2N1bWVudG8uICovXG5leHBvcnQgaW50ZXJmYWNlIEZyYW1lUmVmIHtcbiAgc2VsZWN0b3I6IHN0cmluZztcbiAgZmFsbGJhY2tzPzogc3RyaW5nW107XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3RlcCB7XG4gIGlkOiBzdHJpbmc7XG4gIHR5cGU6IFN0ZXBUeXBlO1xuICAvKiogUnV0YSBkZSBpZnJhbWVzIGRlc2RlIGxhIHDDoWdpbmEgcHJpbmNpcGFsIGhhc3RhIGVsIGRvY3VtZW50byBkZWwgZWxlbWVudG8gKHZhY8OtbyA9IHDDoWdpbmEgcHJpbmNpcGFsKS4gKi9cbiAgZnJhbWU/OiBGcmFtZVJlZltdO1xuICAvKiogU2VsZWN0b3IgcHJpbmNpcGFsIChlZGl0YWJsZSkuIEFkbWl0ZSBDU1MsIGB0ZXh0PeKApmAgeSBgeHBhdGg94oCmYC4gKi9cbiAgc2VsZWN0b3I/OiBzdHJpbmc7XG4gIC8qKiBTZWxlY3RvcmVzIGFsdGVybmF0aXZvcyBxdWUgc2UgcHJ1ZWJhbiBzaSBmYWxsYSBlbCBwcmluY2lwYWwuICovXG4gIGZhbGxiYWNrcz86IHN0cmluZ1tdO1xuICAvKiogRGVzY3JpcGNpw7NuIGxlZ2libGU6IMKrRW1haWzCuywgwqtFbnZpYXLCu+KApiAqL1xuICBsYWJlbD86IHN0cmluZztcbiAgLyoqIFRleHRvIGEgZXNjcmliaXIsIG9wY2nDs24sIFVSTCwgdGVjbGEsIG1zLCB0ZXh0byBlc3BlcmFkbyBvIFwidHJ1ZVwiL1wiZmFsc2VcIiBwYXJhIGNoZWNrLiAqL1xuICB2YWx1ZT86IHN0cmluZztcbiAgLyoqIFBhcmEgPHNlbGVjdD46IHRleHRvIHZpc2libGUgZGUgbGEgb3BjacOzbiAocG9yIHNpIGNhbWJpYSBlbCB2YWx1ZSkuICovXG4gIG9wdGlvblRleHQ/OiBzdHJpbmc7XG4gIC8qKiBFbCB2YWxvciBlcyBzZW5zaWJsZSAocGFzc3dvcmQpOiBzZSBlbm1hc2NhcmEgZW4gbGEgVUkuICovXG4gIHNlY3JldD86IGJvb2xlYW47XG4gIGVuYWJsZWQ6IGJvb2xlYW47XG4gIC8qKiBUaW1lb3V0IHByb3BpbyBlbiBtcyAoc2kgbm8sIGVsIGdsb2JhbCkuICovXG4gIHRpbWVvdXQ/OiBudW1iZXI7XG4gIG5vdGU/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmxvdyB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG4gIGZvbGRlcj86IHN0cmluZztcbiAgdGFnczogc3RyaW5nW107XG4gIC8qKiBWYXJpYWJsZXMgdXNhYmxlcyBjb21vIHt7bm9tYnJlfX0gZW4gbG9zIHZhbG9yZXMgZGUgbG9zIHBhc29zLiAqL1xuICB2YXJpYWJsZXM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG4gIHN0ZXBzOiBTdGVwW107XG4gIGNyZWF0ZWRBdDogbnVtYmVyO1xuICB1cGRhdGVkQXQ6IG51bWJlcjtcbiAgbGFzdFJ1bj86IFJ1blN1bW1hcnk7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU3VtbWFyeSB7XG4gIGF0OiBudW1iZXI7XG4gIG9rOiBib29sZWFuO1xuICBtczogbnVtYmVyO1xuICBmYWlsZWRTdGVwSWQ/OiBzdHJpbmc7XG4gIGVycm9yPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNldHRpbmdzIHtcbiAgLyoqIFRpZW1wbyBtw6F4aW1vIGVzcGVyYW5kbyBhIHVuIGVsZW1lbnRvLiAqL1xuICB0aW1lb3V0OiBudW1iZXI7XG4gIC8qKiBQYXVzYSBlbnRyZSBwYXNvcyBkdXJhbnRlIGxhIHJlcHJvZHVjY2nDs24uICovXG4gIHN0ZXBEZWxheTogbnVtYmVyO1xuICAvKiogRXNjcmliaXIgY2Fyw6FjdGVyIGEgY2Fyw6FjdGVyIChtw6FzIHJlYWxpc3RhKSBvIGRlIGdvbHBlLiAqL1xuICB0eXBlTW9kZTogXCJpbnN0YW50XCIgfCBcImtleXNcIjtcbiAgLyoqIFBhdXNhIGVudHJlIHRlY2xhcyBlbiBtb2RvIFwia2V5c1wiLiAqL1xuICBrZXlEZWxheTogbnVtYmVyO1xuICAvKiogUmVzYWx0YXIgZWwgZWxlbWVudG8gYW50ZXMgZGUgYWN0dWFyLiAqL1xuICBoaWdobGlnaHQ6IGJvb2xlYW47XG4gIC8qKiBBbnRlcyBkZSBjYWRhIGFjY2nDs24sIGVzcGVyYXIgYSBxdWUgbm8gaGF5YSBwZXRpY2lvbmVzL2xvYWRlcnMgeSBlbCBlbGVtZW50byBlc3TDqSBsaXN0by4gKi9cbiAgYXV0b1dhaXQ6IGJvb2xlYW47XG4gIC8qKiBTZWxlY3RvciBDU1MgZXh0cmEgZGUgbG9zIGxvYWRlcnMgcHJvcGlvcyBkZSBsYSBhcHAgKHNlIHN1bWEgYSBsb3MgZGUgbGlicmVyw61hcyBjb25vY2lkYXMpLiAqL1xuICBsb2FkZXJTZWxlY3Rvcjogc3RyaW5nO1xufVxuXG5leHBvcnQgY29uc3QgREVGQVVMVF9TRVRUSU5HUzogU2V0dGluZ3MgPSB7XG4gIHRpbWVvdXQ6IDgwMDAsXG4gIHN0ZXBEZWxheTogMjUwLFxuICB0eXBlTW9kZTogXCJpbnN0YW50XCIsXG4gIGtleURlbGF5OiAyNSxcbiAgaGlnaGxpZ2h0OiB0cnVlLFxuICBhdXRvV2FpdDogdHJ1ZSxcbiAgbG9hZGVyU2VsZWN0b3I6IFwiXCIsXG59O1xuXG4vKiogRXN0YWRvIGRlIGdyYWJhY2nDs24gKHZpdmUgZW4gc3RvcmFnZS5zZXNzaW9uKS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUmVjb3JkaW5nU3RhdGUge1xuICBmbG93SWQ6IHN0cmluZztcbiAgdGFiSWQ6IG51bWJlcjtcbiAgLyoqIHJlY29yZDogbGFzIGludGVyYWNjaW9uZXMgb2N1cnJlbiBkZSB2ZXJkYWQuIHBvaW50OiBzb2xvIHNlIHNlw7FhbGFuLCBsb3MgY2xpY2tzIG5vIHNlIGVqZWN1dGFuLiAqL1xuICBtb2RlOiBcInJlY29yZFwiIHwgXCJwb2ludFwiO1xuICBwYXVzZWQ6IGJvb2xlYW47XG59XG5cbi8qKiBGb3JtYXRvIGRlbCBmaWNoZXJvIGRlIGV4cG9ydGFjacOzbi4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRXhwb3J0RmlsZSB7XG4gIGZvcm1hdDogXCJyYXN0cm9cIjtcbiAgdmVyc2lvbjogMTtcbiAgZXhwb3J0ZWRBdDogc3RyaW5nO1xuICBmbG93czogRmxvd1tdO1xufVxuXG5leHBvcnQgY29uc3QgU1RFUF9NRVRBOiBSZWNvcmQ8U3RlcFR5cGUsIHsgbGFiZWw6IHN0cmluZzsgaWNvbjogc3RyaW5nOyBuZWVkc1RhcmdldDogYm9vbGVhbjsgdmFsdWVIaW50Pzogc3RyaW5nIH0+ID0ge1xuICBuYXZpZ2F0ZTogeyBsYWJlbDogXCJJciBhXCIsIGljb246IFwi4oaXXCIsIG5lZWRzVGFyZ2V0OiBmYWxzZSwgdmFsdWVIaW50OiBcImh0dHBzOi8v4oCmXCIgfSxcbiAgY2xpY2s6IHsgbGFiZWw6IFwiQ2xpY2tcIiwgaWNvbjogXCLil4lcIiwgbmVlZHNUYXJnZXQ6IHRydWUgfSxcbiAgZmlsbDogeyBsYWJlbDogXCJFc2NyaWJpclwiLCBpY29uOiBcIuKMqFwiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRleHRvIG8ge3t2YXJpYWJsZX19XCIgfSxcbiAgc2VsZWN0OiB7IGxhYmVsOiBcIlNlbGVjY2lvbmFyXCIsIGljb246IFwi4piwXCIsIG5lZWRzVGFyZ2V0OiB0cnVlLCB2YWx1ZUhpbnQ6IFwidmFsdWUgZGUgbGEgb3BjacOzblwiIH0sXG4gIGNoZWNrOiB7IGxhYmVsOiBcIk1hcmNhclwiLCBpY29uOiBcIuKYkVwiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRydWUgLyBmYWxzZVwiIH0sXG4gIHByZXNzOiB7IGxhYmVsOiBcIlRlY2xhXCIsIGljb246IFwi4o+OXCIsIG5lZWRzVGFyZ2V0OiBmYWxzZSwgdmFsdWVIaW50OiBcIkVudGVyLCBUYWIsIEVzY2FwZeKAplwiIH0sXG4gIHdhaXQ6IHsgbGFiZWw6IFwiRXNwZXJhclwiLCBpY29uOiBcIuKPsVwiLCBuZWVkc1RhcmdldDogZmFsc2UsIHZhbHVlSGludDogXCJtaWxpc2VndW5kb3NcIiB9LFxuICB3YWl0Rm9yOiB7IGxhYmVsOiBcIkVzcGVyYXIgYVwiLCBpY29uOiBcIuKMm1wiLCBuZWVkc1RhcmdldDogdHJ1ZSB9LFxuICBhc3NlcnRUZXh0OiB7IGxhYmVsOiBcIkNvbXByb2JhclwiLCBpY29uOiBcIuKck1wiLCBuZWVkc1RhcmdldDogdHJ1ZSwgdmFsdWVIaW50OiBcInRleHRvIGVzcGVyYWRvXCIgfSxcbn07XG4iLAogICAgImV4cG9ydCBjb25zdCB1aWQgPSAoKTogc3RyaW5nID0+IGNyeXB0by5yYW5kb21VVUlEKCkuc2xpY2UoMCwgOCkgKyBEYXRlLm5vdygpLnRvU3RyaW5nKDM2KS5zbGljZSgtNCk7XG5cbi8qKiDCv1BhcmVjZSB1biBpZC9jbGFzZSBhdXRvZ2VuZXJhZG8gKGhhc2hlcywgY29udGFkb3JlcywgaWRzIGRlIFJlYWN0L0VsZW1lbnQgUGx1c+KApik/ICovXG5leHBvcnQgZnVuY3Rpb24gbG9va3NHZW5lcmF0ZWQoczogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAoXG4gICAgcy5sZW5ndGggPiA0MCB8fFxuICAgIC9cXGR7NCx9Ly50ZXN0KHMpIHx8XG4gICAgL1stXzpdXFxkK1stXzpdXFxkKyQvLnRlc3QocykgfHwgLy8gcHJlZmlqby1hbGVhdG9yaW8tY29udGFkb3I6IGVsLWlkLTc0NC0xNjUsIGlucHV0LTEyLTNcbiAgICAvXlthLWYwLTktXXsxMCx9JC9pLnRlc3QocykgfHxcbiAgICAvXjpyWzAtOWEtel0rOj8kLy50ZXN0KHMpIHx8IC8vIFJlYWN0IHVzZUlkXG4gICAgL14oZW1iZXJ8ZXh0LWdlbnxyZWFjdC18bXVpLXxyYWRpeC18aGVhZGxlc3N1aS18ZG93bnNoaWZ0LXxyYy18ZWwtaWQtfHYtXFxkfGlucHV0LVxcZCkvaS50ZXN0KHMpIHx8XG4gICAgKC9bXy1dW2EtekEtWjAtOV17NSx9JC8udGVzdChzKSAmJiAvXFxkLipcXGQvLnRlc3Qocy5zbGljZSgtNikpKSB8fCAvLyBjc3MtbW9kdWxlczogYnRuX3gzRjlhXG4gICAgL14oY3NzfHNjfGpzeHxlbW90aW9ufHN2ZWx0ZSktW2EtejAtOV0rJC9pLnRlc3QocylcbiAgKTtcbn1cblxuZXhwb3J0IGNvbnN0IHNsZWVwID0gKG1zOiBudW1iZXIpID0+IG5ldyBQcm9taXNlPHZvaWQ+KChyKSA9PiBzZXRUaW1lb3V0KHIsIG1zKSk7XG5cbi8qKiBWYXJpYWJsZXMgaW50ZWdyYWRhczoge3skdGltZXN0YW1wfX0sIHt7JHV1aWR9fSwge3skcmFuZG9tRW1haWx9fSwge3skcmFuZG9tSW50fX0sIHt7JHRvZGF5fX0gKi9cbmZ1bmN0aW9uIGJ1aWx0aW4obmFtZTogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgc3dpdGNoIChuYW1lKSB7XG4gICAgY2FzZSBcIiR0aW1lc3RhbXBcIjpcbiAgICAgIHJldHVybiBTdHJpbmcoRGF0ZS5ub3coKSk7XG4gICAgY2FzZSBcIiR1dWlkXCI6XG4gICAgICByZXR1cm4gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjYXNlIFwiJHJhbmRvbUludFwiOlxuICAgICAgcmV0dXJuIFN0cmluZyhNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAxXzAwMF8wMDApKTtcbiAgICBjYXNlIFwiJHJhbmRvbUVtYWlsXCI6XG4gICAgICByZXR1cm4gYHRlc3QrJHtEYXRlLm5vdygpLnRvU3RyaW5nKDM2KX0ke01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDEwMDApfUBleGFtcGxlLmNvbWA7XG4gICAgY2FzZSBcIiR0b2RheVwiOlxuICAgICAgcmV0dXJuIG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKS5zbGljZSgwLCAxMCk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuLyoqIFN1c3RpdHV5ZSB7e3ZhcmlhYmxlfX0gcG9yIHN1IHZhbG9yLiBMYXMgZGVzY29ub2NpZGFzIHNlIGRlamFuIHRhbCBjdWFsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludGVycG9sYXRlKHRleHQ6IHN0cmluZywgdmFyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IHN0cmluZyB7XG4gIHJldHVybiB0ZXh0LnJlcGxhY2UoL1xce1xce1xccyooWyRcXHcuLV0rKVxccypcXH1cXH0vZywgKG0sIG5hbWU6IHN0cmluZykgPT4gdmFyc1tuYW1lXSA/PyBidWlsdGluKG5hbWUpID8/IG0pO1xufVxuXG5leHBvcnQgY29uc3QgQlVJTFRJTl9WQVJTID0gW1wiJHRpbWVzdGFtcFwiLCBcIiR1dWlkXCIsIFwiJHJhbmRvbUVtYWlsXCIsIFwiJHJhbmRvbUludFwiLCBcIiR0b2RheVwiXTtcbiIsCiAgICAiLy8gUGVyc2lzdGVuY2lhIGVuIGNocm9tZS5zdG9yYWdlLmxvY2FsLiBDYWRhIGZsdWpvIHZhIGVuIHN1IHByb3BpYSBjbGF2ZSAoZmxvdzo8aWQ+KVxuLy8gcGFyYSBxdWUgbGFzIGVzY3JpdHVyYXMgY29uY3VycmVudGVzIGRlbCBiYWNrZ3JvdW5kIChncmFiYW5kbykgeSBkZWwgcGFuZWwgKGVkaXRhbmRvKVxuLy8gbm8gc2UgcGlzZW4gZW50cmUgZmx1am9zIGRpc3RpbnRvcy5cbmltcG9ydCB7IERFRkFVTFRfU0VUVElOR1MsIHR5cGUgRmxvdywgdHlwZSBSZWNvcmRpbmdTdGF0ZSwgdHlwZSBTZXR0aW5ncywgdHlwZSBTdGVwIH0gZnJvbSBcIi4vdHlwZXNcIjtcbmltcG9ydCB7IHVpZCB9IGZyb20gXCIuL3V0aWxcIjtcblxuY29uc3QgRkxPV19QUkVGSVggPSBcImZsb3c6XCI7XG5jb25zdCBTRVRUSU5HU19LRVkgPSBcInNldHRpbmdzXCI7XG5jb25zdCBSRUNPUkRJTkdfS0VZID0gXCJyZWNvcmRpbmdcIjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxpc3RGbG93cygpOiBQcm9taXNlPEZsb3dbXT4ge1xuICBjb25zdCBhbGwgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQobnVsbCk7XG4gIHJldHVybiBPYmplY3QuZW50cmllcyhhbGwpXG4gICAgLmZpbHRlcigoW2tdKSA9PiBrLnN0YXJ0c1dpdGgoRkxPV19QUkVGSVgpKVxuICAgIC5tYXAoKFssIHZdKSA9PiB2IGFzIEZsb3cpXG4gICAgLnNvcnQoKGEsIGIpID0+IGIudXBkYXRlZEF0IC0gYS51cGRhdGVkQXQpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RmxvdyhpZDogc3RyaW5nKTogUHJvbWlzZTxGbG93IHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IGtleSA9IEZMT1dfUFJFRklYICsgaWQ7XG4gIHJldHVybiAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KGtleSkpW2tleV0gYXMgRmxvdyB8IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVGbG93KGZsb3c6IEZsb3csIHRvdWNoID0gdHJ1ZSk6IFByb21pc2U8Rmxvdz4ge1xuICBpZiAodG91Y2gpIGZsb3cudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcbiAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW0ZMT1dfUFJFRklYICsgZmxvdy5pZF06IGZsb3cgfSk7XG4gIHJldHVybiBmbG93O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlRmxvd3MoaWRzOiBzdHJpbmdbXSk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoaWRzLm1hcCgoaWQpID0+IEZMT1dfUFJFRklYICsgaWQpKTtcbn1cblxuLyoqIExlZS1tb2RpZmljYS1lc2NyaWJlIHVuIGZsdWpvLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUZsb3coaWQ6IHN0cmluZywgZm46IChmOiBGbG93KSA9PiB2b2lkLCB0b3VjaCA9IHRydWUpOiBQcm9taXNlPEZsb3cgfCB1bmRlZmluZWQ+IHtcbiAgY29uc3QgZmxvdyA9IGF3YWl0IGdldEZsb3coaWQpO1xuICBpZiAoIWZsb3cpIHJldHVybjtcbiAgZm4oZmxvdyk7XG4gIHJldHVybiBzYXZlRmxvdyhmbG93LCB0b3VjaCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdGbG93KHBhcnRpYWw6IFBhcnRpYWw8Rmxvdz4gPSB7fSk6IEZsb3cge1xuICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICByZXR1cm4ge1xuICAgIGlkOiB1aWQoKSxcbiAgICBuYW1lOiBcIk51ZXZvIGZsdWpvXCIsXG4gICAgdGFnczogW10sXG4gICAgdmFyaWFibGVzOiB7fSxcbiAgICBzdGVwczogW10sXG4gICAgY3JlYXRlZEF0OiBub3csXG4gICAgdXBkYXRlZEF0OiBub3csXG4gICAgLi4ucGFydGlhbCxcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1N0ZXAocGFydGlhbDogUGFydGlhbDxTdGVwPiAmIFBpY2s8U3RlcCwgXCJ0eXBlXCI+KTogU3RlcCB7XG4gIHJldHVybiB7IGlkOiB1aWQoKSwgZW5hYmxlZDogdHJ1ZSwgLi4ucGFydGlhbCB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2V0dGluZ3MoKTogUHJvbWlzZTxTZXR0aW5ncz4ge1xuICBjb25zdCBzID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChTRVRUSU5HU19LRVkpKVtTRVRUSU5HU19LRVldO1xuICByZXR1cm4geyAuLi5ERUZBVUxUX1NFVFRJTkdTLCAuLi4ocyA/PyB7fSkgfTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVTZXR0aW5ncyhzOiBTZXR0aW5ncyk6IFByb21pc2U8dm9pZD4ge1xuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU0VUVElOR1NfS0VZXTogcyB9KTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFJlY29yZGluZygpOiBQcm9taXNlPFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkPiB7XG4gIHJldHVybiAoYXdhaXQgY2hyb21lLnN0b3JhZ2Uuc2Vzc2lvbi5nZXQoUkVDT1JESU5HX0tFWSkpW1JFQ09SRElOR19LRVldIGFzIFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UmVjb3JkaW5nKHI6IFJlY29yZGluZ1N0YXRlIHwgdW5kZWZpbmVkKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChyKSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5zZXNzaW9uLnNldCh7IFtSRUNPUkRJTkdfS0VZXTogciB9KTtcbiAgZWxzZSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5zZXNzaW9uLnJlbW92ZShSRUNPUkRJTkdfS0VZKTtcbn1cblxuZXhwb3J0IGNvbnN0IGlzRmxvd0tleSA9IChrOiBzdHJpbmcpID0+IGsuc3RhcnRzV2l0aChGTE9XX1BSRUZJWCk7XG5leHBvcnQgY29uc3QgUkVDT1JESU5HX1NUT1JBR0VfS0VZID0gUkVDT1JESU5HX0tFWTtcbiIsCiAgICAiLy8gQ29udmVyc2nDs24gZGVzZGUvaGFjaWEgZWwgZm9ybWF0byBKU09OIGRlbCBwYW5lbCDCq1JlY29yZGVywrsgZGUgQ2hyb21lIERldlRvb2xzLlxuLy8gRm9ybWF0bzogaHR0cHM6Ly9naXRodWIuY29tL3B1cHBldGVlci9yZXBsYXkgKHRpdGxlICsgc3RlcHNbXSBjb24gc2VsZWN0b3JzOiBzdHJpbmdbXVtdKS5cbmltcG9ydCB7IG5ld0Zsb3csIG5ld1N0ZXAgfSBmcm9tIFwiLi9zdG9yZVwiO1xuaW1wb3J0IHR5cGUgeyBGbG93LCBGcmFtZVJlZiwgU3RlcCB9IGZyb20gXCIuL3R5cGVzXCI7XG5pbXBvcnQgeyBsb29rc0dlbmVyYXRlZCB9IGZyb20gXCIuL3V0aWxcIjtcblxuaW50ZXJmYWNlIERUU3RlcCB7XG4gIHR5cGU6IHN0cmluZztcbiAgdGFyZ2V0Pzogc3RyaW5nO1xuICBmcmFtZT86IG51bWJlcltdO1xuICBzZWxlY3RvcnM/OiAoc3RyaW5nIHwgc3RyaW5nW10pW107XG4gIHVybD86IHN0cmluZztcbiAgdmFsdWU/OiBzdHJpbmc7XG4gIGtleT86IHN0cmluZztcbiAgdGltZW91dD86IG51bWJlcjtcbiAgW2s6IHN0cmluZ106IHVua25vd247XG59XG5cbmludGVyZmFjZSBEVFJlY29yZGluZyB7XG4gIHRpdGxlPzogc3RyaW5nO1xuICB0aW1lb3V0PzogbnVtYmVyO1xuICBzdGVwczogRFRTdGVwW107XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0RldlRvb2xzUmVjb3JkaW5nKGRhdGE6IHVua25vd24pOiBkYXRhIGlzIERUUmVjb3JkaW5nIHtcbiAgaWYgKCFkYXRhIHx8IHR5cGVvZiBkYXRhICE9PSBcIm9iamVjdFwiIHx8ICFBcnJheS5pc0FycmF5KChkYXRhIGFzIERUUmVjb3JkaW5nKS5zdGVwcykpIHJldHVybiBmYWxzZTtcbiAgY29uc3Qgc3RlcHMgPSAoZGF0YSBhcyBEVFJlY29yZGluZykuc3RlcHM7XG4gIHJldHVybiBcInRpdGxlXCIgaW4gZGF0YSAmJiBzdGVwcy5zb21lKChzKSA9PiBzICYmIChzLnR5cGUgPT09IFwic2V0Vmlld3BvcnRcIiB8fCBBcnJheS5pc0FycmF5KHMuc2VsZWN0b3JzKSB8fCBzLnR5cGUgPT09IFwibmF2aWdhdGVcIiAmJiBcInVybFwiIGluIHMpKTtcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIEltcG9ydGFyIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIFRyYWR1Y2UgbG9zIHNlbGVjdG9yZXMgZGUgUmVjb3JkZXIgYSBsb3MgZGUgUmFzdHJvLiBDYWRhIGVudHJhZGEgZXMgdW5hIGNhZGVuYVxuICogKHZhcmlhcyBwYXJ0ZXMgPSBhdHJhdmVzYXIgc2hhZG93IHJvb3RzOyBub3MgcXVlZGFtb3MgY29uIGxhcyBkZSB1bmEgc29sYSBwYXJ0ZSkuXG4gKi9cbmZ1bmN0aW9uIG1hcFNlbGVjdG9ycyhyYXc6IChzdHJpbmcgfCBzdHJpbmdbXSlbXSB8IHVuZGVmaW5lZCwgaXNJbnB1dDogYm9vbGVhbik6IHsgc2VsZWN0b3JzOiBzdHJpbmdbXTsgbmFtZT86IHN0cmluZyB9IHtcbiAgY29uc3Qgc3RhYmxlOiBzdHJpbmdbXSA9IFtdOyAvLyAjaWQsIFthdHJpYnV0b11cbiAgY29uc3QgbmFtZWQ6IHN0cmluZ1tdID0gW107IC8vIHRleHQ9IC8gbGFiZWw9XG4gIGNvbnN0IHBvc2l0aW9uYWw6IHN0cmluZ1tdID0gW107IC8vIHJ1dGFzIENTUyBjb24gbnRoLW9mLXR5cGXigKZcbiAgY29uc3QgeHBhdGg6IHN0cmluZ1tdID0gW107XG4gIGxldCBuYW1lOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGZvciAoY29uc3QgZW50cnkgb2YgcmF3ID8/IFtdKSB7XG4gICAgY29uc3QgcGFydHMgPSBBcnJheS5pc0FycmF5KGVudHJ5KSA/IGVudHJ5IDogW2VudHJ5XTtcbiAgICBpZiAocGFydHMubGVuZ3RoICE9PSAxKSBjb250aW51ZTtcbiAgICBjb25zdCBzID0gcGFydHNbMF0hO1xuICAgIC8vIFJlY29yZGVyIG5vIHNhYmUgcXXDqSBpZHMgc29uIGFsZWF0b3Jpb3M6ICNlbC1pZC03NDQwLTE2NTggZGVqYXLDrWEgZGUgZXhpc3RpciBlbiBsYSBwcsOzeGltYSBjYXJnYS5cbiAgICBpZiAoaGFzR2VuZXJhdGVkSWQocykpIGNvbnRpbnVlO1xuICAgIGlmIChzLnN0YXJ0c1dpdGgoXCJhcmlhL1wiKSkge1xuICAgICAgY29uc3QgbiA9IHMuc2xpY2UoNSkucmVwbGFjZSgvXFxbcm9sZT1cIlteXCJdKlwiXFxdJC8sIFwiXCIpO1xuICAgICAgbmFtZSA/Pz0gbi5yZXBsYWNlKC9cXHMqXFwqJC8sIFwiXCIpO1xuICAgICAgaWYgKGlzSW5wdXQpIG5hbWVkLnB1c2goYGxhYmVsPSR7bi5yZXBsYWNlKC9cXHMqXFwqJC8sIFwiXCIpfWApO1xuICAgICAgZWxzZSBuYW1lZC5wdXNoKGB0ZXh0PSR7bn1gLCBgW2FyaWEtbGFiZWw9JHtKU09OLnN0cmluZ2lmeShuKX1dYCk7XG4gICAgfSBlbHNlIGlmIChzLnN0YXJ0c1dpdGgoXCJ0ZXh0L1wiKSkge1xuICAgICAgbmFtZSA/Pz0gcy5zbGljZSg1KTtcbiAgICAgIG5hbWVkLnB1c2goYHRleHQ9JHtzLnNsaWNlKDUpfWApO1xuICAgIH0gZWxzZSBpZiAocy5zdGFydHNXaXRoKFwieHBhdGgvXCIpKSB4cGF0aC5wdXNoKGB4cGF0aD0ke3Muc2xpY2UoNil9YCk7XG4gICAgZWxzZSB7XG4gICAgICBjb25zdCBjc3MgPSBzLnN0YXJ0c1dpdGgoXCJwaWVyY2UvXCIpID8gcy5zbGljZSg3KSA6IHM7XG4gICAgICAoL14jW1xcdy1dKyR8XltcXHctXSpcXFtbXlxcXV0rXFxdJC8udGVzdChjc3MpID8gc3RhYmxlIDogcG9zaXRpb25hbCkucHVzaChjc3MpO1xuICAgIH1cbiAgfVxuICByZXR1cm4geyBzZWxlY3RvcnM6IFsuLi5uZXcgU2V0KFsuLi5zdGFibGUsIC4uLm5hbWVkLCAuLi5wb3NpdGlvbmFsLCAuLi54cGF0aF0pXS5zbGljZSgwLCA2KSwgbmFtZSB9O1xufVxuXG5mdW5jdGlvbiBoYXNHZW5lcmF0ZWRJZChzZWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBpZHMgPSBbLi4uc2VsLm1hdGNoQWxsKC8jKCg/OlxcXFwufFtcXHctXSkrKS9nKSwgLi4uc2VsLm1hdGNoQWxsKC9AaWQ9W1wiJ10oW15cIiddKylbXCInXS9nKSwgLi4uc2VsLm1hdGNoQWxsKC9cXFtpZD1bXCInXT8oW15cIidcXF1dKykvZyldO1xuICByZXR1cm4gaWRzLnNvbWUoKG0pID0+IGxvb2tzR2VuZXJhdGVkKG1bMV0hLnJlcGxhY2UoL1xcXFwvZywgXCJcIikpKTtcbn1cblxuZnVuY3Rpb24gbWFwRnJhbWUoZnJhbWU6IG51bWJlcltdIHwgdW5kZWZpbmVkKTogRnJhbWVSZWZbXSB8IHVuZGVmaW5lZCB7XG4gIHJldHVybiBmcmFtZT8ubGVuZ3RoID8gZnJhbWUubWFwKChpKSA9PiAoeyBzZWxlY3RvcjogYGZyYW1lPSR7aX1gIH0pKSA6IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGZyb21EZXZUb29scyhyZWM6IERUUmVjb3JkaW5nKTogeyBmbG93OiBGbG93OyBza2lwcGVkOiBzdHJpbmdbXSB9IHtcbiAgY29uc3Qgc3RlcHM6IFN0ZXBbXSA9IFtdO1xuICBjb25zdCBza2lwcGVkOiBzdHJpbmdbXSA9IFtdO1xuICBmb3IgKGNvbnN0IHMgb2YgcmVjLnN0ZXBzKSB7XG4gICAgaWYgKHMudGFyZ2V0ICYmIHMudGFyZ2V0ICE9PSBcIm1haW5cIikge1xuICAgICAgc2tpcHBlZC5wdXNoKGAke3MudHlwZX0gKGVuIG90cmEgdmVudGFuYSlgKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBpc0lucHV0ID0gcy50eXBlID09PSBcImNoYW5nZVwiO1xuICAgIGNvbnN0IG1hcHBlZCA9IG1hcFNlbGVjdG9ycyhzLnNlbGVjdG9ycywgaXNJbnB1dCk7XG4gICAgY29uc3QgW3NlbGVjdG9yLCAuLi5mYWxsYmFja3NdID0gbWFwcGVkLnNlbGVjdG9ycztcbiAgICBjb25zdCB0YXJnZXQgPSB7IHNlbGVjdG9yLCBmYWxsYmFja3MsIGZyYW1lOiBtYXBGcmFtZShzLmZyYW1lKSwgdGltZW91dDogcy50aW1lb3V0IH07XG4gICAgY29uc3QgbGFiZWwgPSBtYXBwZWQubmFtZSA/PyBzZWxlY3RvcjtcbiAgICBzd2l0Y2ggKHMudHlwZSkge1xuICAgICAgY2FzZSBcInNldFZpZXdwb3J0XCI6XG4gICAgICBjYXNlIFwia2V5VXBcIjpcbiAgICAgICAgYnJlYWs7IC8vIHNpbiBlcXVpdmFsZW50ZSAvIHJlZHVuZGFudGVcbiAgICAgIGNhc2UgXCJuYXZpZ2F0ZVwiOlxuICAgICAgICBzdGVwcy5wdXNoKG5ld1N0ZXAoeyB0eXBlOiBcIm5hdmlnYXRlXCIsIHZhbHVlOiBzLnVybCB9KSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNsaWNrXCI6XG4gICAgICBjYXNlIFwiZG91YmxlQ2xpY2tcIjpcbiAgICAgICAgaWYgKCFzZWxlY3Rvcikgc2tpcHBlZC5wdXNoKHMudHlwZSArIFwiIHNpbiBzZWxlY3RvciB1c2FibGVcIik7XG4gICAgICAgIGVsc2Ugc3RlcHMucHVzaChuZXdTdGVwKHsgdHlwZTogXCJjbGlja1wiLCAuLi50YXJnZXQsIGxhYmVsLCBub3RlOiBzLnR5cGUgPT09IFwiZG91YmxlQ2xpY2tcIiA/IFwiZG9ibGUgY2xpY2sgZW4gRGV2VG9vbHNcIiA6IHVuZGVmaW5lZCB9KSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNoYW5nZVwiOiB7XG4gICAgICAgIGlmICghc2VsZWN0b3IpIHtcbiAgICAgICAgICBza2lwcGVkLnB1c2goXCJjaGFuZ2Ugc2luIHNlbGVjdG9yIHVzYWJsZVwiKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICAvLyBSZWNvcmRlciBncmFiYSDCq2NsaWNrIGVuIGVsIGNhbXBvwrsgKyDCq2NoYW5nZcK7OiBlbCBjbGljayBzb2JyYS5cbiAgICAgICAgY29uc3QgcHJldiA9IHN0ZXBzLmF0KC0xKTtcbiAgICAgICAgaWYgKHByZXY/LnR5cGUgPT09IFwiY2xpY2tcIiAmJiBwcmV2LnNlbGVjdG9yID09PSBzZWxlY3RvciAmJiBKU09OLnN0cmluZ2lmeShwcmV2LmZyYW1lKSA9PT0gSlNPTi5zdHJpbmdpZnkodGFyZ2V0LmZyYW1lKSkgc3RlcHMucG9wKCk7XG4gICAgICAgIHN0ZXBzLnB1c2gobmV3U3RlcCh7IHR5cGU6IFwiZmlsbFwiLCAuLi50YXJnZXQsIGxhYmVsLCB2YWx1ZTogcy52YWx1ZSA/PyBcIlwiIH0pKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlIFwia2V5RG93blwiOlxuICAgICAgICBzdGVwcy5wdXNoKG5ld1N0ZXAoeyB0eXBlOiBcInByZXNzXCIsIHZhbHVlOiBzLmtleSA/PyBcIkVudGVyXCIgfSkpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ3YWl0Rm9yRWxlbWVudFwiOlxuICAgICAgICBpZiAoc2VsZWN0b3IpIHN0ZXBzLnB1c2gobmV3U3RlcCh7IHR5cGU6IFwid2FpdEZvclwiLCAuLi50YXJnZXQsIGxhYmVsIH0pKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBza2lwcGVkLnB1c2gocy50eXBlKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgZmxvdyA9IG5ld0Zsb3coeyBuYW1lOiByZWMudGl0bGUgfHwgXCJHcmFiYWNpw7NuIGRlIERldlRvb2xzXCIsIHRhZ3M6IFtcImRldnRvb2xzXCJdLCBzdGVwcyB9KTtcbiAgcmV0dXJuIHsgZmxvdywgc2tpcHBlZCB9O1xufVxuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgRXhwb3J0YXIg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmZ1bmN0aW9uIHRvRFRTZWxlY3RvcihzZWw6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcInRleHQ9XCIpKSByZXR1cm4gYHRleHQvJHtzZWwuc2xpY2UoNSl9YDtcbiAgaWYgKHNlbC5zdGFydHNXaXRoKFwibGFiZWw9XCIpKSByZXR1cm4gYGFyaWEvJHtzZWwuc2xpY2UoNil9YDtcbiAgaWYgKHNlbC5zdGFydHNXaXRoKFwieHBhdGg9XCIpKSByZXR1cm4gYHhwYXRoLyR7c2VsLnNsaWNlKDYpfWA7XG4gIHJldHVybiBzZWw7XG59XG5cbi8qKiBFeHBvcnRhIGFsIGZvcm1hdG8gZGUgRGV2VG9vbHMgUmVjb3JkZXIuIExvcyBwYXNvcyBkZW50cm8gZGUgaWZyYW1lcyBwaWVyZGVuIGxhIHJ1dGEgKFJlY29yZGVyIHVzYSDDrW5kaWNlcykuICovXG5leHBvcnQgZnVuY3Rpb24gdG9EZXZUb29scyhmbG93OiBGbG93KTogeyBqc29uOiBEVFJlY29yZGluZzsgd2FybmluZ3M6IG51bWJlciB9IHtcbiAgY29uc3Qgc3RlcHM6IERUU3RlcFtdID0gW1xuICAgIHsgdHlwZTogXCJzZXRWaWV3cG9ydFwiLCB3aWR0aDogMTI4MCwgaGVpZ2h0OiA4MDAsIGRldmljZVNjYWxlRmFjdG9yOiAxLCBpc01vYmlsZTogZmFsc2UsIGhhc1RvdWNoOiBmYWxzZSwgaXNMYW5kc2NhcGU6IGZhbHNlIH0sXG4gIF07XG4gIGxldCB3YXJuaW5ncyA9IDA7XG4gIGZvciAoY29uc3QgcyBvZiBmbG93LnN0ZXBzKSB7XG4gICAgaWYgKCFzLmVuYWJsZWQpIGNvbnRpbnVlO1xuICAgIGlmIChzLmZyYW1lPy5sZW5ndGgpIHdhcm5pbmdzKys7XG4gICAgY29uc3Qgc2VsZWN0b3JzID0gW3Muc2VsZWN0b3IsIC4uLihzLmZhbGxiYWNrcyA/PyBbXSldLmZpbHRlcihCb29sZWFuKS5tYXAoKHgpID0+IFt0b0RUU2VsZWN0b3IoeCEpXSk7XG4gICAgY29uc3QgYmFzZSA9IHsgdGFyZ2V0OiBcIm1haW5cIiwgc2VsZWN0b3JzLCAuLi4ocy50aW1lb3V0ID8geyB0aW1lb3V0OiBzLnRpbWVvdXQgfSA6IHt9KSB9O1xuICAgIHN3aXRjaCAocy50eXBlKSB7XG4gICAgICBjYXNlIFwibmF2aWdhdGVcIjpcbiAgICAgICAgc3RlcHMucHVzaCh7IHR5cGU6IFwibmF2aWdhdGVcIiwgdXJsOiBzLnZhbHVlID8/IFwiXCIgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNsaWNrXCI6XG4gICAgICBjYXNlIFwiY2hlY2tcIjpcbiAgICAgICAgc3RlcHMucHVzaCh7IHR5cGU6IFwiY2xpY2tcIiwgLi4uYmFzZSwgb2Zmc2V0WDogMSwgb2Zmc2V0WTogMSB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiZmlsbFwiOlxuICAgICAgY2FzZSBcInNlbGVjdFwiOlxuICAgICAgICBzdGVwcy5wdXNoKHsgdHlwZTogXCJjaGFuZ2VcIiwgLi4uYmFzZSwgdmFsdWU6IHMudmFsdWUgPz8gXCJcIiB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwicHJlc3NcIjpcbiAgICAgICAgc3RlcHMucHVzaCh7IHR5cGU6IFwia2V5RG93blwiLCB0YXJnZXQ6IFwibWFpblwiLCBrZXk6IHMudmFsdWUgfHwgXCJFbnRlclwiIH0sIHsgdHlwZTogXCJrZXlVcFwiLCB0YXJnZXQ6IFwibWFpblwiLCBrZXk6IHMudmFsdWUgfHwgXCJFbnRlclwiIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ3YWl0Rm9yXCI6XG4gICAgICAgIHN0ZXBzLnB1c2goeyB0eXBlOiBcIndhaXRGb3JFbGVtZW50XCIsIC4uLmJhc2UgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImFzc2VydFRleHRcIjpcbiAgICAgICAgc3RlcHMucHVzaCh7XG4gICAgICAgICAgdHlwZTogXCJ3YWl0Rm9yRXhwcmVzc2lvblwiLFxuICAgICAgICAgIHRhcmdldDogXCJtYWluXCIsXG4gICAgICAgICAgZXhwcmVzc2lvbjogYCgoKSA9PiB7IGNvbnN0IGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCR7SlNPTi5zdHJpbmdpZnkocy5zZWxlY3RvciA/PyBcIlwiKX0pOyByZXR1cm4gISFlICYmIChlLnZhbHVlID8/IGUuaW5uZXJUZXh0KS5pbmNsdWRlcygke0pTT04uc3RyaW5naWZ5KHMudmFsdWUgPz8gXCJcIil9KTsgfSkoKWAsXG4gICAgICAgIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJ3YWl0XCI6XG4gICAgICAgIHN0ZXBzLnB1c2goeyB0eXBlOiBcIndhaXRGb3JFeHByZXNzaW9uXCIsIHRhcmdldDogXCJtYWluXCIsIGV4cHJlc3Npb246IGBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dCgoKSA9PiByKHRydWUpLCAke051bWJlcihzLnZhbHVlKSB8fCAxMDAwfSkpYCB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGpzb246IHsgdGl0bGU6IGZsb3cubmFtZSwgc3RlcHMgfSwgd2FybmluZ3MgfTtcbn1cbiIsCiAgICAiaW1wb3J0IHsgZnJvbURldlRvb2xzLCBpc0RldlRvb2xzUmVjb3JkaW5nIH0gZnJvbSBcIi4vZGV2dG9vbHNcIjtcbmltcG9ydCB7IG5ld0Zsb3cgfSBmcm9tIFwiLi9zdG9yZVwiO1xuaW1wb3J0IHR5cGUgeyBFeHBvcnRGaWxlLCBGbG93LCBTdGVwLCBTdGVwVHlwZSB9IGZyb20gXCIuL3R5cGVzXCI7XG5pbXBvcnQgeyB1aWQgfSBmcm9tIFwiLi91dGlsXCI7XG5cbmV4cG9ydCBmdW5jdGlvbiB0b0V4cG9ydEZpbGUoZmxvd3M6IEZsb3dbXSk6IEV4cG9ydEZpbGUge1xuICByZXR1cm4geyBmb3JtYXQ6IFwicmFzdHJvXCIsIHZlcnNpb246IDEsIGV4cG9ydGVkQXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSwgZmxvd3M6IGZsb3dzLm1hcCgoZikgPT4gKHsgLi4uZiwgbGFzdFJ1bjogdW5kZWZpbmVkIH0pKSB9O1xufVxuXG5jb25zdCBTVEVQX1RZUEVTOiBTdGVwVHlwZVtdID0gW1wibmF2aWdhdGVcIiwgXCJjbGlja1wiLCBcImZpbGxcIiwgXCJzZWxlY3RcIiwgXCJjaGVja1wiLCBcInByZXNzXCIsIFwid2FpdFwiLCBcIndhaXRGb3JcIiwgXCJhc3NlcnRUZXh0XCJdO1xuXG5leHBvcnQgaW50ZXJmYWNlIEltcG9ydFJlc3VsdCB7XG4gIGZsb3dzOiBGbG93W107XG4gIHNvdXJjZTogXCJyYXN0cm9cIiB8IFwiZGV2dG9vbHNcIjtcbiAgLyoqIFBhc29zIHF1ZSBubyBzZSBwdWRpZXJvbiBjb252ZXJ0aXIgKGltcG9ydGFjacOzbiBkZXNkZSBEZXZUb29scykuICovXG4gIHNraXBwZWQ6IHN0cmluZ1tdO1xufVxuXG4vKiogQWNlcHRhIHVuIEV4cG9ydEZpbGUgZGUgUmFzdHJvLCB1biBGbG93IHN1ZWx0bywgdW4gYXJyYXkgZGUgRmxvdyBvIHVuYSBncmFiYWNpw7NuIGRlIERldlRvb2xzIFJlY29yZGVyLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlSW1wb3J0KHRleHQ6IHN0cmluZyk6IEltcG9ydFJlc3VsdCB7XG4gIGxldCBkYXRhOiB1bmtub3duO1xuICB0cnkge1xuICAgIGRhdGEgPSBKU09OLnBhcnNlKHRleHQpO1xuICB9IGNhdGNoIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJFbCBmaWNoZXJvIG5vIGVzIEpTT04gdsOhbGlkb1wiKTtcbiAgfVxuICBpZiAoaXNEZXZUb29sc1JlY29yZGluZyhkYXRhKSkge1xuICAgIGNvbnN0IHsgZmxvdywgc2tpcHBlZCB9ID0gZnJvbURldlRvb2xzKGRhdGEpO1xuICAgIHJldHVybiB7IGZsb3dzOiBbZmxvd10sIHNvdXJjZTogXCJkZXZ0b29sc1wiLCBza2lwcGVkIH07XG4gIH1cbiAgcmV0dXJuIHsgZmxvd3M6IHBhcnNlUmFzdHJvKGRhdGEpLCBzb3VyY2U6IFwicmFzdHJvXCIsIHNraXBwZWQ6IFtdIH07XG59XG5cbmZ1bmN0aW9uIHBhcnNlUmFzdHJvKGRhdGE6IHVua25vd24pOiBGbG93W10ge1xuICBjb25zdCByYXc6IHVua25vd25bXSA9IEFycmF5LmlzQXJyYXkoZGF0YSlcbiAgICA/IGRhdGFcbiAgICA6IGRhdGEgJiYgdHlwZW9mIGRhdGEgPT09IFwib2JqZWN0XCIgJiYgXCJmbG93c1wiIGluIGRhdGEgJiYgQXJyYXkuaXNBcnJheSgoZGF0YSBhcyBFeHBvcnRGaWxlKS5mbG93cylcbiAgICAgID8gKGRhdGEgYXMgRXhwb3J0RmlsZSkuZmxvd3NcbiAgICAgIDogZGF0YSAmJiB0eXBlb2YgZGF0YSA9PT0gXCJvYmplY3RcIiAmJiBcInN0ZXBzXCIgaW4gZGF0YVxuICAgICAgICA/IFtkYXRhXVxuICAgICAgICA6IFtdO1xuICBpZiAoIXJhdy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcihcIk5vIHNlIGVuY29udHJhcm9uIGZsdWpvcyBlbiBlbCBmaWNoZXJvXCIpO1xuXG4gIHJldHVybiByYXcubWFwKChyLCBpKSA9PiB7XG4gICAgY29uc3QgZiA9IHIgYXMgUGFydGlhbDxGbG93PjtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoZi5zdGVwcykpIHRocm93IG5ldyBFcnJvcihgRWwgZmx1am8gIyR7aSArIDF9IG5vIHRpZW5lIHBhc29zYCk7XG4gICAgY29uc3Qgc3RlcHM6IFN0ZXBbXSA9IGYuc3RlcHMubWFwKChzLCBqKSA9PiB7XG4gICAgICBpZiAoIXMgfHwgIVNURVBfVFlQRVMuaW5jbHVkZXMocy50eXBlKSkgdGhyb3cgbmV3IEVycm9yKGBQYXNvICR7aiArIDF9IGRlIMKrJHtmLm5hbWUgPz8gaSArIDF9wrs6IHRpcG8gZGVzY29ub2NpZG9gKTtcbiAgICAgIHJldHVybiB7IC4uLnMsIGlkOiB0eXBlb2Ygcy5pZCA9PT0gXCJzdHJpbmdcIiA/IHMuaWQgOiB1aWQoKSwgZW5hYmxlZDogcy5lbmFibGVkICE9PSBmYWxzZSB9O1xuICAgIH0pO1xuICAgIHJldHVybiBuZXdGbG93KHtcbiAgICAgIGlkOiB0eXBlb2YgZi5pZCA9PT0gXCJzdHJpbmdcIiA/IGYuaWQgOiB1aWQoKSxcbiAgICAgIG5hbWU6IFN0cmluZyhmLm5hbWUgPz8gYEltcG9ydGFkbyAke2kgKyAxfWApLFxuICAgICAgZGVzY3JpcHRpb246IGYuZGVzY3JpcHRpb24sXG4gICAgICBmb2xkZXI6IGYuZm9sZGVyLFxuICAgICAgdGFnczogQXJyYXkuaXNBcnJheShmLnRhZ3MpID8gZi50YWdzLm1hcChTdHJpbmcpIDogW10sXG4gICAgICB2YXJpYWJsZXM6IGYudmFyaWFibGVzICYmIHR5cGVvZiBmLnZhcmlhYmxlcyA9PT0gXCJvYmplY3RcIiA/IGYudmFyaWFibGVzIDoge30sXG4gICAgICBzdGVwcyxcbiAgICAgIGNyZWF0ZWRBdDogdHlwZW9mIGYuY3JlYXRlZEF0ID09PSBcIm51bWJlclwiID8gZi5jcmVhdGVkQXQgOiBEYXRlLm5vdygpLFxuICAgIH0pO1xuICB9KTtcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIFB1cHBldGVlciDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIFRyYWR1Y2UgdW4gc2VsZWN0b3IgZGUgUmFzdHJvIGEgbGEgc2ludGF4aXMgZGUgUHVwcGV0ZWVyLiAqL1xuZnVuY3Rpb24gcHBTZWxlY3RvcihzZWw6IHN0cmluZyk6IHN0cmluZyB7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcInRleHQ9XCIpKSByZXR1cm4gYDo6LXAtdGV4dCgke0pTT04uc3RyaW5naWZ5KHNlbC5zbGljZSg1KSl9KWA7XG4gIGlmIChzZWwuc3RhcnRzV2l0aChcImxhYmVsPVwiKSkgcmV0dXJuIGA6Oi1wLWFyaWEoJHtKU09OLnN0cmluZ2lmeShzZWwuc2xpY2UoNikpfSlgO1xuICBpZiAoc2VsLnN0YXJ0c1dpdGgoXCJ4cGF0aD1cIikpIHJldHVybiBgOjotcC14cGF0aCgke3NlbC5zbGljZSg2KX0pYDtcbiAgcmV0dXJuIHNlbDtcbn1cblxuY29uc3QganMgPSAoczogc3RyaW5nKSA9PiBKU09OLnN0cmluZ2lmeShzKTtcblxuLyoqIFZhbG9yIGNvbiB7e3ZhcmlhYmxlc319IOKGkiBleHByZXNpw7NuIEpTLiAqL1xuZnVuY3Rpb24ganNWYWx1ZSh2OiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoIS9cXHtcXHsvLnRlc3QodikpIHJldHVybiBqcyh2KTtcbiAgcmV0dXJuIFwidihcIiArIGpzKHYpICsgXCIpXCI7XG59XG5cbmZ1bmN0aW9uIGxvY2F0b3Ioc3RlcDogU3RlcCwgY3R4ID0gXCJwYWdlXCIpOiBzdHJpbmcge1xuICBjb25zdCBzZWxzID0gW3N0ZXAuc2VsZWN0b3IhLCAuLi4oc3RlcC5mYWxsYmFja3MgPz8gW10pXS5tYXAocHBTZWxlY3Rvcik7XG4gIGlmIChzZWxzLmxlbmd0aCA9PT0gMSkgcmV0dXJuIGAke2N0eH0ubG9jYXRvcigke2pzKHNlbHNbMF0hKX0pYDtcbiAgcmV0dXJuIGBMb2NhdG9yLnJhY2UoWyR7c2Vscy5tYXAoKHgpID0+IGAke2N0eH0ubG9jYXRvcigke2pzKHgpfSlgKS5qb2luKFwiLCBcIil9XSlgO1xufVxuXG4vKiogRXhwcmVzacOzbiBxdWUgcmVzdWVsdmUgZWwgZnJhbWUgZGVsIHBhc28gKG8gYHBhZ2VgKS4gKi9cbmZ1bmN0aW9uIGZyYW1lRXhwcihzdGVwOiBTdGVwKTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgaWYgKCFzdGVwLmZyYW1lPy5sZW5ndGgpIHJldHVybiB1bmRlZmluZWQ7XG4gIGNvbnN0IHBhdGggPSBzdGVwLmZyYW1lLm1hcCgoZikgPT4gW2Yuc2VsZWN0b3IsIC4uLihmLmZhbGxiYWNrcyA/PyBbXSldLm1hcChwcFNlbGVjdG9yKSk7XG4gIHJldHVybiBgYXdhaXQgZnJhbWVPZigke0pTT04uc3RyaW5naWZ5KHBhdGgpfSlgO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdG9QdXBwZXRlZXIoZmxvdzogRmxvdyk6IHN0cmluZyB7XG4gIGNvbnN0IG91dDogc3RyaW5nW10gPSBbXTtcbiAgb3V0LnB1c2goYC8vICR7Zmxvdy5uYW1lfSDigJQgZXhwb3J0YWRvIGRlc2RlIFJhc3RybyBlbCAke25ldyBEYXRlKCkudG9Mb2NhbGVTdHJpbmcoKX1gKTtcbiAgb3V0LnB1c2goYC8vIFJlcXVpZXJlOiBucG0gaSBwdXBwZXRlZXIgICDCtyAgIEVqZWN1dGFyOiBub2RlICR7c2x1ZyhmbG93Lm5hbWUpfS5tanMgIChvIGJ1bilgKTtcbiAgb3V0LnB1c2goYGltcG9ydCBwdXBwZXRlZXIsIHsgTG9jYXRvciB9IGZyb20gXCJwdXBwZXRlZXJcIjtgKTtcbiAgb3V0LnB1c2goXCJcIik7XG4gIG91dC5wdXNoKGBjb25zdCBUID0gODAwMDtgKTtcbiAgb3V0LnB1c2goYGNvbnN0IHZhcnMgPSAke0pTT04uc3RyaW5naWZ5KGZsb3cudmFyaWFibGVzID8/IHt9LCBudWxsLCAyKX07YCk7XG4gIG91dC5wdXNoKGBjb25zdCBidWlsdGlucyA9IHtgKTtcbiAgb3V0LnB1c2goYCAgJHRpbWVzdGFtcDogU3RyaW5nKERhdGUubm93KCkpLGApO1xuICBvdXQucHVzaChgICAkdXVpZDogY3J5cHRvLnJhbmRvbVVVSUQoKSxgKTtcbiAgb3V0LnB1c2goYCAgJHJhbmRvbUludDogU3RyaW5nKE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDFlNikpLGApO1xuICBvdXQucHVzaChgICAkcmFuZG9tRW1haWw6IFxcYHRlc3QrXFwke0RhdGUubm93KCkudG9TdHJpbmcoMzYpfUBleGFtcGxlLmNvbVxcYCxgKTtcbiAgb3V0LnB1c2goYCAgJHRvZGF5OiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApLGApO1xuICBvdXQucHVzaChgfTtgKTtcbiAgb3V0LnB1c2goYGNvbnN0IHYgPSAocykgPT4gcy5yZXBsYWNlKC9cXFxce1xcXFx7XFxcXHMqKFskXFxcXHcuLV0rKVxcXFxzKlxcXFx9XFxcXH0vZywgKG0sIGspID0+IHZhcnNba10gIT0gbnVsbCA/IHYodmFyc1trXSkgOiBidWlsdGluc1trXSA/PyBtKTtgKTtcbiAgb3V0LnB1c2goXCJcIik7XG4gIGlmIChmbG93LnN0ZXBzLnNvbWUoKHN0KSA9PiBzdC5mcmFtZT8ubGVuZ3RoKSkge1xuICAgIG91dC5wdXNoKGAvKiogQmFqYSBwb3IgbGEgcnV0YSBkZSBpZnJhbWVzOiBlbiBjYWRhIG5pdmVsLCBlbCBwcmltZXIgc2VsZWN0b3IgcXVlIGFwYXJlemNhLiAqL2ApO1xuICAgIG91dC5wdXNoKGBhc3luYyBmdW5jdGlvbiBmcmFtZU9mKHBhdGgpIHtgKTtcbiAgICBvdXQucHVzaChgICBsZXQgZiA9IHBhZ2UubWFpbkZyYW1lKCk7YCk7XG4gICAgb3V0LnB1c2goYCAgZm9yIChjb25zdCBzZWxzIG9mIHBhdGgpIHtgKTtcbiAgICBvdXQucHVzaChgICAgIGNvbnN0IGVsID0gYXdhaXQgTG9jYXRvci5yYWNlKHNlbHMubWFwKChzKSA9PiBmLmxvY2F0b3IocykpKS53YWl0SGFuZGxlKCk7YCk7XG4gICAgb3V0LnB1c2goYCAgICBmID0gYXdhaXQgZWwuY29udGVudEZyYW1lKCk7YCk7XG4gICAgb3V0LnB1c2goYCAgfWApO1xuICAgIG91dC5wdXNoKGAgIHJldHVybiBmO2ApO1xuICAgIG91dC5wdXNoKGB9YCk7XG4gICAgb3V0LnB1c2goXCJcIik7XG4gIH1cbiAgb3V0LnB1c2goYGNvbnN0IGJyb3dzZXIgPSBhd2FpdCBwdXBwZXRlZXIubGF1bmNoKHsgaGVhZGxlc3M6IHByb2Nlc3MuZW52LkhFQURMRVNTICE9PSBcIjBcIiA/IFwibmV3XCIgOiBmYWxzZSB9KTtgKTtcbiAgb3V0LnB1c2goYGNvbnN0IHBhZ2UgPSBhd2FpdCBicm93c2VyLm5ld1BhZ2UoKTtgKTtcbiAgb3V0LnB1c2goYHBhZ2Uuc2V0RGVmYXVsdFRpbWVvdXQoVCk7YCk7XG4gIG91dC5wdXNoKGB0cnkge2ApO1xuXG4gIGZsb3cuc3RlcHMuZm9yRWFjaCgocywgaSkgPT4ge1xuICAgIGNvbnN0IGNvbW1lbnQgPSBgICAvLyAke2kgKyAxfS4gJHtzLnR5cGV9JHtzLmxhYmVsID8gYCDCtyAke3MubGFiZWx9YCA6IFwiXCJ9YDtcbiAgICBpZiAoIXMuZW5hYmxlZCkge1xuICAgICAgb3V0LnB1c2goY29tbWVudCArIFwiIChkZXNhY3RpdmFkbylcIik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIG91dC5wdXNoKGNvbW1lbnQpO1xuICAgIGNvbnN0IHZhbCA9IHMudmFsdWUgPz8gXCJcIjtcbiAgICBjb25zdCBmciA9IGZyYW1lRXhwcihzKTtcbiAgICBjb25zdCBjdHggPSBmciA/IFwiZlwiIDogXCJwYWdlXCI7XG4gICAgY29uc3QgbG9jID0gKCkgPT4gbG9jYXRvcihzLCBjdHgpO1xuICAgIGlmIChmciAmJiBzLnR5cGUgIT09IFwibmF2aWdhdGVcIiAmJiBzLnR5cGUgIT09IFwid2FpdFwiKSBvdXQucHVzaChgICB7YCwgYCAgY29uc3QgZiA9ICR7ZnJ9O2ApO1xuICAgIHN3aXRjaCAocy50eXBlKSB7XG4gICAgICBjYXNlIFwibmF2aWdhdGVcIjpcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgcGFnZS5nb3RvKCR7anNWYWx1ZSh2YWwpfSwgeyB3YWl0VW50aWw6IFwibmV0d29ya2lkbGUyXCIgfSk7YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNsaWNrXCI6XG4gICAgICAgIG91dC5wdXNoKGAgIGF3YWl0IFByb21pc2UuYWxsKFtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBwYWdlLndhaXRGb3JOYXZpZ2F0aW9uKHsgdGltZW91dDogMTUwMCB9KS5jYXRjaCgoKSA9PiB7fSksYCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgJHtsb2MoKX0uY2xpY2soKSxgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgXSk7YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImZpbGxcIjpcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgJHtsb2MoKX0uZmlsbCgke2pzVmFsdWUodmFsKX0pO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJzZWxlY3RcIjpcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgJHtjdHh9LnNlbGVjdCgke2pzKHBwU2VsZWN0b3Iocy5zZWxlY3RvciEpKX0sICR7anNWYWx1ZSh2YWwpfSk7YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNoZWNrXCI6XG4gICAgICAgIG91dC5wdXNoKGAgIHtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBjb25zdCBlbCA9IGF3YWl0ICR7bG9jKCl9LndhaXRIYW5kbGUoKTtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBpZiAoKGF3YWl0IGVsLmV2YWx1YXRlKChlKSA9PiBlLmNoZWNrZWQgPz8gZS5nZXRBdHRyaWJ1dGUoXCJhcmlhLWNoZWNrZWRcIikgPT09IFwidHJ1ZVwiKSkgIT09ICR7dmFsICE9PSBcImZhbHNlXCJ9KSBhd2FpdCBlbC5jbGljaygpO2ApO1xuICAgICAgICBvdXQucHVzaChgICB9YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcInByZXNzXCI6XG4gICAgICAgIGlmIChzLnNlbGVjdG9yKSBvdXQucHVzaChgICBhd2FpdCAke2xvYygpfS5jbGljaygpO2ApO1xuICAgICAgICBvdXQucHVzaChgICBhd2FpdCBQcm9taXNlLmFsbChbYCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgcGFnZS53YWl0Rm9yTmF2aWdhdGlvbih7IHRpbWVvdXQ6IDE1MDAgfSkuY2F0Y2goKCkgPT4ge30pLGApO1xuICAgICAgICBvdXQucHVzaChgICAgIHBhZ2Uua2V5Ym9hcmQucHJlc3MoJHtqcyh2YWwgfHwgXCJFbnRlclwiKX0pLGApO1xuICAgICAgICBvdXQucHVzaChgICBdKTtgKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwid2FpdFwiOlxuICAgICAgICBvdXQucHVzaChgICBhd2FpdCBuZXcgUHJvbWlzZSgocikgPT4gc2V0VGltZW91dChyLCAke051bWJlcih2YWwpIHx8IDEwMDB9KSk7YCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcIndhaXRGb3JcIjpcbiAgICAgICAgb3V0LnB1c2goYCAgYXdhaXQgJHtsb2MoKX0ud2FpdCgpO2ApO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJhc3NlcnRUZXh0XCI6XG4gICAgICAgIG91dC5wdXNoKGAgIHtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBjb25zdCBlbCA9IGF3YWl0ICR7bG9jKCl9LndhaXRIYW5kbGUoKTtgKTtcbiAgICAgICAgb3V0LnB1c2goYCAgICBjb25zdCB0eHQgPSBhd2FpdCBlbC5ldmFsdWF0ZSgoZSkgPT4gZS52YWx1ZSA/PyBlLmlubmVyVGV4dCk7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgICAgaWYgKCF0eHQuaW5jbHVkZXMoJHtqc1ZhbHVlKHZhbCl9KSkgdGhyb3cgbmV3IEVycm9yKFxcYFBhc28gJHtpICsgMX06IHNlIGVzcGVyYWJhICR7dmFsLnJlcGxhY2UoL1tgJFxcXFxdL2csIFwiXCIpfSB5IGhheSBcXCR7dHh0fVxcYCk7YCk7XG4gICAgICAgIG91dC5wdXNoKGAgIH1gKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGlmIChmciAmJiBzLnR5cGUgIT09IFwibmF2aWdhdGVcIiAmJiBzLnR5cGUgIT09IFwid2FpdFwiKSBvdXQucHVzaChgICB9YCk7XG4gIH0pO1xuXG4gIG91dC5wdXNoKGAgIGNvbnNvbGUubG9nKFwi4pyTICR7Zmxvdy5uYW1lLnJlcGxhY2UoL1wiL2csIFwiJ1wiKX06IE9LXCIpO2ApO1xuICBvdXQucHVzaChgfSBjYXRjaCAoZSkge2ApO1xuICBvdXQucHVzaChgICBjb25zb2xlLmVycm9yKFwi4pyXXCIsIGUubWVzc2FnZSk7YCk7XG4gIG91dC5wdXNoKGAgIGF3YWl0IHBhZ2Uuc2NyZWVuc2hvdCh7IHBhdGg6IFwicmFzdHJvLWVycm9yLnBuZ1wiIH0pO2ApO1xuICBvdXQucHVzaChgICBwcm9jZXNzLmV4aXRDb2RlID0gMTtgKTtcbiAgb3V0LnB1c2goYH0gZmluYWxseSB7YCk7XG4gIG91dC5wdXNoKGAgIGF3YWl0IGJyb3dzZXIuY2xvc2UoKTtgKTtcbiAgb3V0LnB1c2goYH1gKTtcbiAgcmV0dXJuIG91dC5qb2luKFwiXFxuXCIpICsgXCJcXG5cIjtcbn1cblxuZXhwb3J0IGNvbnN0IHNsdWcgPSAoczogc3RyaW5nKSA9PlxuICBzXG4gICAgLm5vcm1hbGl6ZShcIk5GRFwiKVxuICAgIC5yZXBsYWNlKC9bzIAtza9dL2csIFwiXCIpXG4gICAgLnRvTG93ZXJDYXNlKClcbiAgICAucmVwbGFjZSgvW15hLXowLTldKy9nLCBcIi1cIilcbiAgICAucmVwbGFjZSgvXi18LSQvZywgXCJcIikgfHwgXCJmbHVqb1wiO1xuIiwKICAgICIvLyBPcnF1ZXN0YWRvciBkZSBsYSByZXByb2R1Y2Npw7NuLiBWaXZlIGVuIGVsIHNpZGUgcGFuZWw6IG1hbmRhIGNhZGEgcGFzbyBhbCBjb250ZW50XG4vLyBzY3JpcHQgZGUgbGEgcGVzdGHDsWEgeSBnZXN0aW9uYSBuYXZlZ2FjaW9uZXMgZW50cmUgcMOhZ2luYXMgKHF1ZSBtYXRhbiBhbCBjb250ZW50IHNjcmlwdCkuXG5pbXBvcnQgdHlwZSB7IFN0ZXBSZXN1bHQsIFRvQ29udGVudCB9IGZyb20gXCIuLi9zaGFyZWQvbWVzc2FnZXNcIjtcbmltcG9ydCB0eXBlIHsgRnJhbWVSZWYsIEZsb3csIFJ1blN1bW1hcnksIFNldHRpbmdzLCBTdGVwIH0gZnJvbSBcIi4uL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHsgQlVJTFRJTl9WQVJTLCBpbnRlcnBvbGF0ZSwgc2xlZXAgfSBmcm9tIFwiLi4vc2hhcmVkL3V0aWxcIjtcblxuZXhwb3J0IHR5cGUgU3RlcFN0YXR1cyA9IFwicGVuZGluZ1wiIHwgXCJydW5uaW5nXCIgfCBcIm9rXCIgfCBcImVycm9yXCIgfCBcInNraXBwZWRcIjtcblxuZXhwb3J0IGludGVyZmFjZSBSdW5Ib29rcyB7XG4gIG9uU3RhdHVzKHN0ZXBJZDogc3RyaW5nLCBzdGF0dXM6IFN0ZXBTdGF0dXMsIGluZm8/OiBzdHJpbmcpOiB2b2lkO1xufVxuXG5jb25zdCBQT1JUX0NMT1NFRCA9IC9tZXNzYWdlIHBvcnQgY2xvc2VkfFJlY2VpdmluZyBlbmQgZG9lcyBub3QgZXhpc3R8YmFja1xcL2ZvcndhcmQgY2FjaGV8Y29udGV4dCBpbnZhbGlkYXRlZC9pO1xuXG4vKiogcGFuZWwuaHRtbD90YWI9PGlkPiBmaWphIGVsIHBhbmVsIGEgdW5hIHBlc3Rhw7FhIGNvbmNyZXRhICjDunRpbCBhYmllcnRvIGNvbW8gcGVzdGHDsWEgbyBlbiB0ZXN0cykuICovXG5jb25zdCBwaW5uZWRUYWIgPSBOdW1iZXIobmV3IFVSTFNlYXJjaFBhcmFtcyhsb2NhdGlvbi5zZWFyY2gpLmdldChcInRhYlwiKSkgfHwgdW5kZWZpbmVkO1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYWN0aXZlVGFiKCk6IFByb21pc2U8Y2hyb21lLnRhYnMuVGFiPiB7XG4gIGlmIChwaW5uZWRUYWIpIHJldHVybiBjaHJvbWUudGFicy5nZXQocGlubmVkVGFiKTtcbiAgY29uc3QgW3RhYl0gPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgaWYgKCF0YWI/LmlkKSB0aHJvdyBuZXcgRXJyb3IoXCJObyBoYXkgcGVzdGHDsWEgYWN0aXZhXCIpO1xuICByZXR1cm4gdGFiO1xufVxuXG5hc3luYyBmdW5jdGlvbiB3YWl0Rm9yTG9hZCh0YWJJZDogbnVtYmVyLCB0aW1lb3V0ID0gMzAwMDApIHtcbiAgY29uc3Qgc3RhcnQgPSBEYXRlLm5vdygpO1xuICB3aGlsZSAoRGF0ZS5ub3coKSAtIHN0YXJ0IDwgdGltZW91dCkge1xuICAgIGNvbnN0IHQgPSBhd2FpdCBjaHJvbWUudGFicy5nZXQodGFiSWQpO1xuICAgIGlmICh0LnN0YXR1cyA9PT0gXCJjb21wbGV0ZVwiKSByZXR1cm47XG4gICAgYXdhaXQgc2xlZXAoMTIwKTtcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXCJMYSBww6FnaW5hIHRhcmTDsyBkZW1hc2lhZG8gZW4gY2FyZ2FyXCIpO1xufVxuXG4vKiogT2JzZXJ2YSBuYXZlZ2FjaW9uZXMgZGUgcMOhZ2luYSBjb21wbGV0YSBlbiBsYSBwZXN0YcOxYSAoaW5pY2lvIHkgZmluKS4gKi9cbmZ1bmN0aW9uIHdhdGNoTmF2aWdhdGlvbnModGFiSWQ6IG51bWJlciwgZnJhbWVJZCA9IDApIHtcbiAgbGV0IHN0YXJ0ZWQgPSBmYWxzZTtcbiAgbGV0IHBlbmRpbmcgPSAwO1xuICBjb25zdCBtaW5lID0gKGQ6IHsgdGFiSWQ6IG51bWJlcjsgZnJhbWVJZDogbnVtYmVyIH0pID0+IGQudGFiSWQgPT09IHRhYklkICYmIChkLmZyYW1lSWQgPT09IDAgfHwgZC5mcmFtZUlkID09PSBmcmFtZUlkKTtcbiAgY29uc3Qgb25TdGFydCA9IChkOiBjaHJvbWUud2ViTmF2aWdhdGlvbi5XZWJOYXZpZ2F0aW9uUGFyZW50ZWRDYWxsYmFja0RldGFpbHMpID0+IHtcbiAgICBpZiAobWluZShkKSkgKHN0YXJ0ZWQgPSB0cnVlKSwgcGVuZGluZysrO1xuICB9O1xuICBjb25zdCBvbkVuZCA9IChkOiB7IHRhYklkOiBudW1iZXI7IGZyYW1lSWQ6IG51bWJlciB9KSA9PiB7XG4gICAgaWYgKG1pbmUoZCkpIHBlbmRpbmcgPSBNYXRoLm1heCgwLCBwZW5kaW5nIC0gMSk7XG4gIH07XG4gIGNvbnN0IG5hdiA9IGNocm9tZS53ZWJOYXZpZ2F0aW9uO1xuICBuYXYub25CZWZvcmVOYXZpZ2F0ZS5hZGRMaXN0ZW5lcihvblN0YXJ0KTtcbiAgbmF2Lm9uQ29tcGxldGVkLmFkZExpc3RlbmVyKG9uRW5kKTtcbiAgbmF2Lm9uRXJyb3JPY2N1cnJlZC5hZGRMaXN0ZW5lcihvbkVuZCk7XG4gIHJldHVybiB7XG4gICAgLyoqIMK/RW1wZXrDsyBhbGd1bmEgbmF2ZWdhY2nDs24gZW4gbG9zIHByw7N4aW1vcyBgd2l0aGluYCBtcz8gKi9cbiAgICBhc3luYyBzdGFydGVkKHdpdGhpbjogbnVtYmVyKSB7XG4gICAgICBjb25zdCBlbmQgPSBEYXRlLm5vdygpICsgd2l0aGluO1xuICAgICAgd2hpbGUgKCFzdGFydGVkICYmIERhdGUubm93KCkgPCBlbmQpIGF3YWl0IHNsZWVwKDUwKTtcbiAgICAgIHJldHVybiBzdGFydGVkO1xuICAgIH0sXG4gICAgLyoqIEVzcGVyYSBhIHF1ZSB0ZXJtaW5lbiBsYXMgbmF2ZWdhY2lvbmVzIGVuIGN1cnNvLiAqL1xuICAgIGFzeW5jIHNldHRsZWQodGltZW91dCA9IDMwMDAwKSB7XG4gICAgICBjb25zdCBlbmQgPSBEYXRlLm5vdygpICsgdGltZW91dDtcbiAgICAgIHdoaWxlIChwZW5kaW5nID4gMCkge1xuICAgICAgICBpZiAoRGF0ZS5ub3coKSA+IGVuZCkgdGhyb3cgbmV3IEVycm9yKFwiTGEgcMOhZ2luYSB0YXJkw7MgZGVtYXNpYWRvIGVuIGNhcmdhclwiKTtcbiAgICAgICAgYXdhaXQgc2xlZXAoODApO1xuICAgICAgfVxuICAgICAgYXdhaXQgd2FpdEZvckxvYWQodGFiSWQsIHRpbWVvdXQpO1xuICAgIH0sXG4gICAgZGlzcG9zZSgpIHtcbiAgICAgIG5hdi5vbkJlZm9yZU5hdmlnYXRlLnJlbW92ZUxpc3RlbmVyKG9uU3RhcnQpO1xuICAgICAgbmF2Lm9uQ29tcGxldGVkLnJlbW92ZUxpc3RlbmVyKG9uRW5kKTtcbiAgICAgIG5hdi5vbkVycm9yT2NjdXJyZWQucmVtb3ZlTGlzdGVuZXIob25FbmQpO1xuICAgIH0sXG4gIH07XG59XG5cbi8qKiBHYXJhbnRpemEgcXVlIGVsIGNvbnRlbnQgc2NyaXB0IHJlc3BvbmRlIGVuIGVsIGZyYW1lIChsbyBpbnllY3RhIHNpIGhhY2UgZmFsdGEpLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuc3VyZUNvbnRlbnQodGFiSWQ6IG51bWJlciwgZnJhbWVJZCA9IDApOiBQcm9taXNlPHZvaWQ+IHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAyMDsgaSsrKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHIgPSBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwgeyBraW5kOiBcInBpbmdcIiB9IHNhdGlzZmllcyBUb0NvbnRlbnQsIHsgZnJhbWVJZCB9KTtcbiAgICAgIGlmIChyPy5vaykgcmV0dXJuO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLyogYcO6biBubyBlc3TDoSAqL1xuICAgIH1cbiAgICBpZiAoaSA9PT0gMykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgLy8gUGVzdGHDsWEgYWJpZXJ0YSBhbnRlcyBkZSBpbnN0YWxhciBsYSBleHRlbnNpw7NuOiB0YW1iacOpbiBlbCBob29rIGRlIHJlZCAobXVuZG8gZGUgbGEgcMOhZ2luYSkuXG4gICAgICAgIGF3YWl0IGNocm9tZS5zY3JpcHRpbmcuZXhlY3V0ZVNjcmlwdCh7IHRhcmdldDogeyB0YWJJZCwgZnJhbWVJZHM6IFtmcmFtZUlkXSB9LCBmaWxlczogW1wiaG9vay5qc1wiXSwgd29ybGQ6IFwiTUFJTlwiIH0pLmNhdGNoKCgpID0+IHt9KTtcbiAgICAgICAgYXdhaXQgY2hyb21lLnNjcmlwdGluZy5leGVjdXRlU2NyaXB0KHsgdGFyZ2V0OiB7IHRhYklkLCBmcmFtZUlkczogW2ZyYW1lSWRdIH0sIGZpbGVzOiBbXCJjb250ZW50LmpzXCJdIH0pO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzZSBwdWVkZSBhY3R1YXIgZW4gZXN0YSBww6FnaW5hIChcIiArIChlIGFzIEVycm9yKS5tZXNzYWdlICsgXCIpXCIpO1xuICAgICAgfVxuICAgIH1cbiAgICBhd2FpdCBzbGVlcCgxNTApO1xuICB9XG4gIHRocm93IG5ldyBFcnJvcihmcmFtZUlkID8gXCJFbCBpZnJhbWUgbm8gcmVzcG9uZGVcIiA6IFwiRWwgY29udGVudCBzY3JpcHQgbm8gcmVzcG9uZGUgZW4gbGEgcGVzdGHDsWFcIik7XG59XG5cbi8qKiBFbnbDrWEgYSB1biBmcmFtZSBjb25jcmV0byAoMCA9IHDDoWdpbmEgcHJpbmNpcGFsKS4gTnVuY2EgYSB0b2RvczogY2FkYSBmcmFtZSBlamVjdXRhcsOtYSBlbCBwYXNvLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNlbmRUb1RhYjxUID0gdW5rbm93bj4odGFiSWQ6IG51bWJlciwgbXNnOiBUb0NvbnRlbnQsIGZyYW1lSWQgPSAwKTogUHJvbWlzZTxUPiB7XG4gIGF3YWl0IGVuc3VyZUNvbnRlbnQodGFiSWQsIGZyYW1lSWQpO1xuICByZXR1cm4gY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiSWQsIG1zZywgeyBmcmFtZUlkIH0pO1xufVxuXG4vKiogUmVjb3JyZSBsYSBydXRhIGRlIGlmcmFtZXMgZGVsIHBhc28geSBkZXZ1ZWx2ZSBlbCBmcmFtZUlkIGRlbCBkb2N1bWVudG8gZGVzdGluby4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmcmFtZUlkRm9yKHRhYklkOiBudW1iZXIsIGZyYW1lOiBGcmFtZVJlZltdIHwgdW5kZWZpbmVkLCB0aW1lb3V0OiBudW1iZXIpOiBQcm9taXNlPG51bWJlcj4ge1xuICBsZXQgZmlkID0gMDtcbiAgZm9yIChjb25zdCBbaSwgcmVmXSBvZiAoZnJhbWUgPz8gW10pLmVudHJpZXMoKSkge1xuICAgIGNvbnN0IGVuZCA9IERhdGUubm93KCkgKyB0aW1lb3V0O1xuICAgIGxldCBuZXh0OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgLy8gRWwgcGFkcmUgbG9jYWxpemEgZWwgPGlmcmFtZT4geSBsZSBtYW5kYSB1bmEgc29uZGE7IGVsIGNvbnRlbnQgc2NyaXB0IGRlbCBoaWpvIGxhIHJlcG9ydGFcbiAgICAvLyBhbCBiYWNrZ3JvdW5kIGNvbiBzdSBmcmFtZUlkLiBTaSBlbCBpZnJhbWUgYcO6biBjYXJnYSwgbGEgc29uZGEgc2UgcGllcmRlOiBzZSByZWludGVudGEuXG4gICAgd2hpbGUgKG5leHQgPT0gbnVsbCkge1xuICAgICAgY29uc3QgciA9IGF3YWl0IHNlbmRUb1RhYjx7IHRva2VuPzogc3RyaW5nOyBlcnJvcj86IHN0cmluZyB9PihcbiAgICAgICAgdGFiSWQsXG4gICAgICAgIHsga2luZDogXCJmcmFtZTpyZXNvbHZlXCIsIHNlbGVjdG9yczogW3JlZi5zZWxlY3RvciwgLi4uKHJlZi5mYWxsYmFja3MgPz8gW10pXSwgdGltZW91dDogTWF0aC5tYXgoMCwgZW5kIC0gRGF0ZS5ub3coKSkgfSxcbiAgICAgICAgZmlkLFxuICAgICAgKTtcbiAgICAgIGlmICghcj8udG9rZW4pIHRocm93IG5ldyBFcnJvcihgJHtyPy5lcnJvciA/PyBcIk5vIHNlIGVuY29udHLDsyBlbCBpZnJhbWVcIn0gKG5pdmVsICR7aSArIDF9KWApO1xuICAgICAgZm9yIChsZXQgayA9IDA7IGsgPCA4ICYmIG5leHQgPT0gbnVsbDsgaysrKSB7XG4gICAgICAgIGF3YWl0IHNsZWVwKDYwKTtcbiAgICAgICAgbmV4dCA9IChhd2FpdCBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IGtpbmQ6IFwiZnJhbWU6cHJvYmVkXCIsIHRva2VuOiByLnRva2VuIH0pKT8uZnJhbWVJZDtcbiAgICAgIH1cbiAgICAgIGlmIChuZXh0ID09IG51bGwgJiYgRGF0ZS5ub3coKSA+IGVuZCkgdGhyb3cgbmV3IEVycm9yKGBFbCBpZnJhbWUgwqske3JlZi5zZWxlY3Rvcn3CuyBubyByZXNwb25kZSAobml2ZWwgJHtpICsgMX0pYCk7XG4gICAgfVxuICAgIGZpZCA9IG5leHQ7XG4gIH1cbiAgcmV0dXJuIGZpZDtcbn1cblxuLyoqIFZhbG9yZXMgZGUgdmFyaWFibGVzIHBhcmEgdW5hIGVqZWN1Y2nDs246IGludGVncmFkYXMgZmlqYWRhcyB1bmEgdmV6ICsgbGFzIGRlbCBmbHVqby4gKi9cbmV4cG9ydCBmdW5jdGlvbiBydW5WYXJpYWJsZXMoZmxvdzogRmxvdyk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4ge1xuICBjb25zdCBiYXNlOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gIGZvciAoY29uc3QgYiBvZiBCVUlMVElOX1ZBUlMpIGJhc2VbYl0gPSBpbnRlcnBvbGF0ZShge3ske2J9fX1gLCB7fSk7XG4gIGNvbnN0IHZhcnMgPSB7IC4uLmJhc2UgfTtcbiAgZm9yIChjb25zdCBbaywgdl0gb2YgT2JqZWN0LmVudHJpZXMoZmxvdy52YXJpYWJsZXMgPz8ge30pKSB2YXJzW2tdID0gaW50ZXJwb2xhdGUodiwgYmFzZSk7XG4gIHJldHVybiB2YXJzO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlU3RlcChzdGVwOiBTdGVwLCB2YXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KTogU3RlcCB7XG4gIHJldHVybiB7IC4uLnN0ZXAsIHZhbHVlOiBzdGVwLnZhbHVlICE9IG51bGwgPyBpbnRlcnBvbGF0ZShzdGVwLnZhbHVlLCB2YXJzKSA6IHVuZGVmaW5lZCB9O1xufVxuXG5leHBvcnQgY2xhc3MgUnVubmVyIHtcbiAgcHJpdmF0ZSBzdG9wcGVkID0gZmFsc2U7XG4gIHJ1bm5pbmcgPSBmYWxzZTtcblxuICBzdG9wKCkge1xuICAgIHRoaXMuc3RvcHBlZCA9IHRydWU7XG4gIH1cblxuICBhc3luYyBydW4oZmxvdzogRmxvdywgc2V0dGluZ3M6IFNldHRpbmdzLCBob29rczogUnVuSG9va3MsIGZyb20gPSAwLCBvbmx5PzogbnVtYmVyKTogUHJvbWlzZTxSdW5TdW1tYXJ5PiB7XG4gICAgdGhpcy5zdG9wcGVkID0gZmFsc2U7XG4gICAgdGhpcy5ydW5uaW5nID0gdHJ1ZTtcbiAgICBjb25zdCB0MCA9IERhdGUubm93KCk7XG4gICAgY29uc3QgdmFycyA9IHJ1blZhcmlhYmxlcyhmbG93KTtcbiAgICBjb25zdCBzdGVwcyA9IGZsb3cuc3RlcHM7XG4gICAgY29uc3QgZW5kID0gb25seSAhPSBudWxsID8gb25seSArIDEgOiBzdGVwcy5sZW5ndGg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdGVwcy5sZW5ndGg7IGkrKykgaWYgKGkgPj0gZnJvbSAmJiBpIDwgZW5kKSBob29rcy5vblN0YXR1cyhzdGVwc1tpXSEuaWQsIFwicGVuZGluZ1wiKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB0YWIgPSBhd2FpdCBhY3RpdmVUYWIoKTtcbiAgICAgIGNvbnN0IHRhYklkID0gdGFiLmlkITtcbiAgICAgIGZvciAobGV0IGkgPSBmcm9tOyBpIDwgZW5kOyBpKyspIHtcbiAgICAgICAgaWYgKHRoaXMuc3RvcHBlZCkgdGhyb3cgbmV3IEVycm9yKFwiRGV0ZW5pZG8gcG9yIGVsIHVzdWFyaW9cIik7XG4gICAgICAgIGNvbnN0IHN0ZXAgPSBzdGVwc1tpXSE7XG4gICAgICAgIGlmICghc3RlcC5lbmFibGVkKSB7XG4gICAgICAgICAgaG9va3Mub25TdGF0dXMoc3RlcC5pZCwgXCJza2lwcGVkXCIpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGhvb2tzLm9uU3RhdHVzKHN0ZXAuaWQsIFwicnVubmluZ1wiKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCB0aGlzLmV4ZWModGFiSWQsIHJlc29sdmVTdGVwKHN0ZXAsIHZhcnMpLCBzZXR0aW5ncyk7XG4gICAgICAgICAgaG9va3Mub25TdGF0dXMoc3RlcC5pZCwgXCJva1wiKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIGNvbnN0IG1zZyA9IChlIGFzIEVycm9yKS5tZXNzYWdlO1xuICAgICAgICAgIGhvb2tzLm9uU3RhdHVzKHN0ZXAuaWQsIFwiZXJyb3JcIiwgbXNnKTtcbiAgICAgICAgICByZXR1cm4geyBhdDogdDAsIG9rOiBmYWxzZSwgbXM6IERhdGUubm93KCkgLSB0MCwgZmFpbGVkU3RlcElkOiBzdGVwLmlkLCBlcnJvcjogbXNnIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGkgPCBlbmQgLSAxICYmIHNldHRpbmdzLnN0ZXBEZWxheSkgYXdhaXQgc2xlZXAoc2V0dGluZ3Muc3RlcERlbGF5KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IGF0OiB0MCwgb2s6IHRydWUsIG1zOiBEYXRlLm5vdygpIC0gdDAgfTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4geyBhdDogdDAsIG9rOiBmYWxzZSwgbXM6IERhdGUubm93KCkgLSB0MCwgZXJyb3I6IChlIGFzIEVycm9yKS5tZXNzYWdlIH07XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHRoaXMucnVubmluZyA9IGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZXhlYyh0YWJJZDogbnVtYmVyLCBzdGVwOiBTdGVwLCBzZXR0aW5nczogU2V0dGluZ3MpIHtcbiAgICBzd2l0Y2ggKHN0ZXAudHlwZSkge1xuICAgICAgY2FzZSBcIm5hdmlnYXRlXCI6IHtcbiAgICAgICAgaWYgKCFzdGVwLnZhbHVlKSB0aHJvdyBuZXcgRXJyb3IoXCJGYWx0YSBsYSBVUkxcIik7XG4gICAgICAgIGNvbnN0IG5hdnMgPSB3YXRjaE5hdmlnYXRpb25zKHRhYklkKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBjaHJvbWUudGFicy51cGRhdGUodGFiSWQsIHsgdXJsOiBzdGVwLnZhbHVlIH0pO1xuICAgICAgICAgIGF3YWl0IG5hdnMuc3RhcnRlZCgzMDAwKTtcbiAgICAgICAgICBhd2FpdCBuYXZzLnNldHRsZWQoKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBuYXZzLmRpc3Bvc2UoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjYXNlIFwid2FpdFwiOlxuICAgICAgICBhd2FpdCBzbGVlcChOdW1iZXIoc3RlcC52YWx1ZSkgfHwgMTAwMCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBjb25zdCBhY3RzID0gc3RlcC50eXBlID09PSBcImNsaWNrXCIgfHwgc3RlcC50eXBlID09PSBcInByZXNzXCI7XG4gICAgY29uc3QgdGltZW91dCA9IHN0ZXAudGltZW91dCA/PyBzZXR0aW5ncy50aW1lb3V0O1xuICAgIGxldCByZXM6IFN0ZXBSZXN1bHQgfCB1bmRlZmluZWQ7XG4gICAgbGV0IGZpZCA9IGF3YWl0IGZyYW1lSWRGb3IodGFiSWQsIHN0ZXAuZnJhbWUsIHRpbWVvdXQpO1xuICAgIGNvbnN0IG5hdnMgPSB3YXRjaE5hdmlnYXRpb25zKHRhYklkLCBmaWQpO1xuICAgIHRyeSB7XG4gICAgICBmb3IgKGxldCBhdHRlbXB0ID0gMDsgOyBhdHRlbXB0KyspIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXMgPSBhd2FpdCBzZW5kVG9UYWI8U3RlcFJlc3VsdD4odGFiSWQsIHsga2luZDogXCJydW4tc3RlcFwiLCBzdGVwLCBzZXR0aW5ncyB9LCBmaWQpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgaWYgKCFQT1JUX0NMT1NFRC50ZXN0KChlIGFzIEVycm9yKS5tZXNzYWdlKSkgdGhyb3cgZTtcbiAgICAgICAgICAvLyBMYSBww6FnaW5hIChvIGVsIGlmcmFtZSkgbmF2ZWfDsyBtaWVudHJhcyBzZSBlamVjdXRhYmEgZWwgcGFzby5cbiAgICAgICAgICBhd2FpdCBuYXZzLnNldHRsZWQoKTtcbiAgICAgICAgICBpZiAoYWN0cykgcmV0dXJuOyAvLyBlbCBjbGljay90ZWNsYSB5YSBwcm92b2PDsyBsYSBuYXZlZ2FjacOzblxuICAgICAgICAgIGlmIChhdHRlbXB0ID49IDIpIHRocm93IG5ldyBFcnJvcihcIkxhIHDDoWdpbmEgbm8gcGFyw7MgZGUgbmF2ZWdhciBkdXJhbnRlIGVsIHBhc29cIik7XG4gICAgICAgICAgZmlkID0gYXdhaXQgZnJhbWVJZEZvcih0YWJJZCwgc3RlcC5mcmFtZSwgdGltZW91dCk7XG4gICAgICAgICAgY29udGludWU7IC8vIHJlaW50ZW50YXIgZW4gbGEgcMOhZ2luYSBudWV2YVxuICAgICAgICB9XG4gICAgICAgIGlmICghcmVzKSB0aHJvdyBuZXcgRXJyb3IoXCJTaW4gcmVzcHVlc3RhIGRlIGxhIHDDoWdpbmFcIik7XG4gICAgICAgIGlmICghcmVzLm9rKSB0aHJvdyBuZXcgRXJyb3IocmVzLmVycm9yKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICAvLyBVbiBjbGljayBlbiBlbmxhY2Uvc3VibWl0IHB1ZWRlIG5hdmVnYXIgY29uIHJldHJhc28gKHZhbGlkYWNpw7NuLCBwZXRpY2nDs24gYWwgc2Vydmlkb3LigKYpOlxuICAgICAgLy8gZGFtb3MgdW4gbWFyZ2VuIHBhcmEgcXVlIGVtcGllY2UgeSwgc2kgZW1waWV6YSwgZXNwZXJhbW9zIGEgcXVlIGNhcmd1ZS5cbiAgICAgIGlmIChhY3RzICYmIChhd2FpdCBuYXZzLnN0YXJ0ZWQocmVzLm1heU5hdmlnYXRlID8gMTUwMCA6IDE1MCkpKSBhd2FpdCBuYXZzLnNldHRsZWQoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgbmF2cy5kaXNwb3NlKCk7XG4gICAgfVxuICB9XG59XG4iLAogICAgIi8vIE1pbmkgaGVscGVycyBkZSBVSSBzaW4gZnJhbWV3b3JrOiBoKCkgcGFyYSBjcmVhciBET00sIGRpw6Fsb2dvcywgdG9hc3RzIHkgZGVzY2FyZ2FzLlxuXG50eXBlIENoaWxkID0gTm9kZSB8IHN0cmluZyB8IG51bWJlciB8IG51bGwgfCB1bmRlZmluZWQgfCBmYWxzZSB8IENoaWxkW107XG50eXBlIFByb3BzID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj4gJiB7IGNsYXNzPzogc3RyaW5nIHwgZmFsc2UgfCBudWxsOyBzdHlsZT86IHN0cmluZyB9O1xuXG5leHBvcnQgZnVuY3Rpb24gaDxLIGV4dGVuZHMga2V5b2YgSFRNTEVsZW1lbnRUYWdOYW1lTWFwPih0YWc6IEssIHByb3BzPzogUHJvcHMgfCBudWxsLCAuLi5jaGlsZHJlbjogQ2hpbGRbXSk6IEhUTUxFbGVtZW50VGFnTmFtZU1hcFtLXSB7XG4gIGNvbnN0IGVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCh0YWcpO1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhwcm9wcyA/PyB7fSkpIHtcbiAgICBpZiAodiA9PSBudWxsIHx8IHYgPT09IGZhbHNlKSBjb250aW51ZTtcbiAgICBpZiAoay5zdGFydHNXaXRoKFwib25cIikgJiYgdHlwZW9mIHYgPT09IFwiZnVuY3Rpb25cIikgZWwuYWRkRXZlbnRMaXN0ZW5lcihrLnNsaWNlKDIpLnRvTG93ZXJDYXNlKCksIHYgYXMgRXZlbnRMaXN0ZW5lcik7XG4gICAgZWxzZSBpZiAoayA9PT0gXCJjbGFzc1wiKSBlbC5jbGFzc05hbWUgPSBTdHJpbmcodik7XG4gICAgZWxzZSBpZiAoayA9PT0gXCJ2YWx1ZVwiIHx8IGsgPT09IFwiY2hlY2tlZFwiIHx8IGsgPT09IFwic2VsZWN0ZWRcIiB8fCBrID09PSBcImluZGV0ZXJtaW5hdGVcIikgKGVsIGFzIGFueSlba10gPSB2O1xuICAgIGVsc2UgaWYgKHYgPT09IHRydWUpIGVsLnNldEF0dHJpYnV0ZShrLCBcIlwiKTtcbiAgICBlbHNlIGVsLnNldEF0dHJpYnV0ZShrLCBTdHJpbmcodikpO1xuICB9XG4gIGFwcGVuZChlbCwgY2hpbGRyZW4pO1xuICByZXR1cm4gZWw7XG59XG5cbmZ1bmN0aW9uIGFwcGVuZChlbDogTm9kZSwgY2hpbGRyZW46IENoaWxkW10pIHtcbiAgZm9yIChjb25zdCBjIG9mIGNoaWxkcmVuKSB7XG4gICAgaWYgKGMgPT0gbnVsbCB8fCBjID09PSBmYWxzZSkgY29udGludWU7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoYykpIGFwcGVuZChlbCwgYyk7XG4gICAgZWxzZSBlbC5hcHBlbmRDaGlsZChjIGluc3RhbmNlb2YgTm9kZSA/IGMgOiBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShTdHJpbmcoYykpKTtcbiAgfVxufVxuXG4vKiogUmUtcmVuZGVyaXphIGNvbnNlcnZhbmRvIGVsIGZvY28geSBsYSBzZWxlY2Npw7NuIGRlbCBpbnB1dCBhY3Rpdm8gKHBvciBkYXRhLWspIHkgZWwgc2Nyb2xsLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG1vcnBoKHJvb3Q6IEhUTUxFbGVtZW50LCBuZXh0OiBOb2RlKSB7XG4gIGNvbnN0IGFjdGl2ZSA9IGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgYXMgSFRNTElucHV0RWxlbWVudCB8IG51bGw7XG4gIGNvbnN0IGtleSA9IGFjdGl2ZT8uZGF0YXNldD8uaztcbiAgY29uc3Qgc2VsID0ga2V5ICYmIFwic2VsZWN0aW9uU3RhcnRcIiBpbiBhY3RpdmUhID8gW2FjdGl2ZSEuc2VsZWN0aW9uU3RhcnQsIGFjdGl2ZSEuc2VsZWN0aW9uRW5kXSA6IG51bGw7XG4gIGNvbnN0IHNjcm9sbGVycyA9IFsuLi5yb290LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTEVsZW1lbnQ+KFwiW2RhdGEtc2Nyb2xsXVwiKV0ubWFwKChlKSA9PiBbZS5kYXRhc2V0LnNjcm9sbCwgZS5zY3JvbGxUb3BdIGFzIGNvbnN0KTtcbiAgcm9vdC5yZXBsYWNlQ2hpbGRyZW4obmV4dCk7XG4gIGZvciAoY29uc3QgW2ssIHRvcF0gb2Ygc2Nyb2xsZXJzKSB7XG4gICAgY29uc3QgZSA9IHJvb3QucXVlcnlTZWxlY3RvcjxIVE1MRWxlbWVudD4oYFtkYXRhLXNjcm9sbD1cIiR7a31cIl1gKTtcbiAgICBpZiAoZSkgZS5zY3JvbGxUb3AgPSB0b3A7XG4gIH1cbiAgaWYgKGtleSkge1xuICAgIGNvbnN0IGVsID0gcm9vdC5xdWVyeVNlbGVjdG9yPEhUTUxJbnB1dEVsZW1lbnQ+KGBbZGF0YS1rPVwiJHtDU1MuZXNjYXBlKGtleSl9XCJdYCk7XG4gICAgaWYgKGVsKSB7XG4gICAgICBlbC5mb2N1cyh7IHByZXZlbnRTY3JvbGw6IHRydWUgfSk7XG4gICAgICBpZiAoc2VsKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgZWwuc2V0U2VsZWN0aW9uUmFuZ2Uoc2VsWzBdLCBzZWxbMV0pO1xuICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAvKiB0aXBvcyBzaW4gc2VsZWNjacOzbiAqL1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBEacOhbG9nb3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmludGVyZmFjZSBBc2tPcHRzIHtcbiAgdGl0bGU6IHN0cmluZztcbiAgbWVzc2FnZT86IHN0cmluZztcbiAgaW5wdXQ/OiBzdHJpbmc7IC8vIHNpIHNlIHBhc2EsIG11ZXN0cmEgdW4gY2FtcG8gZGUgdGV4dG8gY29uIGVzdGUgdmFsb3IgaW5pY2lhbFxuICBwbGFjZWhvbGRlcj86IHN0cmluZztcbiAgb2s/OiBzdHJpbmc7XG4gIGRhbmdlcj86IGJvb2xlYW47XG4gIG9wdGlvbnM/OiBzdHJpbmdbXTsgLy8gc3VnZXJlbmNpYXMgcGFyYSBlbCBpbnB1dFxuICBleHRyYT86IHsgbGFiZWw6IHN0cmluZzsgdmFsdWU6IHN0cmluZyB9OyAvLyBib3TDs24gYWx0ZXJuYXRpdm9cbn1cblxuLyoqIERpw6Fsb2dvIG1vZGFsLiBEZXZ1ZWx2ZSBlbCB0ZXh0byAobyBcIm9rXCIpLCBlbCB2YWx1ZSBkZWwgYm90w7NuIGV4dHJhLCBvIG51bGwgc2kgc2UgY2FuY2VsYS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhc2sobzogQXNrT3B0cyk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBjb25zdCBsaXN0SWQgPSBcImRsLVwiICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc2xpY2UoMik7XG4gICAgY29uc3QgaW5wdXQgPVxuICAgICAgby5pbnB1dCAhPSBudWxsID8gaChcImlucHV0XCIsIHsgY2xhc3M6IFwiaW5wdXRcIiwgdmFsdWU6IG8uaW5wdXQsIHBsYWNlaG9sZGVyOiBvLnBsYWNlaG9sZGVyLCBsaXN0OiBvLm9wdGlvbnMgPyBsaXN0SWQgOiBudWxsIH0pIDogbnVsbDtcbiAgICBjb25zdCBkbGcgPSBoKFxuICAgICAgXCJkaWFsb2dcIixcbiAgICAgIHsgY2xhc3M6IFwiZGlhbG9nXCIgfSxcbiAgICAgIGgoXG4gICAgICAgIFwiZm9ybVwiLFxuICAgICAgICB7IG1ldGhvZDogXCJkaWFsb2dcIiB9LFxuICAgICAgICBoKFwiaDNcIiwgbnVsbCwgby50aXRsZSksXG4gICAgICAgIG8ubWVzc2FnZSAmJiBoKFwicFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgby5tZXNzYWdlKSxcbiAgICAgICAgaW5wdXQsXG4gICAgICAgIG8ub3B0aW9ucyAmJiBoKFwiZGF0YWxpc3RcIiwgeyBpZDogbGlzdElkIH0sIG8ub3B0aW9ucy5tYXAoKHgpID0+IGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogeCB9KSkpLFxuICAgICAgICBoKFxuICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgeyBjbGFzczogXCJyb3cgZW5kXCIgfSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIGdob3N0XCIsIHZhbHVlOiBcIl9fY2FuY2VsXCIsIHR5cGU6IFwic3VibWl0XCIgfSwgXCJDYW5jZWxhclwiKSxcbiAgICAgICAgICBvLmV4dHJhICYmIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG5cIiwgdmFsdWU6IFwiX19leHRyYVwiLCB0eXBlOiBcInN1Ym1pdFwiIH0sIG8uZXh0cmEubGFiZWwpLFxuICAgICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gXCIgKyAoby5kYW5nZXIgPyBcImRhbmdlclwiIDogXCJwcmltYXJ5XCIpLCB2YWx1ZTogXCJfX29rXCIsIHR5cGU6IFwic3VibWl0XCIgfSwgby5vayA/PyBcIkFjZXB0YXJcIiksXG4gICAgICAgICksXG4gICAgICApLFxuICAgICk7XG4gICAgZGxnLmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoKSA9PiB7XG4gICAgICBjb25zdCBydiA9IGRsZy5yZXR1cm5WYWx1ZTtcbiAgICAgIGRsZy5yZW1vdmUoKTtcbiAgICAgIGlmIChydiA9PT0gXCJfX29rXCIpIHJlc29sdmUoaW5wdXQgPyBpbnB1dC52YWx1ZSA6IFwib2tcIik7XG4gICAgICBlbHNlIGlmIChydiA9PT0gXCJfX2V4dHJhXCIpIHJlc29sdmUoby5leHRyYSEudmFsdWUpO1xuICAgICAgZWxzZSByZXNvbHZlKG51bGwpO1xuICAgIH0pO1xuICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZGxnKTtcbiAgICBkbGcuc2hvd01vZGFsKCk7XG4gICAgaWYgKGlucHV0KSB7XG4gICAgICAvLyBFbnRlciA9IGFjZXB0YXIgKHNpIG5vLCBlbCBlbnbDrW8gaW1wbMOtY2l0byBwdWxzYXLDrWEgZWwgcHJpbWVyIGJvdMOzbjogwqtDYW5jZWxhcsK7KS5cbiAgICAgIGlucHV0LmFkZEV2ZW50TGlzdGVuZXIoXCJrZXlkb3duXCIsIChlKSA9PiB7XG4gICAgICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGRsZy5jbG9zZShcIl9fb2tcIik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgaW5wdXQuZm9jdXMoKTtcbiAgICAgIGlucHV0LnNlbGVjdCgpO1xuICAgIH1cbiAgfSk7XG59XG5cbmxldCB0b2FzdFRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbmV4cG9ydCBmdW5jdGlvbiB0b2FzdCh0ZXh0OiBzdHJpbmcsIGtpbmQ6IFwib2tcIiB8IFwiZXJyb3JcIiB8IFwiaW5mb1wiID0gXCJpbmZvXCIpIHtcbiAgbGV0IGVsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJ0b2FzdFwiKTtcbiAgaWYgKCFlbCkge1xuICAgIGVsID0gaChcImRpdlwiLCB7IGlkOiBcInRvYXN0XCIgfSk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlbCk7XG4gIH1cbiAgZWwudGV4dENvbnRlbnQgPSB0ZXh0O1xuICBlbC5jbGFzc05hbWUgPSBcInNob3cgXCIgKyBraW5kO1xuICBjbGVhclRpbWVvdXQodG9hc3RUaW1lcik7XG4gIHRvYXN0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IChlbCEuY2xhc3NOYW1lID0gXCJcIiksIGtpbmQgPT09IFwiZXJyb3JcIiA/IDUwMDAgOiAyNTAwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvd25sb2FkKGZpbGVuYW1lOiBzdHJpbmcsIGNvbnRlbnQ6IHN0cmluZywgbWltZSA9IFwiYXBwbGljYXRpb24vanNvblwiKSB7XG4gIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwobmV3IEJsb2IoW2NvbnRlbnRdLCB7IHR5cGU6IG1pbWUgfSkpO1xuICBjb25zdCBhID0gaChcImFcIiwgeyBocmVmOiB1cmwsIGRvd25sb2FkOiBmaWxlbmFtZSB9KTtcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgYS5jbGljaygpO1xuICBhLnJlbW92ZSgpO1xuICBzZXRUaW1lb3V0KCgpID0+IFVSTC5yZXZva2VPYmplY3RVUkwodXJsKSwgMjAwMCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwaWNrRmlsZShhY2NlcHQgPSBcIi5qc29uLGFwcGxpY2F0aW9uL2pzb25cIik6IFByb21pc2U8RmlsZSB8IG51bGw+IHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgY29uc3QgaW5wdXQgPSBoKFwiaW5wdXRcIiwgeyB0eXBlOiBcImZpbGVcIiwgYWNjZXB0IH0pO1xuICAgIGlucHV0LmFkZEV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgKCkgPT4gcmVzb2x2ZShpbnB1dC5maWxlcz8uWzBdID8/IG51bGwpKTtcbiAgICBpbnB1dC5hZGRFdmVudExpc3RlbmVyKFwiY2FuY2VsXCIsICgpID0+IHJlc29sdmUobnVsbCkpO1xuICAgIGlucHV0LmNsaWNrKCk7XG4gIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdGltZUFnbyh0czogbnVtYmVyKTogc3RyaW5nIHtcbiAgY29uc3QgcyA9IE1hdGgucm91bmQoKERhdGUubm93KCkgLSB0cykgLyAxMDAwKTtcbiAgaWYgKHMgPCA0NSkgcmV0dXJuIFwiYWhvcmFcIjtcbiAgY29uc3QgbSA9IE1hdGgucm91bmQocyAvIDYwKTtcbiAgaWYgKG0gPCA2MCkgcmV0dXJuIGBoYWNlICR7bX0gbWluYDtcbiAgY29uc3QgaHIgPSBNYXRoLnJvdW5kKG0gLyA2MCk7XG4gIGlmIChociA8IDI0KSByZXR1cm4gYGhhY2UgJHtocn0gaGA7XG4gIGNvbnN0IGQgPSBNYXRoLnJvdW5kKGhyIC8gMjQpO1xuICBpZiAoZCA8IDMwKSByZXR1cm4gYGhhY2UgJHtkfSBkYDtcbiAgcmV0dXJuIG5ldyBEYXRlKHRzKS50b0xvY2FsZURhdGVTdHJpbmcoKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGhvc3RPZih1cmw/OiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAoIXVybCkgcmV0dXJuIFwiXCI7XG4gIHRyeSB7XG4gICAgcmV0dXJuIG5ldyBVUkwodXJsKS5ob3N0O1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gXCJcIjtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVib3VuY2U8QSBleHRlbmRzIHVua25vd25bXT4oZm46ICguLi5hOiBBKSA9PiB2b2lkLCBtczogbnVtYmVyKSB7XG4gIGxldCB0OiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PiB8IHVuZGVmaW5lZDtcbiAgcmV0dXJuICguLi5hOiBBKSA9PiB7XG4gICAgY2xlYXJUaW1lb3V0KHQpO1xuICAgIHQgPSBzZXRUaW1lb3V0KCgpID0+IGZuKC4uLmEpLCBtcyk7XG4gIH07XG59XG4iLAogICAgImltcG9ydCB7IHRvRGV2VG9vbHMgfSBmcm9tIFwiLi4vc2hhcmVkL2RldnRvb2xzXCI7XG5pbXBvcnQgeyBwYXJzZUltcG9ydCwgc2x1ZywgdG9FeHBvcnRGaWxlLCB0b1B1cHBldGVlciB9IGZyb20gXCIuLi9zaGFyZWQvZXhwb3J0ZXJzXCI7XG5pbXBvcnQgdHlwZSB7IFBhbmVsVG9CYWNrZ3JvdW5kLCBSZWNvcmRlZFN0ZXAgfSBmcm9tIFwiLi4vc2hhcmVkL21lc3NhZ2VzXCI7XG5pbXBvcnQgKiBhcyBzdG9yZSBmcm9tIFwiLi4vc2hhcmVkL3N0b3JlXCI7XG5pbXBvcnQgeyBERUZBVUxUX1NFVFRJTkdTLCB0eXBlIEZsb3csIHR5cGUgUmVjb3JkaW5nU3RhdGUsIHR5cGUgU2V0dGluZ3MsIHR5cGUgU3RlcCwgdHlwZSBTdGVwVHlwZSB9IGZyb20gXCIuLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB7IHVpZCB9IGZyb20gXCIuLi9zaGFyZWQvdXRpbFwiO1xuaW1wb3J0IHsgYWN0aXZlVGFiLCBmcmFtZUlkRm9yLCBSdW5uZXIsIHNlbmRUb1RhYiwgdHlwZSBTdGVwU3RhdHVzIH0gZnJvbSBcIi4vcnVubmVyXCI7XG5pbXBvcnQgeyBhc2ssIGRlYm91bmNlLCBkb3dubG9hZCwgdG9hc3QgfSBmcm9tIFwiLi91aVwiO1xuXG5leHBvcnQgdHlwZSBWaWV3ID0gXCJsaWJyYXJ5XCIgfCBcImVkaXRvclwiIHwgXCJzZXR0aW5nc1wiO1xuXG5leHBvcnQgY29uc3Qgc3RhdGUgPSB7XG4gIHZpZXc6IFwibGlicmFyeVwiIGFzIFZpZXcsXG4gIGZsb3dzOiBbXSBhcyBGbG93W10sXG4gIGN1cnJlbnRJZDogdW5kZWZpbmVkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgc2V0dGluZ3M6IHsgLi4uREVGQVVMVF9TRVRUSU5HUyB9IGFzIFNldHRpbmdzLFxuICByZWNvcmRpbmc6IHVuZGVmaW5lZCBhcyBSZWNvcmRpbmdTdGF0ZSB8IHVuZGVmaW5lZCxcbiAgZXhwYW5kZWQ6IG5ldyBTZXQ8c3RyaW5nPigpLFxuICBzZWxlY3RlZDogbmV3IFNldDxzdHJpbmc+KCksXG4gIGZpbHRlcjogeyBxOiBcIlwiLCBmb2xkZXI6IFwiXCIsIHRhZ3M6IG5ldyBTZXQ8c3RyaW5nPigpLCBzb3J0OiBcInVwZGF0ZWRcIiBhcyBcInVwZGF0ZWRcIiB8IFwibmFtZVwiIHwgXCJsYXN0UnVuXCIgfSxcbiAgY29sbGFwc2VkRm9sZGVyczogbmV3IFNldDxzdHJpbmc+KCksXG4gIHJ1bjogdW5kZWZpbmVkIGFzIHVuZGVmaW5lZCB8IHsgZmxvd0lkOiBzdHJpbmc7IHN0YXR1czogUmVjb3JkPHN0cmluZywgU3RlcFN0YXR1cz47IGluZm86IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gfSxcbiAgcGlja2luZzogdW5kZWZpbmVkIGFzIHN0cmluZyB8IHVuZGVmaW5lZCwgLy8gaWQgZGVsIHBhc28gcXVlIHNlIGVzdMOhIHJlLWFwdW50YW5kb1xuICBkcmFnSWQ6IHVuZGVmaW5lZCBhcyBzdHJpbmcgfCB1bmRlZmluZWQsXG59O1xuXG5sZXQgcmVuZGVyRm46ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcbmV4cG9ydCBjb25zdCBzZXRSZW5kZXIgPSAoZm46ICgpID0+IHZvaWQpID0+IChyZW5kZXJGbiA9IGZuKTtcbmV4cG9ydCBjb25zdCByZW5kZXIgPSAoKSA9PiByZW5kZXJGbigpO1xuXG5leHBvcnQgY29uc3QgcnVubmVyID0gbmV3IFJ1bm5lcigpO1xuXG5leHBvcnQgY29uc3QgY3VycmVudCA9ICgpID0+IHN0YXRlLmZsb3dzLmZpbmQoKGYpID0+IGYuaWQgPT09IHN0YXRlLmN1cnJlbnRJZCk7XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBQZXJzaXN0ZW5jaWEg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmNvbnN0IHBlbmRpbmdTYXZlcyA9IG5ldyBNYXA8c3RyaW5nLCAoKSA9PiB2b2lkPigpO1xuXG4vKiogR3VhcmRhIHVuIGZsdWpvIGNvbiBkZWJvdW5jZSAocGFyYSBpbnB1dHMgZGUgdGV4dG8pLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNhdmVTb29uKGZsb3c6IEZsb3cpIHtcbiAgbGV0IGZuID0gcGVuZGluZ1NhdmVzLmdldChmbG93LmlkKTtcbiAgaWYgKCFmbikge1xuICAgIGZuID0gZGVib3VuY2UoKCkgPT4ge1xuICAgICAgY29uc3QgZiA9IHN0YXRlLmZsb3dzLmZpbmQoKHgpID0+IHguaWQgPT09IGZsb3cuaWQpO1xuICAgICAgaWYgKGYpIHZvaWQgc3RvcmUuc2F2ZUZsb3coZik7XG4gICAgfSwgMzAwKTtcbiAgICBwZW5kaW5nU2F2ZXMuc2V0KGZsb3cuaWQsIGZuKTtcbiAgfVxuICBmbigpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2F2ZU5vdyhmbG93OiBGbG93KSB7XG4gIGF3YWl0IHN0b3JlLnNhdmVGbG93KGZsb3cpO1xuICByZW5kZXIoKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbG9hZCgpIHtcbiAgc3RhdGUuZmxvd3MgPSBhd2FpdCBzdG9yZS5saXN0Rmxvd3MoKTtcbiAgcmVuZGVyKCk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBGbHVqb3Mg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVGbG93KCkge1xuICBjb25zdCBuYW1lID0gYXdhaXQgYXNrKHsgdGl0bGU6IFwiTnVldm8gZmx1am9cIiwgaW5wdXQ6IFwiXCIsIHBsYWNlaG9sZGVyOiBcInAuIGVqLiBBbHRhIGRlIGNsaWVudGVcIiwgb2s6IFwiQ3JlYXJcIiB9KTtcbiAgaWYgKG5hbWUgPT0gbnVsbCkgcmV0dXJuO1xuICBjb25zdCBmb2xkZXIgPSBzdGF0ZS5maWx0ZXIuZm9sZGVyICYmIHN0YXRlLmZpbHRlci5mb2xkZXIgIT09IFwiX19ub25lXCIgPyBzdGF0ZS5maWx0ZXIuZm9sZGVyIDogdW5kZWZpbmVkO1xuICBjb25zdCBmbG93ID0gc3RvcmUubmV3Rmxvdyh7IG5hbWU6IG5hbWUudHJpbSgpIHx8IFwiTnVldm8gZmx1am9cIiwgZm9sZGVyIH0pO1xuICBhd2FpdCBzdG9yZS5zYXZlRmxvdyhmbG93KTtcbiAgLy8gRWwgbGlzdGVuZXIgZGUgc3RvcmFnZSBwdWVkZSBoYWJlcmxvIGHDsWFkaWRvIHlhLlxuICBpZiAoIXN0YXRlLmZsb3dzLnNvbWUoKGYpID0+IGYuaWQgPT09IGZsb3cuaWQpKSBzdGF0ZS5mbG93cy51bnNoaWZ0KGZsb3cpO1xuICBvcGVuRmxvdyhmbG93LmlkKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG9wZW5GbG93KGlkOiBzdHJpbmcpIHtcbiAgc3RhdGUuY3VycmVudElkID0gaWQ7XG4gIHN0YXRlLnZpZXcgPSBcImVkaXRvclwiO1xuICBzdGF0ZS5leHBhbmRlZC5jbGVhcigpO1xuICBpZiAoc3RhdGUucnVuPy5mbG93SWQgIT09IGlkKSBzdGF0ZS5ydW4gPSB1bmRlZmluZWQ7XG4gIHJlbmRlcigpO1xuICBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiW2RhdGEtc2Nyb2xsXVwiKT8uc2Nyb2xsVG8oMCwgMCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkdXBsaWNhdGVGbG93KGZsb3c6IEZsb3cpIHtcbiAgY29uc3QgY29weSA9IHN0cnVjdHVyZWRDbG9uZShmbG93KTtcbiAgY29weS5pZCA9IHVpZCgpO1xuICBjb3B5Lm5hbWUgPSBmbG93Lm5hbWUgKyBcIiAoY29waWEpXCI7XG4gIGNvcHkuY3JlYXRlZEF0ID0gRGF0ZS5ub3coKTtcbiAgY29weS5sYXN0UnVuID0gdW5kZWZpbmVkO1xuICBjb3B5LnN0ZXBzLmZvckVhY2goKHMpID0+IChzLmlkID0gdWlkKCkpKTtcbiAgYXdhaXQgc3RvcmUuc2F2ZUZsb3coY29weSk7XG4gIGF3YWl0IHJlbG9hZCgpO1xuICB0b2FzdChcIkZsdWpvIGR1cGxpY2Fkb1wiLCBcIm9rXCIpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVtb3ZlRmxvd3MoaWRzOiBzdHJpbmdbXSkge1xuICBjb25zdCBuYW1lcyA9IHN0YXRlLmZsb3dzLmZpbHRlcigoZikgPT4gaWRzLmluY2x1ZGVzKGYuaWQpKS5tYXAoKGYpID0+IGYubmFtZSk7XG4gIGNvbnN0IG9rID0gYXdhaXQgYXNrKHtcbiAgICB0aXRsZTogaWRzLmxlbmd0aCA9PT0gMSA/IGDCv0JvcnJhciDCqyR7bmFtZXNbMF19wrs/YCA6IGDCv0JvcnJhciAke2lkcy5sZW5ndGh9IGZsdWpvcz9gLFxuICAgIG1lc3NhZ2U6IFwiTm8gc2UgcHVlZGUgZGVzaGFjZXIuIEV4cG9ydGEgYW50ZXMgc2kgcXVpZXJlcyBjb25zZXJ2YXJsb3MuXCIsXG4gICAgb2s6IFwiQm9ycmFyXCIsXG4gICAgZGFuZ2VyOiB0cnVlLFxuICB9KTtcbiAgaWYgKCFvaykgcmV0dXJuO1xuICBhd2FpdCBzdG9yZS5kZWxldGVGbG93cyhpZHMpO1xuICBpZHMuZm9yRWFjaCgoaWQpID0+IHN0YXRlLnNlbGVjdGVkLmRlbGV0ZShpZCkpO1xuICBpZiAoc3RhdGUuY3VycmVudElkICYmIGlkcy5pbmNsdWRlcyhzdGF0ZS5jdXJyZW50SWQpKSBzdGF0ZS52aWV3ID0gXCJsaWJyYXJ5XCI7XG4gIGF3YWl0IHJlbG9hZCgpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWxsRm9sZGVycygpOiBzdHJpbmdbXSB7XG4gIHJldHVybiBbLi4ubmV3IFNldChzdGF0ZS5mbG93cy5tYXAoKGYpID0+IGYuZm9sZGVyKS5maWx0ZXIoQm9vbGVhbikgYXMgc3RyaW5nW10pXS5zb3J0KChhLCBiKSA9PiBhLmxvY2FsZUNvbXBhcmUoYikpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWxsVGFncygpOiBzdHJpbmdbXSB7XG4gIHJldHVybiBbLi4ubmV3IFNldChzdGF0ZS5mbG93cy5mbGF0TWFwKChmKSA9PiBmLnRhZ3MpKV0uc29ydCgoYSwgYikgPT4gYS5sb2NhbGVDb21wYXJlKGIpKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGZpbHRlcmVkRmxvd3MoKTogRmxvd1tdIHtcbiAgY29uc3QgeyBxLCBmb2xkZXIsIHRhZ3MsIHNvcnQgfSA9IHN0YXRlLmZpbHRlcjtcbiAgY29uc3QgdG9rZW5zID0gcS50b0xvd2VyQ2FzZSgpLnNwbGl0KC9cXHMrLykuZmlsdGVyKEJvb2xlYW4pO1xuICBjb25zdCBsaXN0ID0gc3RhdGUuZmxvd3MuZmlsdGVyKChmKSA9PiB7XG4gICAgaWYgKGZvbGRlciA9PT0gXCJfX25vbmVcIiA/IGYuZm9sZGVyIDogZm9sZGVyICYmIGYuZm9sZGVyICE9PSBmb2xkZXIpIHJldHVybiBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IHQgb2YgdGFncykgaWYgKCFmLnRhZ3MuaW5jbHVkZXModCkpIHJldHVybiBmYWxzZTtcbiAgICBpZiAoIXRva2Vucy5sZW5ndGgpIHJldHVybiB0cnVlO1xuICAgIGNvbnN0IGhheSA9IFtmLm5hbWUsIGYuZGVzY3JpcHRpb24sIGYuZm9sZGVyLCAuLi5mLnRhZ3MubWFwKCh0KSA9PiBcIiNcIiArIHQpLCAuLi5mLnN0ZXBzLm1hcCgocykgPT4gYCR7cy5sYWJlbCA/PyBcIlwifSAke3MudHlwZSA9PT0gXCJuYXZpZ2F0ZVwiID8gcy52YWx1ZSA6IFwiXCJ9YCldXG4gICAgICAuam9pbihcIiBcIilcbiAgICAgIC50b0xvd2VyQ2FzZSgpO1xuICAgIHJldHVybiB0b2tlbnMuZXZlcnkoKHQpID0+IGhheS5pbmNsdWRlcyh0KSk7XG4gIH0pO1xuICBpZiAoc29ydCA9PT0gXCJuYW1lXCIpIGxpc3Quc29ydCgoYSwgYikgPT4gYS5uYW1lLmxvY2FsZUNvbXBhcmUoYi5uYW1lKSk7XG4gIGVsc2UgaWYgKHNvcnQgPT09IFwibGFzdFJ1blwiKSBsaXN0LnNvcnQoKGEsIGIpID0+IChiLmxhc3RSdW4/LmF0ID8/IDApIC0gKGEubGFzdFJ1bj8uYXQgPz8gMCkpO1xuICBlbHNlIGxpc3Quc29ydCgoYSwgYikgPT4gYi51cGRhdGVkQXQgLSBhLnVwZGF0ZWRBdCk7XG4gIHJldHVybiBsaXN0O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYnVsa01vdmUoaWRzOiBzdHJpbmdbXSkge1xuICBjb25zdCBmb2xkZXIgPSBhd2FpdCBhc2soeyB0aXRsZTogXCJNb3ZlciBhIGNhcnBldGFcIiwgaW5wdXQ6IFwiXCIsIHBsYWNlaG9sZGVyOiBcIk5vbWJyZSBkZSBjYXJwZXRhICh2YWPDrW8gPSBzaW4gY2FycGV0YSlcIiwgb3B0aW9uczogYWxsRm9sZGVycygpLCBvazogXCJNb3ZlclwiIH0pO1xuICBpZiAoZm9sZGVyID09IG51bGwpIHJldHVybjtcbiAgZm9yIChjb25zdCBmIG9mIHN0YXRlLmZsb3dzLmZpbHRlcigoeCkgPT4gaWRzLmluY2x1ZGVzKHguaWQpKSkge1xuICAgIGYuZm9sZGVyID0gZm9sZGVyLnRyaW0oKSB8fCB1bmRlZmluZWQ7XG4gICAgYXdhaXQgc3RvcmUuc2F2ZUZsb3coZik7XG4gIH1cbiAgYXdhaXQgcmVsb2FkKCk7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBidWxrVGFnKGlkczogc3RyaW5nW10pIHtcbiAgY29uc3QgdGFnID0gYXdhaXQgYXNrKHsgdGl0bGU6IFwiQcOxYWRpciBldGlxdWV0YVwiLCBpbnB1dDogXCJcIiwgcGxhY2Vob2xkZXI6IFwiZXRpcXVldGFcIiwgb3B0aW9uczogYWxsVGFncygpLCBvazogXCJBw7FhZGlyXCIgfSk7XG4gIGNvbnN0IHQgPSB0YWc/LnRyaW0oKS5yZXBsYWNlKC9eIy8sIFwiXCIpO1xuICBpZiAoIXQpIHJldHVybjtcbiAgZm9yIChjb25zdCBmIG9mIHN0YXRlLmZsb3dzLmZpbHRlcigoeCkgPT4gaWRzLmluY2x1ZGVzKHguaWQpKSkge1xuICAgIGlmICghZi50YWdzLmluY2x1ZGVzKHQpKSBmLnRhZ3MucHVzaCh0KTtcbiAgICBhd2FpdCBzdG9yZS5zYXZlRmxvdyhmKTtcbiAgfVxuICBhd2FpdCByZWxvYWQoKTtcbn1cblxuLy8g4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAIEltcG9ydCAvIGV4cG9ydCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY29uc3Qgc3RhbXAgPSAoKSA9PiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xuXG5leHBvcnQgZnVuY3Rpb24gZXhwb3J0Rmxvd3MoZmxvd3M6IEZsb3dbXSkge1xuICBpZiAoIWZsb3dzLmxlbmd0aCkgcmV0dXJuIHRvYXN0KFwiTm8gaGF5IGZsdWpvcyBxdWUgZXhwb3J0YXJcIiwgXCJlcnJvclwiKTtcbiAgY29uc3QgbmFtZSA9IGZsb3dzLmxlbmd0aCA9PT0gMSA/IGByYXN0cm8tJHtzbHVnKGZsb3dzWzBdIS5uYW1lKX0tJHtzdGFtcCgpfS5qc29uYCA6IGByYXN0cm8tJHtmbG93cy5sZW5ndGh9LWZsdWpvcy0ke3N0YW1wKCl9Lmpzb25gO1xuICBkb3dubG9hZChuYW1lLCBKU09OLnN0cmluZ2lmeSh0b0V4cG9ydEZpbGUoZmxvd3MpLCBudWxsLCAyKSk7XG4gIHRvYXN0KGAke2Zsb3dzLmxlbmd0aH0gZmx1am8ocykgZXhwb3J0YWRvKHMpYCwgXCJva1wiKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGV4cG9ydFB1cHBldGVlcihmbG93OiBGbG93KSB7XG4gIGRvd25sb2FkKGAke3NsdWcoZmxvdy5uYW1lKX0ubWpzYCwgdG9QdXBwZXRlZXIoZmxvdyksIFwidGV4dC9qYXZhc2NyaXB0XCIpO1xuICB0b2FzdChcIlNjcmlwdCBkZSBQdXBwZXRlZXIgZGVzY2FyZ2Fkb1wiLCBcIm9rXCIpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW1wb3J0VGV4dCh0ZXh0OiBzdHJpbmcpIHtcbiAgbGV0IGZsb3dzOiBGbG93W107XG4gIGxldCByZXN1bHQ6IFJldHVyblR5cGU8dHlwZW9mIHBhcnNlSW1wb3J0PjtcbiAgdHJ5IHtcbiAgICByZXN1bHQgPSBwYXJzZUltcG9ydCh0ZXh0KTtcbiAgICBmbG93cyA9IHJlc3VsdC5mbG93cztcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiB0b2FzdCgoZSBhcyBFcnJvcikubWVzc2FnZSwgXCJlcnJvclwiKTtcbiAgfVxuICBjb25zdCBleGlzdGluZyA9IG5ldyBTZXQoc3RhdGUuZmxvd3MubWFwKChmKSA9PiBmLmlkKSk7XG4gIGNvbnN0IGNsYXNoZXMgPSBmbG93cy5maWx0ZXIoKGYpID0+IGV4aXN0aW5nLmhhcyhmLmlkKSk7XG4gIGxldCBtb2RlOiBcIm92ZXJ3cml0ZVwiIHwgXCJjb3B5XCIgPSBcImNvcHlcIjtcbiAgaWYgKGNsYXNoZXMubGVuZ3RoKSB7XG4gICAgY29uc3QgciA9IGF3YWl0IGFzayh7XG4gICAgICB0aXRsZTogYCR7Y2xhc2hlcy5sZW5ndGh9IGZsdWpvKHMpIHlhIGV4aXN0ZW5gLFxuICAgICAgbWVzc2FnZTogY2xhc2hlcy5tYXAoKGYpID0+IGYubmFtZSkuam9pbihcIiwgXCIpLFxuICAgICAgb2s6IFwiU29icmVzY3JpYmlyXCIsXG4gICAgICBleHRyYTogeyBsYWJlbDogXCJJbXBvcnRhciBjb21vIGNvcGlhXCIsIHZhbHVlOiBcImNvcHlcIiB9LFxuICAgIH0pO1xuICAgIGlmIChyID09IG51bGwpIHJldHVybjtcbiAgICBtb2RlID0gciA9PT0gXCJjb3B5XCIgPyBcImNvcHlcIiA6IFwib3ZlcndyaXRlXCI7XG4gIH1cbiAgZm9yIChjb25zdCBmIG9mIGZsb3dzKSB7XG4gICAgaWYgKGV4aXN0aW5nLmhhcyhmLmlkKSAmJiBtb2RlID09PSBcImNvcHlcIikge1xuICAgICAgZi5pZCA9IHVpZCgpO1xuICAgICAgZi5uYW1lICs9IFwiIChpbXBvcnRhZG8pXCI7XG4gICAgfVxuICAgIGF3YWl0IHN0b3JlLnNhdmVGbG93KGYpO1xuICB9XG4gIGF3YWl0IHJlbG9hZCgpO1xuICBpZiAocmVzdWx0LnNvdXJjZSA9PT0gXCJkZXZ0b29sc1wiKSB7XG4gICAgY29uc3QgbiA9IHJlc3VsdC5za2lwcGVkLmxlbmd0aDtcbiAgICB0b2FzdChgR3JhYmFjacOzbiBkZSBEZXZUb29scyBpbXBvcnRhZGEke24gPyBgICgke259IHBhc28ocykgc2luIGVxdWl2YWxlbnRlOiAke1suLi5uZXcgU2V0KHJlc3VsdC5za2lwcGVkKV0uam9pbihcIiwgXCIpfSlgIDogXCJcIn1gLCBuID8gXCJpbmZvXCIgOiBcIm9rXCIpO1xuICAgIG9wZW5GbG93KGZsb3dzWzBdIS5pZCk7XG4gIH0gZWxzZSB0b2FzdChgJHtmbG93cy5sZW5ndGh9IGZsdWpvKHMpIGltcG9ydGFkbyhzKWAsIFwib2tcIik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBleHBvcnREZXZUb29scyhmbG93OiBGbG93KSB7XG4gIGNvbnN0IHsganNvbiwgd2FybmluZ3MgfSA9IHRvRGV2VG9vbHMoZmxvdyk7XG4gIGRvd25sb2FkKGAke3NsdWcoZmxvdy5uYW1lKX0ucmVjb3JkZXIuanNvbmAsIEpTT04uc3RyaW5naWZ5KGpzb24sIG51bGwsIDIpKTtcbiAgdG9hc3QoXG4gICAgd2FybmluZ3MgPyBgRXhwb3J0YWRvLiAke3dhcm5pbmdzfSBwYXNvKHMpIGVuIGlmcmFtZXMgdmFuIHNpbiBydXRhIGRlIGZyYW1lOiByZXbDrXNhbG9zIGVuIERldlRvb2xzYCA6IFwiRXhwb3J0YWRvOiBpbXDDs3J0YWxvIGVuIERldlRvb2xzIOKAuiBSZWNvcmRlclwiLFxuICAgIHdhcm5pbmdzID8gXCJpbmZvXCIgOiBcIm9rXCIsXG4gICk7XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBQYXNvcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGZ1bmN0aW9uIGFkZFN0ZXAoZmxvdzogRmxvdywgdHlwZTogU3RlcFR5cGUsIGFmdGVyPzogc3RyaW5nKSB7XG4gIGNvbnN0IHN0ZXAgPSBzdG9yZS5uZXdTdGVwKHsgdHlwZSwgdmFsdWU6IHR5cGUgPT09IFwicHJlc3NcIiA/IFwiRW50ZXJcIiA6IHR5cGUgPT09IFwid2FpdFwiID8gXCIxMDAwXCIgOiB0eXBlID09PSBcImNoZWNrXCIgPyBcInRydWVcIiA6IHVuZGVmaW5lZCB9KTtcbiAgY29uc3QgaSA9IGFmdGVyID8gZmxvdy5zdGVwcy5maW5kSW5kZXgoKHMpID0+IHMuaWQgPT09IGFmdGVyKSA6IC0xO1xuICBpZiAoaSA+PSAwKSBmbG93LnN0ZXBzLnNwbGljZShpICsgMSwgMCwgc3RlcCk7XG4gIGVsc2UgZmxvdy5zdGVwcy5wdXNoKHN0ZXApO1xuICBzdGF0ZS5leHBhbmRlZC5hZGQoc3RlcC5pZCk7XG4gIHZvaWQgc2F2ZU5vdyhmbG93KTtcbiAgcmV0dXJuIHN0ZXA7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtb3ZlU3RlcChmbG93OiBGbG93LCBpZDogc3RyaW5nLCBiZWZvcmVJZDogc3RyaW5nIHwgbnVsbCkge1xuICBjb25zdCBmcm9tID0gZmxvdy5zdGVwcy5maW5kSW5kZXgoKHMpID0+IHMuaWQgPT09IGlkKTtcbiAgaWYgKGZyb20gPCAwKSByZXR1cm47XG4gIGNvbnN0IFtzXSA9IGZsb3cuc3RlcHMuc3BsaWNlKGZyb20sIDEpO1xuICBjb25zdCB0byA9IGJlZm9yZUlkID8gZmxvdy5zdGVwcy5maW5kSW5kZXgoKHgpID0+IHguaWQgPT09IGJlZm9yZUlkKSA6IGZsb3cuc3RlcHMubGVuZ3RoO1xuICBmbG93LnN0ZXBzLnNwbGljZSh0byA8IDAgPyBmbG93LnN0ZXBzLmxlbmd0aCA6IHRvLCAwLCBzISk7XG4gIHZvaWQgc2F2ZU5vdyhmbG93KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGR1cGxpY2F0ZVN0ZXAoZmxvdzogRmxvdywgc3RlcDogU3RlcCkge1xuICBjb25zdCBpID0gZmxvdy5zdGVwcy5pbmRleE9mKHN0ZXApO1xuICBjb25zdCBjb3B5ID0geyAuLi5zdHJ1Y3R1cmVkQ2xvbmUoc3RlcCksIGlkOiB1aWQoKSB9O1xuICBmbG93LnN0ZXBzLnNwbGljZShpICsgMSwgMCwgY29weSk7XG4gIHZvaWQgc2F2ZU5vdyhmbG93KTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlbGV0ZVN0ZXAoZmxvdzogRmxvdywgc3RlcDogU3RlcCkge1xuICBmbG93LnN0ZXBzID0gZmxvdy5zdGVwcy5maWx0ZXIoKHMpID0+IHMgIT09IHN0ZXApO1xuICBzdGF0ZS5leHBhbmRlZC5kZWxldGUoc3RlcC5pZCk7XG4gIHZvaWQgc2F2ZU5vdyhmbG93KTtcbn1cblxuLyoqIFJlLWFwdW50YSBlbCBzZWxlY3RvciBkZSB1biBwYXNvIGNsaWNhbmRvIGVuIGxhIHDDoWdpbmEuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcGlja0ZvcihmbG93OiBGbG93LCBzdGVwOiBTdGVwKSB7XG4gIHRyeSB7XG4gICAgY29uc3QgdGFiID0gYXdhaXQgYWN0aXZlVGFiKCk7XG4gICAgc3RhdGUucGlja2luZyA9IHN0ZXAuaWQ7XG4gICAgcmVuZGVyKCk7XG4gICAgYXdhaXQgc2VuZFRvVGFiKHRhYi5pZCEsIHsga2luZDogXCJwaW5nXCIgfSk7XG4gICAgLy8gU2luIGZyYW1lSWQ6IHNlIGRpZnVuZGUgYSB0b2RvcyBsb3MgZnJhbWVzIHkgcmVzcG9uZGUgYXF1ZWwgZG9uZGUgY2xpcXVlIGVsIHVzdWFyaW8uXG4gICAgY29uc3QgcjogUmVjb3JkZWRTdGVwIHwgbnVsbCA9IGF3YWl0IGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYi5pZCEsIHsga2luZDogXCJwaWNrXCIgfSk7XG4gICAgdm9pZCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQhLCB7IGtpbmQ6IFwicGljazpjYW5jZWxcIiB9KS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgaWYgKHIpIHtcbiAgICAgIHN0ZXAuc2VsZWN0b3IgPSByLnNlbGVjdG9yO1xuICAgICAgc3RlcC5mYWxsYmFja3MgPSByLmZhbGxiYWNrcztcbiAgICAgIHN0ZXAubGFiZWwgPSByLmxhYmVsO1xuICAgICAgc3RlcC5mcmFtZSA9IHIuZnJhbWU7XG4gICAgICBpZiAoc3RlcC50eXBlID09PSBcImNsaWNrXCIgJiYgci50eXBlICE9PSBcImNsaWNrXCIpIHtcbiAgICAgICAgLy8gU2kgYXB1bnRhcyBhIHVuIGlucHV0IGRlc2RlIHVuIHBhc28gdmFjw61vLCBhZG9wdGEgc3UgdGlwbyB5IHZhbG9yIGFjdHVhbC5cbiAgICAgICAgT2JqZWN0LmFzc2lnbihzdGVwLCB7IHR5cGU6IHIudHlwZSwgdmFsdWU6IHIudmFsdWUsIG9wdGlvblRleHQ6IHIub3B0aW9uVGV4dCwgc2VjcmV0OiByLnNlY3JldCB9KTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHNhdmVOb3coZmxvdyk7XG4gICAgICB0b2FzdChcIkVsZW1lbnRvIGFjdHVhbGl6YWRvXCIsIFwib2tcIik7XG4gICAgfVxuICB9IGNhdGNoIChlKSB7XG4gICAgdG9hc3QoKGUgYXMgRXJyb3IpLm1lc3NhZ2UsIFwiZXJyb3JcIik7XG4gIH0gZmluYWxseSB7XG4gICAgc3RhdGUucGlja2luZyA9IHVuZGVmaW5lZDtcbiAgICByZW5kZXIoKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2FuY2VsUGljaygpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWIgPSBhd2FpdCBhY3RpdmVUYWIoKTtcbiAgICBhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQhLCB7IGtpbmQ6IFwicGljazpjYW5jZWxcIiB9KTtcbiAgfSBjYXRjaCB7XG4gICAgLyogbmFkYSAqL1xuICB9XG4gIHN0YXRlLnBpY2tpbmcgPSB1bmRlZmluZWQ7XG4gIHJlbmRlcigpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGlnaGxpZ2h0U3RlcChzdGVwOiBTdGVwKSB7XG4gIGlmICghc3RlcC5zZWxlY3RvcikgcmV0dXJuO1xuICB0cnkge1xuICAgIGNvbnN0IHRhYiA9IGF3YWl0IGFjdGl2ZVRhYigpO1xuICAgIGNvbnN0IGZpZCA9IGF3YWl0IGZyYW1lSWRGb3IodGFiLmlkISwgc3RlcC5mcmFtZSwgMzAwMCk7XG4gICAgY29uc3QgciA9IGF3YWl0IHNlbmRUb1RhYjx7IG9rOiBib29sZWFuIH0+KHRhYi5pZCEsIHsga2luZDogXCJoaWdobGlnaHRcIiwgc2VsZWN0b3I6IHN0ZXAuc2VsZWN0b3IsIGZhbGxiYWNrczogc3RlcC5mYWxsYmFja3MgfSwgZmlkKTtcbiAgICBpZiAoIXI/Lm9rKSB0b2FzdChcIk5vIHNlIGVuY3VlbnRyYSBlbiBlc3RhIHDDoWdpbmFcIiwgXCJlcnJvclwiKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHRvYXN0KChlIGFzIEVycm9yKS5tZXNzYWdlLCBcImVycm9yXCIpO1xuICB9XG59XG5cbi8vIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCBHcmFiYWNpw7NuIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jb25zdCBiZyA9IDxUID0geyBvazogYm9vbGVhbjsgZXJyb3I/OiBzdHJpbmcgfT4obXNnOiBQYW5lbFRvQmFja2dyb3VuZCk6IFByb21pc2U8VD4gPT4gY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UobXNnKTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN0YXJ0UmVjb3JkaW5nKGZsb3c6IEZsb3csIG1vZGU6IFwicmVjb3JkXCIgfCBcInBvaW50XCIpIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB0YWIgPSBhd2FpdCBhY3RpdmVUYWIoKTtcbiAgICBpZiAoIXRhYi51cmwgfHwgIS9eKGh0dHBzP3xmaWxlKTovLnRlc3QodGFiLnVybCkpIHtcbiAgICAgIHJldHVybiB0b2FzdChcIkFicmUgdW5hIHDDoWdpbmEgd2ViIGVuIGxhIHBlc3Rhw7FhIGFjdGl2YSBwYXJhIGdyYWJhclwiLCBcImVycm9yXCIpO1xuICAgIH1cbiAgICBjb25zdCByID0gYXdhaXQgYmcoeyBraW5kOiBcInJlY29yZDpzdGFydFwiLCBmbG93SWQ6IGZsb3cuaWQsIHRhYklkOiB0YWIuaWQhLCBtb2RlIH0pO1xuICAgIGlmICghci5vaykgdG9hc3Qoci5lcnJvciA/PyBcIk5vIHNlIHB1ZG8gZW1wZXphciBhIGdyYWJhclwiLCBcImVycm9yXCIpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgdG9hc3QoKGUgYXMgRXJyb3IpLm1lc3NhZ2UsIFwiZXJyb3JcIik7XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IHN0b3BSZWNvcmRpbmcgPSAoKSA9PiBiZyh7IGtpbmQ6IFwicmVjb3JkOnN0b3BcIiB9KTtcbmV4cG9ydCBjb25zdCBwYXVzZVJlY29yZGluZyA9IChwYXVzZWQ6IGJvb2xlYW4pID0+IGJnKHsga2luZDogXCJyZWNvcmQ6cGF1c2VcIiwgcGF1c2VkIH0pO1xuXG4vLyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIAgUmVwcm9kdWNjacOzbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHBsYXkoZmxvdzogRmxvdywgZnJvbSA9IDAsIG9ubHk/OiBudW1iZXIpIHtcbiAgaWYgKHJ1bm5lci5ydW5uaW5nKSByZXR1cm47XG4gIGlmIChzdGF0ZS5yZWNvcmRpbmcpIGF3YWl0IHN0b3BSZWNvcmRpbmcoKTtcbiAgc3RhdGUucnVuID0geyBmbG93SWQ6IGZsb3cuaWQsIHN0YXR1czoge30sIGluZm86IHt9IH07XG4gIHJlbmRlcigpO1xuICBjb25zdCBzdW1tYXJ5ID0gYXdhaXQgcnVubmVyLnJ1bihmbG93LCBzdGF0ZS5zZXR0aW5ncywge1xuICAgIG9uU3RhdHVzKGlkLCBzdGF0dXMsIGluZm8pIHtcbiAgICAgIGlmICghc3RhdGUucnVuKSByZXR1cm47XG4gICAgICBzdGF0ZS5ydW4uc3RhdHVzW2lkXSA9IHN0YXR1cztcbiAgICAgIGlmIChpbmZvKSBzdGF0ZS5ydW4uaW5mb1tpZF0gPSBpbmZvO1xuICAgICAgcmVuZGVyKCk7XG4gICAgICBpZiAoc3RhdHVzID09PSBcInJ1bm5pbmdcIikgZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgW2RhdGEtc3RlcD1cIiR7aWR9XCJdYCk/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6IFwibmVhcmVzdFwiIH0pO1xuICAgIH0sXG4gIH0sIGZyb20sIG9ubHkpO1xuICBpZiAob25seSA9PSBudWxsKSB7XG4gICAgZmxvdy5sYXN0UnVuID0gc3VtbWFyeTtcbiAgICBhd2FpdCBzdG9yZS5zYXZlRmxvdyhmbG93LCBmYWxzZSk7XG4gIH1cbiAgcmVuZGVyKCk7XG4gIGlmIChzdW1tYXJ5Lm9rKSB0b2FzdChg4pyTIENvbXBsZXRhZG8gZW4gJHsoc3VtbWFyeS5tcyAvIDEwMDApLnRvRml4ZWQoMSl9c2AsIFwib2tcIik7XG4gIGVsc2UgdG9hc3QoYOKclyAke3N1bW1hcnkuZXJyb3J9YCwgXCJlcnJvclwiKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0b3BQbGF5KCkge1xuICBydW5uZXIuc3RvcCgpO1xufVxuIiwKICAgICJpbXBvcnQgeyBTVEVQX01FVEEsIHR5cGUgRmxvdywgdHlwZSBTdGVwLCB0eXBlIFN0ZXBUeXBlIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHsgQlVJTFRJTl9WQVJTIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC91dGlsXCI7XG5pbXBvcnQgKiBhcyBBIGZyb20gXCIuLi9zdGF0ZVwiO1xuaW1wb3J0IHsgc3RhdGUgfSBmcm9tIFwiLi4vc3RhdGVcIjtcbmltcG9ydCB7IGgsIHRpbWVBZ28gfSBmcm9tIFwiLi4vdWlcIjtcblxuY29uc3QgVFlQRVMgPSBPYmplY3Qua2V5cyhTVEVQX01FVEEpIGFzIFN0ZXBUeXBlW107XG5cbmV4cG9ydCBmdW5jdGlvbiBlZGl0b3JWaWV3KGZsb3c6IEZsb3cpOiBIVE1MRWxlbWVudCB7XG4gIGNvbnN0IHJlYyA9IHN0YXRlLnJlY29yZGluZz8uZmxvd0lkID09PSBmbG93LmlkID8gc3RhdGUucmVjb3JkaW5nIDogdW5kZWZpbmVkO1xuICBjb25zdCBvdGhlclJlYyA9IHN0YXRlLnJlY29yZGluZyAmJiAhcmVjO1xuICBjb25zdCBydW5uaW5nID0gQS5ydW5uZXIucnVubmluZztcbiAgY29uc3QgcnVuID0gc3RhdGUucnVuPy5mbG93SWQgPT09IGZsb3cuaWQgPyBzdGF0ZS5ydW4gOiB1bmRlZmluZWQ7XG5cbiAgY29uc3Qgc2V0ID0gPEsgZXh0ZW5kcyBrZXlvZiBGbG93PihrOiBLLCB2OiBGbG93W0tdKSA9PiB7XG4gICAgZmxvd1trXSA9IHY7XG4gICAgQS5zYXZlU29vbihmbG93KTtcbiAgfTtcblxuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwidmlld1wiIH0sXG4gICAgaChcbiAgICAgIFwiaGVhZGVyXCIsXG4gICAgICB7IGNsYXNzOiBcInRvcFwiIH0sXG4gICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIGdob3N0IHNtXCIsIG9uY2xpY2s6ICgpID0+ICgoc3RhdGUudmlldyA9IFwibGlicmFyeVwiKSwgQS5yZW5kZXIoKSkgfSwgXCLihpAgRmx1am9zXCIpLFxuICAgICAgaChcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgeyBjbGFzczogXCJyb3dcIiB9LFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiaWNvblwiLCB0aXRsZTogXCJFeHBvcnRhciBKU09OXCIsIG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0Rmxvd3MoW2Zsb3ddKSB9LCBcIuKHqVwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiRXhwb3J0YXIgYSBQdXBwZXRlZXJcIiwgb25jbGljazogKCkgPT4gQS5leHBvcnRQdXBwZXRlZXIoZmxvdykgfSwgXCJKU1wiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiRXhwb3J0YXIgYSBEZXZUb29scyBSZWNvcmRlclwiLCBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydERldlRvb2xzKGZsb3cpIH0sIFwiRFRcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIkR1cGxpY2FyXCIsIG9uY2xpY2s6ICgpID0+IEEuZHVwbGljYXRlRmxvdyhmbG93KSB9LCBcIuKniVwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb24gZGFuZ2VyXCIsIHRpdGxlOiBcIkJvcnJhciBmbHVqb1wiLCBvbmNsaWNrOiAoKSA9PiBBLnJlbW92ZUZsb3dzKFtmbG93LmlkXSkgfSwgXCLwn5eRXCIpLFxuICAgICAgKSxcbiAgICApLFxuICAgIGgoXG4gICAgICBcIm1haW5cIixcbiAgICAgIHsgY2xhc3M6IFwic2Nyb2xsXCIsIFwiZGF0YS1zY3JvbGxcIjogXCJlZGl0b3JcIiB9LFxuICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgY2xhc3M6IFwidGl0bGUtaW5wdXRcIixcbiAgICAgICAgdmFsdWU6IGZsb3cubmFtZSxcbiAgICAgICAgXCJkYXRhLWtcIjogXCJmbG93LW5hbWVcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6IFwiTm9tYnJlIGRlbCBmbHVqb1wiLFxuICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHNldChcIm5hbWVcIiwgKGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlKSxcbiAgICAgIH0pLFxuICAgICAgaChcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgeyBjbGFzczogXCJtZXRhLWdyaWRcIiB9LFxuICAgICAgICBoKFxuICAgICAgICAgIFwibGFiZWxcIixcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIGgoXCJzcGFuXCIsIG51bGwsIFwiQ2FycGV0YVwiKSxcbiAgICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIGxpc3Q6IFwiZm9sZGVyc1wiLFxuICAgICAgICAgICAgdmFsdWU6IGZsb3cuZm9sZGVyID8/IFwiXCIsXG4gICAgICAgICAgICBwbGFjZWhvbGRlcjogXCLigJRcIixcbiAgICAgICAgICAgIFwiZGF0YS1rXCI6IFwiZmxvdy1mb2xkZXJcIixcbiAgICAgICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4gc2V0KFwiZm9sZGVyXCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS50cmltKCkgfHwgdW5kZWZpbmVkKSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBoKFwiZGF0YWxpc3RcIiwgeyBpZDogXCJmb2xkZXJzXCIgfSwgQS5hbGxGb2xkZXJzKCkubWFwKChmKSA9PiBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IGYgfSkpKSxcbiAgICAgICAgKSxcbiAgICAgICAgaChcImxhYmVsXCIsIG51bGwsIGgoXCJzcGFuXCIsIG51bGwsIFwiRXRpcXVldGFzXCIpLCB0YWdFZGl0b3IoZmxvdykpLFxuICAgICAgKSxcbiAgICAgIGgoXCJ0ZXh0YXJlYVwiLCB7XG4gICAgICAgIGNsYXNzOiBcImlucHV0IGRlc2NcIixcbiAgICAgICAgcm93czogMSxcbiAgICAgICAgcGxhY2Vob2xkZXI6IFwiRGVzY3JpcGNpw7NuIC8gbm90YXMgKG9wY2lvbmFsKVwiLFxuICAgICAgICBcImRhdGEta1wiOiBcImZsb3ctZGVzY1wiLFxuICAgICAgICB2YWx1ZTogZmxvdy5kZXNjcmlwdGlvbiA/PyBcIlwiLFxuICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHNldChcImRlc2NyaXB0aW9uXCIsIChlLnRhcmdldCBhcyBIVE1MVGV4dEFyZWFFbGVtZW50KS52YWx1ZSB8fCB1bmRlZmluZWQpLFxuICAgICAgfSksXG5cbiAgICAgIC8vIOKUgOKUgCBCYXJyYSBkZSBhY2Npb25lcyDilIDilIBcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwiYWN0aW9uc1wiIH0sXG4gICAgICAgIHJlY1xuICAgICAgICAgID8gW1xuICAgICAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHJlYyBvblwiLCBvbmNsaWNrOiAoKSA9PiBBLnN0b3BSZWNvcmRpbmcoKSB9LCBcIuKWoCBUZXJtaW5hclwiKSxcbiAgICAgICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0blwiLCBvbmNsaWNrOiAoKSA9PiBBLnBhdXNlUmVjb3JkaW5nKCFyZWMucGF1c2VkKSB9LCByZWMucGF1c2VkID8gXCLilrYgUmVhbnVkYXJcIiA6IFwi4p2a4p2aIFBhdXNhclwiKSxcbiAgICAgICAgICAgIF1cbiAgICAgICAgICA6IFtcbiAgICAgICAgICAgICAgaChcbiAgICAgICAgICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgIHsgY2xhc3M6IFwiYnRuIHJlY1wiLCBkaXNhYmxlZDogcnVubmluZyB8fCBvdGhlclJlYywgdGl0bGU6IFwiVXNhIGxhIHDDoWdpbmEgbm9ybWFsbWVudGU7IHRvZG8gbG8gcXVlIGhhZ2FzIHNlIGdyYWJhXCIsIG9uY2xpY2s6ICgpID0+IEEuc3RhcnRSZWNvcmRpbmcoZmxvdywgXCJyZWNvcmRcIikgfSxcbiAgICAgICAgICAgICAgICBcIuKXjyBHcmFiYXJcIixcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgaChcbiAgICAgICAgICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgIGNsYXNzOiBcImJ0blwiLFxuICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ6IHJ1bm5pbmcgfHwgb3RoZXJSZWMsXG4gICAgICAgICAgICAgICAgICB0aXRsZTogXCJDbGljYSBlbGVtZW50b3MgcGFyYSBhw7FhZGlybG9zIHNpbiBxdWUgbG9zIGJvdG9uZXMgaGFnYW4gbmFkYVwiLFxuICAgICAgICAgICAgICAgICAgb25jbGljazogKCkgPT4gQS5zdGFydFJlY29yZGluZyhmbG93LCBcInBvaW50XCIpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgXCLil44gU2XDsWFsYXJcIixcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIHJ1bm5pbmdcbiAgICAgICAgICA/IGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gZGFuZ2VyXCIsIG9uY2xpY2s6IEEuc3RvcFBsYXkgfSwgXCLilqAgUGFyYXJcIilcbiAgICAgICAgICA6IGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gcHJpbWFyeVwiLCBkaXNhYmxlZDogIWZsb3cuc3RlcHMubGVuZ3RoIHx8ICEhcmVjLCBvbmNsaWNrOiAoKSA9PiBBLnBsYXkoZmxvdykgfSwgXCLilrYgUmVwcm9kdWNpclwiKSxcbiAgICAgICksXG4gICAgICByZWMgJiZcbiAgICAgICAgaChcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IFwiYmFubmVyIFwiICsgKHJlYy5wYXVzZWQgPyBcInBhdXNlZFwiIDogcmVjLm1vZGUpIH0sXG4gICAgICAgICAgcmVjLnBhdXNlZFxuICAgICAgICAgICAgPyBcIkdyYWJhY2nDs24gZW4gcGF1c2EuXCJcbiAgICAgICAgICAgIDogcmVjLm1vZGUgPT09IFwicmVjb3JkXCJcbiAgICAgICAgICAgICAgPyBcIkdyYWJhbmRvIGVuIGxhIHBlc3Rhw7FhIGFjdGl2YS4gQm90b25lcyDihpIgY2xpY2ssIGlucHV0cyDihpIgZXNjcmliaXIgc3UgY29udGVuaWRvLlwiXG4gICAgICAgICAgICAgIDogXCJNb2RvIHNlw7FhbGFyOiBjbGljYSBlbGVtZW50b3MgZGUgbGEgcMOhZ2luYS4gTG9zIGJvdG9uZXMgbm8gc2UgZWplY3V0YW4uIEVzYyBwYXJhIHNhbGlyLlwiLFxuICAgICAgICApLFxuICAgICAgb3RoZXJSZWMgJiYgaChcImRpdlwiLCB7IGNsYXNzOiBcImJhbm5lciBwYXVzZWRcIiB9LCBcIlNlIGVzdMOhIGdyYWJhbmRvIG90cm8gZmx1am8uXCIpLFxuICAgICAgc3RhdGUucGlja2luZyAmJiBoKFwiZGl2XCIsIHsgY2xhc3M6IFwiYmFubmVyIHBvaW50XCIgfSwgXCJDbGljYSB1biBlbGVtZW50byBlbiBsYSBww6FnaW5h4oCmIFwiLCBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6IEEuY2FuY2VsUGljayB9LCBcIkNhbmNlbGFyXCIpKSxcbiAgICAgICFydW5uaW5nICYmIGZsb3cubGFzdFJ1biAmJiBydW5TdW1tYXJ5KGZsb3cpLFxuXG4gICAgICB2YXJpYWJsZXNFZGl0b3IoZmxvdyksXG5cbiAgICAgIC8vIOKUgOKUgCBQYXNvcyDilIDilIBcbiAgICAgIGgoXG4gICAgICAgIFwib2xcIixcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzOiBcInN0ZXBzXCIsXG4gICAgICAgICAgb25kcmFnb3ZlcjogKGU6IERyYWdFdmVudCkgPT4gZS5wcmV2ZW50RGVmYXVsdCgpLFxuICAgICAgICAgIG9uZHJvcDogKGU6IERyYWdFdmVudCkgPT4ge1xuICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgaWYgKHN0YXRlLmRyYWdJZCkgQS5tb3ZlU3RlcChmbG93LCBzdGF0ZS5kcmFnSWQsIG51bGwpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGZsb3cuc3RlcHMubWFwKChzLCBpKSA9PiBzdGVwUm93KGZsb3csIHMsIGksIHJ1bikpLFxuICAgICAgKSxcbiAgICAgIGZsb3cuc3RlcHMubGVuZ3RoID09PSAwICYmICFyZWMgJiYgaChcInBcIiwgeyBjbGFzczogXCJlbXB0eSBtdXRlZFwiIH0sIFwiU2luIHBhc29zIHRvZGF2w61hLiBQdWxzYSBcIiwgaChcImJcIiwgbnVsbCwgXCJHcmFiYXJcIiksIFwiIG8gYcOxYWRlIHBhc29zIGEgbWFuby5cIiksXG4gICAgICBhZGRTdGVwTWVudShmbG93KSxcbiAgICApLFxuICApO1xufVxuXG5mdW5jdGlvbiBydW5TdW1tYXJ5KGZsb3c6IEZsb3cpIHtcbiAgY29uc3QgciA9IGZsb3cubGFzdFJ1biE7XG4gIGNvbnN0IGlkeCA9IHIuZmFpbGVkU3RlcElkID8gZmxvdy5zdGVwcy5maW5kSW5kZXgoKHMpID0+IHMuaWQgPT09IHIuZmFpbGVkU3RlcElkKSArIDEgOiAwO1xuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwic3VtbWFyeSBcIiArIChyLm9rID8gXCJva1wiIDogXCJlcnJcIikgfSxcbiAgICByLm9rID8gYOKckyBPSyBlbiAkeyhyLm1zIC8gMTAwMCkudG9GaXhlZCgxKX1zYCA6IGDinJcgRmFsbMOzJHtpZHggPyBgIGVuIGVsIHBhc28gJHtpZHh9YCA6IFwiXCJ9OiAke3IuZXJyb3J9YCxcbiAgICBoKFwic3BhblwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgXCIgwrcgXCIgKyB0aW1lQWdvKHIuYXQpKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gdGFnRWRpdG9yKGZsb3c6IEZsb3cpIHtcbiAgcmV0dXJuIGgoXG4gICAgXCJkaXZcIixcbiAgICB7IGNsYXNzOiBcInRhZy1lZGl0b3JcIiB9LFxuICAgIGZsb3cudGFncy5tYXAoKHQpID0+XG4gICAgICBoKFxuICAgICAgICBcInNwYW5cIixcbiAgICAgICAgeyBjbGFzczogXCJjaGlwXCIgfSxcbiAgICAgICAgXCIjXCIgKyB0LFxuICAgICAgICBoKFxuICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwieFwiLFxuICAgICAgICAgICAgdGl0bGU6IFwiUXVpdGFyXCIsXG4gICAgICAgICAgICBvbmNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGZsb3cudGFncyA9IGZsb3cudGFncy5maWx0ZXIoKHgpID0+IHggIT09IHQpO1xuICAgICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIsOXXCIsXG4gICAgICAgICksXG4gICAgICApLFxuICAgICksXG4gICAgaChcImlucHV0XCIsIHtcbiAgICAgIGNsYXNzOiBcInRhZy1pbnB1dFwiLFxuICAgICAgcGxhY2Vob2xkZXI6IGZsb3cudGFncy5sZW5ndGggPyBcIitcIiA6IFwiYcOxYWRpcuKAplwiLFxuICAgICAgbGlzdDogXCJhbGwtdGFnc1wiLFxuICAgICAgXCJkYXRhLWtcIjogXCJ0YWctaW5wdXRcIixcbiAgICAgIG9ua2V5ZG93bjogKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgaW5wdXQgPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICBpZiAoKGUua2V5ID09PSBcIkVudGVyXCIgfHwgZS5rZXkgPT09IFwiLFwiKSAmJiBpbnB1dC52YWx1ZS50cmltKCkpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgY29uc3QgdCA9IGlucHV0LnZhbHVlLnRyaW0oKS5yZXBsYWNlKC9eIy8sIFwiXCIpLnJlcGxhY2UoLywkLywgXCJcIik7XG4gICAgICAgICAgaWYgKHQgJiYgIWZsb3cudGFncy5pbmNsdWRlcyh0KSkgZmxvdy50YWdzLnB1c2godCk7XG4gICAgICAgICAgaW5wdXQudmFsdWUgPSBcIlwiO1xuICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICB9IGVsc2UgaWYgKGUua2V5ID09PSBcIkJhY2tzcGFjZVwiICYmICFpbnB1dC52YWx1ZSAmJiBmbG93LnRhZ3MubGVuZ3RoKSB7XG4gICAgICAgICAgZmxvdy50YWdzLnBvcCgpO1xuICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgIH0pLFxuICAgIGgoXCJkYXRhbGlzdFwiLCB7IGlkOiBcImFsbC10YWdzXCIgfSwgQS5hbGxUYWdzKCkubWFwKCh0KSA9PiBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IHQgfSkpKSxcbiAgKTtcbn1cblxubGV0IHZhcnNPcGVuOiBib29sZWFuIHwgdW5kZWZpbmVkO1xuXG5mdW5jdGlvbiB2YXJpYWJsZXNFZGl0b3IoZmxvdzogRmxvdykge1xuICBjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXMoZmxvdy52YXJpYWJsZXMgPz8ge30pO1xuICBjb25zdCB3cml0ZSA9IChwYWlyczogW3N0cmluZywgc3RyaW5nXVtdKSA9PiB7XG4gICAgZmxvdy52YXJpYWJsZXMgPSBPYmplY3QuZnJvbUVudHJpZXMocGFpcnMuZmlsdGVyKChba10pID0+IGsudHJpbSgpKSk7XG4gIH07XG4gIHJldHVybiBoKFxuICAgIFwiZGV0YWlsc1wiLFxuICAgIHtcbiAgICAgIGNsYXNzOiBcInZhcnNcIixcbiAgICAgIG9wZW46IHZhcnNPcGVuID8/IGVudHJpZXMubGVuZ3RoID4gMCxcbiAgICAgIG9udG9nZ2xlOiAoZTogRXZlbnQpID0+ICh2YXJzT3BlbiA9IChlLnRhcmdldCBhcyBIVE1MRGV0YWlsc0VsZW1lbnQpLm9wZW4pLFxuICAgIH0sXG4gICAgaChcInN1bW1hcnlcIiwgbnVsbCwgXCJWYXJpYWJsZXNcIiwgZW50cmllcy5sZW5ndGggPiAwICYmIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiY291bnRcIiB9LCBTdHJpbmcoZW50cmllcy5sZW5ndGgpKSksXG4gICAgaChcbiAgICAgIFwicFwiLFxuICAgICAgeyBjbGFzczogXCJtdXRlZCBzbWFsbFwiIH0sXG4gICAgICBcIlVzYSBcIixcbiAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwie3tub21icmV9fVwiKSxcbiAgICAgIFwiIGVuIGN1YWxxdWllciB2YWxvci4gSW50ZWdyYWRhczogXCIsXG4gICAgICBCVUlMVElOX1ZBUlMubWFwKChiLCBpKSA9PiBbaSA/IFwiLCBcIiA6IFwiXCIsIGgoXCJjb2RlXCIsIG51bGwsIGB7eyR7Yn19fWApXSksXG4gICAgKSxcbiAgICBlbnRyaWVzLm1hcCgoW2ssIHZdLCBpKSA9PlxuICAgICAgaChcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgeyBjbGFzczogXCJ2YXItcm93XCIgfSxcbiAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbSBtb25vXCIsXG4gICAgICAgICAgdmFsdWU6IGssXG4gICAgICAgICAgcGxhY2Vob2xkZXI6IFwibm9tYnJlXCIsXG4gICAgICAgICAgXCJkYXRhLWtcIjogYHZhci1rLSR7aX1gLFxuICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHBhaXJzID0gT2JqZWN0LmVudHJpZXMoZmxvdy52YXJpYWJsZXMpO1xuICAgICAgICAgICAgcGFpcnNbaV0gPSBbKGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlLnRyaW0oKSwgdl07XG4gICAgICAgICAgICB3cml0ZShwYWlycyk7XG4gICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgIHZhbHVlOiB2LFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiBcInZhbG9yXCIsXG4gICAgICAgICAgXCJkYXRhLWtcIjogYHZhci12LSR7aX1gLFxuICAgICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgZmxvdy52YXJpYWJsZXNba10gPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgICBBLnNhdmVTb29uKGZsb3cpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgICBoKFxuICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiaWNvblwiLFxuICAgICAgICAgICAgdGl0bGU6IFwiUXVpdGFyXCIsXG4gICAgICAgICAgICBvbmNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIGRlbGV0ZSBmbG93LnZhcmlhYmxlc1trXTtcbiAgICAgICAgICAgICAgdm9pZCBBLnNhdmVOb3coZmxvdyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCLDl1wiLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICAgIGgoXG4gICAgICBcImJ1dHRvblwiLFxuICAgICAge1xuICAgICAgICBjbGFzczogXCJidG4gc20gZ2hvc3RcIixcbiAgICAgICAgb25jbGljazogKCkgPT4ge1xuICAgICAgICAgIGxldCBuID0gMTtcbiAgICAgICAgICB3aGlsZSAoYHZhciR7bn1gIGluIGZsb3cudmFyaWFibGVzKSBuKys7XG4gICAgICAgICAgZmxvdy52YXJpYWJsZXNbYHZhciR7bn1gXSA9IFwiXCI7XG4gICAgICAgICAgdm9pZCBBLnNhdmVOb3coZmxvdyk7XG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgXCIrIFZhcmlhYmxlXCIsXG4gICAgKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gc3VtbWFyeVZhbHVlKHM6IFN0ZXApOiBzdHJpbmcge1xuICBpZiAocy52YWx1ZSA9PSBudWxsIHx8IHMudmFsdWUgPT09IFwiXCIpIHJldHVybiBcIlwiO1xuICBpZiAocy5zZWNyZXQpIHJldHVybiBcIuKAouKAouKAouKAouKAouKAolwiO1xuICBpZiAocy50eXBlID09PSBcImNoZWNrXCIpIHJldHVybiBzLnZhbHVlID09PSBcImZhbHNlXCIgPyBcImRlc21hcmNhclwiIDogXCJtYXJjYXJcIjtcbiAgaWYgKHMudHlwZSA9PT0gXCJzZWxlY3RcIikgcmV0dXJuIHMub3B0aW9uVGV4dCB8fCBzLnZhbHVlO1xuICBpZiAocy50eXBlID09PSBcIndhaXRcIikgcmV0dXJuIGAke3MudmFsdWV9IG1zYDtcbiAgcmV0dXJuIHMudmFsdWU7XG59XG5cbmZ1bmN0aW9uIHN0ZXBSb3coZmxvdzogRmxvdywgczogU3RlcCwgaTogbnVtYmVyLCBydW46IHR5cGVvZiBzdGF0ZS5ydW4pIHtcbiAgY29uc3QgbWV0YSA9IFNURVBfTUVUQVtzLnR5cGVdO1xuICBjb25zdCBvcGVuID0gc3RhdGUuZXhwYW5kZWQuaGFzKHMuaWQpO1xuICBjb25zdCBzdGF0dXMgPSBydW4/LnN0YXR1c1tzLmlkXTtcbiAgY29uc3QgaW5mbyA9IHJ1bj8uaW5mb1tzLmlkXTtcbiAgY29uc3QgdGl0bGUgPVxuICAgIHMudHlwZSA9PT0gXCJuYXZpZ2F0ZVwiID8gcy5sYWJlbCB8fCBzLnZhbHVlIHx8IFwiVVJMXCIgOiBzLnR5cGUgPT09IFwicHJlc3NcIiA/IHMudmFsdWUgfHwgXCJFbnRlclwiIDogcy50eXBlID09PSBcIndhaXRcIiA/IFwiXCIgOiBzLmxhYmVsIHx8IHMuc2VsZWN0b3IgfHwgXCJzaW4gZWxlbWVudG9cIjtcbiAgY29uc3QgdmFsID0gcy50eXBlID09PSBcIm5hdmlnYXRlXCIgfHwgcy50eXBlID09PSBcInByZXNzXCIgPyBcIlwiIDogc3VtbWFyeVZhbHVlKHMpO1xuXG4gIGNvbnN0IHRvZ2dsZSA9ICgpID0+IHtcbiAgICBvcGVuID8gc3RhdGUuZXhwYW5kZWQuZGVsZXRlKHMuaWQpIDogc3RhdGUuZXhwYW5kZWQuYWRkKHMuaWQpO1xuICAgIEEucmVuZGVyKCk7XG4gIH07XG5cbiAgY29uc3QgbGkgPSBoKFxuICAgIFwibGlcIixcbiAgICB7XG4gICAgICBjbGFzczogYHN0ZXAgdC0ke3MudHlwZX0ke29wZW4gPyBcIiBvcGVuXCIgOiBcIlwifSR7cy5lbmFibGVkID8gXCJcIiA6IFwiIGRpc2FibGVkXCJ9JHtzdGF0dXMgPyBcIiBzdC1cIiArIHN0YXR1cyA6IFwiXCJ9JHtzdGF0ZS5kcmFnSWQgPT09IHMuaWQgPyBcIiBkcmFnZ2luZ1wiIDogXCJcIn1gLFxuICAgICAgXCJkYXRhLXN0ZXBcIjogcy5pZCxcbiAgICAgIG9uZHJhZ3N0YXJ0OiAoZTogRHJhZ0V2ZW50KSA9PiB7XG4gICAgICAgIHN0YXRlLmRyYWdJZCA9IHMuaWQ7XG4gICAgICAgIGUuZGF0YVRyYW5zZmVyIS5lZmZlY3RBbGxvd2VkID0gXCJtb3ZlXCI7XG4gICAgICAgIGUuZGF0YVRyYW5zZmVyIS5zZXREYXRhKFwidGV4dC9wbGFpblwiLCBzLmlkKTtcbiAgICAgIH0sXG4gICAgICBvbmRyYWdlbmQ6ICgpID0+IHtcbiAgICAgICAgc3RhdGUuZHJhZ0lkID0gdW5kZWZpbmVkO1xuICAgICAgICBsaS5kcmFnZ2FibGUgPSBmYWxzZTtcbiAgICAgICAgQS5yZW5kZXIoKTtcbiAgICAgIH0sXG4gICAgICBvbmRyYWdvdmVyOiAoZTogRHJhZ0V2ZW50KSA9PiB7XG4gICAgICAgIGlmICghc3RhdGUuZHJhZ0lkIHx8IHN0YXRlLmRyYWdJZCA9PT0gcy5pZCkgcmV0dXJuO1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGNvbnN0IHIgPSBsaS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgbGkuY2xhc3NMaXN0LnRvZ2dsZShcImRyb3AtYmVmb3JlXCIsIGUuY2xpZW50WSA8IHIudG9wICsgci5oZWlnaHQgLyAyKTtcbiAgICAgICAgbGkuY2xhc3NMaXN0LnRvZ2dsZShcImRyb3AtYWZ0ZXJcIiwgZS5jbGllbnRZID49IHIudG9wICsgci5oZWlnaHQgLyAyKTtcbiAgICAgIH0sXG4gICAgICBvbmRyYWdsZWF2ZTogKCkgPT4gbGkuY2xhc3NMaXN0LnJlbW92ZShcImRyb3AtYmVmb3JlXCIsIFwiZHJvcC1hZnRlclwiKSxcbiAgICAgIG9uZHJvcDogKGU6IERyYWdFdmVudCkgPT4ge1xuICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGlmICghc3RhdGUuZHJhZ0lkIHx8IHN0YXRlLmRyYWdJZCA9PT0gcy5pZCkgcmV0dXJuO1xuICAgICAgICBjb25zdCBhZnRlciA9IGxpLmNsYXNzTGlzdC5jb250YWlucyhcImRyb3AtYWZ0ZXJcIik7XG4gICAgICAgIGNvbnN0IG5leHQgPSBhZnRlciA/IGZsb3cuc3RlcHNbaSArIDFdPy5pZCA/PyBudWxsIDogcy5pZDtcbiAgICAgICAgQS5tb3ZlU3RlcChmbG93LCBzdGF0ZS5kcmFnSWQsIG5leHQgPT09IHN0YXRlLmRyYWdJZCA/IHMuaWQgOiBuZXh0KTtcbiAgICAgIH0sXG4gICAgfSxcbiAgICBoKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IFwic3RlcC1oXCIgfSxcbiAgICAgIGgoXG4gICAgICAgIFwic3BhblwiLFxuICAgICAgICB7XG4gICAgICAgICAgY2xhc3M6IFwiZ3JpcFwiLFxuICAgICAgICAgIHRpdGxlOiBcIkFycmFzdHJhciBwYXJhIHJlb3JkZW5hclwiLFxuICAgICAgICAgIG9ubW91c2Vkb3duOiAoKSA9PiAobGkuZHJhZ2dhYmxlID0gdHJ1ZSksXG4gICAgICAgICAgb25tb3VzZXVwOiAoKSA9PiAobGkuZHJhZ2dhYmxlID0gZmFsc2UpLFxuICAgICAgICB9LFxuICAgICAgICBcIuKLruKLrlwiLFxuICAgICAgKSxcbiAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwibnVtXCIgfSwgU3RyaW5nKGkgKyAxKSksXG4gICAgICBoKFwic3BhblwiLCB7IGNsYXNzOiBcImJhZGdlXCIsIHRpdGxlOiBtZXRhLmxhYmVsIH0sIG1ldGEuaWNvbiksXG4gICAgICBoKFxuICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICB7IGNsYXNzOiBcInN0ZXAtdGl0bGVcIiwgb25jbGljazogdG9nZ2xlIH0sXG4gICAgICAgIGgoXCJiXCIsIG51bGwsIG1ldGEubGFiZWwpLFxuICAgICAgICB0aXRsZSAmJiBoKFwic3BhblwiLCB7IGNsYXNzOiBcImxibFwiIH0sIHRpdGxlKSxcbiAgICAgICAgISFzLmZyYW1lPy5sZW5ndGggJiYgaChcInNwYW5cIiwgeyBjbGFzczogXCJmcmFtZS10YWdcIiwgdGl0bGU6IFwiRGVudHJvIGRlIGlmcmFtZTogXCIgKyBzLmZyYW1lLm1hcCgoZikgPT4gZi5zZWxlY3Rvcikuam9pbihcIiDCuyBcIikgfSwgcy5mcmFtZS5sZW5ndGggPiAxID8gYGlmcmFtZSDDlyR7cy5mcmFtZS5sZW5ndGh9YCA6IFwiaWZyYW1lXCIpLFxuICAgICAgICB2YWwgJiYgaChcInNwYW5cIiwgeyBjbGFzczogXCJ2YWxcIiB9LCB2YWwpLFxuICAgICAgKSxcbiAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwic3RhdHVzXCIsIHRpdGxlOiBpbmZvID8/IHN0YXR1cyA/PyBcIlwiIH0sIHN0YXR1c0ljb24oc3RhdHVzKSksXG4gICAgKSxcbiAgICBzdGF0dXMgPT09IFwiZXJyb3JcIiAmJiBpbmZvICYmIGgoXCJkaXZcIiwgeyBjbGFzczogXCJzdGVwLWVyclwiIH0sIGluZm8pLFxuICAgIG9wZW4gJiYgc3RlcERldGFpbHMoZmxvdywgcywgaSksXG4gICk7XG4gIHJldHVybiBsaTtcbn1cblxuZnVuY3Rpb24gc3RhdHVzSWNvbihzdD86IHN0cmluZykge1xuICBzd2l0Y2ggKHN0KSB7XG4gICAgY2FzZSBcInJ1bm5pbmdcIjpcbiAgICAgIHJldHVybiBoKFwic3BhblwiLCB7IGNsYXNzOiBcInNwaW5cIiB9KTtcbiAgICBjYXNlIFwib2tcIjpcbiAgICAgIHJldHVybiBcIuKck1wiO1xuICAgIGNhc2UgXCJlcnJvclwiOlxuICAgICAgcmV0dXJuIFwi4pyXXCI7XG4gICAgY2FzZSBcInNraXBwZWRcIjpcbiAgICAgIHJldHVybiBcIuKAk1wiO1xuICAgIGRlZmF1bHQ6XG4gICAgICByZXR1cm4gXCJcIjtcbiAgfVxufVxuXG5mdW5jdGlvbiBzdGVwRGV0YWlscyhmbG93OiBGbG93LCBzOiBTdGVwLCBpOiBudW1iZXIpIHtcbiAgY29uc3QgbWV0YSA9IFNURVBfTUVUQVtzLnR5cGVdO1xuICBjb25zdCBzYXZlID0gKCkgPT4gQS5zYXZlU29vbihmbG93KTtcbiAgY29uc3QgZmllbGQgPSAobGFiZWw6IHN0cmluZywgLi4uY29udHJvbDogKE5vZGUgfCBmYWxzZSB8IHVuZGVmaW5lZCB8IG51bGwpW10pID0+IGgoXCJsYWJlbFwiLCB7IGNsYXNzOiBcImZpZWxkXCIgfSwgaChcInNwYW5cIiwgbnVsbCwgbGFiZWwpLCAuLi5jb250cm9sKTtcbiAgY29uc3QgdGFyZ2V0YWJsZSA9IG1ldGEubmVlZHNUYXJnZXQgfHwgcy50eXBlID09PSBcInByZXNzXCI7XG5cbiAgcmV0dXJuIGgoXG4gICAgXCJkaXZcIixcbiAgICB7IGNsYXNzOiBcInN0ZXAtYm9keVwiIH0sXG4gICAgZmllbGQoXG4gICAgICBcIlRpcG9cIixcbiAgICAgIGgoXG4gICAgICAgIFwic2VsZWN0XCIsXG4gICAgICAgIHtcbiAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMudHlwZSA9IChlLnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWUgYXMgU3RlcFR5cGU7XG4gICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBUWVBFUy5tYXAoKHQpID0+IGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogdCwgc2VsZWN0ZWQ6IHQgPT09IHMudHlwZSB9LCBgJHtTVEVQX01FVEFbdF0uaWNvbn0gICR7U1RFUF9NRVRBW3RdLmxhYmVsfWApKSxcbiAgICAgICksXG4gICAgKSxcbiAgICB0YXJnZXRhYmxlICYmXG4gICAgICBmaWVsZChcbiAgICAgICAgcy50eXBlID09PSBcInByZXNzXCIgPyBcIkVsZW1lbnRvIChvcGNpb25hbClcIiA6IFwiRWxlbWVudG9cIixcbiAgICAgICAgaChcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IFwicm93IHRpZ2h0XCIgfSxcbiAgICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc20gbW9ubyBncm93XCIsXG4gICAgICAgICAgICB2YWx1ZTogcy5zZWxlY3RvciA/PyBcIlwiLFxuICAgICAgICAgICAgcGxhY2Vob2xkZXI6IFwiY3NzLCB0ZXh0PeKApiwgbGFiZWw94oCmLCB4cGF0aD3igKZcIixcbiAgICAgICAgICAgIFwiZGF0YS1rXCI6IGBzZWwtJHtzLmlkfWAsXG4gICAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgcy5zZWxlY3RvciA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSB8fCB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgIHNhdmUoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiQXB1bnRhciBlbiBsYSBww6FnaW5hXCIsIGRpc2FibGVkOiAhIXN0YXRlLnBpY2tpbmcsIG9uY2xpY2s6ICgpID0+IEEucGlja0ZvcihmbG93LCBzKSB9LCBcIvCfjq9cIiksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiUmVzYWx0YXIgZW4gbGEgcMOhZ2luYVwiLCBkaXNhYmxlZDogIXMuc2VsZWN0b3IsIG9uY2xpY2s6ICgpID0+IEEuaGlnaGxpZ2h0U3RlcChzKSB9LCBcIvCfkYFcIiksXG4gICAgICAgICksXG4gICAgICApLFxuICAgIHRhcmdldGFibGUgJiYgZnJhbWVGaWVsZChmbG93LCBzLCBmaWVsZCksXG4gICAgdGFyZ2V0YWJsZSAmJlxuICAgICAgISFzLmZhbGxiYWNrcz8ubGVuZ3RoICYmXG4gICAgICBoKFxuICAgICAgICBcImRldGFpbHNcIixcbiAgICAgICAgeyBjbGFzczogXCJmYWxsYmFja3NcIiB9LFxuICAgICAgICBoKFwic3VtbWFyeVwiLCBudWxsLCBgJHtzLmZhbGxiYWNrcy5sZW5ndGh9IHNlbGVjdG9yKGVzKSBhbHRlcm5hdGl2byhzKWApLFxuICAgICAgICBoKFwidGV4dGFyZWFcIiwge1xuICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtIG1vbm9cIixcbiAgICAgICAgICByb3dzOiBNYXRoLm1pbig1LCBzLmZhbGxiYWNrcy5sZW5ndGgpLFxuICAgICAgICAgIFwiZGF0YS1rXCI6IGBmYi0ke3MuaWR9YCxcbiAgICAgICAgICB2YWx1ZTogcy5mYWxsYmFja3Muam9pbihcIlxcblwiKSxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMuZmFsbGJhY2tzID0gKGUudGFyZ2V0IGFzIEhUTUxUZXh0QXJlYUVsZW1lbnQpLnZhbHVlLnNwbGl0KFwiXFxuXCIpLm1hcCgoeCkgPT4geC50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgICAgIHNhdmUoKTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KSxcbiAgICAgICksXG4gICAgdGFyZ2V0YWJsZSAmJlxuICAgICAgZmllbGQoXG4gICAgICAgIFwiTm9tYnJlXCIsXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICB2YWx1ZTogcy5sYWJlbCA/PyBcIlwiLFxuICAgICAgICAgIHBsYWNlaG9sZGVyOiBcIkRlc2NyaXBjacOzbiBsZWdpYmxlXCIsXG4gICAgICAgICAgXCJkYXRhLWtcIjogYGxibC0ke3MuaWR9YCxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMubGFiZWwgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWUgfHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgc2F2ZSgpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgKSxcbiAgICBzLnR5cGUgIT09IFwiY2xpY2tcIiAmJiBzLnR5cGUgIT09IFwid2FpdEZvclwiICYmIHZhbHVlRmllbGQoZmxvdywgcywgZmllbGQpLFxuICAgIGgoXG4gICAgICBcImRpdlwiLFxuICAgICAgeyBjbGFzczogXCJyb3cgdHdvXCIgfSxcbiAgICAgIHMudHlwZSAhPT0gXCJuYXZpZ2F0ZVwiICYmXG4gICAgICAgIHMudHlwZSAhPT0gXCJ3YWl0XCIgJiZcbiAgICAgICAgZmllbGQoXG4gICAgICAgICAgXCJUaW1lb3V0IChtcylcIixcbiAgICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgICAgICBtaW46IDAsXG4gICAgICAgICAgICBzdGVwOiA1MDAsXG4gICAgICAgICAgICBwbGFjZWhvbGRlcjogU3RyaW5nKHN0YXRlLnNldHRpbmdzLnRpbWVvdXQpLFxuICAgICAgICAgICAgdmFsdWU6IHMudGltZW91dCA/PyBcIlwiLFxuICAgICAgICAgICAgXCJkYXRhLWtcIjogYHRvLSR7cy5pZH1gLFxuICAgICAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IHYgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkudmFsdWVBc051bWJlcjtcbiAgICAgICAgICAgICAgcy50aW1lb3V0ID0gTnVtYmVyLmlzRmluaXRlKHYpID8gdiA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgc2F2ZSgpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKSxcbiAgICAgIGZpZWxkKFxuICAgICAgICBcIk5vdGFcIixcbiAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgIHZhbHVlOiBzLm5vdGUgPz8gXCJcIixcbiAgICAgICAgICBcImRhdGEta1wiOiBgbm90ZS0ke3MuaWR9YCxcbiAgICAgICAgICBvbmlucHV0OiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHMubm90ZSA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZSB8fCB1bmRlZmluZWQ7XG4gICAgICAgICAgICBzYXZlKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICApLFxuICAgICksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcInJvdyBzdGVwLWZvb3RcIiB9LFxuICAgICAgaChcbiAgICAgICAgXCJsYWJlbFwiLFxuICAgICAgICB7IGNsYXNzOiBcInRvZ2dsZVwiIH0sXG4gICAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgICAgdHlwZTogXCJjaGVja2JveFwiLFxuICAgICAgICAgIGNoZWNrZWQ6IHMuZW5hYmxlZCxcbiAgICAgICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgICBzLmVuYWJsZWQgPSAoZS50YXJnZXQgYXMgSFRNTElucHV0RWxlbWVudCkuY2hlY2tlZDtcbiAgICAgICAgICAgIHZvaWQgQS5zYXZlTm93KGZsb3cpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pLFxuICAgICAgICBcIkFjdGl2b1wiLFxuICAgICAgKSxcbiAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiZ3Jvd1wiIH0pLFxuICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImJ0biBzbSBnaG9zdFwiLCB0aXRsZTogXCJFamVjdXRhciBzb2xvIGVzdGUgcGFzb1wiLCBkaXNhYmxlZDogQS5ydW5uZXIucnVubmluZywgb25jbGljazogKCkgPT4gQS5wbGF5KGZsb3csIGksIGkpIH0sIFwi4pa2IFNvbG8gZXN0ZVwiKSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gc20gZ2hvc3RcIiwgdGl0bGU6IFwiUmVwcm9kdWNpciBkZXNkZSBlc3RlIHBhc29cIiwgZGlzYWJsZWQ6IEEucnVubmVyLnJ1bm5pbmcsIG9uY2xpY2s6ICgpID0+IEEucGxheShmbG93LCBpKSB9LCBcIuKWtiBEZXNkZSBhcXXDrVwiKSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIkR1cGxpY2FyIHBhc29cIiwgb25jbGljazogKCkgPT4gQS5kdXBsaWNhdGVTdGVwKGZsb3csIHMpIH0sIFwi4qeJXCIpLFxuICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb24gZGFuZ2VyXCIsIHRpdGxlOiBcIkJvcnJhciBwYXNvXCIsIG9uY2xpY2s6ICgpID0+IEEuZGVsZXRlU3RlcChmbG93LCBzKSB9LCBcIvCfl5FcIiksXG4gICAgKSxcbiAgKTtcbn1cblxuY29uc3QgRlJBTUVfU0VQID0gXCIgPj4gXCI7XG5cbmZ1bmN0aW9uIGZyYW1lRmllbGQoZmxvdzogRmxvdywgczogU3RlcCwgZmllbGQ6IChsOiBzdHJpbmcsIC4uLmM6IChOb2RlIHwgZmFsc2UgfCB1bmRlZmluZWQgfCBudWxsKVtdKSA9PiBIVE1MRWxlbWVudCkge1xuICByZXR1cm4gZmllbGQoXG4gICAgXCJJZnJhbWVcIixcbiAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgY2xhc3M6IFwiaW5wdXQgc20gbW9ub1wiLFxuICAgICAgdmFsdWU6IChzLmZyYW1lID8/IFtdKS5tYXAoKGYpID0+IGYuc2VsZWN0b3IpLmpvaW4oRlJBTUVfU0VQKSxcbiAgICAgIHBsYWNlaG9sZGVyOiBcIuKAlCBww6FnaW5hIHByaW5jaXBhbCDigJQgICAoaWZyYW1lI3BhZ28gPj4gaWZyYW1lW25hbWU9Y3ZjXSlcIixcbiAgICAgIFwiZGF0YS1rXCI6IGBmcmFtZS0ke3MuaWR9YCxcbiAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICBjb25zdCBwYXJ0cyA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZS5zcGxpdChcIj4+XCIpLm1hcCgoeCkgPT4geC50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgICAgICAgLy8gQ29uc2VydmEgbG9zIGFsdGVybmF0aXZvcyBkZSBsb3Mgbml2ZWxlcyBxdWUgbm8gY2FtYmlhbi5cbiAgICAgICAgcy5mcmFtZSA9IHBhcnRzLmxlbmd0aCA/IHBhcnRzLm1hcCgoc2VsLCBpKSA9PiAocy5mcmFtZT8uW2ldPy5zZWxlY3RvciA9PT0gc2VsID8gcy5mcmFtZVtpXSEgOiB7IHNlbGVjdG9yOiBzZWwgfSkpIDogdW5kZWZpbmVkO1xuICAgICAgICBBLnNhdmVTb29uKGZsb3cpO1xuICAgICAgfSxcbiAgICB9KSxcbiAgICAhIXMuZnJhbWU/Lmxlbmd0aCAmJiBoKFwic21hbGxcIiwgeyBjbGFzczogXCJtdXRlZFwiIH0sIFwiUnV0YSBkZSBpZnJhbWVzIGRlc2RlIGxhIHDDoWdpbmEgcHJpbmNpcGFsLCBzZXBhcmFkYSBwb3IgPj5cIiksXG4gICk7XG59XG5cbmZ1bmN0aW9uIHZhbHVlRmllbGQoZmxvdzogRmxvdywgczogU3RlcCwgZmllbGQ6IChsOiBzdHJpbmcsIC4uLmM6IChOb2RlIHwgZmFsc2UgfCB1bmRlZmluZWQgfCBudWxsKVtdKSA9PiBIVE1MRWxlbWVudCkge1xuICBjb25zdCBtZXRhID0gU1RFUF9NRVRBW3MudHlwZV07XG4gIGNvbnN0IG9uVmFsID0gKGU6IEV2ZW50KSA9PiB7XG4gICAgcy52YWx1ZSA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZTtcbiAgICBBLnNhdmVTb29uKGZsb3cpO1xuICB9O1xuICBpZiAocy50eXBlID09PSBcImNoZWNrXCIpIHtcbiAgICByZXR1cm4gZmllbGQoXG4gICAgICBcIkVzdGFkb1wiLFxuICAgICAgaChcbiAgICAgICAgXCJzZWxlY3RcIixcbiAgICAgICAge1xuICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgICAgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgcy52YWx1ZSA9IChlLnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwidHJ1ZVwiLCBzZWxlY3RlZDogcy52YWx1ZSAhPT0gXCJmYWxzZVwiIH0sIFwi4piRIE1hcmNhZG9cIiksXG4gICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJmYWxzZVwiLCBzZWxlY3RlZDogcy52YWx1ZSA9PT0gXCJmYWxzZVwiIH0sIFwi4piQIERlc21hcmNhZG9cIiksXG4gICAgICApLFxuICAgICk7XG4gIH1cbiAgY29uc3QgbGFiZWxzOiBQYXJ0aWFsPFJlY29yZDxTdGVwVHlwZSwgc3RyaW5nPj4gPSB7IG5hdmlnYXRlOiBcIlVSTFwiLCBmaWxsOiBcIlRleHRvXCIsIHNlbGVjdDogXCJPcGNpw7NuICh2YWx1ZSlcIiwgcHJlc3M6IFwiVGVjbGFcIiwgd2FpdDogXCJNaWxpc2VndW5kb3NcIiwgYXNzZXJ0VGV4dDogXCJUZXh0byBlc3BlcmFkb1wiIH07XG4gIGNvbnN0IGlucHV0ID0gaChcImlucHV0XCIsIHtcbiAgICBjbGFzczogXCJpbnB1dCBzbVwiICsgKHMudHlwZSA9PT0gXCJuYXZpZ2F0ZVwiID8gXCIgbW9ub1wiIDogXCJcIiksXG4gICAgdHlwZTogcy5zZWNyZXQgPyBcInBhc3N3b3JkXCIgOiBzLnR5cGUgPT09IFwid2FpdFwiID8gXCJudW1iZXJcIiA6IFwidGV4dFwiLFxuICAgIHZhbHVlOiBzLnZhbHVlID8/IFwiXCIsXG4gICAgcGxhY2Vob2xkZXI6IG1ldGEudmFsdWVIaW50ID8/IFwiXCIsXG4gICAgbGlzdDogcy50eXBlID09PSBcInByZXNzXCIgPyBcImtleXNcIiA6IG51bGwsXG4gICAgXCJkYXRhLWtcIjogYHZhbC0ke3MuaWR9YCxcbiAgICBvbmlucHV0OiBvblZhbCxcbiAgfSk7XG4gIHJldHVybiBmaWVsZChcbiAgICBsYWJlbHNbcy50eXBlXSA/PyBcIlZhbG9yXCIsXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcInJvdyB0aWdodFwiIH0sXG4gICAgICBzLnR5cGUgPT09IFwiZmlsbFwiID8gaChcInRleHRhcmVhXCIsIHsgY2xhc3M6IFwiaW5wdXQgc20gZ3Jvd1wiLCByb3dzOiAxLCB2YWx1ZTogcy52YWx1ZSA/PyBcIlwiLCBcImRhdGEta1wiOiBgdmFsLSR7cy5pZH1gLCBwbGFjZWhvbGRlcjogbWV0YS52YWx1ZUhpbnQsIG9uaW5wdXQ6IG9uVmFsLCBzdHlsZTogcy5zZWNyZXQgPyBcIi13ZWJraXQtdGV4dC1zZWN1cml0eTogZGlzY1wiIDogdW5kZWZpbmVkIH0pIDogaW5wdXQsXG4gICAgICBzLnR5cGUgPT09IFwiZmlsbFwiICYmXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjbGFzczogXCJpY29uXCIsXG4gICAgICAgICAgICB0aXRsZTogcy5zZWNyZXQgPyBcIk1vc3RyYXIgKGRlamEgZGUgc2VyIHNlY3JldG8pXCIgOiBcIk1hcmNhciBjb21vIHNlY3JldG9cIixcbiAgICAgICAgICAgIG9uY2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgcy5zZWNyZXQgPSAhcy5zZWNyZXQgfHwgdW5kZWZpbmVkO1xuICAgICAgICAgICAgICB2b2lkIEEuc2F2ZU5vdyhmbG93KTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBzLnNlY3JldCA/IFwi8J+UklwiIDogXCLwn5STXCIsXG4gICAgICAgICksXG4gICAgKSxcbiAgICBzLnR5cGUgPT09IFwic2VsZWN0XCIgJiYgISFzLm9wdGlvblRleHQgJiYgaChcInNtYWxsXCIsIHsgY2xhc3M6IFwibXV0ZWRcIiB9LCBgVGV4dG8gdmlzaWJsZTogwqske3Mub3B0aW9uVGV4dH3Cu2ApLFxuICAgIHMudHlwZSA9PT0gXCJwcmVzc1wiICYmIGgoXCJkYXRhbGlzdFwiLCB7IGlkOiBcImtleXNcIiB9LCBbXCJFbnRlclwiLCBcIlRhYlwiLCBcIkVzY2FwZVwiLCBcIkFycm93RG93blwiLCBcIkFycm93VXBcIiwgXCJCYWNrc3BhY2VcIiwgXCIgXCJdLm1hcCgoaykgPT4gaChcIm9wdGlvblwiLCB7IHZhbHVlOiBrIH0pKSksXG4gICk7XG59XG5cbmZ1bmN0aW9uIGFkZFN0ZXBNZW51KGZsb3c6IEZsb3cpIHtcbiAgcmV0dXJuIGgoXG4gICAgXCJkZXRhaWxzXCIsXG4gICAgeyBjbGFzczogXCJtZW51IGFkZC1zdGVwXCIgfSxcbiAgICBoKFwic3VtbWFyeVwiLCB7IGNsYXNzOiBcImJ0biBnaG9zdCBzbVwiIH0sIFwiKyBBw7FhZGlyIHBhc29cIiksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcIm1lbnUtbGlzdFwiIH0sXG4gICAgICBUWVBFUy5tYXAoKHQpID0+XG4gICAgICAgIGgoXG4gICAgICAgICAgXCJidXR0b25cIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBvbmNsaWNrOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgKGUudGFyZ2V0IGFzIEhUTUxFbGVtZW50KS5jbG9zZXN0KFwiZGV0YWlsc1wiKSEub3BlbiA9IGZhbHNlO1xuICAgICAgICAgICAgICBjb25zdCBzdGVwID0gQS5hZGRTdGVwKGZsb3csIHQpO1xuICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYFtkYXRhLXN0ZXA9XCIke3N0ZXAuaWR9XCJdYCk/LnNjcm9sbEludG9WaWV3KHsgYmxvY2s6IFwiY2VudGVyXCIsIGJlaGF2aW9yOiBcInNtb290aFwiIH0pLCA1MCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgYCR7U1RFUF9NRVRBW3RdLmljb259ICAke1NURVBfTUVUQVt0XS5sYWJlbH1gLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICApO1xufVxuIiwKICAgICJpbXBvcnQgdHlwZSB7IEZsb3cgfSBmcm9tIFwiLi4vLi4vc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgKiBhcyBBIGZyb20gXCIuLi9zdGF0ZVwiO1xuaW1wb3J0IHsgc3RhdGUgfSBmcm9tIFwiLi4vc3RhdGVcIjtcbmltcG9ydCB7IGgsIGhvc3RPZiwgcGlja0ZpbGUsIHRpbWVBZ28gfSBmcm9tIFwiLi4vdWlcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGxpYnJhcnlWaWV3KCk6IEhUTUxFbGVtZW50IHtcbiAgY29uc3QgZmxvd3MgPSBBLmZpbHRlcmVkRmxvd3MoKTtcbiAgY29uc3QgZm9sZGVycyA9IEEuYWxsRm9sZGVycygpO1xuICBjb25zdCB0YWdzID0gQS5hbGxUYWdzKCk7XG4gIGNvbnN0IHNlbCA9IFsuLi5zdGF0ZS5zZWxlY3RlZF0uZmlsdGVyKChpZCkgPT4gc3RhdGUuZmxvd3Muc29tZSgoZikgPT4gZi5pZCA9PT0gaWQpKTtcblxuICBjb25zdCBncm91cHMgPSBuZXcgTWFwPHN0cmluZywgRmxvd1tdPigpO1xuICBmb3IgKGNvbnN0IGYgb2YgZmxvd3MpIHtcbiAgICBjb25zdCBrID0gZi5mb2xkZXIgPz8gXCJcIjtcbiAgICBpZiAoIWdyb3Vwcy5oYXMoaykpIGdyb3Vwcy5zZXQoaywgW10pO1xuICAgIGdyb3Vwcy5nZXQoaykhLnB1c2goZik7XG4gIH1cbiAgY29uc3QgZ3JvdXBLZXlzID0gWy4uLmdyb3Vwcy5rZXlzKCldLnNvcnQoKGEsIGIpID0+IChhID09PSBcIlwiID8gMSA6IGIgPT09IFwiXCIgPyAtMSA6IGEubG9jYWxlQ29tcGFyZShiKSkpO1xuXG4gIHJldHVybiBoKFxuICAgIFwiZGl2XCIsXG4gICAgeyBjbGFzczogXCJ2aWV3XCIgfSxcbiAgICBoKFxuICAgICAgXCJoZWFkZXJcIixcbiAgICAgIHsgY2xhc3M6IFwidG9wXCIgfSxcbiAgICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJicmFuZFwiIH0sIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwibG9nb1wiIH0pLCBcIlJhc3Ryb1wiKSxcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwicm93XCIgfSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiSW1wb3J0YXJcIiwgb25jbGljazogaW1wb3J0RmlsZSB9LCBcIuKHqlwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiRXhwb3J0YXIgdG9kb1wiLCBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydEZsb3dzKHN0YXRlLmZsb3dzKSB9LCBcIuKHqVwiKSxcbiAgICAgICAgaChcImJ1dHRvblwiLCB7IGNsYXNzOiBcImljb25cIiwgdGl0bGU6IFwiQWp1c3Rlc1wiLCBvbmNsaWNrOiAoKSA9PiAoKHN0YXRlLnZpZXcgPSBcInNldHRpbmdzXCIpLCBBLnJlbmRlcigpKSB9LCBcIuKamVwiKSxcbiAgICAgICksXG4gICAgKSxcbiAgICBoKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IFwidG9vbGJhclwiIH0sXG4gICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICBjbGFzczogXCJpbnB1dCBzZWFyY2hcIixcbiAgICAgICAgdHlwZTogXCJzZWFyY2hcIixcbiAgICAgICAgcGxhY2Vob2xkZXI6IFwiQnVzY2FyIHBvciBub21icmUsICNldGlxdWV0YSwgVVJMLCBjYW1wb+KAplwiLFxuICAgICAgICB2YWx1ZTogc3RhdGUuZmlsdGVyLnEsXG4gICAgICAgIFwiZGF0YS1rXCI6IFwic2VhcmNoXCIsXG4gICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgIHN0YXRlLmZpbHRlci5xID0gKGUudGFyZ2V0IGFzIEhUTUxJbnB1dEVsZW1lbnQpLnZhbHVlO1xuICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gcHJpbWFyeVwiLCBvbmNsaWNrOiBBLmNyZWF0ZUZsb3cgfSwgXCIrIE51ZXZvXCIpLFxuICAgICksXG4gICAgKGZvbGRlcnMubGVuZ3RoID4gMCB8fCB0YWdzLmxlbmd0aCA+IDApICYmXG4gICAgICBoKFxuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7IGNsYXNzOiBcImZpbHRlcnNcIiB9LFxuICAgICAgICBoKFxuICAgICAgICAgIFwic2VsZWN0XCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLmZvbGRlciA9IChlLnRhcmdldCBhcyBIVE1MU2VsZWN0RWxlbWVudCkudmFsdWU7XG4gICAgICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgaChcIm9wdGlvblwiLCB7IHZhbHVlOiBcIlwiLCBzZWxlY3RlZDogc3RhdGUuZmlsdGVyLmZvbGRlciA9PT0gXCJcIiB9LCBcIlRvZGFzIGxhcyBjYXJwZXRhc1wiKSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwiX19ub25lXCIsIHNlbGVjdGVkOiBzdGF0ZS5maWx0ZXIuZm9sZGVyID09PSBcIl9fbm9uZVwiIH0sIFwiU2luIGNhcnBldGFcIiksXG4gICAgICAgICAgZm9sZGVycy5tYXAoKGYpID0+IGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogZiwgc2VsZWN0ZWQ6IHN0YXRlLmZpbHRlci5mb2xkZXIgPT09IGYgfSwgXCLwn5OBIFwiICsgZikpLFxuICAgICAgICApLFxuICAgICAgICBoKFxuICAgICAgICAgIFwic2VsZWN0XCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiaW5wdXQgc21cIixcbiAgICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLnNvcnQgPSAoZS50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlIGFzIHR5cGVvZiBzdGF0ZS5maWx0ZXIuc29ydDtcbiAgICAgICAgICAgICAgQS5yZW5kZXIoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwidXBkYXRlZFwiLCBzZWxlY3RlZDogc3RhdGUuZmlsdGVyLnNvcnQgPT09IFwidXBkYXRlZFwiIH0sIFwiUmVjaWVudGVzXCIpLFxuICAgICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJuYW1lXCIsIHNlbGVjdGVkOiBzdGF0ZS5maWx0ZXIuc29ydCA9PT0gXCJuYW1lXCIgfSwgXCJOb21icmVcIiksXG4gICAgICAgICAgaChcIm9wdGlvblwiLCB7IHZhbHVlOiBcImxhc3RSdW5cIiwgc2VsZWN0ZWQ6IHN0YXRlLmZpbHRlci5zb3J0ID09PSBcImxhc3RSdW5cIiB9LCBcIsOabHRpbWEgZWplY3VjacOzblwiKSxcbiAgICAgICAgKSxcbiAgICAgICAgdGFncy5sZW5ndGggPiAwICYmXG4gICAgICAgICAgaChcbiAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICB7IGNsYXNzOiBcImNoaXBzXCIgfSxcbiAgICAgICAgICAgIHRhZ3MubWFwKCh0KSA9PlxuICAgICAgICAgICAgICBoKFxuICAgICAgICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgY2xhc3M6IFwiY2hpcFwiICsgKHN0YXRlLmZpbHRlci50YWdzLmhhcyh0KSA/IFwiIG9uXCIgOiBcIlwiKSxcbiAgICAgICAgICAgICAgICAgIG9uY2xpY2s6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdGUuZmlsdGVyLnRhZ3MuaGFzKHQpID8gc3RhdGUuZmlsdGVyLnRhZ3MuZGVsZXRlKHQpIDogc3RhdGUuZmlsdGVyLnRhZ3MuYWRkKHQpO1xuICAgICAgICAgICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIFwiI1wiICsgdCxcbiAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKSxcbiAgICAgICksXG4gICAgc2VsLmxlbmd0aCA+IDAgJiZcbiAgICAgIGgoXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHsgY2xhc3M6IFwiYnVsa1wiIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIG51bGwsIGAke3NlbC5sZW5ndGh9IHNlbGVjY2lvbmFkbyhzKWApLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0Rmxvd3Moc3RhdGUuZmxvd3MuZmlsdGVyKChmKSA9PiBzZWwuaW5jbHVkZXMoZi5pZCkpKSB9LCBcIkV4cG9ydGFyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuYnVsa01vdmUoc2VsKSB9LCBcIk1vdmVyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtXCIsIG9uY2xpY2s6ICgpID0+IEEuYnVsa1RhZyhzZWwpIH0sIFwiRXRpcXVldGFyXCIpLFxuICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIHNtIGRhbmdlclwiLCBvbmNsaWNrOiAoKSA9PiBBLnJlbW92ZUZsb3dzKHNlbCkgfSwgXCJCb3JyYXJcIiksXG4gICAgICAgIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIlF1aXRhciBzZWxlY2Npw7NuXCIsIG9uY2xpY2s6ICgpID0+IChzdGF0ZS5zZWxlY3RlZC5jbGVhcigpLCBBLnJlbmRlcigpKSB9LCBcIuKclVwiKSxcbiAgICAgICksXG4gICAgaChcbiAgICAgIFwibWFpblwiLFxuICAgICAgeyBjbGFzczogXCJzY3JvbGxcIiwgXCJkYXRhLXNjcm9sbFwiOiBcImxpYnJhcnlcIiB9LFxuICAgICAgc3RhdGUuZmxvd3MubGVuZ3RoID09PSAwXG4gICAgICAgID8gZW1wdHlTdGF0ZSgpXG4gICAgICAgIDogZmxvd3MubGVuZ3RoID09PSAwXG4gICAgICAgICAgPyBoKFwicFwiLCB7IGNsYXNzOiBcImVtcHR5IG11dGVkXCIgfSwgXCJOaW5nw7puIGZsdWpvIGNvaW5jaWRlIGNvbiBlbCBmaWx0cm8uXCIpXG4gICAgICAgICAgOiBncm91cEtleXMubWFwKChrKSA9PiBmb2xkZXJHcm91cChrLCBncm91cHMuZ2V0KGspISwgZ3JvdXBLZXlzLmxlbmd0aCA+IDEgfHwgayAhPT0gXCJcIikpLFxuICAgICksXG4gICk7XG59XG5cbmZ1bmN0aW9uIGZvbGRlckdyb3VwKG5hbWU6IHN0cmluZywgZmxvd3M6IEZsb3dbXSwgc2hvd0hlYWRlcjogYm9vbGVhbikge1xuICBjb25zdCBrZXkgPSBuYW1lIHx8IFwiX19ub25lXCI7XG4gIGNvbnN0IGNvbGxhcHNlZCA9IHN0YXRlLmNvbGxhcHNlZEZvbGRlcnMuaGFzKGtleSk7XG4gIHJldHVybiBoKFxuICAgIFwic2VjdGlvblwiLFxuICAgIHsgY2xhc3M6IFwiZ3JvdXBcIiB9LFxuICAgIHNob3dIZWFkZXIgJiZcbiAgICAgIGgoXG4gICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgIHtcbiAgICAgICAgICBjbGFzczogXCJncm91cC1oXCIsXG4gICAgICAgICAgb25jbGljazogKCkgPT4ge1xuICAgICAgICAgICAgY29sbGFwc2VkID8gc3RhdGUuY29sbGFwc2VkRm9sZGVycy5kZWxldGUoa2V5KSA6IHN0YXRlLmNvbGxhcHNlZEZvbGRlcnMuYWRkKGtleSk7XG4gICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiY2FyZXRcIiArIChjb2xsYXBzZWQgPyBcIlwiIDogXCIgb3BlblwiKSB9LCBcIuKWuFwiKSxcbiAgICAgICAgbmFtZSA/IFwi8J+TgSBcIiArIG5hbWUgOiBcIlNpbiBjYXJwZXRhXCIsXG4gICAgICAgIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiY291bnRcIiB9LCBTdHJpbmcoZmxvd3MubGVuZ3RoKSksXG4gICAgICApLFxuICAgICFjb2xsYXBzZWQgJiYgZmxvd3MubWFwKGZsb3dDYXJkKSxcbiAgKTtcbn1cblxuZnVuY3Rpb24gZmxvd0NhcmQoZjogRmxvdykge1xuICBjb25zdCBob3N0ID0gaG9zdE9mKGYuc3RlcHMuZmluZCgocykgPT4gcy50eXBlID09PSBcIm5hdmlnYXRlXCIpPy52YWx1ZSk7XG4gIGNvbnN0IHJ1bm5pbmcgPSBBLnJ1bm5lci5ydW5uaW5nICYmIHN0YXRlLnJ1bj8uZmxvd0lkID09PSBmLmlkO1xuICByZXR1cm4gaChcbiAgICBcImFydGljbGVcIixcbiAgICB7IGNsYXNzOiBcImNhcmRcIiArIChzdGF0ZS5zZWxlY3RlZC5oYXMoZi5pZCkgPyBcIiBzZWxlY3RlZFwiIDogXCJcIikgfSxcbiAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgdHlwZTogXCJjaGVja2JveFwiLFxuICAgICAgY2xhc3M6IFwiY2hlY2tcIixcbiAgICAgIGNoZWNrZWQ6IHN0YXRlLnNlbGVjdGVkLmhhcyhmLmlkKSxcbiAgICAgIHRpdGxlOiBcIlNlbGVjY2lvbmFyXCIsXG4gICAgICBvbmNoYW5nZTogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkID8gc3RhdGUuc2VsZWN0ZWQuYWRkKGYuaWQpIDogc3RhdGUuc2VsZWN0ZWQuZGVsZXRlKGYuaWQpO1xuICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgfSxcbiAgICB9KSxcbiAgICBoKFxuICAgICAgXCJkaXZcIixcbiAgICAgIHsgY2xhc3M6IFwiY2FyZC1ib2R5XCIsIG9uY2xpY2s6ICgpID0+IEEub3BlbkZsb3coZi5pZCkgfSxcbiAgICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJjYXJkLXRpdGxlXCIgfSwgZi5sYXN0UnVuICYmIGgoXCJzcGFuXCIsIHsgY2xhc3M6IFwiZG90IFwiICsgKGYubGFzdFJ1bi5vayA/IFwib2tcIiA6IFwiZXJyXCIpLCB0aXRsZTogbGFzdFJ1blRleHQoZikgfSksIGYubmFtZSksXG4gICAgICBoKFxuICAgICAgICBcImRpdlwiLFxuICAgICAgICB7IGNsYXNzOiBcIm1ldGFcIiB9LFxuICAgICAgICBgJHtmLnN0ZXBzLmxlbmd0aH0gcGFzbyR7Zi5zdGVwcy5sZW5ndGggPT09IDEgPyBcIlwiIDogXCJzXCJ9YCxcbiAgICAgICAgaG9zdCAmJiBgIMK3ICR7aG9zdH1gLFxuICAgICAgICBgIMK3ICR7dGltZUFnbyhmLnVwZGF0ZWRBdCl9YCxcbiAgICAgICksXG4gICAgICBmLnRhZ3MubGVuZ3RoID4gMCAmJiBoKFwiZGl2XCIsIHsgY2xhc3M6IFwiY2hpcHNcIiB9LCBmLnRhZ3MubWFwKCh0KSA9PiBoKFwic3BhblwiLCB7IGNsYXNzOiBcImNoaXAgc3RhdGljXCIgfSwgXCIjXCIgKyB0KSkpLFxuICAgICksXG4gICAgaChcbiAgICAgIFwiZGl2XCIsXG4gICAgICB7IGNsYXNzOiBcImNhcmQtYWN0aW9uc1wiIH0sXG4gICAgICBoKFxuICAgICAgICBcImJ1dHRvblwiLFxuICAgICAgICB7IGNsYXNzOiBcImljb24gcGxheVwiLCB0aXRsZTogXCJSZXByb2R1Y2lyIGVuIGxhIHBlc3Rhw7FhIGFjdGl2YVwiLCBkaXNhYmxlZDogQS5ydW5uZXIucnVubmluZywgb25jbGljazogKCkgPT4gQS5wbGF5KGYpIH0sXG4gICAgICAgIHJ1bm5pbmcgPyBcIuKAplwiIDogXCLilrZcIixcbiAgICAgICksXG4gICAgICBoKFxuICAgICAgICBcImRldGFpbHNcIixcbiAgICAgICAgeyBjbGFzczogXCJtZW51XCIgfSxcbiAgICAgICAgaChcInN1bW1hcnlcIiwgeyBjbGFzczogXCJpY29uXCIsIHRpdGxlOiBcIk3DoXNcIiB9LCBcIuKLr1wiKSxcbiAgICAgICAgaChcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHsgY2xhc3M6IFwibWVudS1saXN0XCIgfSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgb25jbGljazogKCkgPT4gQS5kdXBsaWNhdGVGbG93KGYpIH0sIFwi4qeJIER1cGxpY2FyXCIpLFxuICAgICAgICAgIGgoXCJidXR0b25cIiwgeyBvbmNsaWNrOiAoKSA9PiBBLmV4cG9ydEZsb3dzKFtmXSkgfSwgXCLih6kgRXhwb3J0YXIgSlNPTlwiKSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgb25jbGljazogKCkgPT4gQS5leHBvcnRQdXBwZXRlZXIoZikgfSwgXCLih6kgRXhwb3J0YXIgYSBQdXBwZXRlZXJcIiksXG4gICAgICAgICAgaChcImJ1dHRvblwiLCB7IG9uY2xpY2s6ICgpID0+IEEuZXhwb3J0RGV2VG9vbHMoZikgfSwgXCLih6kgRXhwb3J0YXIgYSBEZXZUb29scyBSZWNvcmRlclwiKSxcbiAgICAgICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiZGFuZ2VyXCIsIG9uY2xpY2s6ICgpID0+IEEucmVtb3ZlRmxvd3MoW2YuaWRdKSB9LCBcIvCfl5EgQm9ycmFyXCIpLFxuICAgICAgICApLFxuICAgICAgKSxcbiAgICApLFxuICApO1xufVxuXG5mdW5jdGlvbiBsYXN0UnVuVGV4dChmOiBGbG93KSB7XG4gIGNvbnN0IHIgPSBmLmxhc3RSdW4hO1xuICByZXR1cm4gci5vayA/IGBPSyAke3RpbWVBZ28oci5hdCl9ICgkeyhyLm1zIC8gMTAwMCkudG9GaXhlZCgxKX1zKWAgOiBgRmFsbMOzICR7dGltZUFnbyhyLmF0KX06ICR7ci5lcnJvcn1gO1xufVxuXG5mdW5jdGlvbiBlbXB0eVN0YXRlKCkge1xuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwiZW1wdHlcIiB9LFxuICAgIGgoXCJkaXZcIiwgeyBjbGFzczogXCJlbXB0eS1hcnRcIiB9LCBcIuKXiSDihpIg4oyoIOKGkiDij45cIiksXG4gICAgaChcImgyXCIsIG51bGwsIFwiR3JhYmEgdHUgcHJpbWVyIGZsdWpvXCIpLFxuICAgIGgoXG4gICAgICBcIm9sXCIsXG4gICAgICB7IGNsYXNzOiBcIm11dGVkXCIgfSxcbiAgICAgIGgoXCJsaVwiLCBudWxsLCBcIkNyZWEgdW4gZmx1am8geSBhYnJlIGxhIHdlYiBxdWUgcXVpZXJhcyBhdXRvbWF0aXphci5cIiksXG4gICAgICBoKFwibGlcIiwgbnVsbCwgXCJQdWxzYSBcIiwgaChcImJcIiwgbnVsbCwgXCJHcmFiYXJcIiksIFwiIHkgdXNhIGxhIHDDoWdpbmEgY29uIG5vcm1hbGlkYWQ6IGxvcyBib3RvbmVzIHNlIGdyYWJhbiBjb21vIGNsaWNrIHkgbG9zIGlucHV0cyBjb21vIMKrZXNjcmliaXLCuyBjb24gc3UgY29udGVuaWRvLlwiKSxcbiAgICAgIGgoXCJsaVwiLCBudWxsLCBcIkVkaXRhLCByZW9yZGVuYSB5IGRhbGUgYSBcIiwgaChcImJcIiwgbnVsbCwgXCJSZXByb2R1Y2lyXCIpLCBcIi5cIiksXG4gICAgKSxcbiAgICBoKFwiZGl2XCIsIHsgY2xhc3M6IFwicm93IGNlbnRlclwiIH0sIGgoXCJidXR0b25cIiwgeyBjbGFzczogXCJidG4gcHJpbWFyeVwiLCBvbmNsaWNrOiBBLmNyZWF0ZUZsb3cgfSwgXCIrIE51ZXZvIGZsdWpvXCIpLCBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuXCIsIG9uY2xpY2s6IGltcG9ydEZpbGUgfSwgXCJJbXBvcnRhclwiKSksXG4gICk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGltcG9ydEZpbGUoKSB7XG4gIGNvbnN0IGZpbGUgPSBhd2FpdCBwaWNrRmlsZSgpO1xuICBpZiAoZmlsZSkgYXdhaXQgQS5pbXBvcnRUZXh0KGF3YWl0IGZpbGUudGV4dCgpKTtcbn1cbiIsCiAgICAiaW1wb3J0IHsgc2F2ZVNldHRpbmdzIH0gZnJvbSBcIi4uLy4uL3NoYXJlZC9zdG9yZVwiO1xuaW1wb3J0IHsgREVGQVVMVF9TRVRUSU5HUywgdHlwZSBTZXR0aW5ncyB9IGZyb20gXCIuLi8uLi9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCAqIGFzIEEgZnJvbSBcIi4uL3N0YXRlXCI7XG5pbXBvcnQgeyBzdGF0ZSB9IGZyb20gXCIuLi9zdGF0ZVwiO1xuaW1wb3J0IHsgaCwgdG9hc3QgfSBmcm9tIFwiLi4vdWlcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHNldHRpbmdzVmlldygpOiBIVE1MRWxlbWVudCB7XG4gIGNvbnN0IHMgPSBzdGF0ZS5zZXR0aW5ncztcbiAgY29uc3Qgc2V0ID0gPEsgZXh0ZW5kcyBrZXlvZiBTZXR0aW5ncz4oazogSywgdjogU2V0dGluZ3NbS10pID0+IHtcbiAgICBzW2tdID0gdjtcbiAgICB2b2lkIHNhdmVTZXR0aW5ncyhzKTtcbiAgfTtcbiAgY29uc3QgbnVtID0gKGs6IFwidGltZW91dFwiIHwgXCJzdGVwRGVsYXlcIiB8IFwia2V5RGVsYXlcIiwgbGFiZWw6IHN0cmluZywgaGludDogc3RyaW5nKSA9PlxuICAgIGgoXG4gICAgICBcImxhYmVsXCIsXG4gICAgICB7IGNsYXNzOiBcImZpZWxkXCIgfSxcbiAgICAgIGgoXCJzcGFuXCIsIG51bGwsIGxhYmVsKSxcbiAgICAgIGgoXCJpbnB1dFwiLCB7XG4gICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgIHR5cGU6IFwibnVtYmVyXCIsXG4gICAgICAgIG1pbjogMCxcbiAgICAgICAgc3RlcDogayA9PT0gXCJrZXlEZWxheVwiID8gNSA6IDEwMCxcbiAgICAgICAgdmFsdWU6IHNba10sXG4gICAgICAgIFwiZGF0YS1rXCI6IFwic2V0LVwiICsgayxcbiAgICAgICAgb25pbnB1dDogKGU6IEV2ZW50KSA9PiB7XG4gICAgICAgICAgY29uc3QgdiA9IChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS52YWx1ZUFzTnVtYmVyO1xuICAgICAgICAgIGlmIChOdW1iZXIuaXNGaW5pdGUodikgJiYgdiA+PSAwKSBzZXQoaywgdik7XG4gICAgICAgIH0sXG4gICAgICB9KSxcbiAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgaGludCksXG4gICAgKTtcblxuICByZXR1cm4gaChcbiAgICBcImRpdlwiLFxuICAgIHsgY2xhc3M6IFwidmlld1wiIH0sXG4gICAgaChcbiAgICAgIFwiaGVhZGVyXCIsXG4gICAgICB7IGNsYXNzOiBcInRvcFwiIH0sXG4gICAgICBoKFwiYnV0dG9uXCIsIHsgY2xhc3M6IFwiYnRuIGdob3N0IHNtXCIsIG9uY2xpY2s6ICgpID0+ICgoc3RhdGUudmlldyA9IFwibGlicmFyeVwiKSwgQS5yZW5kZXIoKSkgfSwgXCLihpAgRmx1am9zXCIpLFxuICAgICAgaChcImJcIiwgbnVsbCwgXCJBanVzdGVzXCIpLFxuICAgICksXG4gICAgaChcbiAgICAgIFwibWFpblwiLFxuICAgICAgeyBjbGFzczogXCJzY3JvbGwgc2V0dGluZ3NcIiwgXCJkYXRhLXNjcm9sbFwiOiBcInNldHRpbmdzXCIgfSxcbiAgICAgIGgoXCJoM1wiLCBudWxsLCBcIlJlcHJvZHVjY2nDs25cIiksXG4gICAgICBudW0oXCJ0aW1lb3V0XCIsIFwiVGltZW91dCBwb3IgcGFzbyAobXMpXCIsIFwiQ3XDoW50byBlc3BlcmFyIGEgcXVlIGFwYXJlemNhIHVuIGVsZW1lbnRvIGFudGVzIGRlIGZhbGxhci5cIiksXG4gICAgICBudW0oXCJzdGVwRGVsYXlcIiwgXCJQYXVzYSBlbnRyZSBwYXNvcyAobXMpXCIsIFwiw5p0aWwgcGFyYSB2ZXIgbG8gcXVlIHBhc2EgbyBwYXJhIHdlYnMgbGVudGFzLlwiKSxcbiAgICAgIGgoXG4gICAgICAgIFwibGFiZWxcIixcbiAgICAgICAgeyBjbGFzczogXCJmaWVsZFwiIH0sXG4gICAgICAgIGgoXCJzcGFuXCIsIG51bGwsIFwiRm9ybWEgZGUgZXNjcmliaXJcIiksXG4gICAgICAgIGgoXG4gICAgICAgICAgXCJzZWxlY3RcIixcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjbGFzczogXCJpbnB1dCBzbVwiLFxuICAgICAgICAgICAgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgICBzZXQoXCJ0eXBlTW9kZVwiLCAoZS50YXJnZXQgYXMgSFRNTFNlbGVjdEVsZW1lbnQpLnZhbHVlIGFzIFNldHRpbmdzW1widHlwZU1vZGVcIl0pO1xuICAgICAgICAgICAgICBBLnJlbmRlcigpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGgoXCJvcHRpb25cIiwgeyB2YWx1ZTogXCJpbnN0YW50XCIsIHNlbGVjdGVkOiBzLnR5cGVNb2RlID09PSBcImluc3RhbnRcIiB9LCBcIkRlIGdvbHBlIChyw6FwaWRvKVwiKSxcbiAgICAgICAgICBoKFwib3B0aW9uXCIsIHsgdmFsdWU6IFwia2V5c1wiLCBzZWxlY3RlZDogcy50eXBlTW9kZSA9PT0gXCJrZXlzXCIgfSwgXCJUZWNsYSBhIHRlY2xhIChyZWFsaXN0YSlcIiksXG4gICAgICAgICksXG4gICAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgXCJUZWNsYSBhIHRlY2xhIGRpc3BhcmEga2V5ZG93bi9rZXl1cDogw7p0aWwgcGFyYSBhdXRvY29tcGxldGFkb3MgeSBtw6FzY2FyYXMuXCIpLFxuICAgICAgKSxcbiAgICAgIHMudHlwZU1vZGUgPT09IFwia2V5c1wiICYmIG51bShcImtleURlbGF5XCIsIFwiUGF1c2EgZW50cmUgdGVjbGFzIChtcylcIiwgXCJcIiksXG4gICAgICBoKFxuICAgICAgICBcImxhYmVsXCIsXG4gICAgICAgIHsgY2xhc3M6IFwidG9nZ2xlXCIgfSxcbiAgICAgICAgaChcImlucHV0XCIsIHsgdHlwZTogXCJjaGVja2JveFwiLCBjaGVja2VkOiBzLmhpZ2hsaWdodCwgb25jaGFuZ2U6IChlOiBFdmVudCkgPT4gc2V0KFwiaGlnaGxpZ2h0XCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkKSB9KSxcbiAgICAgICAgXCJSZXNhbHRhciBjYWRhIGVsZW1lbnRvIGFudGVzIGRlIGFjdHVhclwiLFxuICAgICAgKSxcbiAgICAgIGgoXG4gICAgICAgIFwibGFiZWxcIixcbiAgICAgICAgeyBjbGFzczogXCJ0b2dnbGVcIiB9LFxuICAgICAgICBoKFwiaW5wdXRcIiwge1xuICAgICAgICAgIHR5cGU6IFwiY2hlY2tib3hcIixcbiAgICAgICAgICBjaGVja2VkOiBzLmF1dG9XYWl0LFxuICAgICAgICAgIG9uY2hhbmdlOiAoZTogRXZlbnQpID0+IHtcbiAgICAgICAgICAgIHNldChcImF1dG9XYWl0XCIsIChlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50KS5jaGVja2VkKTtcbiAgICAgICAgICAgIEEucmVuZGVyKCk7XG4gICAgICAgICAgfSxcbiAgICAgICAgfSksXG4gICAgICAgIFwiRXNwZXJhciBhIHF1ZSBsYSBww6FnaW5hIHRlcm1pbmUgZGUgY2FyZ2FyIGFudGVzIGRlIGNhZGEgYWNjacOzblwiLFxuICAgICAgKSxcbiAgICAgIGgoXG4gICAgICAgIFwic21hbGxcIixcbiAgICAgICAgeyBjbGFzczogXCJtdXRlZFwiIH0sXG4gICAgICAgIFwiQW50ZXMgZGUgYWN0dWFyIGVzcGVyYSBhIHF1ZSBubyBoYXlhIHBldGljaW9uZXMgZW4gY3Vyc28gbmkgbG9hZGVycyB2aXNpYmxlcywgeSBhIHF1ZSBlbCBlbGVtZW50byBlc3TDqSBoYWJpbGl0YWRvIHkgc2luIG5hZGEgZW5jaW1hLlwiLFxuICAgICAgKSxcbiAgICAgIHMuYXV0b1dhaXQgJiZcbiAgICAgICAgaChcbiAgICAgICAgICBcImxhYmVsXCIsXG4gICAgICAgICAgeyBjbGFzczogXCJmaWVsZFwiIH0sXG4gICAgICAgICAgaChcInNwYW5cIiwgbnVsbCwgXCJTZWxlY3RvciBkZSBsb2FkZXJzIHByb3Bpb3NcIiksXG4gICAgICAgICAgaChcImlucHV0XCIsIHtcbiAgICAgICAgICAgIGNsYXNzOiBcImlucHV0IHNtXCIsXG4gICAgICAgICAgICB0eXBlOiBcInRleHRcIixcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyOiBcIi5taS1sb2FkZXIsICNvdmVybGF5LWNhcmdhbmRvXCIsXG4gICAgICAgICAgICB2YWx1ZTogcy5sb2FkZXJTZWxlY3RvcixcbiAgICAgICAgICAgIG9uaW5wdXQ6IChlOiBFdmVudCkgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBpbnAgPSBlLnRhcmdldCBhcyBIVE1MSW5wdXRFbGVtZW50O1xuICAgICAgICAgICAgICBsZXQgb2sgPSB0cnVlO1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmIChpbnAudmFsdWUudHJpbSgpKSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGlucC52YWx1ZSk7XG4gICAgICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgICAgIG9rID0gZmFsc2U7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgaW5wLnNldEN1c3RvbVZhbGlkaXR5KG9rID8gXCJcIiA6IFwiU2VsZWN0b3IgQ1NTIG5vIHbDoWxpZG9cIik7XG4gICAgICAgICAgICAgIGlucC5yZXBvcnRWYWxpZGl0eSgpO1xuICAgICAgICAgICAgICBpZiAob2spIHNldChcImxvYWRlclNlbGVjdG9yXCIsIGlucC52YWx1ZSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIGgoXCJzbWFsbFwiLCB7IGNsYXNzOiBcIm11dGVkXCIgfSwgXCJPcGNpb25hbC4gU2Ugc3VtYSBhIGxvcyBsb2FkZXJzIGRlIEVsZW1lbnQgUGx1cywgQW50LCBWdWV0aWZ5LCBNVUksIEJvb3RzdHJhcOKApiBNaWVudHJhcyBhbGd1bm8gc2VhIHZpc2libGUsIFJhc3RybyBlc3BlcmEuXCIpLFxuICAgICAgICApLFxuICAgICAgaChcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAgeyBjbGFzczogXCJyb3dcIiB9LFxuICAgICAgICBoKFxuICAgICAgICAgIFwiYnV0dG9uXCIsXG4gICAgICAgICAge1xuICAgICAgICAgICAgY2xhc3M6IFwiYnRuIHNtIGdob3N0XCIsXG4gICAgICAgICAgICBvbmNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgICAgIHN0YXRlLnNldHRpbmdzID0geyAuLi5ERUZBVUxUX1NFVFRJTkdTIH07XG4gICAgICAgICAgICAgIHZvaWQgc2F2ZVNldHRpbmdzKHN0YXRlLnNldHRpbmdzKTtcbiAgICAgICAgICAgICAgQS5yZW5kZXIoKTtcbiAgICAgICAgICAgICAgdG9hc3QoXCJBanVzdGVzIHJlc3RhYmxlY2lkb3NcIiwgXCJva1wiKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIlJlc3RhYmxlY2VyXCIsXG4gICAgICAgICksXG4gICAgICApLFxuICAgICAgaChcImgzXCIsIG51bGwsIFwiU2VsZWN0b3Jlc1wiKSxcbiAgICAgIGgoXG4gICAgICAgIFwicFwiLFxuICAgICAgICB7IGNsYXNzOiBcIm11dGVkIHNtYWxsXCIgfSxcbiAgICAgICAgXCJSYXN0cm8gZ2VuZXJhIHZhcmlvcyBzZWxlY3RvcmVzIHBvciBlbGVtZW50byB5IHBydWViYSBsb3MgYWx0ZXJuYXRpdm9zIHNpIGZhbGxhIGVsIHByaW5jaXBhbC4gT3JkZW4gZGUgcHJlZmVyZW5jaWE6IFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcImRhdGEtdGVzdGlkXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwiI2lkXCIpLFxuICAgICAgICBcIiBlc3RhYmxlLCBcIixcbiAgICAgICAgaChcImNvZGVcIiwgbnVsbCwgXCJuYW1lXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwibGFiZWw94oCmXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwiYXJpYS1sYWJlbFwiKSxcbiAgICAgICAgXCIsIFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcInBsYWNlaG9sZGVyXCIpLFxuICAgICAgICBcIiwgXCIsXG4gICAgICAgIGgoXCJjb2RlXCIsIG51bGwsIFwidGV4dD3igKZcIiksXG4gICAgICAgIFwiIHkgcG9yIMO6bHRpbW8gcnV0YSBDU1MuIElkcyB5IGNsYXNlcyBjb24gcGludGEgZGUgYXV0b2dlbmVyYWRhcyBzZSBpZ25vcmFuLiBBw7FhZGlyIFwiLFxuICAgICAgICBoKFwiY29kZVwiLCBudWxsLCBcImRhdGEtdGVzdGlkXCIpLFxuICAgICAgICBcIiBhIGxhIGFwcCBlcyBsbyBxdWUgZGEgbG9zIGZsdWpvcyBtw6FzIHJvYnVzdG9zLlwiLFxuICAgICAgKSxcbiAgICAgIGgoXCJoM1wiLCBudWxsLCBcIkRhdG9zXCIpLFxuICAgICAgaChcInBcIiwgeyBjbGFzczogXCJtdXRlZCBzbWFsbFwiIH0sIGAke3N0YXRlLmZsb3dzLmxlbmd0aH0gZmx1am8ocyksICR7c3RhdGUuZmxvd3MucmVkdWNlKChuLCBmKSA9PiBuICsgZi5zdGVwcy5sZW5ndGgsIDApfSBwYXNvKHMpLiBTZSBndWFyZGFuIGVuIGVsIGFsbWFjZW5hbWllbnRvIGxvY2FsIGRlIGxhIGV4dGVuc2nDs24sIGVuIGVzdGUgbmF2ZWdhZG9yLmApLFxuICAgICksXG4gICk7XG59XG4iLAogICAgImltcG9ydCAqIGFzIHN0b3JlIGZyb20gXCIuLi9zaGFyZWQvc3RvcmVcIjtcbmltcG9ydCB7IGN1cnJlbnQsIGltcG9ydFRleHQsIHJlbmRlciwgc2V0UmVuZGVyLCBzdGF0ZSB9IGZyb20gXCIuL3N0YXRlXCI7XG5pbXBvcnQgeyBtb3JwaCB9IGZyb20gXCIuL3VpXCI7XG5pbXBvcnQgeyBlZGl0b3JWaWV3IH0gZnJvbSBcIi4vdmlld3MvZWRpdG9yXCI7XG5pbXBvcnQgeyBsaWJyYXJ5VmlldyB9IGZyb20gXCIuL3ZpZXdzL2xpYnJhcnlcIjtcbmltcG9ydCB7IHNldHRpbmdzVmlldyB9IGZyb20gXCIuL3ZpZXdzL3NldHRpbmdzXCI7XG5cbmNvbnN0IGFwcCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiYXBwXCIpITtcblxubGV0IHNjaGVkdWxlZCA9IGZhbHNlO1xuc2V0UmVuZGVyKCgpID0+IHtcbiAgLy8gQWdydXBhIHJlbmRlcnMgZGVsIG1pc21vIHRpY2sgKHAuIGVqLiB2YXJpb3MgY2FtYmlvcyBkZSBzdG9yYWdlIHNlZ3VpZG9zKS5cbiAgaWYgKHNjaGVkdWxlZCkgcmV0dXJuO1xuICBzY2hlZHVsZWQgPSB0cnVlO1xuICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgc2NoZWR1bGVkID0gZmFsc2U7XG4gICAgY29uc3QgZmxvdyA9IGN1cnJlbnQoKTtcbiAgICBpZiAoc3RhdGUudmlldyA9PT0gXCJlZGl0b3JcIiAmJiAhZmxvdykgc3RhdGUudmlldyA9IFwibGlicmFyeVwiO1xuICAgIGNvbnN0IHZpZXcgPSBzdGF0ZS52aWV3ID09PSBcImVkaXRvclwiID8gZWRpdG9yVmlldyhmbG93ISkgOiBzdGF0ZS52aWV3ID09PSBcInNldHRpbmdzXCIgPyBzZXR0aW5nc1ZpZXcoKSA6IGxpYnJhcnlWaWV3KCk7XG4gICAgbW9ycGgoYXBwLCB2aWV3KTtcbiAgfSk7XG59KTtcblxuYXN5bmMgZnVuY3Rpb24gYm9vdCgpIHtcbiAgW3N0YXRlLmZsb3dzLCBzdGF0ZS5zZXR0aW5ncywgc3RhdGUucmVjb3JkaW5nXSA9IGF3YWl0IFByb21pc2UuYWxsKFtzdG9yZS5saXN0Rmxvd3MoKSwgc3RvcmUuZ2V0U2V0dGluZ3MoKSwgc3RvcmUuZ2V0UmVjb3JkaW5nKCldKTtcbiAgcmVuZGVyKCk7XG5cbiAgY2hyb21lLnN0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhKSA9PiB7XG4gICAgbGV0IGRpcnR5ID0gZmFsc2U7XG4gICAgbGV0IGFwcGVuZGVkID0gZmFsc2U7XG4gICAgaWYgKGFyZWEgPT09IFwibG9jYWxcIikge1xuICAgICAgZm9yIChjb25zdCBbaywgeyBuZXdWYWx1ZSB9XSBvZiBPYmplY3QuZW50cmllcyhjaGFuZ2VzKSkge1xuICAgICAgICBpZiAoc3RvcmUuaXNGbG93S2V5KGspKSB7XG4gICAgICAgICAgY29uc3QgaWQgPSBrLnNsaWNlKDUpO1xuICAgICAgICAgIGNvbnN0IGkgPSBzdGF0ZS5mbG93cy5maW5kSW5kZXgoKGYpID0+IGYuaWQgPT09IGlkKTtcbiAgICAgICAgICBpZiAoIW5ld1ZhbHVlKSB7XG4gICAgICAgICAgICBpZiAoaSA+PSAwKSBzdGF0ZS5mbG93cy5zcGxpY2UoaSwgMSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChpID49IDApIHtcbiAgICAgICAgICAgIGFwcGVuZGVkIHx8PSBuZXdWYWx1ZS5zdGVwcy5sZW5ndGggPiBzdGF0ZS5mbG93c1tpXSEuc3RlcHMubGVuZ3RoO1xuICAgICAgICAgICAgc3RhdGUuZmxvd3NbaV0gPSBuZXdWYWx1ZTtcbiAgICAgICAgICB9IGVsc2Ugc3RhdGUuZmxvd3MudW5zaGlmdChuZXdWYWx1ZSk7XG4gICAgICAgICAgZGlydHkgPSB0cnVlO1xuICAgICAgICB9IGVsc2UgaWYgKGsgPT09IFwic2V0dGluZ3NcIikge1xuICAgICAgICAgIHN0YXRlLnNldHRpbmdzID0geyAuLi5zdGF0ZS5zZXR0aW5ncywgLi4ubmV3VmFsdWUgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYXJlYSA9PT0gXCJzZXNzaW9uXCIgJiYgc3RvcmUuUkVDT1JESU5HX1NUT1JBR0VfS0VZIGluIGNoYW5nZXMpIHtcbiAgICAgIHN0YXRlLnJlY29yZGluZyA9IGNoYW5nZXNbc3RvcmUuUkVDT1JESU5HX1NUT1JBR0VfS0VZXSEubmV3VmFsdWU7XG4gICAgICBkaXJ0eSA9IHRydWU7XG4gICAgfVxuICAgIGlmICghZGlydHkpIHJldHVybjtcbiAgICByZW5kZXIoKTtcbiAgICAvLyBNaWVudHJhcyBzZSBncmFiYSwgc2VndWlyIGVsIMO6bHRpbW8gcGFzby5cbiAgICBpZiAoYXBwZW5kZWQgJiYgc3RhdGUucmVjb3JkaW5nPy5mbG93SWQgPT09IHN0YXRlLmN1cnJlbnRJZCkge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIltkYXRhLXNjcm9sbF1cIik7XG4gICAgICAgIGVsPy5zY3JvbGxUbyh7IHRvcDogZWwuc2Nyb2xsSGVpZ2h0LCBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcbiAgICAgIH0sIDMwKTtcbiAgICB9XG4gIH0pO1xufVxuXG4vLyBDZXJyYXIgbWVuw7pzIGRlc3BsZWdhYmxlcyBhbCBjbGljYXIgZnVlcmEuXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgKGUpID0+IHtcbiAgZm9yIChjb25zdCBkIG9mIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTERldGFpbHNFbGVtZW50PihcImRldGFpbHMubWVudVtvcGVuXVwiKSkge1xuICAgIGlmICghZC5jb250YWlucyhlLnRhcmdldCBhcyBOb2RlKSkgZC5vcGVuID0gZmFsc2U7XG4gIH1cbn0pO1xuXG4vLyBJbXBvcnRhciBhcnJhc3RyYW5kbyB1biAuanNvbiBhbCBwYW5lbC5cbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnb3ZlclwiLCAoZSkgPT4ge1xuICBpZiAoZS5kYXRhVHJhbnNmZXI/LnR5cGVzLmluY2x1ZGVzKFwiRmlsZXNcIikpIHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QuYWRkKFwiZHJvcHBpbmdcIik7XG4gIH1cbn0pO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdsZWF2ZVwiLCAoZSkgPT4ge1xuICBpZiAoIWUucmVsYXRlZFRhcmdldCkgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiZHJvcHBpbmdcIik7XG59KTtcbmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJkcm9wXCIsIGFzeW5jIChlKSA9PiB7XG4gIGNvbnN0IGZpbGUgPSBlLmRhdGFUcmFuc2Zlcj8uZmlsZXM/LlswXTtcbiAgZG9jdW1lbnQuYm9keS5jbGFzc0xpc3QucmVtb3ZlKFwiZHJvcHBpbmdcIik7XG4gIGlmICghZmlsZSkgcmV0dXJuO1xuICBlLnByZXZlbnREZWZhdWx0KCk7XG4gIGF3YWl0IGltcG9ydFRleHQoYXdhaXQgZmlsZS50ZXh0KCkpO1xufSk7XG5cbnZvaWQgYm9vdCgpO1xuIgogIF0sCiAgIm1hcHBpbmdzIjogIjtBQStFTyxJQUFNLG1CQUE2QjtBQUFBLEVBQ3hDLFNBQVM7QUFBQSxFQUNULFdBQVc7QUFBQSxFQUNYLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFdBQVc7QUFBQSxFQUNYLFVBQVU7QUFBQSxFQUNWLGdCQUFnQjtBQUNsQjtBQW1CTyxJQUFNLFlBQXlHO0FBQUEsRUFDcEgsVUFBVSxFQUFFLE9BQU8sUUFBUSxNQUFNLEtBQUssYUFBYSxPQUFPLFdBQVcsWUFBWTtBQUFBLEVBQ2pGLE9BQU8sRUFBRSxPQUFPLFNBQVMsTUFBTSxLQUFLLGFBQWEsS0FBSztBQUFBLEVBQ3RELE1BQU0sRUFBRSxPQUFPLFlBQVksTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLHVCQUF1QjtBQUFBLEVBQzNGLFFBQVEsRUFBRSxPQUFPLGVBQWUsTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLHFCQUFxQjtBQUFBLEVBQzlGLE9BQU8sRUFBRSxPQUFPLFVBQVUsTUFBTSxLQUFLLGFBQWEsTUFBTSxXQUFXLGVBQWU7QUFBQSxFQUNsRixPQUFPLEVBQUUsT0FBTyxTQUFTLE1BQU0sS0FBSyxhQUFhLE9BQU8sV0FBVyxzQkFBc0I7QUFBQSxFQUN6RixNQUFNLEVBQUUsT0FBTyxXQUFXLE1BQU0sS0FBSyxhQUFhLE9BQU8sV0FBVyxlQUFlO0FBQUEsRUFDbkYsU0FBUyxFQUFFLE9BQU8sYUFBYSxNQUFNLEtBQUssYUFBYSxLQUFLO0FBQUEsRUFDNUQsWUFBWSxFQUFFLE9BQU8sYUFBYSxNQUFNLEtBQUssYUFBYSxNQUFNLFdBQVcsaUJBQWlCO0FBQzlGOzs7QUNwSE8sSUFBTSxNQUFNLE1BQWMsT0FBTyxXQUFXLEVBQUUsTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLElBQUksRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLEVBQUU7QUFHNUYsU0FBUyxjQUFjLENBQUMsR0FBb0I7QUFBQSxFQUNqRCxPQUNFLEVBQUUsU0FBUyxNQUNYLFNBQVMsS0FBSyxDQUFDLEtBQ2Ysb0JBQW9CLEtBQUssQ0FBQyxLQUMxQixvQkFBb0IsS0FBSyxDQUFDLEtBQzFCLGtCQUFrQixLQUFLLENBQUMsS0FDeEIsdUZBQXVGLEtBQUssQ0FBQyxLQUM1Rix1QkFBdUIsS0FBSyxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsS0FDNUQsMkNBQTJDLEtBQUssQ0FBQztBQUFBO0FBSTlDLElBQU0sUUFBUSxDQUFDLE9BQWUsSUFBSSxRQUFjLENBQUMsTUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBRy9FLFNBQVMsT0FBTyxDQUFDLE1BQWtDO0FBQUEsRUFDakQsUUFBUTtBQUFBLFNBQ0Q7QUFBQSxNQUNILE9BQU8sT0FBTyxLQUFLLElBQUksQ0FBQztBQUFBLFNBQ3JCO0FBQUEsTUFDSCxPQUFPLE9BQU8sV0FBVztBQUFBLFNBQ3RCO0FBQUEsTUFDSCxPQUFPLE9BQU8sS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLEdBQVMsQ0FBQztBQUFBLFNBQ2hEO0FBQUEsTUFDSCxPQUFPLFFBQVEsS0FBSyxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksS0FBSyxNQUFNLEtBQUssT0FBTyxJQUFJLElBQUk7QUFBQSxTQUNyRTtBQUFBLE1BQ0gsT0FBTyxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFBQTtBQUFBLEVBRS9DO0FBQUE7QUFJSyxTQUFTLFdBQVcsQ0FBQyxNQUFjLE1BQXNDO0FBQUEsRUFDOUUsT0FBTyxLQUFLLFFBQVEsNkJBQTZCLENBQUMsR0FBRyxTQUFpQixLQUFLLFNBQVMsUUFBUSxJQUFJLEtBQUssQ0FBQztBQUFBO0FBR2pHLElBQU0sZUFBZSxDQUFDLGNBQWMsU0FBUyxnQkFBZ0IsY0FBYyxRQUFROzs7QUNsQzFGLElBQU0sY0FBYztBQUNwQixJQUFNLGVBQWU7QUFDckIsSUFBTSxnQkFBZ0I7QUFFdEIsZUFBc0IsU0FBUyxHQUFvQjtBQUFBLEVBQ2pELE1BQU0sTUFBTSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksSUFBSTtBQUFBLEVBQy9DLE9BQU8sT0FBTyxRQUFRLEdBQUcsRUFDdEIsT0FBTyxFQUFFLE9BQU8sRUFBRSxXQUFXLFdBQVcsQ0FBQyxFQUN6QyxJQUFJLElBQUksT0FBTyxDQUFTLEVBQ3hCLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxZQUFZLEVBQUUsU0FBUztBQUFBO0FBUTdDLGVBQXNCLFFBQVEsQ0FBQyxNQUFZLFFBQVEsTUFBcUI7QUFBQSxFQUN0RSxJQUFJO0FBQUEsSUFBTyxLQUFLLFlBQVksS0FBSyxJQUFJO0FBQUEsRUFDckMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEdBQUcsY0FBYyxLQUFLLEtBQUssS0FBSyxDQUFDO0FBQUEsRUFDaEUsT0FBTztBQUFBO0FBR1QsZUFBc0IsV0FBVyxDQUFDLEtBQThCO0FBQUEsRUFDOUQsTUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLElBQUksSUFBSSxDQUFDLE9BQU8sY0FBYyxFQUFFLENBQUM7QUFBQTtBQVc5RCxTQUFTLE9BQU8sQ0FBQyxVQUF5QixDQUFDLEdBQVM7QUFBQSxFQUN6RCxNQUFNLE1BQU0sS0FBSyxJQUFJO0FBQUEsRUFDckIsT0FBTztBQUFBLElBQ0wsSUFBSSxJQUFJO0FBQUEsSUFDUixNQUFNO0FBQUEsSUFDTixNQUFNLENBQUM7QUFBQSxJQUNQLFdBQVcsQ0FBQztBQUFBLElBQ1osT0FBTyxDQUFDO0FBQUEsSUFDUixXQUFXO0FBQUEsSUFDWCxXQUFXO0FBQUEsT0FDUjtBQUFBLEVBQ0w7QUFBQTtBQUdLLFNBQVMsT0FBTyxDQUFDLFNBQW1EO0FBQUEsRUFDekUsT0FBTyxFQUFFLElBQUksSUFBSSxHQUFHLFNBQVMsU0FBUyxRQUFRO0FBQUE7QUFHaEQsZUFBc0IsV0FBVyxHQUFzQjtBQUFBLEVBQ3JELE1BQU0sS0FBSyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksWUFBWSxHQUFHO0FBQUEsRUFDekQsT0FBTyxLQUFLLHFCQUFzQixLQUFLLENBQUMsRUFBRztBQUFBO0FBRzdDLGVBQXNCLFlBQVksQ0FBQyxHQUE0QjtBQUFBLEVBQzdELE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxHQUFHLGVBQWUsRUFBRSxDQUFDO0FBQUE7QUFHdEQsZUFBc0IsWUFBWSxHQUF3QztBQUFBLEVBQ3hFLFFBQVEsTUFBTSxPQUFPLFFBQVEsUUFBUSxJQUFJLGFBQWEsR0FBRztBQUFBO0FBUXBELElBQU0sWUFBWSxDQUFDLE1BQWMsRUFBRSxXQUFXLFdBQVc7QUFDekQsSUFBTSx3QkFBd0I7OztBQ3REOUIsU0FBUyxtQkFBbUIsQ0FBQyxNQUFvQztBQUFBLEVBQ3RFLElBQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxZQUFZLENBQUMsTUFBTSxRQUFTLEtBQXFCLEtBQUs7QUFBQSxJQUFHLE9BQU87QUFBQSxFQUM3RixNQUFNLFFBQVMsS0FBcUI7QUFBQSxFQUNwQyxPQUFPLFdBQVcsUUFBUSxNQUFNLEtBQUssQ0FBQyxNQUFNLE1BQU0sRUFBRSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsRUFBRSxTQUFTLEtBQUssRUFBRSxTQUFTLGVBQWMsU0FBUyxHQUFFO0FBQUE7QUFTbEosU0FBUyxZQUFZLENBQUMsS0FBd0MsU0FBMEQ7QUFBQSxFQUN0SCxNQUFNLFNBQW1CLENBQUM7QUFBQSxFQUMxQixNQUFNLFFBQWtCLENBQUM7QUFBQSxFQUN6QixNQUFNLGFBQXVCLENBQUM7QUFBQSxFQUM5QixNQUFNLFFBQWtCLENBQUM7QUFBQSxFQUN6QixJQUFJO0FBQUEsRUFDSixXQUFXLFNBQVMsT0FBTyxDQUFDLEdBQUc7QUFBQSxJQUM3QixNQUFNLFFBQVEsTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLENBQUMsS0FBSztBQUFBLElBQ25ELElBQUksTUFBTSxXQUFXO0FBQUEsTUFBRztBQUFBLElBQ3hCLE1BQU0sSUFBSSxNQUFNO0FBQUEsSUFFaEIsSUFBSSxlQUFlLENBQUM7QUFBQSxNQUFHO0FBQUEsSUFDdkIsSUFBSSxFQUFFLFdBQVcsT0FBTyxHQUFHO0FBQUEsTUFDekIsTUFBTSxJQUFJLEVBQUUsTUFBTSxDQUFDLEVBQUUsUUFBUSxxQkFBcUIsRUFBRTtBQUFBLE1BQ3BELFNBQVMsRUFBRSxRQUFRLFVBQVUsRUFBRTtBQUFBLE1BQy9CLElBQUk7QUFBQSxRQUFTLE1BQU0sS0FBSyxTQUFTLEVBQUUsUUFBUSxVQUFVLEVBQUUsR0FBRztBQUFBLE1BQ3JEO0FBQUEsY0FBTSxLQUFLLFFBQVEsS0FBSyxlQUFlLEtBQUssVUFBVSxDQUFDLElBQUk7QUFBQSxJQUNsRSxFQUFPLFNBQUksRUFBRSxXQUFXLE9BQU8sR0FBRztBQUFBLE1BQ2hDLFNBQVMsRUFBRSxNQUFNLENBQUM7QUFBQSxNQUNsQixNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQUEsSUFDakMsRUFBTyxTQUFJLEVBQUUsV0FBVyxRQUFRO0FBQUEsTUFBRyxNQUFNLEtBQUssU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQUEsSUFDOUQ7QUFBQSxNQUNILE1BQU0sTUFBTSxFQUFFLFdBQVcsU0FBUyxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFBQSxPQUNsRCwrQkFBK0IsS0FBSyxHQUFHLElBQUksU0FBUyxZQUFZLEtBQUssR0FBRztBQUFBO0FBQUEsRUFFN0U7QUFBQSxFQUNBLE9BQU8sRUFBRSxXQUFXLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxHQUFHLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxHQUFHLENBQUMsR0FBRyxLQUFLO0FBQUE7QUFHckcsU0FBUyxjQUFjLENBQUMsS0FBc0I7QUFBQSxFQUM1QyxNQUFNLE1BQU0sQ0FBQyxHQUFHLElBQUksU0FBUyxvQkFBb0IsR0FBRyxHQUFHLElBQUksU0FBUyx1QkFBdUIsR0FBRyxHQUFHLElBQUksU0FBUyx1QkFBdUIsQ0FBQztBQUFBLEVBQ3RJLE9BQU8sSUFBSSxLQUFLLENBQUMsTUFBTSxlQUFlLEVBQUUsR0FBSSxRQUFRLE9BQU8sRUFBRSxDQUFDLENBQUM7QUFBQTtBQUdqRSxTQUFTLFFBQVEsQ0FBQyxPQUFxRDtBQUFBLEVBQ3JFLE9BQU8sT0FBTyxTQUFTLE1BQU0sSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLFNBQVMsSUFBSSxFQUFFLElBQUk7QUFBQTtBQUduRSxTQUFTLFlBQVksQ0FBQyxLQUFxRDtBQUFBLEVBQ2hGLE1BQU0sUUFBZ0IsQ0FBQztBQUFBLEVBQ3ZCLE1BQU0sVUFBb0IsQ0FBQztBQUFBLEVBQzNCLFdBQVcsS0FBSyxJQUFJLE9BQU87QUFBQSxJQUN6QixJQUFJLEVBQUUsVUFBVSxFQUFFLFdBQVcsUUFBUTtBQUFBLE1BQ25DLFFBQVEsS0FBSyxHQUFHLEVBQUUsd0JBQXdCO0FBQUEsTUFDMUM7QUFBQSxJQUNGO0FBQUEsSUFDQSxNQUFNLFVBQVUsRUFBRSxTQUFTO0FBQUEsSUFDM0IsTUFBTSxTQUFTLGFBQWEsRUFBRSxXQUFXLE9BQU87QUFBQSxJQUNoRCxPQUFPLGFBQWEsYUFBYSxPQUFPO0FBQUEsSUFDeEMsTUFBTSxTQUFTLEVBQUUsVUFBVSxXQUFXLE9BQU8sU0FBUyxFQUFFLEtBQUssR0FBRyxTQUFTLEVBQUUsUUFBUTtBQUFBLElBQ25GLE1BQU0sUUFBUSxPQUFPLFFBQVE7QUFBQSxJQUM3QixRQUFRLEVBQUU7QUFBQSxXQUNIO0FBQUEsV0FDQTtBQUFBLFFBQ0g7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sWUFBWSxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFBQSxRQUN0RDtBQUFBLFdBQ0c7QUFBQSxXQUNBO0FBQUEsUUFDSCxJQUFJLENBQUM7QUFBQSxVQUFVLFFBQVEsS0FBSyxFQUFFLE9BQU8sc0JBQXNCO0FBQUEsUUFDdEQ7QUFBQSxnQkFBTSxLQUFLLFFBQVEsRUFBRSxNQUFNLFlBQVksUUFBUSxPQUFPLE1BQU0sRUFBRSxTQUFTLGdCQUFnQiw0QkFBNEIsVUFBVSxDQUFDLENBQUM7QUFBQSxRQUNwSTtBQUFBLFdBQ0csVUFBVTtBQUFBLFFBQ2IsSUFBSSxDQUFDLFVBQVU7QUFBQSxVQUNiLFFBQVEsS0FBSyw0QkFBNEI7QUFBQSxVQUN6QztBQUFBLFFBQ0Y7QUFBQSxRQUVBLE1BQU0sT0FBTyxNQUFNLEdBQUcsRUFBRTtBQUFBLFFBQ3hCLElBQUksTUFBTSxTQUFTLFdBQVcsS0FBSyxhQUFhLFlBQVksS0FBSyxVQUFVLEtBQUssS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPLEtBQUs7QUFBQSxVQUFHLE1BQU0sSUFBSTtBQUFBLFFBQ25JLE1BQU0sS0FBSyxRQUFRLEVBQUUsTUFBTSxXQUFXLFFBQVEsT0FBTyxPQUFPLEVBQUUsU0FBUyxHQUFHLENBQUMsQ0FBQztBQUFBLFFBQzVFO0FBQUEsTUFDRjtBQUFBLFdBQ0s7QUFBQSxRQUNILE1BQU0sS0FBSyxRQUFRLEVBQUUsTUFBTSxTQUFTLE9BQU8sRUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDO0FBQUEsUUFDOUQ7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJO0FBQUEsVUFBVSxNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sY0FBYyxRQUFRLE1BQU0sQ0FBQyxDQUFDO0FBQUEsUUFDdkU7QUFBQTtBQUFBLFFBRUEsUUFBUSxLQUFLLEVBQUUsSUFBSTtBQUFBO0FBQUEsRUFFekI7QUFBQSxFQUNBLE1BQU0sT0FBTyxRQUFRLEVBQUUsTUFBTSxJQUFJLFNBQVMseUJBQXlCLE1BQU0sQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDO0FBQUEsRUFDOUYsT0FBTyxFQUFFLE1BQU0sUUFBUTtBQUFBO0FBS3pCLFNBQVMsWUFBWSxDQUFDLEtBQXFCO0FBQUEsRUFDekMsSUFBSSxJQUFJLFdBQVcsT0FBTztBQUFBLElBQUcsT0FBTyxRQUFRLElBQUksTUFBTSxDQUFDO0FBQUEsRUFDdkQsSUFBSSxJQUFJLFdBQVcsUUFBUTtBQUFBLElBQUcsT0FBTyxRQUFRLElBQUksTUFBTSxDQUFDO0FBQUEsRUFDeEQsSUFBSSxJQUFJLFdBQVcsUUFBUTtBQUFBLElBQUcsT0FBTyxTQUFTLElBQUksTUFBTSxDQUFDO0FBQUEsRUFDekQsT0FBTztBQUFBO0FBSUYsU0FBUyxVQUFVLENBQUMsTUFBcUQ7QUFBQSxFQUM5RSxNQUFNLFFBQWtCO0FBQUEsSUFDdEIsRUFBRSxNQUFNLGVBQWUsT0FBTyxNQUFNLFFBQVEsS0FBSyxtQkFBbUIsR0FBRyxVQUFVLE9BQU8sVUFBVSxPQUFPLGFBQWEsTUFBTTtBQUFBLEVBQzlIO0FBQUEsRUFDQSxJQUFJLFdBQVc7QUFBQSxFQUNmLFdBQVcsS0FBSyxLQUFLLE9BQU87QUFBQSxJQUMxQixJQUFJLENBQUMsRUFBRTtBQUFBLE1BQVM7QUFBQSxJQUNoQixJQUFJLEVBQUUsT0FBTztBQUFBLE1BQVE7QUFBQSxJQUNyQixNQUFNLFlBQVksQ0FBQyxFQUFFLFVBQVUsR0FBSSxFQUFFLGFBQWEsQ0FBQyxDQUFFLEVBQUUsT0FBTyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUUsQ0FBQyxDQUFDO0FBQUEsSUFDcEcsTUFBTSxPQUFPLEVBQUUsUUFBUSxRQUFRLGNBQWUsRUFBRSxVQUFVLEVBQUUsU0FBUyxFQUFFLFFBQVEsSUFBSSxDQUFDLEVBQUc7QUFBQSxJQUN2RixRQUFRLEVBQUU7QUFBQSxXQUNIO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLFlBQVksS0FBSyxFQUFFLFNBQVMsR0FBRyxDQUFDO0FBQUEsUUFDbkQ7QUFBQSxXQUNHO0FBQUEsV0FDQTtBQUFBLFFBQ0gsTUFBTSxLQUFLLEVBQUUsTUFBTSxZQUFZLE1BQU0sU0FBUyxHQUFHLFNBQVMsRUFBRSxDQUFDO0FBQUEsUUFDN0Q7QUFBQSxXQUNHO0FBQUEsV0FDQTtBQUFBLFFBQ0gsTUFBTSxLQUFLLEVBQUUsTUFBTSxhQUFhLE1BQU0sT0FBTyxFQUFFLFNBQVMsR0FBRyxDQUFDO0FBQUEsUUFDNUQ7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLFdBQVcsUUFBUSxRQUFRLEtBQUssRUFBRSxTQUFTLFFBQVEsR0FBRyxFQUFFLE1BQU0sU0FBUyxRQUFRLFFBQVEsS0FBSyxFQUFFLFNBQVMsUUFBUSxDQUFDO0FBQUEsUUFDbkk7QUFBQSxXQUNHO0FBQUEsUUFDSCxNQUFNLEtBQUssRUFBRSxNQUFNLHFCQUFxQixLQUFLLENBQUM7QUFBQSxRQUM5QztBQUFBLFdBQ0c7QUFBQSxRQUNILE1BQU0sS0FBSztBQUFBLFVBQ1QsTUFBTTtBQUFBLFVBQ04sUUFBUTtBQUFBLFVBQ1IsWUFBWSw2Q0FBNkMsS0FBSyxVQUFVLEVBQUUsWUFBWSxFQUFFLHVEQUF1RCxLQUFLLFVBQVUsRUFBRSxTQUFTLEVBQUU7QUFBQSxRQUM3SyxDQUFDO0FBQUEsUUFDRDtBQUFBLFdBQ0c7QUFBQSxRQUNILE1BQU0sS0FBSyxFQUFFLE1BQU0scUJBQXFCLFFBQVEsUUFBUSxZQUFZLGdEQUFnRCxPQUFPLEVBQUUsS0FBSyxLQUFLLFNBQVMsQ0FBQztBQUFBLFFBQ2pKO0FBQUE7QUFBQSxFQUVOO0FBQUEsRUFDQSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sS0FBSyxNQUFNLE1BQU0sR0FBRyxTQUFTO0FBQUE7OztBQ3pLaEQsU0FBUyxZQUFZLENBQUMsT0FBMkI7QUFBQSxFQUN0RCxPQUFPLEVBQUUsUUFBUSxVQUFVLFNBQVMsR0FBRyxZQUFZLElBQUksS0FBSyxFQUFFLFlBQVksR0FBRyxPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sS0FBSyxHQUFHLFNBQVMsVUFBVSxFQUFFLEVBQUU7QUFBQTtBQUd2SSxJQUFNLGFBQXlCLENBQUMsWUFBWSxTQUFTLFFBQVEsVUFBVSxTQUFTLFNBQVMsUUFBUSxXQUFXLFlBQVk7QUFVakgsU0FBUyxXQUFXLENBQUMsTUFBNEI7QUFBQSxFQUN0RCxJQUFJO0FBQUEsRUFDSixJQUFJO0FBQUEsSUFDRixPQUFPLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDdEIsTUFBTTtBQUFBLElBQ04sTUFBTSxJQUFJLE1BQU0sOEJBQThCO0FBQUE7QUFBQSxFQUVoRCxJQUFJLG9CQUFvQixJQUFJLEdBQUc7QUFBQSxJQUM3QixRQUFRLE1BQU0sWUFBWSxhQUFhLElBQUk7QUFBQSxJQUMzQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksR0FBRyxRQUFRLFlBQVksUUFBUTtBQUFBLEVBQ3REO0FBQUEsRUFDQSxPQUFPLEVBQUUsT0FBTyxZQUFZLElBQUksR0FBRyxRQUFRLFVBQVUsU0FBUyxDQUFDLEVBQUU7QUFBQTtBQUduRSxTQUFTLFdBQVcsQ0FBQyxNQUF1QjtBQUFBLEVBQzFDLE1BQU0sTUFBaUIsTUFBTSxRQUFRLElBQUksSUFDckMsT0FDQSxRQUFRLE9BQU8sU0FBUyxhQUFZLFdBQVcsU0FBUSxNQUFNLFFBQVMsS0FBb0IsS0FBSyxJQUM1RixLQUFvQixRQUNyQixRQUFRLE9BQU8sU0FBUyxhQUFZLFdBQVcsUUFDN0MsQ0FBQyxJQUFJLElBQ0wsQ0FBQztBQUFBLEVBQ1QsSUFBSSxDQUFDLElBQUk7QUFBQSxJQUFRLE1BQU0sSUFBSSxNQUFNLHdDQUF3QztBQUFBLEVBRXpFLE9BQU8sSUFBSSxJQUFJLENBQUMsR0FBRyxNQUFNO0FBQUEsSUFDdkIsTUFBTSxJQUFJO0FBQUEsSUFDVixJQUFJLENBQUMsTUFBTSxRQUFRLEVBQUUsS0FBSztBQUFBLE1BQUcsTUFBTSxJQUFJLE1BQU0sYUFBYSxJQUFJLGtCQUFrQjtBQUFBLElBQ2hGLE1BQU0sUUFBZ0IsRUFBRSxNQUFNLElBQUksQ0FBQyxHQUFHLE1BQU07QUFBQSxNQUMxQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsU0FBUyxFQUFFLElBQUk7QUFBQSxRQUFHLE1BQU0sSUFBSSxNQUFNLFFBQVEsSUFBSSxTQUFTLEVBQUUsUUFBUSxJQUFJLHNCQUFzQjtBQUFBLE1BQ2pILE9BQU8sS0FBSyxHQUFHLElBQUksT0FBTyxFQUFFLE9BQU8sV0FBVyxFQUFFLEtBQUssSUFBSSxHQUFHLFNBQVMsRUFBRSxZQUFZLE1BQU07QUFBQSxLQUMxRjtBQUFBLElBQ0QsT0FBTyxRQUFRO0FBQUEsTUFDYixJQUFJLE9BQU8sRUFBRSxPQUFPLFdBQVcsRUFBRSxLQUFLLElBQUk7QUFBQSxNQUMxQyxNQUFNLE9BQU8sRUFBRSxRQUFRLGFBQWEsSUFBSSxHQUFHO0FBQUEsTUFDM0MsYUFBYSxFQUFFO0FBQUEsTUFDZixRQUFRLEVBQUU7QUFBQSxNQUNWLE1BQU0sTUFBTSxRQUFRLEVBQUUsSUFBSSxJQUFJLEVBQUUsS0FBSyxJQUFJLE1BQU0sSUFBSSxDQUFDO0FBQUEsTUFDcEQsV0FBVyxFQUFFLGFBQWEsT0FBTyxFQUFFLGNBQWMsV0FBVyxFQUFFLFlBQVksQ0FBQztBQUFBLE1BQzNFO0FBQUEsTUFDQSxXQUFXLE9BQU8sRUFBRSxjQUFjLFdBQVcsRUFBRSxZQUFZLEtBQUssSUFBSTtBQUFBLElBQ3RFLENBQUM7QUFBQSxHQUNGO0FBQUE7QUFNSCxTQUFTLFVBQVUsQ0FBQyxLQUFxQjtBQUFBLEVBQ3ZDLElBQUksSUFBSSxXQUFXLE9BQU87QUFBQSxJQUFHLE9BQU8sYUFBYSxLQUFLLFVBQVUsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVFLElBQUksSUFBSSxXQUFXLFFBQVE7QUFBQSxJQUFHLE9BQU8sYUFBYSxLQUFLLFVBQVUsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzdFLElBQUksSUFBSSxXQUFXLFFBQVE7QUFBQSxJQUFHLE9BQU8sY0FBYyxJQUFJLE1BQU0sQ0FBQztBQUFBLEVBQzlELE9BQU87QUFBQTtBQUdULElBQU0sS0FBSyxDQUFDLE1BQWMsS0FBSyxVQUFVLENBQUM7QUFHMUMsU0FBUyxPQUFPLENBQUMsR0FBbUI7QUFBQSxFQUNsQyxJQUFJLENBQUMsT0FBTyxLQUFLLENBQUM7QUFBQSxJQUFHLE9BQU8sR0FBRyxDQUFDO0FBQUEsRUFDaEMsT0FBTyxPQUFPLEdBQUcsQ0FBQyxJQUFJO0FBQUE7QUFHeEIsU0FBUyxPQUFPLENBQUMsTUFBWSxNQUFNLFFBQWdCO0FBQUEsRUFDakQsTUFBTSxPQUFPLENBQUMsS0FBSyxVQUFXLEdBQUksS0FBSyxhQUFhLENBQUMsQ0FBRSxFQUFFLElBQUksVUFBVTtBQUFBLEVBQ3ZFLElBQUksS0FBSyxXQUFXO0FBQUEsSUFBRyxPQUFPLEdBQUcsZUFBZSxHQUFHLEtBQUssRUFBRztBQUFBLEVBQzNELE9BQU8saUJBQWlCLEtBQUssSUFBSSxDQUFDLE1BQU0sR0FBRyxlQUFlLEdBQUcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxJQUFJO0FBQUE7QUFJL0UsU0FBUyxTQUFTLENBQUMsTUFBZ0M7QUFBQSxFQUNqRCxJQUFJLENBQUMsS0FBSyxPQUFPO0FBQUEsSUFBUTtBQUFBLEVBQ3pCLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLFVBQVUsR0FBSSxFQUFFLGFBQWEsQ0FBQyxDQUFFLEVBQUUsSUFBSSxVQUFVLENBQUM7QUFBQSxFQUN2RixPQUFPLGlCQUFpQixLQUFLLFVBQVUsSUFBSTtBQUFBO0FBR3RDLFNBQVMsV0FBVyxDQUFDLE1BQW9CO0FBQUEsRUFDOUMsTUFBTSxNQUFnQixDQUFDO0FBQUEsRUFDdkIsSUFBSSxLQUFLLE1BQU0sS0FBSyxvQ0FBb0MsSUFBSSxLQUFLLEVBQUUsZUFBZSxHQUFHO0FBQUEsRUFDckYsSUFBSSxLQUFLLHFEQUFxRCxLQUFLLEtBQUssSUFBSSxnQkFBZ0I7QUFBQSxFQUM1RixJQUFJLEtBQUssaURBQWlEO0FBQUEsRUFDMUQsSUFBSSxLQUFLLEVBQUU7QUFBQSxFQUNYLElBQUksS0FBSyxpQkFBaUI7QUFBQSxFQUMxQixJQUFJLEtBQUssZ0JBQWdCLEtBQUssVUFBVSxLQUFLLGFBQWEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxJQUFJO0FBQUEsRUFDekUsSUFBSSxLQUFLLG9CQUFvQjtBQUFBLEVBQzdCLElBQUksS0FBSyxtQ0FBbUM7QUFBQSxFQUM1QyxJQUFJLEtBQUssK0JBQStCO0FBQUEsRUFDeEMsSUFBSSxLQUFLLHdEQUF3RDtBQUFBLEVBQ2pFLElBQUksS0FBSyxtRUFBbUU7QUFBQSxFQUM1RSxJQUFJLEtBQUssa0RBQWtEO0FBQUEsRUFDM0QsSUFBSSxLQUFLLElBQUk7QUFBQSxFQUNiLElBQUksS0FBSyw0SEFBNEg7QUFBQSxFQUNySSxJQUFJLEtBQUssRUFBRTtBQUFBLEVBQ1gsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDLE9BQU8sR0FBRyxPQUFPLE1BQU0sR0FBRztBQUFBLElBQzdDLElBQUksS0FBSyxxRkFBcUY7QUFBQSxJQUM5RixJQUFJLEtBQUssZ0NBQWdDO0FBQUEsSUFDekMsSUFBSSxLQUFLLDZCQUE2QjtBQUFBLElBQ3RDLElBQUksS0FBSyw4QkFBOEI7QUFBQSxJQUN2QyxJQUFJLEtBQUssZ0ZBQWdGO0FBQUEsSUFDekYsSUFBSSxLQUFLLGtDQUFrQztBQUFBLElBQzNDLElBQUksS0FBSyxLQUFLO0FBQUEsSUFDZCxJQUFJLEtBQUssYUFBYTtBQUFBLElBQ3RCLElBQUksS0FBSyxHQUFHO0FBQUEsSUFDWixJQUFJLEtBQUssRUFBRTtBQUFBLEVBQ2I7QUFBQSxFQUNBLElBQUksS0FBSyxxR0FBcUc7QUFBQSxFQUM5RyxJQUFJLEtBQUssdUNBQXVDO0FBQUEsRUFDaEQsSUFBSSxLQUFLLDRCQUE0QjtBQUFBLEVBQ3JDLElBQUksS0FBSyxPQUFPO0FBQUEsRUFFaEIsS0FBSyxNQUFNLFFBQVEsQ0FBQyxHQUFHLE1BQU07QUFBQSxJQUMzQixNQUFNLFVBQVUsUUFBUSxJQUFJLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxNQUFNLEVBQUUsVUFBVTtBQUFBLElBQ3ZFLElBQUksQ0FBQyxFQUFFLFNBQVM7QUFBQSxNQUNkLElBQUksS0FBSyxVQUFVLGdCQUFnQjtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxLQUFLLE9BQU87QUFBQSxJQUNoQixNQUFNLE1BQU0sRUFBRSxTQUFTO0FBQUEsSUFDdkIsTUFBTSxLQUFLLFVBQVUsQ0FBQztBQUFBLElBQ3RCLE1BQU0sTUFBTSxLQUFLLE1BQU07QUFBQSxJQUN2QixNQUFNLE1BQU0sTUFBTSxRQUFRLEdBQUcsR0FBRztBQUFBLElBQ2hDLElBQUksTUFBTSxFQUFFLFNBQVMsY0FBYyxFQUFFLFNBQVM7QUFBQSxNQUFRLElBQUksS0FBSyxPQUFPLGVBQWUsS0FBSztBQUFBLElBQzFGLFFBQVEsRUFBRTtBQUFBLFdBQ0g7QUFBQSxRQUNILElBQUksS0FBSyxxQkFBcUIsUUFBUSxHQUFHLG9DQUFvQztBQUFBLFFBQzdFO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLHVCQUF1QjtBQUFBLFFBQ2hDLElBQUksS0FBSyxnRUFBZ0U7QUFBQSxRQUN6RSxJQUFJLEtBQUssT0FBTyxJQUFJLFlBQVk7QUFBQSxRQUNoQyxJQUFJLEtBQUssT0FBTztBQUFBLFFBQ2hCO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLFdBQVcsSUFBSSxVQUFVLFFBQVEsR0FBRyxLQUFLO0FBQUEsUUFDbEQ7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJLEtBQUssV0FBVyxjQUFjLEdBQUcsV0FBVyxFQUFFLFFBQVMsQ0FBQyxNQUFNLFFBQVEsR0FBRyxLQUFLO0FBQUEsUUFDbEY7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJLEtBQUssS0FBSztBQUFBLFFBQ2QsSUFBSSxLQUFLLHdCQUF3QixJQUFJLGlCQUFpQjtBQUFBLFFBQ3RELElBQUksS0FBSyxrR0FBa0csUUFBUSw0QkFBNEI7QUFBQSxRQUMvSSxJQUFJLEtBQUssS0FBSztBQUFBLFFBQ2Q7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJLEVBQUU7QUFBQSxVQUFVLElBQUksS0FBSyxXQUFXLElBQUksWUFBWTtBQUFBLFFBQ3BELElBQUksS0FBSyx1QkFBdUI7QUFBQSxRQUNoQyxJQUFJLEtBQUssZ0VBQWdFO0FBQUEsUUFDekUsSUFBSSxLQUFLLDJCQUEyQixHQUFHLE9BQU8sT0FBTyxLQUFLO0FBQUEsUUFDMUQsSUFBSSxLQUFLLE9BQU87QUFBQSxRQUNoQjtBQUFBLFdBQ0c7QUFBQSxRQUNILElBQUksS0FBSyw0Q0FBNEMsT0FBTyxHQUFHLEtBQUssU0FBUztBQUFBLFFBQzdFO0FBQUEsV0FDRztBQUFBLFFBQ0gsSUFBSSxLQUFLLFdBQVcsSUFBSSxXQUFXO0FBQUEsUUFDbkM7QUFBQSxXQUNHO0FBQUEsUUFDSCxJQUFJLEtBQUssS0FBSztBQUFBLFFBQ2QsSUFBSSxLQUFLLHdCQUF3QixJQUFJLGlCQUFpQjtBQUFBLFFBQ3RELElBQUksS0FBSyxtRUFBbUU7QUFBQSxRQUM1RSxJQUFJLEtBQUsseUJBQXlCLFFBQVEsR0FBRyw4QkFBOEIsSUFBSSxrQkFBa0IsSUFBSSxRQUFRLFdBQVcsRUFBRSxxQkFBcUI7QUFBQSxRQUMvSSxJQUFJLEtBQUssS0FBSztBQUFBLFFBQ2Q7QUFBQTtBQUFBLElBRUosSUFBSSxNQUFNLEVBQUUsU0FBUyxjQUFjLEVBQUUsU0FBUztBQUFBLE1BQVEsSUFBSSxLQUFLLEtBQUs7QUFBQSxHQUNyRTtBQUFBLEVBRUQsSUFBSSxLQUFLLG9CQUFvQixLQUFLLEtBQUssUUFBUSxNQUFNLEdBQUcsVUFBVTtBQUFBLEVBQ2xFLElBQUksS0FBSyxlQUFlO0FBQUEsRUFDeEIsSUFBSSxLQUFLLGtDQUFrQztBQUFBLEVBQzNDLElBQUksS0FBSyx3REFBd0Q7QUFBQSxFQUNqRSxJQUFJLEtBQUsseUJBQXlCO0FBQUEsRUFDbEMsSUFBSSxLQUFLLGFBQWE7QUFBQSxFQUN0QixJQUFJLEtBQUssMEJBQTBCO0FBQUEsRUFDbkMsSUFBSSxLQUFLLEdBQUc7QUFBQSxFQUNaLE9BQU8sSUFBSSxLQUFLO0FBQUEsQ0FBSSxJQUFJO0FBQUE7QUFBQTtBQUduQixJQUFNLE9BQU8sQ0FBQyxNQUNuQixFQUNHLFVBQVUsS0FBSyxFQUNmLFFBQVEsVUFBVSxFQUFFLEVBQ3BCLFlBQVksRUFDWixRQUFRLGVBQWUsR0FBRyxFQUMxQixRQUFRLFVBQVUsRUFBRSxLQUFLOzs7QUMvTDlCLElBQU0sY0FBYztBQUdwQixJQUFNLFlBQVksT0FBTyxJQUFJLGdCQUFnQixTQUFTLE1BQU0sRUFBRSxJQUFJLEtBQUssQ0FBQyxLQUFLO0FBRTdFLGVBQXNCLFNBQVMsR0FBNkI7QUFBQSxFQUMxRCxJQUFJO0FBQUEsSUFBVyxPQUFPLE9BQU8sS0FBSyxJQUFJLFNBQVM7QUFBQSxFQUMvQyxPQUFPLE9BQU8sTUFBTSxPQUFPLEtBQUssTUFBTSxFQUFFLFFBQVEsTUFBTSxlQUFlLEtBQUssQ0FBQztBQUFBLEVBQzNFLElBQUksQ0FBQyxLQUFLO0FBQUEsSUFBSSxNQUFNLElBQUksTUFBTSx1QkFBdUI7QUFBQSxFQUNyRCxPQUFPO0FBQUE7QUFHVCxlQUFlLFdBQVcsQ0FBQyxPQUFlLFVBQVUsT0FBTztBQUFBLEVBQ3pELE1BQU0sUUFBUSxLQUFLLElBQUk7QUFBQSxFQUN2QixPQUFPLEtBQUssSUFBSSxJQUFJLFFBQVEsU0FBUztBQUFBLElBQ25DLE1BQU0sSUFBSSxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUs7QUFBQSxJQUNyQyxJQUFJLEVBQUUsV0FBVztBQUFBLE1BQVk7QUFBQSxJQUM3QixNQUFNLE1BQU0sR0FBRztBQUFBLEVBQ2pCO0FBQUEsRUFDQSxNQUFNLElBQUksTUFBTSxxQ0FBcUM7QUFBQTtBQUl2RCxTQUFTLGdCQUFnQixDQUFDLE9BQWUsVUFBVSxHQUFHO0FBQUEsRUFDcEQsSUFBSSxVQUFVO0FBQUEsRUFDZCxJQUFJLFVBQVU7QUFBQSxFQUNkLE1BQU0sT0FBTyxDQUFDLE1BQTBDLEVBQUUsVUFBVSxVQUFVLEVBQUUsWUFBWSxLQUFLLEVBQUUsWUFBWTtBQUFBLEVBQy9HLE1BQU0sVUFBVSxDQUFDLE1BQWlFO0FBQUEsSUFDaEYsSUFBSSxLQUFLLENBQUM7QUFBQSxNQUFJLFVBQVUsTUFBTztBQUFBO0FBQUEsRUFFakMsTUFBTSxRQUFRLENBQUMsTUFBMEM7QUFBQSxJQUN2RCxJQUFJLEtBQUssQ0FBQztBQUFBLE1BQUcsVUFBVSxLQUFLLElBQUksR0FBRyxVQUFVLENBQUM7QUFBQTtBQUFBLEVBRWhELE1BQU0sTUFBTSxPQUFPO0FBQUEsRUFDbkIsSUFBSSxpQkFBaUIsWUFBWSxPQUFPO0FBQUEsRUFDeEMsSUFBSSxZQUFZLFlBQVksS0FBSztBQUFBLEVBQ2pDLElBQUksZ0JBQWdCLFlBQVksS0FBSztBQUFBLEVBQ3JDLE9BQU87QUFBQSxTQUVDLFFBQU8sQ0FBQyxRQUFnQjtBQUFBLE1BQzVCLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUFBLE1BQ3pCLE9BQU8sQ0FBQyxXQUFXLEtBQUssSUFBSSxJQUFJO0FBQUEsUUFBSyxNQUFNLE1BQU0sRUFBRTtBQUFBLE1BQ25ELE9BQU87QUFBQTtBQUFBLFNBR0gsUUFBTyxDQUFDLFVBQVUsT0FBTztBQUFBLE1BQzdCLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUFBLE1BQ3pCLE9BQU8sVUFBVSxHQUFHO0FBQUEsUUFDbEIsSUFBSSxLQUFLLElBQUksSUFBSTtBQUFBLFVBQUssTUFBTSxJQUFJLE1BQU0scUNBQXFDO0FBQUEsUUFDM0UsTUFBTSxNQUFNLEVBQUU7QUFBQSxNQUNoQjtBQUFBLE1BQ0EsTUFBTSxZQUFZLE9BQU8sT0FBTztBQUFBO0FBQUEsSUFFbEMsT0FBTyxHQUFHO0FBQUEsTUFDUixJQUFJLGlCQUFpQixlQUFlLE9BQU87QUFBQSxNQUMzQyxJQUFJLFlBQVksZUFBZSxLQUFLO0FBQUEsTUFDcEMsSUFBSSxnQkFBZ0IsZUFBZSxLQUFLO0FBQUE7QUFBQSxFQUU1QztBQUFBO0FBSUYsZUFBc0IsYUFBYSxDQUFDLE9BQWUsVUFBVSxHQUFrQjtBQUFBLEVBQzdFLFNBQVMsSUFBSSxFQUFHLElBQUksSUFBSSxLQUFLO0FBQUEsSUFDM0IsSUFBSTtBQUFBLE1BQ0YsTUFBTSxJQUFJLE1BQU0sT0FBTyxLQUFLLFlBQVksT0FBTyxFQUFFLE1BQU0sT0FBTyxHQUF1QixFQUFFLFFBQVEsQ0FBQztBQUFBLE1BQ2hHLElBQUksR0FBRztBQUFBLFFBQUk7QUFBQSxNQUNYLE1BQU07QUFBQSxJQUdSLElBQUksTUFBTSxHQUFHO0FBQUEsTUFDWCxJQUFJO0FBQUEsUUFFRixNQUFNLE9BQU8sVUFBVSxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sVUFBVSxDQUFDLE9BQU8sRUFBRSxHQUFHLE9BQU8sQ0FBQyxTQUFTLEdBQUcsT0FBTyxPQUFPLENBQUMsRUFBRSxNQUFNLE1BQU0sRUFBRTtBQUFBLFFBQ2xJLE1BQU0sT0FBTyxVQUFVLGNBQWMsRUFBRSxRQUFRLEVBQUUsT0FBTyxVQUFVLENBQUMsT0FBTyxFQUFFLEdBQUcsT0FBTyxDQUFDLFlBQVksRUFBRSxDQUFDO0FBQUEsUUFDdEcsT0FBTyxHQUFHO0FBQUEsUUFDVixNQUFNLElBQUksTUFBTSx3Q0FBeUMsRUFBWSxVQUFVLEdBQUc7QUFBQTtBQUFBLElBRXRGO0FBQUEsSUFDQSxNQUFNLE1BQU0sR0FBRztBQUFBLEVBQ2pCO0FBQUEsRUFDQSxNQUFNLElBQUksTUFBTSxVQUFVLDBCQUEwQiw2Q0FBNkM7QUFBQTtBQUluRyxlQUFzQixTQUFzQixDQUFDLE9BQWUsS0FBZ0IsVUFBVSxHQUFlO0FBQUEsRUFDbkcsTUFBTSxjQUFjLE9BQU8sT0FBTztBQUFBLEVBQ2xDLE9BQU8sT0FBTyxLQUFLLFlBQVksT0FBTyxLQUFLLEVBQUUsUUFBUSxDQUFDO0FBQUE7QUFJeEQsZUFBc0IsVUFBVSxDQUFDLE9BQWUsT0FBK0IsU0FBa0M7QUFBQSxFQUMvRyxJQUFJLE1BQU07QUFBQSxFQUNWLFlBQVksR0FBRyxTQUFTLFNBQVMsQ0FBQyxHQUFHLFFBQVEsR0FBRztBQUFBLElBQzlDLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUFBLElBQ3pCLElBQUk7QUFBQSxJQUdKLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDbkIsTUFBTSxJQUFJLE1BQU0sVUFDZCxPQUNBLEVBQUUsTUFBTSxpQkFBaUIsV0FBVyxDQUFDLElBQUksVUFBVSxHQUFJLElBQUksYUFBYSxDQUFDLENBQUUsR0FBRyxTQUFTLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxJQUFJLENBQUMsRUFBRSxHQUNySCxHQUNGO0FBQUEsTUFDQSxJQUFJLENBQUMsR0FBRztBQUFBLFFBQU8sTUFBTSxJQUFJLE1BQU0sR0FBRyxHQUFHLFNBQVMscUNBQXFDLElBQUksSUFBSTtBQUFBLE1BQzNGLFNBQVMsSUFBSSxFQUFHLElBQUksS0FBSyxRQUFRLE1BQU0sS0FBSztBQUFBLFFBQzFDLE1BQU0sTUFBTSxFQUFFO0FBQUEsUUFDZCxRQUFRLE1BQU0sT0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLGdCQUFnQixPQUFPLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFBQSxNQUN2RjtBQUFBLE1BQ0EsSUFBSSxRQUFRLFFBQVEsS0FBSyxJQUFJLElBQUk7QUFBQSxRQUFLLE1BQU0sSUFBSSxNQUFNLGNBQWMsSUFBSSxnQ0FBZ0MsSUFBSSxJQUFJO0FBQUEsSUFDbEg7QUFBQSxJQUNBLE1BQU07QUFBQSxFQUNSO0FBQUEsRUFDQSxPQUFPO0FBQUE7QUFJRixTQUFTLFlBQVksQ0FBQyxNQUFvQztBQUFBLEVBQy9ELE1BQU0sT0FBK0IsQ0FBQztBQUFBLEVBQ3RDLFdBQVcsS0FBSztBQUFBLElBQWMsS0FBSyxLQUFLLFlBQVksS0FBSyxPQUFPLENBQUMsQ0FBQztBQUFBLEVBQ2xFLE1BQU0sT0FBTyxLQUFLLEtBQUs7QUFBQSxFQUN2QixZQUFZLEdBQUcsTUFBTSxPQUFPLFFBQVEsS0FBSyxhQUFhLENBQUMsQ0FBQztBQUFBLElBQUcsS0FBSyxLQUFLLFlBQVksR0FBRyxJQUFJO0FBQUEsRUFDeEYsT0FBTztBQUFBO0FBR1QsU0FBUyxXQUFXLENBQUMsTUFBWSxNQUFvQztBQUFBLEVBQ25FLE9BQU8sS0FBSyxNQUFNLE9BQU8sS0FBSyxTQUFTLE9BQU8sWUFBWSxLQUFLLE9BQU8sSUFBSSxJQUFJLFVBQVU7QUFBQTtBQUFBO0FBR25GLE1BQU0sT0FBTztBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ2xCLFVBQVU7QUFBQSxFQUVWLElBQUksR0FBRztBQUFBLElBQ0wsS0FBSyxVQUFVO0FBQUE7QUFBQSxPQUdYLElBQUcsQ0FBQyxNQUFZLFVBQW9CLE9BQWlCLE9BQU8sR0FBRyxNQUFvQztBQUFBLElBQ3ZHLEtBQUssVUFBVTtBQUFBLElBQ2YsS0FBSyxVQUFVO0FBQUEsSUFDZixNQUFNLEtBQUssS0FBSyxJQUFJO0FBQUEsSUFDcEIsTUFBTSxPQUFPLGFBQWEsSUFBSTtBQUFBLElBQzlCLE1BQU0sUUFBUSxLQUFLO0FBQUEsSUFDbkIsTUFBTSxNQUFNLFFBQVEsT0FBTyxPQUFPLElBQUksTUFBTTtBQUFBLElBQzVDLFNBQVMsSUFBSSxFQUFHLElBQUksTUFBTSxRQUFRO0FBQUEsTUFBSyxJQUFJLEtBQUssUUFBUSxJQUFJO0FBQUEsUUFBSyxNQUFNLFNBQVMsTUFBTSxHQUFJLElBQUksU0FBUztBQUFBLElBRXZHLElBQUk7QUFBQSxNQUNGLE1BQU0sTUFBTSxNQUFNLFVBQVU7QUFBQSxNQUM1QixNQUFNLFFBQVEsSUFBSTtBQUFBLE1BQ2xCLFNBQVMsSUFBSSxLQUFNLElBQUksS0FBSyxLQUFLO0FBQUEsUUFDL0IsSUFBSSxLQUFLO0FBQUEsVUFBUyxNQUFNLElBQUksTUFBTSx5QkFBeUI7QUFBQSxRQUMzRCxNQUFNLE9BQU8sTUFBTTtBQUFBLFFBQ25CLElBQUksQ0FBQyxLQUFLLFNBQVM7QUFBQSxVQUNqQixNQUFNLFNBQVMsS0FBSyxJQUFJLFNBQVM7QUFBQSxVQUNqQztBQUFBLFFBQ0Y7QUFBQSxRQUNBLE1BQU0sU0FBUyxLQUFLLElBQUksU0FBUztBQUFBLFFBQ2pDLElBQUk7QUFBQSxVQUNGLE1BQU0sS0FBSyxLQUFLLE9BQU8sWUFBWSxNQUFNLElBQUksR0FBRyxRQUFRO0FBQUEsVUFDeEQsTUFBTSxTQUFTLEtBQUssSUFBSSxJQUFJO0FBQUEsVUFDNUIsT0FBTyxHQUFHO0FBQUEsVUFDVixNQUFNLE1BQU8sRUFBWTtBQUFBLFVBQ3pCLE1BQU0sU0FBUyxLQUFLLElBQUksU0FBUyxHQUFHO0FBQUEsVUFDcEMsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLGNBQWMsS0FBSyxJQUFJLE9BQU8sSUFBSTtBQUFBO0FBQUEsUUFFckYsSUFBSSxJQUFJLE1BQU0sS0FBSyxTQUFTO0FBQUEsVUFBVyxNQUFNLE1BQU0sU0FBUyxTQUFTO0FBQUEsTUFDdkU7QUFBQSxNQUNBLE9BQU8sRUFBRSxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxJQUFJLElBQUksR0FBRztBQUFBLE1BQy9DLE9BQU8sR0FBRztBQUFBLE1BQ1YsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLE9BQVEsRUFBWSxRQUFRO0FBQUEsY0FDN0U7QUFBQSxNQUNBLEtBQUssVUFBVTtBQUFBO0FBQUE7QUFBQSxPQUlMLEtBQUksQ0FBQyxPQUFlLE1BQVksVUFBb0I7QUFBQSxJQUNoRSxRQUFRLEtBQUs7QUFBQSxXQUNOLFlBQVk7QUFBQSxRQUNmLElBQUksQ0FBQyxLQUFLO0FBQUEsVUFBTyxNQUFNLElBQUksTUFBTSxjQUFjO0FBQUEsUUFDL0MsTUFBTSxPQUFPLGlCQUFpQixLQUFLO0FBQUEsUUFDbkMsSUFBSTtBQUFBLFVBQ0YsTUFBTSxPQUFPLEtBQUssT0FBTyxPQUFPLEVBQUUsS0FBSyxLQUFLLE1BQU0sQ0FBQztBQUFBLFVBQ25ELE1BQU0sS0FBSyxRQUFRLElBQUk7QUFBQSxVQUN2QixNQUFNLEtBQUssUUFBUTtBQUFBLGtCQUNuQjtBQUFBLFVBQ0EsS0FBSyxRQUFRO0FBQUE7QUFBQSxRQUVmO0FBQUEsTUFDRjtBQUFBLFdBQ0s7QUFBQSxRQUNILE1BQU0sTUFBTSxPQUFPLEtBQUssS0FBSyxLQUFLLElBQUk7QUFBQSxRQUN0QztBQUFBO0FBQUEsSUFHSixNQUFNLE9BQU8sS0FBSyxTQUFTLFdBQVcsS0FBSyxTQUFTO0FBQUEsSUFDcEQsTUFBTSxVQUFVLEtBQUssV0FBVyxTQUFTO0FBQUEsSUFDekMsSUFBSTtBQUFBLElBQ0osSUFBSSxNQUFNLE1BQU0sV0FBVyxPQUFPLEtBQUssT0FBTyxPQUFPO0FBQUEsSUFDckQsTUFBTSxPQUFPLGlCQUFpQixPQUFPLEdBQUc7QUFBQSxJQUN4QyxJQUFJO0FBQUEsTUFDRixTQUFTLFVBQVUsSUFBSyxXQUFXO0FBQUEsUUFDakMsSUFBSTtBQUFBLFVBQ0YsTUFBTSxNQUFNLFVBQXNCLE9BQU8sRUFBRSxNQUFNLFlBQVksTUFBTSxTQUFTLEdBQUcsR0FBRztBQUFBLFVBQ2xGLE9BQU8sR0FBRztBQUFBLFVBQ1YsSUFBSSxDQUFDLFlBQVksS0FBTSxFQUFZLE9BQU87QUFBQSxZQUFHLE1BQU07QUFBQSxVQUVuRCxNQUFNLEtBQUssUUFBUTtBQUFBLFVBQ25CLElBQUk7QUFBQSxZQUFNO0FBQUEsVUFDVixJQUFJLFdBQVc7QUFBQSxZQUFHLE1BQU0sSUFBSSxNQUFNLDhDQUE4QztBQUFBLFVBQ2hGLE1BQU0sTUFBTSxXQUFXLE9BQU8sS0FBSyxPQUFPLE9BQU87QUFBQSxVQUNqRDtBQUFBO0FBQUEsUUFFRixJQUFJLENBQUM7QUFBQSxVQUFLLE1BQU0sSUFBSSxNQUFNLDRCQUE0QjtBQUFBLFFBQ3RELElBQUksQ0FBQyxJQUFJO0FBQUEsVUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEtBQUs7QUFBQSxRQUN0QztBQUFBLE1BQ0Y7QUFBQSxNQUdBLElBQUksUUFBUyxNQUFNLEtBQUssUUFBUSxJQUFJLGNBQWMsT0FBTyxHQUFHO0FBQUEsUUFBSSxNQUFNLEtBQUssUUFBUTtBQUFBLGNBQ25GO0FBQUEsTUFDQSxLQUFLLFFBQVE7QUFBQTtBQUFBO0FBR25COzs7QUN0T08sU0FBUyxDQUF3QyxDQUFDLEtBQVEsVUFBeUIsVUFBNkM7QUFBQSxFQUNySSxNQUFNLEtBQUssU0FBUyxjQUFjLEdBQUc7QUFBQSxFQUNyQyxZQUFZLEdBQUcsTUFBTSxPQUFPLFFBQVEsU0FBUyxDQUFDLENBQUMsR0FBRztBQUFBLElBQ2hELElBQUksS0FBSyxRQUFRLE1BQU07QUFBQSxNQUFPO0FBQUEsSUFDOUIsSUFBSSxFQUFFLFdBQVcsSUFBSSxLQUFLLE9BQU8sTUFBTTtBQUFBLE1BQVksR0FBRyxpQkFBaUIsRUFBRSxNQUFNLENBQUMsRUFBRSxZQUFZLEdBQUcsQ0FBa0I7QUFBQSxJQUM5RyxTQUFJLE1BQU07QUFBQSxNQUFTLEdBQUcsWUFBWSxPQUFPLENBQUM7QUFBQSxJQUMxQyxTQUFJLE1BQU0sV0FBVyxNQUFNLGFBQWEsTUFBTSxjQUFjLE1BQU07QUFBQSxNQUFrQixHQUFXLEtBQUs7QUFBQSxJQUNwRyxTQUFJLE1BQU07QUFBQSxNQUFNLEdBQUcsYUFBYSxHQUFHLEVBQUU7QUFBQSxJQUNyQztBQUFBLFNBQUcsYUFBYSxHQUFHLE9BQU8sQ0FBQyxDQUFDO0FBQUEsRUFDbkM7QUFBQSxFQUNBLE9BQU8sSUFBSSxRQUFRO0FBQUEsRUFDbkIsT0FBTztBQUFBO0FBR1QsU0FBUyxNQUFNLENBQUMsSUFBVSxVQUFtQjtBQUFBLEVBQzNDLFdBQVcsS0FBSyxVQUFVO0FBQUEsSUFDeEIsSUFBSSxLQUFLLFFBQVEsTUFBTTtBQUFBLE1BQU87QUFBQSxJQUM5QixJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQUEsTUFBRyxPQUFPLElBQUksQ0FBQztBQUFBLElBQzdCO0FBQUEsU0FBRyxZQUFZLGFBQWEsT0FBTyxJQUFJLFNBQVMsZUFBZSxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQUEsRUFDaEY7QUFBQTtBQUlLLFNBQVMsS0FBSyxDQUFDLE1BQW1CLE1BQVk7QUFBQSxFQUNuRCxNQUFNLFNBQVMsU0FBUztBQUFBLEVBQ3hCLE1BQU0sTUFBTSxRQUFRLFNBQVM7QUFBQSxFQUM3QixNQUFNLE1BQU0sT0FBTyxvQkFBb0IsU0FBVSxDQUFDLE9BQVEsZ0JBQWdCLE9BQVEsWUFBWSxJQUFJO0FBQUEsRUFDbEcsTUFBTSxZQUFZLENBQUMsR0FBRyxLQUFLLGlCQUE4QixlQUFlLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsUUFBUSxRQUFRLEVBQUUsU0FBUyxDQUFVO0FBQUEsRUFDOUgsS0FBSyxnQkFBZ0IsSUFBSTtBQUFBLEVBQ3pCLFlBQVksR0FBRyxRQUFRLFdBQVc7QUFBQSxJQUNoQyxNQUFNLElBQUksS0FBSyxjQUEyQixpQkFBaUIsS0FBSztBQUFBLElBQ2hFLElBQUk7QUFBQSxNQUFHLEVBQUUsWUFBWTtBQUFBLEVBQ3ZCO0FBQUEsRUFDQSxJQUFJLEtBQUs7QUFBQSxJQUNQLE1BQU0sS0FBSyxLQUFLLGNBQWdDLFlBQVksSUFBSSxPQUFPLEdBQUcsS0FBSztBQUFBLElBQy9FLElBQUksSUFBSTtBQUFBLE1BQ04sR0FBRyxNQUFNLEVBQUUsZUFBZSxLQUFLLENBQUM7QUFBQSxNQUNoQyxJQUFJLEtBQUs7QUFBQSxRQUNQLElBQUk7QUFBQSxVQUNGLEdBQUcsa0JBQWtCLElBQUksSUFBSSxJQUFJLEVBQUU7QUFBQSxVQUNuQyxNQUFNO0FBQUEsTUFHVjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUE7QUFpQkssU0FBUyxHQUFHLENBQUMsR0FBb0M7QUFBQSxFQUN0RCxPQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFBQSxJQUM5QixNQUFNLFNBQVMsUUFBUSxLQUFLLE9BQU8sRUFBRSxTQUFTLEVBQUUsRUFBRSxNQUFNLENBQUM7QUFBQSxJQUN6RCxNQUFNLFFBQ0osRUFBRSxTQUFTLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxTQUFTLE9BQU8sRUFBRSxPQUFPLGFBQWEsRUFBRSxhQUFhLE1BQU0sRUFBRSxVQUFVLFNBQVMsS0FBSyxDQUFDLElBQUk7QUFBQSxJQUNsSSxNQUFNLE1BQU0sRUFDVixVQUNBLEVBQUUsT0FBTyxTQUFTLEdBQ2xCLEVBQ0UsUUFDQSxFQUFFLFFBQVEsU0FBUyxHQUNuQixFQUFFLE1BQU0sTUFBTSxFQUFFLEtBQUssR0FDckIsRUFBRSxXQUFXLEVBQUUsS0FBSyxFQUFFLE9BQU8sUUFBUSxHQUFHLEVBQUUsT0FBTyxHQUNqRCxPQUNBLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxJQUFJLE9BQU8sR0FBRyxFQUFFLFFBQVEsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQzFGLEVBQ0UsT0FDQSxFQUFFLE9BQU8sVUFBVSxHQUNuQixFQUFFLFVBQVUsRUFBRSxPQUFPLGFBQWEsT0FBTyxZQUFZLE1BQU0sU0FBUyxHQUFHLFVBQVUsR0FDakYsRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sT0FBTyxPQUFPLFdBQVcsTUFBTSxTQUFTLEdBQUcsRUFBRSxNQUFNLEtBQUssR0FDeEYsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLEVBQUUsU0FBUyxXQUFXLFlBQVksT0FBTyxRQUFRLE1BQU0sU0FBUyxHQUFHLEVBQUUsTUFBTSxTQUFTLENBQ3JILENBQ0YsQ0FDRjtBQUFBLElBQ0EsSUFBSSxpQkFBaUIsU0FBUyxNQUFNO0FBQUEsTUFDbEMsTUFBTSxLQUFLLElBQUk7QUFBQSxNQUNmLElBQUksT0FBTztBQUFBLE1BQ1gsSUFBSSxPQUFPO0FBQUEsUUFBUSxRQUFRLFFBQVEsTUFBTSxRQUFRLElBQUk7QUFBQSxNQUNoRCxTQUFJLE9BQU87QUFBQSxRQUFXLFFBQVEsRUFBRSxNQUFPLEtBQUs7QUFBQSxNQUM1QztBQUFBLGdCQUFRLElBQUk7QUFBQSxLQUNsQjtBQUFBLElBQ0QsU0FBUyxLQUFLLFlBQVksR0FBRztBQUFBLElBQzdCLElBQUksVUFBVTtBQUFBLElBQ2QsSUFBSSxPQUFPO0FBQUEsTUFFVCxNQUFNLGlCQUFpQixXQUFXLENBQUMsTUFBTTtBQUFBLFFBQ3ZDLElBQUksRUFBRSxRQUFRLFNBQVM7QUFBQSxVQUNyQixFQUFFLGVBQWU7QUFBQSxVQUNqQixJQUFJLE1BQU0sTUFBTTtBQUFBLFFBQ2xCO0FBQUEsT0FDRDtBQUFBLE1BQ0QsTUFBTSxNQUFNO0FBQUEsTUFDWixNQUFNLE9BQU87QUFBQSxJQUNmO0FBQUEsR0FDRDtBQUFBO0FBR0gsSUFBSTtBQUNHLFNBQVMsS0FBSyxDQUFDLE1BQWMsT0FBZ0MsUUFBUTtBQUFBLEVBQzFFLElBQUksS0FBSyxTQUFTLGVBQWUsT0FBTztBQUFBLEVBQ3hDLElBQUksQ0FBQyxJQUFJO0FBQUEsSUFDUCxLQUFLLEVBQUUsT0FBTyxFQUFFLElBQUksUUFBUSxDQUFDO0FBQUEsSUFDN0IsU0FBUyxLQUFLLFlBQVksRUFBRTtBQUFBLEVBQzlCO0FBQUEsRUFDQSxHQUFHLGNBQWM7QUFBQSxFQUNqQixHQUFHLFlBQVksVUFBVTtBQUFBLEVBQ3pCLGFBQWEsVUFBVTtBQUFBLEVBQ3ZCLGFBQWEsV0FBVyxNQUFPLEdBQUksWUFBWSxJQUFLLFNBQVMsVUFBVSxPQUFPLElBQUk7QUFBQTtBQUc3RSxTQUFTLFFBQVEsQ0FBQyxVQUFrQixTQUFpQixPQUFPLG9CQUFvQjtBQUFBLEVBQ3JGLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQyxDQUFDO0FBQUEsRUFDbkUsTUFBTSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sS0FBSyxVQUFVLFNBQVMsQ0FBQztBQUFBLEVBQ2xELFNBQVMsS0FBSyxZQUFZLENBQUM7QUFBQSxFQUMzQixFQUFFLE1BQU07QUFBQSxFQUNSLEVBQUUsT0FBTztBQUFBLEVBQ1QsV0FBVyxNQUFNLElBQUksZ0JBQWdCLEdBQUcsR0FBRyxJQUFJO0FBQUE7QUFHMUMsU0FBUyxRQUFRLENBQUMsU0FBUywwQkFBZ0Q7QUFBQSxFQUNoRixPQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFBQSxJQUM5QixNQUFNLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTSxRQUFRLE9BQU8sQ0FBQztBQUFBLElBQ2pELE1BQU0saUJBQWlCLFVBQVUsTUFBTSxRQUFRLE1BQU0sUUFBUSxNQUFNLElBQUksQ0FBQztBQUFBLElBQ3hFLE1BQU0saUJBQWlCLFVBQVUsTUFBTSxRQUFRLElBQUksQ0FBQztBQUFBLElBQ3BELE1BQU0sTUFBTTtBQUFBLEdBQ2I7QUFBQTtBQUdJLFNBQVMsT0FBTyxDQUFDLElBQW9CO0FBQUEsRUFDMUMsTUFBTSxJQUFJLEtBQUssT0FBTyxLQUFLLElBQUksSUFBSSxNQUFNLElBQUk7QUFBQSxFQUM3QyxJQUFJLElBQUk7QUFBQSxJQUFJLE9BQU87QUFBQSxFQUNuQixNQUFNLElBQUksS0FBSyxNQUFNLElBQUksRUFBRTtBQUFBLEVBQzNCLElBQUksSUFBSTtBQUFBLElBQUksT0FBTyxRQUFRO0FBQUEsRUFDM0IsTUFBTSxLQUFLLEtBQUssTUFBTSxJQUFJLEVBQUU7QUFBQSxFQUM1QixJQUFJLEtBQUs7QUFBQSxJQUFJLE9BQU8sUUFBUTtBQUFBLEVBQzVCLE1BQU0sSUFBSSxLQUFLLE1BQU0sS0FBSyxFQUFFO0FBQUEsRUFDNUIsSUFBSSxJQUFJO0FBQUEsSUFBSSxPQUFPLFFBQVE7QUFBQSxFQUMzQixPQUFPLElBQUksS0FBSyxFQUFFLEVBQUUsbUJBQW1CO0FBQUE7QUFHbEMsU0FBUyxNQUFNLENBQUMsS0FBc0I7QUFBQSxFQUMzQyxJQUFJLENBQUM7QUFBQSxJQUFLLE9BQU87QUFBQSxFQUNqQixJQUFJO0FBQUEsSUFDRixPQUFPLElBQUksSUFBSSxHQUFHLEVBQUU7QUFBQSxJQUNwQixNQUFNO0FBQUEsSUFDTixPQUFPO0FBQUE7QUFBQTtBQUlKLFNBQVMsUUFBNkIsQ0FBQyxJQUF1QixJQUFZO0FBQUEsRUFDL0UsSUFBSTtBQUFBLEVBQ0osT0FBTyxJQUFJLE1BQVM7QUFBQSxJQUNsQixhQUFhLENBQUM7QUFBQSxJQUNkLElBQUksV0FBVyxNQUFNLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRTtBQUFBO0FBQUE7OztBQy9KOUIsSUFBTSxRQUFRO0FBQUEsRUFDbkIsTUFBTTtBQUFBLEVBQ04sT0FBTyxDQUFDO0FBQUEsRUFDUixXQUFXO0FBQUEsRUFDWCxVQUFVLEtBQUssaUJBQWlCO0FBQUEsRUFDaEMsV0FBVztBQUFBLEVBQ1gsVUFBVSxJQUFJO0FBQUEsRUFDZCxVQUFVLElBQUk7QUFBQSxFQUNkLFFBQVEsRUFBRSxHQUFHLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxLQUFlLE1BQU0sVUFBNEM7QUFBQSxFQUN4RyxrQkFBa0IsSUFBSTtBQUFBLEVBQ3RCLEtBQUs7QUFBQSxFQUNMLFNBQVM7QUFBQSxFQUNULFFBQVE7QUFDVjtBQUVBLElBQUksV0FBdUIsTUFBTTtBQUMxQixJQUFNLFlBQVksQ0FBQyxPQUFvQixXQUFXO0FBQ2xELElBQU0sU0FBUyxNQUFNLFNBQVM7QUFFOUIsSUFBTSxTQUFTLElBQUk7QUFFbkIsSUFBTSxVQUFVLE1BQU0sTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsT0FBTyxNQUFNLFNBQVM7QUFJN0UsSUFBTSxlQUFlLElBQUk7QUFHbEIsU0FBUyxRQUFRLENBQUMsTUFBWTtBQUFBLEVBQ25DLElBQUksS0FBSyxhQUFhLElBQUksS0FBSyxFQUFFO0FBQUEsRUFDakMsSUFBSSxDQUFDLElBQUk7QUFBQSxJQUNQLEtBQUssU0FBUyxNQUFNO0FBQUEsTUFDbEIsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sS0FBSyxFQUFFO0FBQUEsTUFDbEQsSUFBSTtBQUFBLFFBQWMsU0FBUyxDQUFDO0FBQUEsT0FDM0IsR0FBRztBQUFBLElBQ04sYUFBYSxJQUFJLEtBQUssSUFBSSxFQUFFO0FBQUEsRUFDOUI7QUFBQSxFQUNBLEdBQUc7QUFBQTtBQUdMLGVBQXNCLE9BQU8sQ0FBQyxNQUFZO0FBQUEsRUFDeEMsTUFBWSxTQUFTLElBQUk7QUFBQSxFQUN6QixPQUFPO0FBQUE7QUFHVCxlQUFzQixNQUFNLEdBQUc7QUFBQSxFQUM3QixNQUFNLFFBQVEsTUFBWSxVQUFVO0FBQUEsRUFDcEMsT0FBTztBQUFBO0FBS1QsZUFBc0IsVUFBVSxHQUFHO0FBQUEsRUFDakMsTUFBTSxPQUFPLE1BQU0sSUFBSSxFQUFFLE9BQU8sZUFBZSxPQUFPLElBQUksYUFBYSwwQkFBMEIsSUFBSSxRQUFRLENBQUM7QUFBQSxFQUM5RyxJQUFJLFFBQVE7QUFBQSxJQUFNO0FBQUEsRUFDbEIsTUFBTSxTQUFTLE1BQU0sT0FBTyxVQUFVLE1BQU0sT0FBTyxXQUFXLFdBQVcsTUFBTSxPQUFPLFNBQVM7QUFBQSxFQUMvRixNQUFNLE9BQWEsUUFBUSxFQUFFLE1BQU0sS0FBSyxLQUFLLEtBQUssZUFBZSxPQUFPLENBQUM7QUFBQSxFQUN6RSxNQUFZLFNBQVMsSUFBSTtBQUFBLEVBRXpCLElBQUksQ0FBQyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxPQUFPLEtBQUssRUFBRTtBQUFBLElBQUcsTUFBTSxNQUFNLFFBQVEsSUFBSTtBQUFBLEVBQ3hFLFNBQVMsS0FBSyxFQUFFO0FBQUE7QUFHWCxTQUFTLFFBQVEsQ0FBQyxJQUFZO0FBQUEsRUFDbkMsTUFBTSxZQUFZO0FBQUEsRUFDbEIsTUFBTSxPQUFPO0FBQUEsRUFDYixNQUFNLFNBQVMsTUFBTTtBQUFBLEVBQ3JCLElBQUksTUFBTSxLQUFLLFdBQVc7QUFBQSxJQUFJLE1BQU0sTUFBTTtBQUFBLEVBQzFDLE9BQU87QUFBQSxFQUNQLFNBQVMsY0FBYyxlQUFlLEdBQUcsU0FBUyxHQUFHLENBQUM7QUFBQTtBQUd4RCxlQUFzQixhQUFhLENBQUMsTUFBWTtBQUFBLEVBQzlDLE1BQU0sT0FBTyxnQkFBZ0IsSUFBSTtBQUFBLEVBQ2pDLEtBQUssS0FBSyxJQUFJO0FBQUEsRUFDZCxLQUFLLE9BQU8sS0FBSyxPQUFPO0FBQUEsRUFDeEIsS0FBSyxZQUFZLEtBQUssSUFBSTtBQUFBLEVBQzFCLEtBQUssVUFBVTtBQUFBLEVBQ2YsS0FBSyxNQUFNLFFBQVEsQ0FBQyxNQUFPLEVBQUUsS0FBSyxJQUFJLENBQUU7QUFBQSxFQUN4QyxNQUFZLFNBQVMsSUFBSTtBQUFBLEVBQ3pCLE1BQU0sT0FBTztBQUFBLEVBQ2IsTUFBTSxtQkFBbUIsSUFBSTtBQUFBO0FBRy9CLGVBQXNCLFdBQVcsQ0FBQyxLQUFlO0FBQUEsRUFDL0MsTUFBTSxRQUFRLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUk7QUFBQSxFQUM3RSxNQUFNLEtBQUssTUFBTSxJQUFJO0FBQUEsSUFDbkIsT0FBTyxJQUFJLFdBQVcsSUFBSSxZQUFZLE1BQU0sU0FBUyxXQUFXLElBQUk7QUFBQSxJQUNwRSxTQUFTO0FBQUEsSUFDVCxJQUFJO0FBQUEsSUFDSixRQUFRO0FBQUEsRUFDVixDQUFDO0FBQUEsRUFDRCxJQUFJLENBQUM7QUFBQSxJQUFJO0FBQUEsRUFDVCxNQUFZLFlBQVksR0FBRztBQUFBLEVBQzNCLElBQUksUUFBUSxDQUFDLE9BQU8sTUFBTSxTQUFTLE9BQU8sRUFBRSxDQUFDO0FBQUEsRUFDN0MsSUFBSSxNQUFNLGFBQWEsSUFBSSxTQUFTLE1BQU0sU0FBUztBQUFBLElBQUcsTUFBTSxPQUFPO0FBQUEsRUFDbkUsTUFBTSxPQUFPO0FBQUE7QUFHUixTQUFTLFVBQVUsR0FBYTtBQUFBLEVBQ3JDLE9BQU8sQ0FBQyxHQUFHLElBQUksSUFBSSxNQUFNLE1BQU0sSUFBSSxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxPQUFPLENBQWEsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxjQUFjLENBQUMsQ0FBQztBQUFBO0FBRzlHLFNBQVMsT0FBTyxHQUFhO0FBQUEsRUFDbEMsT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sTUFBTSxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLEdBQUcsTUFBTSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0FBQUE7QUFHcEYsU0FBUyxhQUFhLEdBQVc7QUFBQSxFQUN0QyxRQUFRLEdBQUcsUUFBUSxNQUFNLFNBQVMsTUFBTTtBQUFBLEVBQ3hDLE1BQU0sU0FBUyxFQUFFLFlBQVksRUFBRSxNQUFNLEtBQUssRUFBRSxPQUFPLE9BQU87QUFBQSxFQUMxRCxNQUFNLE9BQU8sTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNO0FBQUEsSUFDckMsSUFBSSxXQUFXLFdBQVcsRUFBRSxTQUFTLFVBQVUsRUFBRSxXQUFXO0FBQUEsTUFBUSxPQUFPO0FBQUEsSUFDM0UsV0FBVyxLQUFLO0FBQUEsTUFBTSxJQUFJLENBQUMsRUFBRSxLQUFLLFNBQVMsQ0FBQztBQUFBLFFBQUcsT0FBTztBQUFBLElBQ3RELElBQUksQ0FBQyxPQUFPO0FBQUEsTUFBUSxPQUFPO0FBQUEsSUFDM0IsTUFBTSxNQUFNLENBQUMsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLFFBQVEsR0FBRyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sTUFBTSxDQUFDLEdBQUcsR0FBRyxFQUFFLE1BQU0sSUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLFNBQVMsTUFBTSxFQUFFLFNBQVMsYUFBYSxFQUFFLFFBQVEsSUFBSSxDQUFDLEVBQzNKLEtBQUssR0FBRyxFQUNSLFlBQVk7QUFBQSxJQUNmLE9BQU8sT0FBTyxNQUFNLENBQUMsTUFBTSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0FBQUEsR0FDM0M7QUFBQSxFQUNELElBQUksU0FBUztBQUFBLElBQVEsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsS0FBSyxjQUFjLEVBQUUsSUFBSSxDQUFDO0FBQUEsRUFDaEUsU0FBSSxTQUFTO0FBQUEsSUFBVyxLQUFLLEtBQUssQ0FBQyxHQUFHLE9BQU8sRUFBRSxTQUFTLE1BQU0sTUFBTSxFQUFFLFNBQVMsTUFBTSxFQUFFO0FBQUEsRUFDdkY7QUFBQSxTQUFLLEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxZQUFZLEVBQUUsU0FBUztBQUFBLEVBQ2xELE9BQU87QUFBQTtBQUdULGVBQXNCLFFBQVEsQ0FBQyxLQUFlO0FBQUEsRUFDNUMsTUFBTSxTQUFTLE1BQU0sSUFBSSxFQUFFLE9BQU8sbUJBQW1CLE9BQU8sSUFBSSxhQUFhLDJDQUEyQyxTQUFTLFdBQVcsR0FBRyxJQUFJLFFBQVEsQ0FBQztBQUFBLEVBQzVKLElBQUksVUFBVTtBQUFBLElBQU07QUFBQSxFQUNwQixXQUFXLEtBQUssTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNLElBQUksU0FBUyxFQUFFLEVBQUUsQ0FBQyxHQUFHO0FBQUEsSUFDN0QsRUFBRSxTQUFTLE9BQU8sS0FBSyxLQUFLO0FBQUEsSUFDNUIsTUFBWSxTQUFTLENBQUM7QUFBQSxFQUN4QjtBQUFBLEVBQ0EsTUFBTSxPQUFPO0FBQUE7QUFHZixlQUFzQixPQUFPLENBQUMsS0FBZTtBQUFBLEVBQzNDLE1BQU0sTUFBTSxNQUFNLElBQUksRUFBRSxPQUFPLG1CQUFtQixPQUFPLElBQUksYUFBYSxZQUFZLFNBQVMsUUFBUSxHQUFHLElBQUksU0FBUyxDQUFDO0FBQUEsRUFDeEgsTUFBTSxJQUFJLEtBQUssS0FBSyxFQUFFLFFBQVEsTUFBTSxFQUFFO0FBQUEsRUFDdEMsSUFBSSxDQUFDO0FBQUEsSUFBRztBQUFBLEVBQ1IsV0FBVyxLQUFLLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxJQUFJLFNBQVMsRUFBRSxFQUFFLENBQUMsR0FBRztBQUFBLElBQzdELElBQUksQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDO0FBQUEsTUFBRyxFQUFFLEtBQUssS0FBSyxDQUFDO0FBQUEsSUFDdEMsTUFBWSxTQUFTLENBQUM7QUFBQSxFQUN4QjtBQUFBLEVBQ0EsTUFBTSxPQUFPO0FBQUE7QUFLZixJQUFNLFFBQVEsTUFBTSxJQUFJLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxHQUFHLEVBQUU7QUFFakQsU0FBUyxXQUFXLENBQUMsT0FBZTtBQUFBLEVBQ3pDLElBQUksQ0FBQyxNQUFNO0FBQUEsSUFBUSxPQUFPLE1BQU0sOEJBQThCLE9BQU87QUFBQSxFQUNyRSxNQUFNLE9BQU8sTUFBTSxXQUFXLElBQUksVUFBVSxLQUFLLE1BQU0sR0FBSSxJQUFJLEtBQUssTUFBTSxXQUFXLFVBQVUsTUFBTSxpQkFBaUIsTUFBTTtBQUFBLEVBQzVILFNBQVMsTUFBTSxLQUFLLFVBQVUsYUFBYSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUM7QUFBQSxFQUMzRCxNQUFNLEdBQUcsTUFBTSxnQ0FBZ0MsSUFBSTtBQUFBO0FBRzlDLFNBQVMsZUFBZSxDQUFDLE1BQVk7QUFBQSxFQUMxQyxTQUFTLEdBQUcsS0FBSyxLQUFLLElBQUksU0FBUyxZQUFZLElBQUksR0FBRyxpQkFBaUI7QUFBQSxFQUN2RSxNQUFNLGtDQUFrQyxJQUFJO0FBQUE7QUFHOUMsZUFBc0IsVUFBVSxDQUFDLE1BQWM7QUFBQSxFQUM3QyxJQUFJO0FBQUEsRUFDSixJQUFJO0FBQUEsRUFDSixJQUFJO0FBQUEsSUFDRixTQUFTLFlBQVksSUFBSTtBQUFBLElBQ3pCLFFBQVEsT0FBTztBQUFBLElBQ2YsT0FBTyxHQUFHO0FBQUEsSUFDVixPQUFPLE1BQU8sRUFBWSxTQUFTLE9BQU87QUFBQTtBQUFBLEVBRTVDLE1BQU0sV0FBVyxJQUFJLElBQUksTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO0FBQUEsRUFDckQsTUFBTSxVQUFVLE1BQU0sT0FBTyxDQUFDLE1BQU0sU0FBUyxJQUFJLEVBQUUsRUFBRSxDQUFDO0FBQUEsRUFDdEQsSUFBSSxPQUE2QjtBQUFBLEVBQ2pDLElBQUksUUFBUSxRQUFRO0FBQUEsSUFDbEIsTUFBTSxJQUFJLE1BQU0sSUFBSTtBQUFBLE1BQ2xCLE9BQU8sR0FBRyxRQUFRO0FBQUEsTUFDbEIsU0FBUyxRQUFRLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUssSUFBSTtBQUFBLE1BQzdDLElBQUk7QUFBQSxNQUNKLE9BQU8sRUFBRSxPQUFPLHVCQUF1QixPQUFPLE9BQU87QUFBQSxJQUN2RCxDQUFDO0FBQUEsSUFDRCxJQUFJLEtBQUs7QUFBQSxNQUFNO0FBQUEsSUFDZixPQUFPLE1BQU0sU0FBUyxTQUFTO0FBQUEsRUFDakM7QUFBQSxFQUNBLFdBQVcsS0FBSyxPQUFPO0FBQUEsSUFDckIsSUFBSSxTQUFTLElBQUksRUFBRSxFQUFFLEtBQUssU0FBUyxRQUFRO0FBQUEsTUFDekMsRUFBRSxLQUFLLElBQUk7QUFBQSxNQUNYLEVBQUUsUUFBUTtBQUFBLElBQ1o7QUFBQSxJQUNBLE1BQVksU0FBUyxDQUFDO0FBQUEsRUFDeEI7QUFBQSxFQUNBLE1BQU0sT0FBTztBQUFBLEVBQ2IsSUFBSSxPQUFPLFdBQVcsWUFBWTtBQUFBLElBQ2hDLE1BQU0sSUFBSSxPQUFPLFFBQVE7QUFBQSxJQUN6QixNQUFNLGtDQUFrQyxJQUFJLEtBQUssOEJBQThCLENBQUMsR0FBRyxJQUFJLElBQUksT0FBTyxPQUFPLENBQUMsRUFBRSxLQUFLLElBQUksT0FBTyxNQUFNLElBQUksU0FBUyxJQUFJO0FBQUEsSUFDbkosU0FBUyxNQUFNLEdBQUksRUFBRTtBQUFBLEVBQ3ZCLEVBQU87QUFBQSxVQUFNLEdBQUcsTUFBTSxnQ0FBZ0MsSUFBSTtBQUFBO0FBR3JELFNBQVMsY0FBYyxDQUFDLE1BQVk7QUFBQSxFQUN6QyxRQUFRLE1BQU0sYUFBYSxXQUFXLElBQUk7QUFBQSxFQUMxQyxTQUFTLEdBQUcsS0FBSyxLQUFLLElBQUksbUJBQW1CLEtBQUssVUFBVSxNQUFNLE1BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDMUUsTUFDRSxXQUFXLGNBQWMsNkVBQTZFLCtDQUN0RyxXQUFXLFNBQVMsSUFDdEI7QUFBQTtBQUtLLFNBQVMsT0FBTyxDQUFDLE1BQVksTUFBZ0IsT0FBZ0I7QUFBQSxFQUNsRSxNQUFNLE9BQWEsUUFBUSxFQUFFLE1BQU0sT0FBTyxTQUFTLFVBQVUsVUFBVSxTQUFTLFNBQVMsU0FBUyxTQUFTLFVBQVUsU0FBUyxVQUFVLENBQUM7QUFBQSxFQUN6SSxNQUFNLElBQUksUUFBUSxLQUFLLE1BQU0sVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLEtBQUssSUFBSTtBQUFBLEVBQ2hFLElBQUksS0FBSztBQUFBLElBQUcsS0FBSyxNQUFNLE9BQU8sSUFBSSxHQUFHLEdBQUcsSUFBSTtBQUFBLEVBQ3ZDO0FBQUEsU0FBSyxNQUFNLEtBQUssSUFBSTtBQUFBLEVBQ3pCLE1BQU0sU0FBUyxJQUFJLEtBQUssRUFBRTtBQUFBLEVBQ3JCLFFBQVEsSUFBSTtBQUFBLEVBQ2pCLE9BQU87QUFBQTtBQUdGLFNBQVMsUUFBUSxDQUFDLE1BQVksSUFBWSxVQUF5QjtBQUFBLEVBQ3hFLE1BQU0sT0FBTyxLQUFLLE1BQU0sVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFBQSxFQUNwRCxJQUFJLE9BQU87QUFBQSxJQUFHO0FBQUEsRUFDZCxPQUFPLEtBQUssS0FBSyxNQUFNLE9BQU8sTUFBTSxDQUFDO0FBQUEsRUFDckMsTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxRQUFRLElBQUksS0FBSyxNQUFNO0FBQUEsRUFDbEYsS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUssTUFBTSxTQUFTLElBQUksR0FBRyxDQUFFO0FBQUEsRUFDbkQsUUFBUSxJQUFJO0FBQUE7QUFHWixTQUFTLGFBQWEsQ0FBQyxNQUFZLE1BQVk7QUFBQSxFQUNwRCxNQUFNLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSTtBQUFBLEVBQ2pDLE1BQU0sT0FBTyxLQUFLLGdCQUFnQixJQUFJLEdBQUcsSUFBSSxJQUFJLEVBQUU7QUFBQSxFQUNuRCxLQUFLLE1BQU0sT0FBTyxJQUFJLEdBQUcsR0FBRyxJQUFJO0FBQUEsRUFDM0IsUUFBUSxJQUFJO0FBQUE7QUFHWixTQUFTLFVBQVUsQ0FBQyxNQUFZLE1BQVk7QUFBQSxFQUNqRCxLQUFLLFFBQVEsS0FBSyxNQUFNLE9BQU8sQ0FBQyxNQUFNLE1BQU0sSUFBSTtBQUFBLEVBQ2hELE1BQU0sU0FBUyxPQUFPLEtBQUssRUFBRTtBQUFBLEVBQ3hCLFFBQVEsSUFBSTtBQUFBO0FBSW5CLGVBQXNCLE9BQU8sQ0FBQyxNQUFZLE1BQVk7QUFBQSxFQUNwRCxJQUFJO0FBQUEsSUFDRixNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQUEsSUFDNUIsTUFBTSxVQUFVLEtBQUs7QUFBQSxJQUNyQixPQUFPO0FBQUEsSUFDUCxNQUFNLFVBQVUsSUFBSSxJQUFLLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFBQSxJQUV6QyxNQUFNLElBQXlCLE1BQU0sT0FBTyxLQUFLLFlBQVksSUFBSSxJQUFLLEVBQUUsTUFBTSxPQUFPLENBQUM7QUFBQSxJQUNqRixPQUFPLEtBQUssWUFBWSxJQUFJLElBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQyxFQUFFLE1BQU0sTUFBTSxFQUFFO0FBQUEsSUFDN0UsSUFBSSxHQUFHO0FBQUEsTUFDTCxLQUFLLFdBQVcsRUFBRTtBQUFBLE1BQ2xCLEtBQUssWUFBWSxFQUFFO0FBQUEsTUFDbkIsS0FBSyxRQUFRLEVBQUU7QUFBQSxNQUNmLEtBQUssUUFBUSxFQUFFO0FBQUEsTUFDZixJQUFJLEtBQUssU0FBUyxXQUFXLEVBQUUsU0FBUyxTQUFTO0FBQUEsUUFFL0MsT0FBTyxPQUFPLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxPQUFPLEVBQUUsT0FBTyxZQUFZLEVBQUUsWUFBWSxRQUFRLEVBQUUsT0FBTyxDQUFDO0FBQUEsTUFDbEc7QUFBQSxNQUNBLE1BQU0sUUFBUSxJQUFJO0FBQUEsTUFDbEIsTUFBTSx3QkFBd0IsSUFBSTtBQUFBLElBQ3BDO0FBQUEsSUFDQSxPQUFPLEdBQUc7QUFBQSxJQUNWLE1BQU8sRUFBWSxTQUFTLE9BQU87QUFBQSxZQUNuQztBQUFBLElBQ0EsTUFBTSxVQUFVO0FBQUEsSUFDaEIsT0FBTztBQUFBO0FBQUE7QUFJWCxlQUFzQixVQUFVLEdBQUc7QUFBQSxFQUNqQyxJQUFJO0FBQUEsSUFDRixNQUFNLE1BQU0sTUFBTSxVQUFVO0FBQUEsSUFDNUIsTUFBTSxPQUFPLEtBQUssWUFBWSxJQUFJLElBQUssRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUFBLElBQzlELE1BQU07QUFBQSxFQUdSLE1BQU0sVUFBVTtBQUFBLEVBQ2hCLE9BQU87QUFBQTtBQUdULGVBQXNCLGFBQWEsQ0FBQyxNQUFZO0FBQUEsRUFDOUMsSUFBSSxDQUFDLEtBQUs7QUFBQSxJQUFVO0FBQUEsRUFDcEIsSUFBSTtBQUFBLElBQ0YsTUFBTSxNQUFNLE1BQU0sVUFBVTtBQUFBLElBQzVCLE1BQU0sTUFBTSxNQUFNLFdBQVcsSUFBSSxJQUFLLEtBQUssT0FBTyxJQUFJO0FBQUEsSUFDdEQsTUFBTSxJQUFJLE1BQU0sVUFBMkIsSUFBSSxJQUFLLEVBQUUsTUFBTSxhQUFhLFVBQVUsS0FBSyxVQUFVLFdBQVcsS0FBSyxVQUFVLEdBQUcsR0FBRztBQUFBLElBQ2xJLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFBSSxNQUFNLGtDQUFrQyxPQUFPO0FBQUEsSUFDM0QsT0FBTyxHQUFHO0FBQUEsSUFDVixNQUFPLEVBQVksU0FBUyxPQUFPO0FBQUE7QUFBQTtBQU12QyxJQUFNLEtBQUssQ0FBc0MsUUFBdUMsT0FBTyxRQUFRLFlBQVksR0FBRztBQUV0SCxlQUFzQixjQUFjLENBQUMsTUFBWSxNQUEwQjtBQUFBLEVBQ3pFLElBQUk7QUFBQSxJQUNGLE1BQU0sTUFBTSxNQUFNLFVBQVU7QUFBQSxJQUM1QixJQUFJLENBQUMsSUFBSSxPQUFPLENBQUMsa0JBQWtCLEtBQUssSUFBSSxHQUFHLEdBQUc7QUFBQSxNQUNoRCxPQUFPLE1BQU0sd0RBQXdELE9BQU87QUFBQSxJQUM5RTtBQUFBLElBQ0EsTUFBTSxJQUFJLE1BQU0sR0FBRyxFQUFFLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxJQUFJLE9BQU8sSUFBSSxJQUFLLEtBQUssQ0FBQztBQUFBLElBQ2xGLElBQUksQ0FBQyxFQUFFO0FBQUEsTUFBSSxNQUFNLEVBQUUsU0FBUywrQkFBK0IsT0FBTztBQUFBLElBQ2xFLE9BQU8sR0FBRztBQUFBLElBQ1YsTUFBTyxFQUFZLFNBQVMsT0FBTztBQUFBO0FBQUE7QUFJaEMsSUFBTSxnQkFBZ0IsTUFBTSxHQUFHLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFDdEQsSUFBTSxpQkFBaUIsQ0FBQyxXQUFvQixHQUFHLEVBQUUsTUFBTSxnQkFBZ0IsT0FBTyxDQUFDO0FBSXRGLGVBQXNCLElBQUksQ0FBQyxNQUFZLE9BQU8sR0FBRyxNQUFlO0FBQUEsRUFDOUQsSUFBSSxPQUFPO0FBQUEsSUFBUztBQUFBLEVBQ3BCLElBQUksTUFBTTtBQUFBLElBQVcsTUFBTSxjQUFjO0FBQUEsRUFDekMsTUFBTSxNQUFNLEVBQUUsUUFBUSxLQUFLLElBQUksUUFBUSxDQUFDLEdBQUcsTUFBTSxDQUFDLEVBQUU7QUFBQSxFQUNwRCxPQUFPO0FBQUEsRUFDUCxNQUFNLFVBQVUsTUFBTSxPQUFPLElBQUksTUFBTSxNQUFNLFVBQVU7QUFBQSxJQUNyRCxRQUFRLENBQUMsSUFBSSxRQUFRLE1BQU07QUFBQSxNQUN6QixJQUFJLENBQUMsTUFBTTtBQUFBLFFBQUs7QUFBQSxNQUNoQixNQUFNLElBQUksT0FBTyxNQUFNO0FBQUEsTUFDdkIsSUFBSTtBQUFBLFFBQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtBQUFBLE1BQy9CLE9BQU87QUFBQSxNQUNQLElBQUksV0FBVztBQUFBLFFBQVcsU0FBUyxjQUFjLGVBQWUsTUFBTSxHQUFHLGVBQWUsRUFBRSxPQUFPLFVBQVUsQ0FBQztBQUFBO0FBQUEsRUFFaEgsR0FBRyxNQUFNLElBQUk7QUFBQSxFQUNiLElBQUksUUFBUSxNQUFNO0FBQUEsSUFDaEIsS0FBSyxVQUFVO0FBQUEsSUFDZixNQUFZLFNBQVMsTUFBTSxLQUFLO0FBQUEsRUFDbEM7QUFBQSxFQUNBLE9BQU87QUFBQSxFQUNQLElBQUksUUFBUTtBQUFBLElBQUksTUFBTSxvQkFBb0IsUUFBUSxLQUFLLE1BQU0sUUFBUSxDQUFDLE1BQU0sSUFBSTtBQUFBLEVBQzNFO0FBQUEsVUFBTSxLQUFLLFFBQVEsU0FBUyxPQUFPO0FBQUE7QUFHbkMsU0FBUyxRQUFRLEdBQUc7QUFBQSxFQUN6QixPQUFPLEtBQUs7QUFBQTs7O0FDMVZkLElBQU0sUUFBUSxPQUFPLEtBQUssU0FBUztBQUU1QixTQUFTLFVBQVUsQ0FBQyxNQUF5QjtBQUFBLEVBQ2xELE1BQU0sTUFBTSxNQUFNLFdBQVcsV0FBVyxLQUFLLEtBQUssTUFBTSxZQUFZO0FBQUEsRUFDcEUsTUFBTSxXQUFXLE1BQU0sYUFBYSxDQUFDO0FBQUEsRUFDckMsTUFBTSxVQUFZLE9BQU87QUFBQSxFQUN6QixNQUFNLE1BQU0sTUFBTSxLQUFLLFdBQVcsS0FBSyxLQUFLLE1BQU0sTUFBTTtBQUFBLEVBRXhELE1BQU0sTUFBTSxDQUF1QixHQUFNLE1BQWU7QUFBQSxJQUN0RCxLQUFLLEtBQUs7QUFBQSxJQUNSLFNBQVMsSUFBSTtBQUFBO0FBQUEsRUFHakIsT0FBTyxFQUNMLE9BQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsRUFDRSxVQUNBLEVBQUUsT0FBTyxNQUFNLEdBQ2YsRUFBRSxVQUFVLEVBQUUsT0FBTyxnQkFBZ0IsU0FBUyxPQUFRLE1BQU0sT0FBTyxXQUFjLE9BQU8sR0FBRyxHQUFHLFVBQVUsR0FDeEcsRUFDRSxPQUNBLEVBQUUsT0FBTyxNQUFNLEdBQ2YsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8saUJBQWlCLFNBQVMsTUFBUSxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsR0FBRyxHQUFHLEdBQ2hHLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLHdCQUF3QixTQUFTLE1BQVEsZ0JBQWdCLElBQUksRUFBRSxHQUFHLElBQUksR0FDMUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sZ0NBQWdDLFNBQVMsTUFBUSxlQUFlLElBQUksRUFBRSxHQUFHLElBQUksR0FDakgsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sWUFBWSxTQUFTLE1BQVEsY0FBYyxJQUFJLEVBQUUsR0FBRyxHQUFHLEdBQzNGLEVBQUUsVUFBVSxFQUFFLE9BQU8sZUFBZSxPQUFPLGdCQUFnQixTQUFTLE1BQVEsWUFBWSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsR0FBRyxjQUFJLENBQzVHLENBQ0YsR0FDQSxFQUNFLFFBQ0EsRUFBRSxPQUFPLFVBQVUsZUFBZSxTQUFTLEdBQzNDLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsT0FBTyxLQUFLO0FBQUEsSUFDWixVQUFVO0FBQUEsSUFDVixhQUFhO0FBQUEsSUFDYixTQUFTLENBQUMsTUFBYSxJQUFJLFFBQVMsRUFBRSxPQUE0QixLQUFLO0FBQUEsRUFDekUsQ0FBQyxHQUNELEVBQ0UsT0FDQSxFQUFFLE9BQU8sWUFBWSxHQUNyQixFQUNFLFNBQ0EsTUFDQSxFQUFFLFFBQVEsTUFBTSxTQUFTLEdBQ3pCLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sT0FBTyxLQUFLLFVBQVU7QUFBQSxJQUN0QixhQUFhO0FBQUEsSUFDYixVQUFVO0FBQUEsSUFDVixTQUFTLENBQUMsTUFBYSxJQUFJLFVBQVcsRUFBRSxPQUE0QixNQUFNLEtBQUssS0FBSyxTQUFTO0FBQUEsRUFDL0YsQ0FBQyxHQUNELEVBQUUsWUFBWSxFQUFFLElBQUksVUFBVSxHQUFLLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FDdkYsR0FDQSxFQUFFLFNBQVMsTUFBTSxFQUFFLFFBQVEsTUFBTSxXQUFXLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FDaEUsR0FDQSxFQUFFLFlBQVk7QUFBQSxJQUNaLE9BQU87QUFBQSxJQUNQLE1BQU07QUFBQSxJQUNOLGFBQWE7QUFBQSxJQUNiLFVBQVU7QUFBQSxJQUNWLE9BQU8sS0FBSyxlQUFlO0FBQUEsSUFDM0IsU0FBUyxDQUFDLE1BQWEsSUFBSSxlQUFnQixFQUFFLE9BQStCLFNBQVMsU0FBUztBQUFBLEVBQ2hHLENBQUMsR0FHRCxFQUNFLE9BQ0EsRUFBRSxPQUFPLFVBQVUsR0FDbkIsTUFDSTtBQUFBLElBQ0UsRUFBRSxVQUFVLEVBQUUsT0FBTyxjQUFjLFNBQVMsTUFBUSxjQUFjLEVBQUUsR0FBRyxZQUFZO0FBQUEsSUFDbkYsRUFBRSxVQUFVLEVBQUUsT0FBTyxPQUFPLFNBQVMsTUFBUSxlQUFlLENBQUMsSUFBSSxNQUFNLEVBQUUsR0FBRyxJQUFJLFNBQVMsZUFBZSxXQUFXO0FBQUEsRUFDckgsSUFDQTtBQUFBLElBQ0UsRUFDRSxVQUNBLEVBQUUsT0FBTyxXQUFXLFVBQVUsV0FBVyxVQUFVLE9BQU8seURBQXlELFNBQVMsTUFBUSxlQUFlLE1BQU0sUUFBUSxFQUFFLEdBQ25LLFVBQ0Y7QUFBQSxJQUNBLEVBQ0UsVUFDQTtBQUFBLE1BQ0UsT0FBTztBQUFBLE1BQ1AsVUFBVSxXQUFXO0FBQUEsTUFDckIsT0FBTztBQUFBLE1BQ1AsU0FBUyxNQUFRLGVBQWUsTUFBTSxPQUFPO0FBQUEsSUFDL0MsR0FDQSxXQUNGO0FBQUEsRUFDRixHQUNKLFVBQ0ksRUFBRSxVQUFVLEVBQUUsT0FBTyxjQUFjLFNBQVcsU0FBUyxHQUFHLFNBQVMsSUFDbkUsRUFBRSxVQUFVLEVBQUUsT0FBTyxlQUFlLFVBQVUsQ0FBQyxLQUFLLE1BQU0sVUFBVSxDQUFDLENBQUMsS0FBSyxTQUFTLE1BQVEsS0FBSyxJQUFJLEVBQUUsR0FBRyxjQUFjLENBQzlILEdBQ0EsT0FDRSxFQUNFLE9BQ0EsRUFBRSxPQUFPLGFBQWEsSUFBSSxTQUFTLFdBQVcsSUFBSSxNQUFNLEdBQ3hELElBQUksU0FDQSx3QkFDQSxJQUFJLFNBQVMsV0FDWCxvRkFDQSx5RkFDUixHQUNGLFlBQVksRUFBRSxPQUFPLEVBQUUsT0FBTyxnQkFBZ0IsR0FBRyw4QkFBOEIsR0FDL0UsTUFBTSxXQUFXLEVBQUUsT0FBTyxFQUFFLE9BQU8sZUFBZSxHQUFHLG9DQUFvQyxFQUFFLFVBQVUsRUFBRSxPQUFPLFVBQVUsU0FBVyxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQzVKLENBQUMsV0FBVyxLQUFLLFdBQVcsV0FBVyxJQUFJLEdBRTNDLGdCQUFnQixJQUFJLEdBR3BCLEVBQ0UsTUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsWUFBWSxDQUFDLE1BQWlCLEVBQUUsZUFBZTtBQUFBLElBQy9DLFFBQVEsQ0FBQyxNQUFpQjtBQUFBLE1BQ3hCLEVBQUUsZUFBZTtBQUFBLE1BQ2pCLElBQUksTUFBTTtBQUFBLFFBQVUsU0FBUyxNQUFNLE1BQU0sUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUV6RCxHQUNBLEtBQUssTUFBTSxJQUFJLENBQUMsR0FBRyxNQUFNLFFBQVEsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQ25ELEdBQ0EsS0FBSyxNQUFNLFdBQVcsS0FBSyxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxjQUFjLEdBQUcsNkJBQTZCLEVBQUUsS0FBSyxNQUFNLFFBQVEsR0FBRyx3QkFBd0IsR0FDakosWUFBWSxJQUFJLENBQ2xCLENBQ0Y7QUFBQTtBQUdGLFNBQVMsVUFBVSxDQUFDLE1BQVk7QUFBQSxFQUM5QixNQUFNLElBQUksS0FBSztBQUFBLEVBQ2YsTUFBTSxNQUFNLEVBQUUsZUFBZSxLQUFLLE1BQU0sVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsWUFBWSxJQUFJLElBQUk7QUFBQSxFQUN4RixPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sY0FBYyxFQUFFLEtBQUssT0FBTyxPQUFPLEdBQzVDLEVBQUUsS0FBSyxZQUFZLEVBQUUsS0FBSyxNQUFNLFFBQVEsQ0FBQyxPQUFPLFVBQVUsTUFBTSxlQUFlLFFBQVEsT0FBTyxFQUFFLFNBQ2hHLEVBQUUsUUFBUSxFQUFFLE9BQU8sUUFBUSxHQUFHLFFBQVEsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUNyRDtBQUFBO0FBR0YsU0FBUyxTQUFTLENBQUMsTUFBWTtBQUFBLEVBQzdCLE9BQU8sRUFDTCxPQUNBLEVBQUUsT0FBTyxhQUFhLEdBQ3RCLEtBQUssS0FBSyxJQUFJLENBQUMsTUFDYixFQUNFLFFBQ0EsRUFBRSxPQUFPLE9BQU8sR0FDaEIsTUFBTSxHQUNOLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsU0FBUyxNQUFNO0FBQUEsTUFDYixLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU8sQ0FBQyxNQUFNLE1BQU0sQ0FBQztBQUFBLE1BQ3BDLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFdkIsR0FDQSxHQUNGLENBQ0YsQ0FDRixHQUNBLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsYUFBYSxLQUFLLEtBQUssU0FBUyxNQUFNO0FBQUEsSUFDdEMsTUFBTTtBQUFBLElBQ04sVUFBVTtBQUFBLElBQ1YsV0FBVyxDQUFDLE1BQXFCO0FBQUEsTUFDL0IsTUFBTSxRQUFRLEVBQUU7QUFBQSxNQUNoQixLQUFLLEVBQUUsUUFBUSxXQUFXLEVBQUUsUUFBUSxRQUFRLE1BQU0sTUFBTSxLQUFLLEdBQUc7QUFBQSxRQUM5RCxFQUFFLGVBQWU7QUFBQSxRQUNqQixNQUFNLElBQUksTUFBTSxNQUFNLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFFBQVEsTUFBTSxFQUFFO0FBQUEsUUFDL0QsSUFBSSxLQUFLLENBQUMsS0FBSyxLQUFLLFNBQVMsQ0FBQztBQUFBLFVBQUcsS0FBSyxLQUFLLEtBQUssQ0FBQztBQUFBLFFBQ2pELE1BQU0sUUFBUTtBQUFBLFFBQ1AsUUFBUSxJQUFJO0FBQUEsTUFDckIsRUFBTyxTQUFJLEVBQUUsUUFBUSxlQUFlLENBQUMsTUFBTSxTQUFTLEtBQUssS0FBSyxRQUFRO0FBQUEsUUFDcEUsS0FBSyxLQUFLLElBQUk7QUFBQSxRQUNQLFFBQVEsSUFBSTtBQUFBLE1BQ3JCO0FBQUE7QUFBQSxFQUVKLENBQUMsR0FDRCxFQUFFLFlBQVksRUFBRSxJQUFJLFdBQVcsR0FBSyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQ3JGO0FBQUE7QUFHRixJQUFJO0FBRUosU0FBUyxlQUFlLENBQUMsTUFBWTtBQUFBLEVBQ25DLE1BQU0sVUFBVSxPQUFPLFFBQVEsS0FBSyxhQUFhLENBQUMsQ0FBQztBQUFBLEVBQ25ELE1BQU0sUUFBUSxDQUFDLFVBQThCO0FBQUEsSUFDM0MsS0FBSyxZQUFZLE9BQU8sWUFBWSxNQUFNLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7QUFBQTtBQUFBLEVBRXJFLE9BQU8sRUFDTCxXQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxNQUFNLFlBQVksUUFBUSxTQUFTO0FBQUEsSUFDbkMsVUFBVSxDQUFDLE1BQWMsV0FBWSxFQUFFLE9BQThCO0FBQUEsRUFDdkUsR0FDQSxFQUFFLFdBQVcsTUFBTSxhQUFhLFFBQVEsU0FBUyxLQUFLLEVBQUUsUUFBUSxFQUFFLE9BQU8sUUFBUSxHQUFHLE9BQU8sUUFBUSxNQUFNLENBQUMsQ0FBQyxHQUMzRyxFQUNFLEtBQ0EsRUFBRSxPQUFPLGNBQWMsR0FDdkIsUUFDQSxFQUFFLFFBQVEsTUFBTSxZQUFZLEdBQzVCLHFDQUNBLGFBQWEsSUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDLElBQUksT0FBTyxJQUFJLEVBQUUsUUFBUSxNQUFNLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FDekUsR0FDQSxRQUFRLElBQUksRUFBRSxHQUFHLElBQUksTUFDbkIsRUFDRSxPQUNBLEVBQUUsT0FBTyxVQUFVLEdBQ25CLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsT0FBTztBQUFBLElBQ1AsYUFBYTtBQUFBLElBQ2IsVUFBVSxTQUFTO0FBQUEsSUFDbkIsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUN0QixNQUFNLFFBQVEsT0FBTyxRQUFRLEtBQUssU0FBUztBQUFBLE1BQzNDLE1BQU0sS0FBSyxDQUFFLEVBQUUsT0FBNEIsTUFBTSxLQUFLLEdBQUcsQ0FBQztBQUFBLE1BQzFELE1BQU0sS0FBSztBQUFBLE1BQ0osUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUV2QixDQUFDLEdBQ0QsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxhQUFhO0FBQUEsSUFDYixVQUFVLFNBQVM7QUFBQSxJQUNuQixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLEtBQUssVUFBVSxLQUFNLEVBQUUsT0FBNEI7QUFBQSxNQUNqRCxTQUFTLElBQUk7QUFBQTtBQUFBLEVBRW5CLENBQUMsR0FDRCxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLE9BQU87QUFBQSxJQUNQLFNBQVMsTUFBTTtBQUFBLE1BQ2IsT0FBTyxLQUFLLFVBQVU7QUFBQSxNQUNmLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFdkIsR0FDQSxHQUNGLENBQ0YsQ0FDRixHQUNBLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsU0FBUyxNQUFNO0FBQUEsTUFDYixJQUFJLElBQUk7QUFBQSxNQUNSLE9BQU8sTUFBTSxPQUFPLEtBQUs7QUFBQSxRQUFXO0FBQUEsTUFDcEMsS0FBSyxVQUFVLE1BQU0sT0FBTztBQUFBLE1BQ3JCLFFBQVEsSUFBSTtBQUFBO0FBQUEsRUFFdkIsR0FDQSxZQUNGLENBQ0Y7QUFBQTtBQUdGLFNBQVMsWUFBWSxDQUFDLEdBQWlCO0FBQUEsRUFDckMsSUFBSSxFQUFFLFNBQVMsUUFBUSxFQUFFLFVBQVU7QUFBQSxJQUFJLE9BQU87QUFBQSxFQUM5QyxJQUFJLEVBQUU7QUFBQSxJQUFRLE9BQU87QUFBQSxFQUNyQixJQUFJLEVBQUUsU0FBUztBQUFBLElBQVMsT0FBTyxFQUFFLFVBQVUsVUFBVSxjQUFjO0FBQUEsRUFDbkUsSUFBSSxFQUFFLFNBQVM7QUFBQSxJQUFVLE9BQU8sRUFBRSxjQUFjLEVBQUU7QUFBQSxFQUNsRCxJQUFJLEVBQUUsU0FBUztBQUFBLElBQVEsT0FBTyxHQUFHLEVBQUU7QUFBQSxFQUNuQyxPQUFPLEVBQUU7QUFBQTtBQUdYLFNBQVMsT0FBTyxDQUFDLE1BQVksR0FBUyxHQUFXLEtBQXVCO0FBQUEsRUFDdEUsTUFBTSxPQUFPLFVBQVUsRUFBRTtBQUFBLEVBQ3pCLE1BQU0sT0FBTyxNQUFNLFNBQVMsSUFBSSxFQUFFLEVBQUU7QUFBQSxFQUNwQyxNQUFNLFNBQVMsS0FBSyxPQUFPLEVBQUU7QUFBQSxFQUM3QixNQUFNLE9BQU8sS0FBSyxLQUFLLEVBQUU7QUFBQSxFQUN6QixNQUFNLFFBQ0osRUFBRSxTQUFTLGFBQWEsRUFBRSxTQUFTLEVBQUUsU0FBUyxRQUFRLEVBQUUsU0FBUyxVQUFVLEVBQUUsU0FBUyxVQUFVLEVBQUUsU0FBUyxTQUFTLEtBQUssRUFBRSxTQUFTLEVBQUUsWUFBWTtBQUFBLEVBQ3BKLE1BQU0sTUFBTSxFQUFFLFNBQVMsY0FBYyxFQUFFLFNBQVMsVUFBVSxLQUFLLGFBQWEsQ0FBQztBQUFBLEVBRTdFLE1BQU0sU0FBUyxNQUFNO0FBQUEsSUFDbkIsT0FBTyxNQUFNLFNBQVMsT0FBTyxFQUFFLEVBQUUsSUFBSSxNQUFNLFNBQVMsSUFBSSxFQUFFLEVBQUU7QUFBQSxJQUMxRCxPQUFPO0FBQUE7QUFBQSxFQUdYLE1BQU0sS0FBSyxFQUNULE1BQ0E7QUFBQSxJQUNFLE9BQU8sVUFBVSxFQUFFLE9BQU8sT0FBTyxVQUFVLEtBQUssRUFBRSxVQUFVLEtBQUssY0FBYyxTQUFTLFNBQVMsU0FBUyxLQUFLLE1BQU0sV0FBVyxFQUFFLEtBQUssY0FBYztBQUFBLElBQ3JKLGFBQWEsRUFBRTtBQUFBLElBQ2YsYUFBYSxDQUFDLE1BQWlCO0FBQUEsTUFDN0IsTUFBTSxTQUFTLEVBQUU7QUFBQSxNQUNqQixFQUFFLGFBQWMsZ0JBQWdCO0FBQUEsTUFDaEMsRUFBRSxhQUFjLFFBQVEsY0FBYyxFQUFFLEVBQUU7QUFBQTtBQUFBLElBRTVDLFdBQVcsTUFBTTtBQUFBLE1BQ2YsTUFBTSxTQUFTO0FBQUEsTUFDZixHQUFHLFlBQVk7QUFBQSxNQUNiLE9BQU87QUFBQTtBQUFBLElBRVgsWUFBWSxDQUFDLE1BQWlCO0FBQUEsTUFDNUIsSUFBSSxDQUFDLE1BQU0sVUFBVSxNQUFNLFdBQVcsRUFBRTtBQUFBLFFBQUk7QUFBQSxNQUM1QyxFQUFFLGVBQWU7QUFBQSxNQUNqQixNQUFNLElBQUksR0FBRyxzQkFBc0I7QUFBQSxNQUNuQyxHQUFHLFVBQVUsT0FBTyxlQUFlLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFBQSxNQUNuRSxHQUFHLFVBQVUsT0FBTyxjQUFjLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFBQTtBQUFBLElBRXJFLGFBQWEsTUFBTSxHQUFHLFVBQVUsT0FBTyxlQUFlLFlBQVk7QUFBQSxJQUNsRSxRQUFRLENBQUMsTUFBaUI7QUFBQSxNQUN4QixFQUFFLGVBQWU7QUFBQSxNQUNqQixFQUFFLGdCQUFnQjtBQUFBLE1BQ2xCLElBQUksQ0FBQyxNQUFNLFVBQVUsTUFBTSxXQUFXLEVBQUU7QUFBQSxRQUFJO0FBQUEsTUFDNUMsTUFBTSxRQUFRLEdBQUcsVUFBVSxTQUFTLFlBQVk7QUFBQSxNQUNoRCxNQUFNLE9BQU8sUUFBUSxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sT0FBTyxFQUFFO0FBQUEsTUFDckQsU0FBUyxNQUFNLE1BQU0sUUFBUSxTQUFTLE1BQU0sU0FBUyxFQUFFLEtBQUssSUFBSTtBQUFBO0FBQUEsRUFFdEUsR0FDQSxFQUNFLE9BQ0EsRUFBRSxPQUFPLFNBQVMsR0FDbEIsRUFDRSxRQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxPQUFPO0FBQUEsSUFDUCxhQUFhLE1BQU8sR0FBRyxZQUFZO0FBQUEsSUFDbkMsV0FBVyxNQUFPLEdBQUcsWUFBWTtBQUFBLEVBQ25DLEdBQ0EsSUFDRixHQUNBLEVBQUUsUUFBUSxFQUFFLE9BQU8sTUFBTSxHQUFHLE9BQU8sSUFBSSxDQUFDLENBQUMsR0FDekMsRUFBRSxRQUFRLEVBQUUsT0FBTyxTQUFTLE9BQU8sS0FBSyxNQUFNLEdBQUcsS0FBSyxJQUFJLEdBQzFELEVBQ0UsVUFDQSxFQUFFLE9BQU8sY0FBYyxTQUFTLE9BQU8sR0FDdkMsRUFBRSxLQUFLLE1BQU0sS0FBSyxLQUFLLEdBQ3ZCLFNBQVMsRUFBRSxRQUFRLEVBQUUsT0FBTyxNQUFNLEdBQUcsS0FBSyxHQUMxQyxDQUFDLENBQUMsRUFBRSxPQUFPLFVBQVUsRUFBRSxRQUFRLEVBQUUsT0FBTyxhQUFhLE9BQU8sdUJBQXVCLEVBQUUsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLEtBQUssRUFBRSxHQUFHLEVBQUUsTUFBTSxTQUFTLElBQUksV0FBVyxFQUFFLE1BQU0sV0FBVyxRQUFRLEdBQzVMLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxNQUFNLEdBQUcsR0FBRyxDQUN4QyxHQUNBLEVBQUUsUUFBUSxFQUFFLE9BQU8sVUFBVSxPQUFPLFFBQVEsVUFBVSxHQUFHLEdBQUcsV0FBVyxNQUFNLENBQUMsQ0FDaEYsR0FDQSxXQUFXLFdBQVcsUUFBUSxFQUFFLE9BQU8sRUFBRSxPQUFPLFdBQVcsR0FBRyxJQUFJLEdBQ2xFLFFBQVEsWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUNoQztBQUFBLEVBQ0EsT0FBTztBQUFBO0FBR1QsU0FBUyxVQUFVLENBQUMsSUFBYTtBQUFBLEVBQy9CLFFBQVE7QUFBQSxTQUNEO0FBQUEsTUFDSCxPQUFPLEVBQUUsUUFBUSxFQUFFLE9BQU8sT0FBTyxDQUFDO0FBQUEsU0FDL0I7QUFBQSxNQUNILE9BQU87QUFBQSxTQUNKO0FBQUEsTUFDSCxPQUFPO0FBQUEsU0FDSjtBQUFBLE1BQ0gsT0FBTztBQUFBO0FBQUEsTUFFUCxPQUFPO0FBQUE7QUFBQTtBQUliLFNBQVMsV0FBVyxDQUFDLE1BQVksR0FBUyxHQUFXO0FBQUEsRUFDbkQsTUFBTSxPQUFPLFVBQVUsRUFBRTtBQUFBLEVBQ3pCLE1BQU0sT0FBTyxNQUFRLFNBQVMsSUFBSTtBQUFBLEVBQ2xDLE1BQU0sUUFBUSxDQUFDLFVBQWtCLFlBQWlELEVBQUUsU0FBUyxFQUFFLE9BQU8sUUFBUSxHQUFHLEVBQUUsUUFBUSxNQUFNLEtBQUssR0FBRyxHQUFHLE9BQU87QUFBQSxFQUNuSixNQUFNLGFBQWEsS0FBSyxlQUFlLEVBQUUsU0FBUztBQUFBLEVBRWxELE9BQU8sRUFDTCxPQUNBLEVBQUUsT0FBTyxZQUFZLEdBQ3JCLE1BQ0UsUUFDQSxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFVBQVUsQ0FBQyxNQUFhO0FBQUEsTUFDdEIsRUFBRSxPQUFRLEVBQUUsT0FBNkI7QUFBQSxNQUNsQyxRQUFRLElBQUk7QUFBQTtBQUFBLEVBRXZCLEdBQ0EsTUFBTSxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEdBQUcsVUFBVSxNQUFNLEVBQUUsS0FBSyxHQUFHLEdBQUcsVUFBVSxHQUFHLFNBQVMsVUFBVSxHQUFHLE9BQU8sQ0FBQyxDQUNuSCxDQUNGLEdBQ0EsY0FDRSxNQUNFLEVBQUUsU0FBUyxVQUFVLHdCQUF3QixZQUM3QyxFQUNFLE9BQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxPQUFPLEVBQUUsWUFBWTtBQUFBLElBQ3JCLGFBQWE7QUFBQSxJQUNiLFVBQVUsT0FBTyxFQUFFO0FBQUEsSUFDbkIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixFQUFFLFdBQVksRUFBRSxPQUE0QixTQUFTO0FBQUEsTUFDckQsS0FBSztBQUFBO0FBQUEsRUFFVCxDQUFDLEdBQ0QsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sd0JBQXdCLFVBQVUsQ0FBQyxDQUFDLE1BQU0sU0FBUyxTQUFTLE1BQVEsUUFBUSxNQUFNLENBQUMsRUFBRSxHQUFHLGNBQUksR0FDaEksRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8seUJBQXlCLFVBQVUsQ0FBQyxFQUFFLFVBQVUsU0FBUyxNQUFRLGNBQWMsQ0FBQyxFQUFFLEdBQUcsY0FBSSxDQUMvSCxDQUNGLEdBQ0YsY0FBYyxXQUFXLE1BQU0sR0FBRyxLQUFLLEdBQ3ZDLGNBQ0UsQ0FBQyxDQUFDLEVBQUUsV0FBVyxVQUNmLEVBQ0UsV0FDQSxFQUFFLE9BQU8sWUFBWSxHQUNyQixFQUFFLFdBQVcsTUFBTSxHQUFHLEVBQUUsVUFBVSxvQ0FBb0MsR0FDdEUsRUFBRSxZQUFZO0FBQUEsSUFDWixPQUFPO0FBQUEsSUFDUCxNQUFNLEtBQUssSUFBSSxHQUFHLEVBQUUsVUFBVSxNQUFNO0FBQUEsSUFDcEMsVUFBVSxNQUFNLEVBQUU7QUFBQSxJQUNsQixPQUFPLEVBQUUsVUFBVSxLQUFLO0FBQUEsQ0FBSTtBQUFBLElBQzVCLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDckIsRUFBRSxZQUFhLEVBQUUsT0FBK0IsTUFBTSxNQUFNO0FBQUEsQ0FBSSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsT0FBTyxPQUFPO0FBQUEsTUFDckcsS0FBSztBQUFBO0FBQUEsRUFFVCxDQUFDLENBQ0gsR0FDRixjQUNFLE1BQ0UsVUFDQSxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE9BQU8sRUFBRSxTQUFTO0FBQUEsSUFDbEIsYUFBYTtBQUFBLElBQ2IsVUFBVSxPQUFPLEVBQUU7QUFBQSxJQUNuQixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLEVBQUUsUUFBUyxFQUFFLE9BQTRCLFNBQVM7QUFBQSxNQUNsRCxLQUFLO0FBQUE7QUFBQSxFQUVULENBQUMsQ0FDSCxHQUNGLEVBQUUsU0FBUyxXQUFXLEVBQUUsU0FBUyxhQUFhLFdBQVcsTUFBTSxHQUFHLEtBQUssR0FDdkUsRUFDRSxPQUNBLEVBQUUsT0FBTyxVQUFVLEdBQ25CLEVBQUUsU0FBUyxjQUNULEVBQUUsU0FBUyxVQUNYLE1BQ0UsZ0JBQ0EsRUFBRSxTQUFTO0FBQUEsSUFDVCxPQUFPO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxNQUFNO0FBQUEsSUFDTixhQUFhLE9BQU8sTUFBTSxTQUFTLE9BQU87QUFBQSxJQUMxQyxPQUFPLEVBQUUsV0FBVztBQUFBLElBQ3BCLFVBQVUsTUFBTSxFQUFFO0FBQUEsSUFDbEIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixNQUFNLElBQUssRUFBRSxPQUE0QjtBQUFBLE1BQ3pDLEVBQUUsVUFBVSxPQUFPLFNBQVMsQ0FBQyxJQUFJLElBQUk7QUFBQSxNQUNyQyxLQUFLO0FBQUE7QUFBQSxFQUVULENBQUMsQ0FDSCxHQUNGLE1BQ0UsUUFDQSxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLE9BQU8sRUFBRSxRQUFRO0FBQUEsSUFDakIsVUFBVSxRQUFRLEVBQUU7QUFBQSxJQUNwQixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLEVBQUUsT0FBUSxFQUFFLE9BQTRCLFNBQVM7QUFBQSxNQUNqRCxLQUFLO0FBQUE7QUFBQSxFQUVULENBQUMsQ0FDSCxDQUNGLEdBQ0EsRUFDRSxPQUNBLEVBQUUsT0FBTyxnQkFBZ0IsR0FDekIsRUFDRSxTQUNBLEVBQUUsT0FBTyxTQUFTLEdBQ2xCLEVBQUUsU0FBUztBQUFBLElBQ1QsTUFBTTtBQUFBLElBQ04sU0FBUyxFQUFFO0FBQUEsSUFDWCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3RCLEVBQUUsVUFBVyxFQUFFLE9BQTRCO0FBQUEsTUFDcEMsUUFBUSxJQUFJO0FBQUE7QUFBQSxFQUV2QixDQUFDLEdBQ0QsUUFDRixHQUNBLEVBQUUsUUFBUSxFQUFFLE9BQU8sT0FBTyxDQUFDLEdBQzNCLEVBQUUsVUFBVSxFQUFFLE9BQU8sZ0JBQWdCLE9BQU8sMkJBQTJCLFVBQVksT0FBTyxTQUFTLFNBQVMsTUFBUSxLQUFLLE1BQU0sR0FBRyxDQUFDLEVBQUUsR0FBRyxhQUFhLEdBQ3JKLEVBQUUsVUFBVSxFQUFFLE9BQU8sZ0JBQWdCLE9BQU8sOEJBQThCLFVBQVksT0FBTyxTQUFTLFNBQVMsTUFBUSxLQUFLLE1BQU0sQ0FBQyxFQUFFLEdBQUcsY0FBYyxHQUN0SixFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsT0FBTyxpQkFBaUIsU0FBUyxNQUFRLGNBQWMsTUFBTSxDQUFDLEVBQUUsR0FBRyxHQUFHLEdBQ25HLEVBQUUsVUFBVSxFQUFFLE9BQU8sZUFBZSxPQUFPLGVBQWUsU0FBUyxNQUFRLFdBQVcsTUFBTSxDQUFDLEVBQUUsR0FBRyxjQUFJLENBQ3hHLENBQ0Y7QUFBQTtBQUdGLElBQU0sWUFBWTtBQUVsQixTQUFTLFVBQVUsQ0FBQyxNQUFZLEdBQVMsT0FBOEU7QUFBQSxFQUNySCxPQUFPLE1BQ0wsVUFDQSxFQUFFLFNBQVM7QUFBQSxJQUNULE9BQU87QUFBQSxJQUNQLFFBQVEsRUFBRSxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxLQUFLLFNBQVM7QUFBQSxJQUM1RCxhQUFhO0FBQUEsSUFDYixVQUFVLFNBQVMsRUFBRTtBQUFBLElBQ3JCLFNBQVMsQ0FBQyxNQUFhO0FBQUEsTUFDckIsTUFBTSxRQUFTLEVBQUUsT0FBNEIsTUFBTSxNQUFNLElBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxFQUFFLE9BQU8sT0FBTztBQUFBLE1BRWxHLEVBQUUsUUFBUSxNQUFNLFNBQVMsTUFBTSxJQUFJLENBQUMsS0FBSyxNQUFPLEVBQUUsUUFBUSxJQUFJLGFBQWEsTUFBTSxFQUFFLE1BQU0sS0FBTSxFQUFFLFVBQVUsSUFBSSxDQUFFLElBQUk7QUFBQSxNQUNuSCxTQUFTLElBQUk7QUFBQTtBQUFBLEVBRW5CLENBQUMsR0FDRCxDQUFDLENBQUMsRUFBRSxPQUFPLFVBQVUsRUFBRSxTQUFTLEVBQUUsT0FBTyxRQUFRLEdBQUcsNERBQTRELENBQ2xIO0FBQUE7QUFHRixTQUFTLFVBQVUsQ0FBQyxNQUFZLEdBQVMsT0FBOEU7QUFBQSxFQUNySCxNQUFNLE9BQU8sVUFBVSxFQUFFO0FBQUEsRUFDekIsTUFBTSxRQUFRLENBQUMsTUFBYTtBQUFBLElBQzFCLEVBQUUsUUFBUyxFQUFFLE9BQTRCO0FBQUEsSUFDdkMsU0FBUyxJQUFJO0FBQUE7QUFBQSxFQUVqQixJQUFJLEVBQUUsU0FBUyxTQUFTO0FBQUEsSUFDdEIsT0FBTyxNQUNMLFVBQ0EsRUFDRSxVQUNBO0FBQUEsTUFDRSxPQUFPO0FBQUEsTUFDUCxVQUFVLENBQUMsTUFBYTtBQUFBLFFBQ3RCLEVBQUUsUUFBUyxFQUFFLE9BQTZCO0FBQUEsUUFDbkMsUUFBUSxJQUFJO0FBQUE7QUFBQSxJQUV2QixHQUNBLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxVQUFVLEVBQUUsVUFBVSxRQUFRLEdBQUcsV0FBVyxHQUN6RSxFQUFFLFVBQVUsRUFBRSxPQUFPLFNBQVMsVUFBVSxFQUFFLFVBQVUsUUFBUSxHQUFHLGNBQWMsQ0FDL0UsQ0FDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE1BQU0sU0FBNEMsRUFBRSxVQUFVLE9BQU8sTUFBTSxTQUFTLFFBQVEsa0JBQWtCLE9BQU8sU0FBUyxNQUFNLGdCQUFnQixZQUFZLGlCQUFpQjtBQUFBLEVBQ2pMLE1BQU0sUUFBUSxFQUFFLFNBQVM7QUFBQSxJQUN2QixPQUFPLGNBQWMsRUFBRSxTQUFTLGFBQWEsVUFBVTtBQUFBLElBQ3ZELE1BQU0sRUFBRSxTQUFTLGFBQWEsRUFBRSxTQUFTLFNBQVMsV0FBVztBQUFBLElBQzdELE9BQU8sRUFBRSxTQUFTO0FBQUEsSUFDbEIsYUFBYSxLQUFLLGFBQWE7QUFBQSxJQUMvQixNQUFNLEVBQUUsU0FBUyxVQUFVLFNBQVM7QUFBQSxJQUNwQyxVQUFVLE9BQU8sRUFBRTtBQUFBLElBQ25CLFNBQVM7QUFBQSxFQUNYLENBQUM7QUFBQSxFQUNELE9BQU8sTUFDTCxPQUFPLEVBQUUsU0FBUyxTQUNsQixFQUNFLE9BQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsRUFBRSxTQUFTLFNBQVMsRUFBRSxZQUFZLEVBQUUsT0FBTyxpQkFBaUIsTUFBTSxHQUFHLE9BQU8sRUFBRSxTQUFTLElBQUksVUFBVSxPQUFPLEVBQUUsTUFBTSxhQUFhLEtBQUssV0FBVyxTQUFTLE9BQU8sT0FBTyxFQUFFLFNBQVMsZ0NBQWdDLFVBQVUsQ0FBQyxJQUFJLE9BQ2xPLEVBQUUsU0FBUyxVQUNULEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsT0FBTyxFQUFFLFNBQVMsa0NBQWtDO0FBQUEsSUFDcEQsU0FBUyxNQUFNO0FBQUEsTUFDYixFQUFFLFNBQVMsQ0FBQyxFQUFFLFVBQVU7QUFBQSxNQUNqQixRQUFRLElBQUk7QUFBQTtBQUFBLEVBRXZCLEdBQ0EsRUFBRSxTQUFTLGlCQUFPLGNBQ3BCLENBQ0osR0FDQSxFQUFFLFNBQVMsWUFBWSxDQUFDLENBQUMsRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLE9BQU8sUUFBUSxHQUFHLG1CQUFtQixFQUFFLGFBQWEsR0FDMUcsRUFBRSxTQUFTLFdBQVcsRUFBRSxZQUFZLEVBQUUsSUFBSSxPQUFPLEdBQUcsQ0FBQyxTQUFTLE9BQU8sVUFBVSxhQUFhLFdBQVcsYUFBYSxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQ2hLO0FBQUE7QUFHRixTQUFTLFdBQVcsQ0FBQyxNQUFZO0FBQUEsRUFDL0IsT0FBTyxFQUNMLFdBQ0EsRUFBRSxPQUFPLGdCQUFnQixHQUN6QixFQUFFLFdBQVcsRUFBRSxPQUFPLGVBQWUsR0FBRyxlQUFlLEdBQ3ZELEVBQ0UsT0FDQSxFQUFFLE9BQU8sWUFBWSxHQUNyQixNQUFNLElBQUksQ0FBQyxNQUNULEVBQ0UsVUFDQTtBQUFBLElBQ0UsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNwQixFQUFFLE9BQXVCLFFBQVEsU0FBUyxFQUFHLE9BQU87QUFBQSxNQUNyRCxNQUFNLE9BQVMsUUFBUSxNQUFNLENBQUM7QUFBQSxNQUM5QixXQUFXLE1BQU0sU0FBUyxjQUFjLGVBQWUsS0FBSyxNQUFNLEdBQUcsZUFBZSxFQUFFLE9BQU8sVUFBVSxVQUFVLFNBQVMsQ0FBQyxHQUFHLEVBQUU7QUFBQTtBQUFBLEVBRXBJLEdBQ0EsR0FBRyxVQUFVLEdBQUcsU0FBUyxVQUFVLEdBQUcsT0FDeEMsQ0FDRixDQUNGLENBQ0Y7QUFBQTs7O0FDaG1CSyxTQUFTLFdBQVcsR0FBZ0I7QUFBQSxFQUN6QyxNQUFNLFFBQVUsY0FBYztBQUFBLEVBQzlCLE1BQU0sVUFBWSxXQUFXO0FBQUEsRUFDN0IsTUFBTSxPQUFTLFFBQVE7QUFBQSxFQUN2QixNQUFNLE1BQU0sQ0FBQyxHQUFHLE1BQU0sUUFBUSxFQUFFLE9BQU8sQ0FBQyxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxDQUFDO0FBQUEsRUFFbkYsTUFBTSxTQUFTLElBQUk7QUFBQSxFQUNuQixXQUFXLEtBQUssT0FBTztBQUFBLElBQ3JCLE1BQU0sSUFBSSxFQUFFLFVBQVU7QUFBQSxJQUN0QixJQUFJLENBQUMsT0FBTyxJQUFJLENBQUM7QUFBQSxNQUFHLE9BQU8sSUFBSSxHQUFHLENBQUMsQ0FBQztBQUFBLElBQ3BDLE9BQU8sSUFBSSxDQUFDLEVBQUcsS0FBSyxDQUFDO0FBQUEsRUFDdkI7QUFBQSxFQUNBLE1BQU0sWUFBWSxDQUFDLEdBQUcsT0FBTyxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsR0FBRyxNQUFPLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUU7QUFBQSxFQUV2RyxPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sT0FBTyxHQUNoQixFQUNFLFVBQ0EsRUFBRSxPQUFPLE1BQU0sR0FDZixFQUFFLE9BQU8sRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLE9BQU8sQ0FBQyxHQUFHLFFBQVEsR0FDbkUsRUFDRSxPQUNBLEVBQUUsT0FBTyxNQUFNLEdBQ2YsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sWUFBWSxTQUFTLFdBQVcsR0FBRyxHQUFHLEdBQzFFLEVBQUUsVUFBVSxFQUFFLE9BQU8sUUFBUSxPQUFPLGlCQUFpQixTQUFTLE1BQVEsWUFBWSxNQUFNLEtBQUssRUFBRSxHQUFHLEdBQUcsR0FDckcsRUFBRSxVQUFVLEVBQUUsT0FBTyxRQUFRLE9BQU8sV0FBVyxTQUFTLE9BQVEsTUFBTSxPQUFPLFlBQWUsT0FBTyxHQUFHLEdBQUcsR0FBRyxDQUM5RyxDQUNGLEdBQ0EsRUFDRSxPQUNBLEVBQUUsT0FBTyxVQUFVLEdBQ25CLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sYUFBYTtBQUFBLElBQ2IsT0FBTyxNQUFNLE9BQU87QUFBQSxJQUNwQixVQUFVO0FBQUEsSUFDVixTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLE1BQU0sT0FBTyxJQUFLLEVBQUUsT0FBNEI7QUFBQSxNQUM5QyxPQUFPO0FBQUE7QUFBQSxFQUViLENBQUMsR0FDRCxFQUFFLFVBQVUsRUFBRSxPQUFPLGVBQWUsU0FBVyxXQUFXLEdBQUcsU0FBUyxDQUN4RSxJQUNDLFFBQVEsU0FBUyxLQUFLLEtBQUssU0FBUyxNQUNuQyxFQUNFLE9BQ0EsRUFBRSxPQUFPLFVBQVUsR0FDbkIsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3RCLE1BQU0sT0FBTyxTQUFVLEVBQUUsT0FBNkI7QUFBQSxNQUNwRCxPQUFPO0FBQUE7QUFBQSxFQUViLEdBQ0EsRUFBRSxVQUFVLEVBQUUsT0FBTyxJQUFJLFVBQVUsTUFBTSxPQUFPLFdBQVcsR0FBRyxHQUFHLG9CQUFvQixHQUNyRixFQUFFLFVBQVUsRUFBRSxPQUFPLFVBQVUsVUFBVSxNQUFNLE9BQU8sV0FBVyxTQUFTLEdBQUcsYUFBYSxHQUMxRixRQUFRLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sR0FBRyxVQUFVLE1BQU0sT0FBTyxXQUFXLEVBQUUsR0FBRyxrQkFBUSxDQUFDLENBQUMsQ0FDOUYsR0FDQSxFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFVBQVUsQ0FBQyxNQUFhO0FBQUEsTUFDdEIsTUFBTSxPQUFPLE9BQVEsRUFBRSxPQUE2QjtBQUFBLE1BQ2xELE9BQU87QUFBQTtBQUFBLEVBRWIsR0FDQSxFQUFFLFVBQVUsRUFBRSxPQUFPLFdBQVcsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVLEdBQUcsV0FBVyxHQUN4RixFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsVUFBVSxNQUFNLE9BQU8sU0FBUyxPQUFPLEdBQUcsUUFBUSxHQUMvRSxFQUFFLFVBQVUsRUFBRSxPQUFPLFdBQVcsVUFBVSxNQUFNLE9BQU8sU0FBUyxVQUFVLEdBQUcsa0JBQWtCLENBQ2pHLEdBQ0EsS0FBSyxTQUFTLEtBQ1osRUFDRSxPQUNBLEVBQUUsT0FBTyxRQUFRLEdBQ2pCLEtBQUssSUFBSSxDQUFDLE1BQ1IsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPLFVBQVUsTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksUUFBUTtBQUFBLElBQ3BELFNBQVMsTUFBTTtBQUFBLE1BQ2IsTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksTUFBTSxPQUFPLEtBQUssT0FBTyxDQUFDLElBQUksTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDOUUsT0FBTztBQUFBO0FBQUEsRUFFYixHQUNBLE1BQU0sQ0FDUixDQUNGLENBQ0YsQ0FDSixHQUNGLElBQUksU0FBUyxLQUNYLEVBQ0UsT0FDQSxFQUFFLE9BQU8sT0FBTyxHQUNoQixFQUFFLFFBQVEsTUFBTSxHQUFHLElBQUksd0JBQXdCLEdBQy9DLEVBQUUsVUFBVSxFQUFFLE9BQU8sVUFBVSxTQUFTLE1BQVEsWUFBWSxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sSUFBSSxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxHQUFHLFVBQVUsR0FDeEgsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLFNBQVMsTUFBUSxTQUFTLEdBQUcsRUFBRSxHQUFHLE9BQU8sR0FDeEUsRUFBRSxVQUFVLEVBQUUsT0FBTyxVQUFVLFNBQVMsTUFBUSxRQUFRLEdBQUcsRUFBRSxHQUFHLFdBQVcsR0FDM0UsRUFBRSxVQUFVLEVBQUUsT0FBTyxpQkFBaUIsU0FBUyxNQUFRLFlBQVksR0FBRyxFQUFFLEdBQUcsUUFBUSxHQUNuRixFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsT0FBTyxvQkFBb0IsU0FBUyxPQUFPLE1BQU0sU0FBUyxNQUFNLEdBQUssT0FBTyxHQUFHLEdBQUcsR0FBRyxDQUNwSCxHQUNGLEVBQ0UsUUFDQSxFQUFFLE9BQU8sVUFBVSxlQUFlLFVBQVUsR0FDNUMsTUFBTSxNQUFNLFdBQVcsSUFDbkIsV0FBVyxJQUNYLE1BQU0sV0FBVyxJQUNmLEVBQUUsS0FBSyxFQUFFLE9BQU8sY0FBYyxHQUFHLHNDQUFzQyxJQUN2RSxVQUFVLElBQUksQ0FBQyxNQUFNLFlBQVksR0FBRyxPQUFPLElBQUksQ0FBQyxHQUFJLFVBQVUsU0FBUyxLQUFLLE1BQU0sRUFBRSxDQUFDLENBQzdGLENBQ0Y7QUFBQTtBQUdGLFNBQVMsV0FBVyxDQUFDLE1BQWMsT0FBZSxZQUFxQjtBQUFBLEVBQ3JFLE1BQU0sTUFBTSxRQUFRO0FBQUEsRUFDcEIsTUFBTSxZQUFZLE1BQU0saUJBQWlCLElBQUksR0FBRztBQUFBLEVBQ2hELE9BQU8sRUFDTCxXQUNBLEVBQUUsT0FBTyxRQUFRLEdBQ2pCLGNBQ0UsRUFDRSxVQUNBO0FBQUEsSUFDRSxPQUFPO0FBQUEsSUFDUCxTQUFTLE1BQU07QUFBQSxNQUNiLFlBQVksTUFBTSxpQkFBaUIsT0FBTyxHQUFHLElBQUksTUFBTSxpQkFBaUIsSUFBSSxHQUFHO0FBQUEsTUFDN0UsT0FBTztBQUFBO0FBQUEsRUFFYixHQUNBLEVBQUUsUUFBUSxFQUFFLE9BQU8sV0FBVyxZQUFZLEtBQUssU0FBUyxHQUFHLEdBQUcsR0FDOUQsT0FBTyxrQkFBUSxPQUFPLGVBQ3RCLEVBQUUsUUFBUSxFQUFFLE9BQU8sUUFBUSxHQUFHLE9BQU8sTUFBTSxNQUFNLENBQUMsQ0FDcEQsR0FDRixDQUFDLGFBQWEsTUFBTSxJQUFJLFFBQVEsQ0FDbEM7QUFBQTtBQUdGLFNBQVMsUUFBUSxDQUFDLEdBQVM7QUFBQSxFQUN6QixNQUFNLE9BQU8sT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxTQUFTLFVBQVUsR0FBRyxLQUFLO0FBQUEsRUFDckUsTUFBTSxVQUFZLE9BQU8sV0FBVyxNQUFNLEtBQUssV0FBVyxFQUFFO0FBQUEsRUFDNUQsT0FBTyxFQUNMLFdBQ0EsRUFBRSxPQUFPLFVBQVUsTUFBTSxTQUFTLElBQUksRUFBRSxFQUFFLElBQUksY0FBYyxJQUFJLEdBQ2hFLEVBQUUsU0FBUztBQUFBLElBQ1QsTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLElBQ1AsU0FBUyxNQUFNLFNBQVMsSUFBSSxFQUFFLEVBQUU7QUFBQSxJQUNoQyxPQUFPO0FBQUEsSUFDUCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3JCLEVBQUUsT0FBNEIsVUFBVSxNQUFNLFNBQVMsSUFBSSxFQUFFLEVBQUUsSUFBSSxNQUFNLFNBQVMsT0FBTyxFQUFFLEVBQUU7QUFBQSxNQUM1RixPQUFPO0FBQUE7QUFBQSxFQUViLENBQUMsR0FDRCxFQUNFLE9BQ0EsRUFBRSxPQUFPLGFBQWEsU0FBUyxNQUFRLFNBQVMsRUFBRSxFQUFFLEVBQUUsR0FDdEQsRUFBRSxPQUFPLEVBQUUsT0FBTyxhQUFhLEdBQUcsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLE9BQU8sVUFBVSxFQUFFLFFBQVEsS0FBSyxPQUFPLFFBQVEsT0FBTyxZQUFZLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQzFJLEVBQ0UsT0FDQSxFQUFFLE9BQU8sT0FBTyxHQUNoQixHQUFHLEVBQUUsTUFBTSxjQUFjLEVBQUUsTUFBTSxXQUFXLElBQUksS0FBSyxPQUNyRCxRQUFRLE1BQU0sUUFDZCxNQUFNLFFBQVEsRUFBRSxTQUFTLEdBQzNCLEdBQ0EsRUFBRSxLQUFLLFNBQVMsS0FBSyxFQUFFLE9BQU8sRUFBRSxPQUFPLFFBQVEsR0FBRyxFQUFFLEtBQUssSUFBSSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxjQUFjLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUNuSCxHQUNBLEVBQ0UsT0FDQSxFQUFFLE9BQU8sZUFBZSxHQUN4QixFQUNFLFVBQ0EsRUFBRSxPQUFPLGFBQWEsT0FBTyxtQ0FBbUMsVUFBWSxPQUFPLFNBQVMsU0FBUyxNQUFRLEtBQUssQ0FBQyxFQUFFLEdBQ3JILFVBQVUsTUFBTSxHQUNsQixHQUNBLEVBQ0UsV0FDQSxFQUFFLE9BQU8sT0FBTyxHQUNoQixFQUFFLFdBQVcsRUFBRSxPQUFPLFFBQVEsT0FBTyxNQUFNLEdBQUcsR0FBRyxHQUNqRCxFQUNFLE9BQ0EsRUFBRSxPQUFPLFlBQVksR0FDckIsRUFBRSxVQUFVLEVBQUUsU0FBUyxNQUFRLGNBQWMsQ0FBQyxFQUFFLEdBQUcsWUFBWSxHQUMvRCxFQUFFLFVBQVUsRUFBRSxTQUFTLE1BQVEsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsaUJBQWlCLEdBQ3BFLEVBQUUsVUFBVSxFQUFFLFNBQVMsTUFBUSxnQkFBZ0IsQ0FBQyxFQUFFLEdBQUcsd0JBQXdCLEdBQzdFLEVBQUUsVUFBVSxFQUFFLFNBQVMsTUFBUSxlQUFlLENBQUMsRUFBRSxHQUFHLGdDQUFnQyxHQUNwRixFQUFFLFVBQVUsRUFBRSxPQUFPLFVBQVUsU0FBUyxNQUFRLFlBQVksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLEdBQUcscUJBQVcsQ0FDcEYsQ0FDRixDQUNGLENBQ0Y7QUFBQTtBQUdGLFNBQVMsV0FBVyxDQUFDLEdBQVM7QUFBQSxFQUM1QixNQUFNLElBQUksRUFBRTtBQUFBLEVBQ1osT0FBTyxFQUFFLEtBQUssTUFBTSxRQUFRLEVBQUUsRUFBRSxPQUFPLEVBQUUsS0FBSyxNQUFNLFFBQVEsQ0FBQyxRQUFRLFNBQVMsUUFBUSxFQUFFLEVBQUUsTUFBTSxFQUFFO0FBQUE7QUFHcEcsU0FBUyxVQUFVLEdBQUc7QUFBQSxFQUNwQixPQUFPLEVBQ0wsT0FDQSxFQUFFLE9BQU8sUUFBUSxHQUNqQixFQUFFLE9BQU8sRUFBRSxPQUFPLFlBQVksR0FBRyxXQUFXLEdBQzVDLEVBQUUsTUFBTSxNQUFNLHVCQUF1QixHQUNyQyxFQUNFLE1BQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsRUFBRSxNQUFNLE1BQU0sc0RBQXNELEdBQ3BFLEVBQUUsTUFBTSxNQUFNLFVBQVUsRUFBRSxLQUFLLE1BQU0sUUFBUSxHQUFHLGtIQUFrSCxHQUNsSyxFQUFFLE1BQU0sTUFBTSw2QkFBNkIsRUFBRSxLQUFLLE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FDNUUsR0FDQSxFQUFFLE9BQU8sRUFBRSxPQUFPLGFBQWEsR0FBRyxFQUFFLFVBQVUsRUFBRSxPQUFPLGVBQWUsU0FBVyxXQUFXLEdBQUcsZUFBZSxHQUFHLEVBQUUsVUFBVSxFQUFFLE9BQU8sT0FBTyxTQUFTLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FDakw7QUFBQTtBQUdGLGVBQWUsVUFBVSxHQUFHO0FBQUEsRUFDMUIsTUFBTSxPQUFPLE1BQU0sU0FBUztBQUFBLEVBQzVCLElBQUk7QUFBQSxJQUFNLE1BQVEsV0FBVyxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQUE7OztBQzNOekMsU0FBUyxZQUFZLEdBQWdCO0FBQUEsRUFDMUMsTUFBTSxJQUFJLE1BQU07QUFBQSxFQUNoQixNQUFNLE1BQU0sQ0FBMkIsR0FBTSxNQUFtQjtBQUFBLElBQzlELEVBQUUsS0FBSztBQUFBLElBQ0YsYUFBYSxDQUFDO0FBQUE7QUFBQSxFQUVyQixNQUFNLE1BQU0sQ0FBQyxHQUF5QyxPQUFlLFNBQ25FLEVBQ0UsU0FDQSxFQUFFLE9BQU8sUUFBUSxHQUNqQixFQUFFLFFBQVEsTUFBTSxLQUFLLEdBQ3JCLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sS0FBSztBQUFBLElBQ0wsTUFBTSxNQUFNLGFBQWEsSUFBSTtBQUFBLElBQzdCLE9BQU8sRUFBRTtBQUFBLElBQ1QsVUFBVSxTQUFTO0FBQUEsSUFDbkIsU0FBUyxDQUFDLE1BQWE7QUFBQSxNQUNyQixNQUFNLElBQUssRUFBRSxPQUE0QjtBQUFBLE1BQ3pDLElBQUksT0FBTyxTQUFTLENBQUMsS0FBSyxLQUFLO0FBQUEsUUFBRyxJQUFJLEdBQUcsQ0FBQztBQUFBO0FBQUEsRUFFOUMsQ0FBQyxHQUNELEVBQUUsU0FBUyxFQUFFLE9BQU8sUUFBUSxHQUFHLElBQUksQ0FDckM7QUFBQSxFQUVGLE9BQU8sRUFDTCxPQUNBLEVBQUUsT0FBTyxPQUFPLEdBQ2hCLEVBQ0UsVUFDQSxFQUFFLE9BQU8sTUFBTSxHQUNmLEVBQUUsVUFBVSxFQUFFLE9BQU8sZ0JBQWdCLFNBQVMsT0FBUSxNQUFNLE9BQU8sV0FBYyxPQUFPLEdBQUcsR0FBRyxVQUFVLEdBQ3hHLEVBQUUsS0FBSyxNQUFNLFNBQVMsQ0FDeEIsR0FDQSxFQUNFLFFBQ0EsRUFBRSxPQUFPLG1CQUFtQixlQUFlLFdBQVcsR0FDdEQsRUFBRSxNQUFNLE1BQU0sY0FBYyxHQUM1QixJQUFJLFdBQVcseUJBQXlCLDREQUE0RCxHQUNwRyxJQUFJLGFBQWEsMEJBQTBCLCtDQUErQyxHQUMxRixFQUNFLFNBQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsRUFBRSxRQUFRLE1BQU0sbUJBQW1CLEdBQ25DLEVBQ0UsVUFDQTtBQUFBLElBQ0UsT0FBTztBQUFBLElBQ1AsVUFBVSxDQUFDLE1BQWE7QUFBQSxNQUN0QixJQUFJLFlBQWEsRUFBRSxPQUE2QixLQUE2QjtBQUFBLE1BQzNFLE9BQU87QUFBQTtBQUFBLEVBRWIsR0FDQSxFQUFFLFVBQVUsRUFBRSxPQUFPLFdBQVcsVUFBVSxFQUFFLGFBQWEsVUFBVSxHQUFHLG1CQUFtQixHQUN6RixFQUFFLFVBQVUsRUFBRSxPQUFPLFFBQVEsVUFBVSxFQUFFLGFBQWEsT0FBTyxHQUFHLDBCQUEwQixDQUM1RixHQUNBLEVBQUUsU0FBUyxFQUFFLE9BQU8sUUFBUSxHQUFHLDRFQUE0RSxDQUM3RyxHQUNBLEVBQUUsYUFBYSxVQUFVLElBQUksWUFBWSwyQkFBMkIsRUFBRSxHQUN0RSxFQUNFLFNBQ0EsRUFBRSxPQUFPLFNBQVMsR0FDbEIsRUFBRSxTQUFTLEVBQUUsTUFBTSxZQUFZLFNBQVMsRUFBRSxXQUFXLFVBQVUsQ0FBQyxNQUFhLElBQUksYUFBYyxFQUFFLE9BQTRCLE9BQU8sRUFBRSxDQUFDLEdBQ3ZJLHdDQUNGLEdBQ0EsRUFDRSxTQUNBLEVBQUUsT0FBTyxTQUFTLEdBQ2xCLEVBQUUsU0FBUztBQUFBLElBQ1QsTUFBTTtBQUFBLElBQ04sU0FBUyxFQUFFO0FBQUEsSUFDWCxVQUFVLENBQUMsTUFBYTtBQUFBLE1BQ3RCLElBQUksWUFBYSxFQUFFLE9BQTRCLE9BQU87QUFBQSxNQUNwRCxPQUFPO0FBQUE7QUFBQSxFQUViLENBQUMsR0FDRCxnRUFDRixHQUNBLEVBQ0UsU0FDQSxFQUFFLE9BQU8sUUFBUSxHQUNqQixzSUFDRixHQUNBLEVBQUUsWUFDQSxFQUNFLFNBQ0EsRUFBRSxPQUFPLFFBQVEsR0FDakIsRUFBRSxRQUFRLE1BQU0sNkJBQTZCLEdBQzdDLEVBQUUsU0FBUztBQUFBLElBQ1QsT0FBTztBQUFBLElBQ1AsTUFBTTtBQUFBLElBQ04sYUFBYTtBQUFBLElBQ2IsT0FBTyxFQUFFO0FBQUEsSUFDVCxTQUFTLENBQUMsTUFBYTtBQUFBLE1BQ3JCLE1BQU0sTUFBTSxFQUFFO0FBQUEsTUFDZCxJQUFJLEtBQUs7QUFBQSxNQUNULElBQUk7QUFBQSxRQUNGLElBQUksSUFBSSxNQUFNLEtBQUs7QUFBQSxVQUFHLFNBQVMsY0FBYyxJQUFJLEtBQUs7QUFBQSxRQUN0RCxNQUFNO0FBQUEsUUFDTixLQUFLO0FBQUE7QUFBQSxNQUVQLElBQUksa0JBQWtCLEtBQUssS0FBSyx3QkFBd0I7QUFBQSxNQUN4RCxJQUFJLGVBQWU7QUFBQSxNQUNuQixJQUFJO0FBQUEsUUFBSSxJQUFJLGtCQUFrQixJQUFJLEtBQUs7QUFBQTtBQUFBLEVBRTNDLENBQUMsR0FDRCxFQUFFLFNBQVMsRUFBRSxPQUFPLFFBQVEsR0FBRyw0SEFBNEgsQ0FDN0osR0FDRixFQUNFLE9BQ0EsRUFBRSxPQUFPLE1BQU0sR0FDZixFQUNFLFVBQ0E7QUFBQSxJQUNFLE9BQU87QUFBQSxJQUNQLFNBQVMsTUFBTTtBQUFBLE1BQ2IsTUFBTSxXQUFXLEtBQUssaUJBQWlCO0FBQUEsTUFDbEMsYUFBYSxNQUFNLFFBQVE7QUFBQSxNQUM5QixPQUFPO0FBQUEsTUFDVCxNQUFNLHlCQUF5QixJQUFJO0FBQUE7QUFBQSxFQUV2QyxHQUNBLGFBQ0YsQ0FDRixHQUNBLEVBQUUsTUFBTSxNQUFNLFlBQVksR0FDMUIsRUFDRSxLQUNBLEVBQUUsT0FBTyxjQUFjLEdBQ3ZCLHdIQUNBLEVBQUUsUUFBUSxNQUFNLGFBQWEsR0FDN0IsTUFDQSxFQUFFLFFBQVEsTUFBTSxLQUFLLEdBQ3JCLGNBQ0EsRUFBRSxRQUFRLE1BQU0sTUFBTSxHQUN0QixNQUNBLEVBQUUsUUFBUSxNQUFNLFNBQVMsR0FDekIsTUFDQSxFQUFFLFFBQVEsTUFBTSxZQUFZLEdBQzVCLE1BQ0EsRUFBRSxRQUFRLE1BQU0sYUFBYSxHQUM3QixNQUNBLEVBQUUsUUFBUSxNQUFNLFFBQVEsR0FDeEIsdUZBQ0EsRUFBRSxRQUFRLE1BQU0sYUFBYSxHQUM3QixpREFDRixHQUNBLEVBQUUsTUFBTSxNQUFNLE9BQU8sR0FDckIsRUFBRSxLQUFLLEVBQUUsT0FBTyxjQUFjLEdBQUcsR0FBRyxNQUFNLE1BQU0sb0JBQW9CLE1BQU0sTUFBTSxPQUFPLENBQUMsR0FBRyxNQUFNLElBQUksRUFBRSxNQUFNLFFBQVEsQ0FBQyxzRkFBc0YsQ0FDOU0sQ0FDRjtBQUFBOzs7QUN0SkYsSUFBTSxNQUFNLFNBQVMsZUFBZSxLQUFLO0FBRXpDLElBQUksWUFBWTtBQUNoQixVQUFVLE1BQU07QUFBQSxFQUVkLElBQUk7QUFBQSxJQUFXO0FBQUEsRUFDZixZQUFZO0FBQUEsRUFDWixlQUFlLE1BQU07QUFBQSxJQUNuQixZQUFZO0FBQUEsSUFDWixNQUFNLE9BQU8sUUFBUTtBQUFBLElBQ3JCLElBQUksTUFBTSxTQUFTLFlBQVksQ0FBQztBQUFBLE1BQU0sTUFBTSxPQUFPO0FBQUEsSUFDbkQsTUFBTSxPQUFPLE1BQU0sU0FBUyxXQUFXLFdBQVcsSUFBSyxJQUFJLE1BQU0sU0FBUyxhQUFhLGFBQWEsSUFBSSxZQUFZO0FBQUEsSUFDcEgsTUFBTSxLQUFLLElBQUk7QUFBQSxHQUNoQjtBQUFBLENBQ0Y7QUFFRCxlQUFlLElBQUksR0FBRztBQUFBLEVBQ3BCLENBQUMsTUFBTSxPQUFPLE1BQU0sVUFBVSxNQUFNLFNBQVMsSUFBSSxNQUFNLFFBQVEsSUFBSSxDQUFPLFVBQVUsR0FBUyxZQUFZLEdBQVMsYUFBYSxDQUFDLENBQUM7QUFBQSxFQUNqSSxPQUFPO0FBQUEsRUFFUCxPQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUyxTQUFTO0FBQUEsSUFDdEQsSUFBSSxRQUFRO0FBQUEsSUFDWixJQUFJLFdBQVc7QUFBQSxJQUNmLElBQUksU0FBUyxTQUFTO0FBQUEsTUFDcEIsWUFBWSxLQUFLLGVBQWUsT0FBTyxRQUFRLE9BQU8sR0FBRztBQUFBLFFBQ3ZELElBQVUsVUFBVSxDQUFDLEdBQUc7QUFBQSxVQUN0QixNQUFNLEtBQUssRUFBRSxNQUFNLENBQUM7QUFBQSxVQUNwQixNQUFNLElBQUksTUFBTSxNQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFO0FBQUEsVUFDbEQsSUFBSSxDQUFDLFVBQVU7QUFBQSxZQUNiLElBQUksS0FBSztBQUFBLGNBQUcsTUFBTSxNQUFNLE9BQU8sR0FBRyxDQUFDO0FBQUEsVUFDckMsRUFBTyxTQUFJLEtBQUssR0FBRztBQUFBLFlBQ2pCLGFBQWEsU0FBUyxNQUFNLFNBQVMsTUFBTSxNQUFNLEdBQUksTUFBTTtBQUFBLFlBQzNELE1BQU0sTUFBTSxLQUFLO0FBQUEsVUFDbkIsRUFBTztBQUFBLGtCQUFNLE1BQU0sUUFBUSxRQUFRO0FBQUEsVUFDbkMsUUFBUTtBQUFBLFFBQ1YsRUFBTyxTQUFJLE1BQU0sWUFBWTtBQUFBLFVBQzNCLE1BQU0sV0FBVyxLQUFLLE1BQU0sYUFBYSxTQUFTO0FBQUEsUUFDcEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsSUFBSSxTQUFTLGFBQW1CLHlCQUF5QixTQUFTO0FBQUEsTUFDaEUsTUFBTSxZQUFZLFFBQWMsdUJBQXdCO0FBQUEsTUFDeEQsUUFBUTtBQUFBLElBQ1Y7QUFBQSxJQUNBLElBQUksQ0FBQztBQUFBLE1BQU87QUFBQSxJQUNaLE9BQU87QUFBQSxJQUVQLElBQUksWUFBWSxNQUFNLFdBQVcsV0FBVyxNQUFNLFdBQVc7QUFBQSxNQUMzRCxXQUFXLE1BQU07QUFBQSxRQUNmLE1BQU0sS0FBSyxTQUFTLGNBQWMsZUFBZTtBQUFBLFFBQ2pELElBQUksU0FBUyxFQUFFLEtBQUssR0FBRyxjQUFjLFVBQVUsU0FBUyxDQUFDO0FBQUEsU0FDeEQsRUFBRTtBQUFBLElBQ1A7QUFBQSxHQUNEO0FBQUE7QUFJSCxTQUFTLGlCQUFpQixTQUFTLENBQUMsTUFBTTtBQUFBLEVBQ3hDLFdBQVcsS0FBSyxTQUFTLGlCQUFxQyxvQkFBb0IsR0FBRztBQUFBLElBQ25GLElBQUksQ0FBQyxFQUFFLFNBQVMsRUFBRSxNQUFjO0FBQUEsTUFBRyxFQUFFLE9BQU87QUFBQSxFQUM5QztBQUFBLENBQ0Q7QUFHRCxTQUFTLGlCQUFpQixZQUFZLENBQUMsTUFBTTtBQUFBLEVBQzNDLElBQUksRUFBRSxjQUFjLE1BQU0sU0FBUyxPQUFPLEdBQUc7QUFBQSxJQUMzQyxFQUFFLGVBQWU7QUFBQSxJQUNqQixTQUFTLEtBQUssVUFBVSxJQUFJLFVBQVU7QUFBQSxFQUN4QztBQUFBLENBQ0Q7QUFDRCxTQUFTLGlCQUFpQixhQUFhLENBQUMsTUFBTTtBQUFBLEVBQzVDLElBQUksQ0FBQyxFQUFFO0FBQUEsSUFBZSxTQUFTLEtBQUssVUFBVSxPQUFPLFVBQVU7QUFBQSxDQUNoRTtBQUNELFNBQVMsaUJBQWlCLFFBQVEsT0FBTyxNQUFNO0FBQUEsRUFDN0MsTUFBTSxPQUFPLEVBQUUsY0FBYyxRQUFRO0FBQUEsRUFDckMsU0FBUyxLQUFLLFVBQVUsT0FBTyxVQUFVO0FBQUEsRUFDekMsSUFBSSxDQUFDO0FBQUEsSUFBTTtBQUFBLEVBQ1gsRUFBRSxlQUFlO0FBQUEsRUFDakIsTUFBTSxXQUFXLE1BQU0sS0FBSyxLQUFLLENBQUM7QUFBQSxDQUNuQztBQUVJLEtBQUs7IiwKICAiZGVidWdJZCI6ICJBOEZCNkQ2RTgyMjcxMUFCNjQ3NTZFMjE2NDc1NkUyMSIsCiAgIm5hbWVzIjogW10KfQ==
